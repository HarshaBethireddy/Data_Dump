package com.harsha.automation.enums;

import lombok.Getter;

/**
 * Enum representing different application categories with their navigation paths.
 */
@Getter
public enum Category {
    /**
     * Acquisition category
     */
    ACQ("ACQ", new String[]{"View Only", "Credit Full", "All"}),

    /**
     * Credit Line Increase category
     */
    CLI("CLI", new String[]{"View Only", "CLI Credit Full", "All"}),

    /**
     * Pre-Qualification category
     */
    PRQ("PRQ", new String[]{"View Only", "PreQual Credit Full", "All"}),

    /**
     * Unknown category (default)
     */
    UNKNOWN("UNKNOWN", new String[]{});

    private final String categoryName;
    private final String[] menuPath;

    /**
     * Constructor for Category enum.
     *
     * @param categoryName Name of the category
     * @param menuPath     Navigation menu path for this category
     */
    Category(String categoryName, String[] menuPath) {
        this.categoryName = categoryName;
        this.menuPath = menuPath;
    }

    /**
     * Determines category from filename.
     *
     * @param fileName File name to analyze
     * @return Corresponding Category
     */
    public static Category fromFileName(String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            return UNKNOWN;
        }

        String upperFileName = fileName.toUpperCase();

        if (upperFileName.contains("CLI")) {
            return CLI;
        }
        if (upperFileName.contains("PRQ") || upperFileName.contains("PREQUAL")) {
            return PRQ;
        }
        if (upperFileName.contains("ACQ")) {
            return ACQ;
        }

        return ACQ; // Default to ACQ
    }

    /**
     * Gets Category from string value.
     *
     * @param value String value to convert
     * @return Corresponding Category
     */
    public static Category fromString(String value) {
        if (value == null || value.trim().isEmpty()) {
            return UNKNOWN;
        }

        String upperValue = value.toUpperCase().trim();

        // Handle variations of PreQual
        if (upperValue.equals("PREQUAL") || upperValue.equals("PRE-QUAL")) {
            return PRQ;
        }

        for (Category category : Category.values()) {
            if (category.categoryName.equalsIgnoreCase(value)) {
                return category;
            }
        }

        return UNKNOWN;
    }

    /**
     * Checks if this is a valid category (not UNKNOWN).
     *
     * @return true if valid category, false otherwise
     */
    public boolean isValid() {
        return this != UNKNOWN;
    }
}
