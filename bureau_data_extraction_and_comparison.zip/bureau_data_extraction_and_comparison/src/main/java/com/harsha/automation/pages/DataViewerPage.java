package com.harsha.automation.pages;

import com.harsha.automation.core.base.BasePage;
import com.harsha.automation.enums.ExtractionType;
import com.harsha.automation.exceptions.DataExtractionException;
import com.harsha.automation.utils.FileUtils;
import com.harsha.automation.utils.JavaScriptUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Page Object for Bureau Data Viewer Page (popup window).
 * Handles extraction of bureau data from the viewer.
 */
public class DataViewerPage extends BasePage {

    @FindBy(css = ".jstree")
    private WebElement jsTreeElement;

    private String mainWindowHandle;
    private String popupWindowHandle;

    /**
     * Constructor initializes the page and switches to popup window.
     *
     * @param driver WebDriver instance
     */
    public DataViewerPage(WebDriver driver) {
        super(driver);
        switchToPopupWindow();
    }

    @Override
    public boolean isLoaded() {
        try {
            return isDisplayed(jsTreeElement);
        } catch (Exception e) {
            logger.debug("Data viewer page not loaded: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Switches to the bureau data viewer popup window.
     */
    private void switchToPopupWindow() {
        logger.debug("Switching to popup window");

        mainWindowHandle = driver.getWindowHandle();
        hardWait(2);

        Set<String> allWindows = getAllWindowHandles();
        for (String windowHandle : allWindows) {
            if (!windowHandle.equals(mainWindowHandle)) {
                popupWindowHandle = windowHandle;
                driver.switchTo().window(popupWindowHandle);
                logger.debug("Switched to popup window");
                break;
            }
        }

        if (popupWindowHandle == null) {
            throw new DataExtractionException("Bureau data viewer popup window not found");
        }

        hardWait(3);
    }

    /**
     * Extracts all bureau data and saves to file.
     *
     * @param applicationId Application ID
     * @param outputPath    Output file path
     * @param type          Extraction type (PRE or POST)
     * @return true if extraction successful, false otherwise
     */
    public boolean extractBureauData(String applicationId, String outputPath, ExtractionType type) {
        logger.info("Extracting {} bureau data for application: {}", type, applicationId);

        try {
            StringBuilder allBureauData = new StringBuilder();

            // Header
            allBureauData.append("===== BUREAU DATA EXTRACTION =====\n");
            allBureauData.append("Type: ").append(type.getTypeName()).append("\n");
            allBureauData.append("Application ID: ").append(applicationId).append("\n");
            allBureauData.append("Extraction Time: ").append(LocalDateTime.now()).append("\n");
            allBureauData.append("==================================\n\n");

            // Expand all jsTree nodes
            expandAllJsTreeNodes();

            // Find and process all request/response links
            List<WebElement> links = findRequestResponseLinks();
            logger.info("Found {} request/response links", links.size());

            for (int i = 0; i < links.size(); i++) {
                // Re-find links to avoid stale element exception
                links = findRequestResponseLinks();

                if (i < links.size()) {
                    WebElement link = links.get(i);
                    String bureauKey = link.getAttribute("bureaukey");
                    String linkType = link.getAttribute("type");

                    logger.debug("Processing: {} - {}", bureauKey, linkType);

                    allBureauData.append("\n").append("=".repeat(50)).append("\n");
                    allBureauData.append("Bureau: ").append(bureauKey != null ? bureauKey : "Unknown").append("\n");
                    allBureauData.append("Type: ").append(linkType != null ? linkType : "Unknown").append("\n");
                    allBureauData.append("=".repeat(50)).append("\n");

                    // Extract data from link
                    String content = extractDataFromLink(link);
                    allBureauData.append(content).append("\n");

                    hardWait(1);
                }
            }

            // Save to file
            FileUtils.writeToFile(outputPath, allBureauData.toString());
            logger.info("Bureau data saved to: {}", outputPath);

            // Close popup and return to main window
            closePopupAndReturnToMain();

            return true;

        } catch (Exception e) {
            logger.error("Bureau data extraction failed: {}", e.getMessage(), e);
            return false;
        }
    }

    /**
     * Expands all jsTree nodes.
     */
    private void expandAllJsTreeNodes() {
        logger.debug("Expanding all jsTree nodes");

        // Try using jsTree API first
        boolean success = JavaScriptUtils.expandAllJsTreeNodes(driver);

        if (success) {
            try {
                // Wait for loading to complete
                hardWait(2);
            } catch (Exception ignored) {
            }
            return;
        }

        // Manual expansion as fallback
        int maxAttempts = 50;
        int attempt = 0;

        while (attempt++ < maxAttempts) {
            List<WebElement> closedTogglers = driver.findElements(
                    By.cssSelector(".jstree li.jstree-closed > i.jstree-ocl, " +
                                  ".jstree li.jstree-closed > i.jstree-icon.jstree-ocl")
            );

            if (closedTogglers.isEmpty()) {
                break;
            }

            for (WebElement toggler : closedTogglers) {
                try {
                    JavaScriptUtils.scrollToElement(driver, toggler);
                    toggler.click();
                    Thread.sleep(150);
                } catch (Exception e) {
                    logger.debug("Failed to expand node: {}", e.getMessage());
                }
            }
        }

        logger.debug("jsTree nodes expanded");
    }

    /**
     * Finds all request/response links in the tree.
     *
     * @return List of request/response links
     */
    private List<WebElement> findRequestResponseLinks() {
        List<WebElement> links = new ArrayList<>();

        try {
            List<WebElement> rawLinks = driver.findElements(By.xpath("//a[@raw]"));

            for (WebElement link : rawLinks) {
                String type = link.getAttribute("type");
                if ("request".equals(type) || "response".equals(type)) {
                    links.add(link);
                }
            }
        } catch (Exception e) {
            logger.error("Error finding request/response links: {}", e.getMessage());
        }

        return links;
    }

    /**
     * Extracts data from a single link.
     *
     * @param link Link element to click
     * @return Extracted content
     */
    private String extractDataFromLink(WebElement link) {
        try {
            // Click link using JavaScript
            JavaScriptUtils.clickElement(driver, link);
            hardWait(2);

            // Find the new window
            Set<String> currentWindows = getAllWindowHandles();
            String dataWindow = null;

            for (String windowHandle : currentWindows) {
                if (!windowHandle.equals(mainWindowHandle) && !windowHandle.equals(popupWindowHandle)) {
                    dataWindow = windowHandle;
                    break;
                }
            }

            if (dataWindow != null) {
                driver.switchTo().window(dataWindow);

                // Extract content
                String content = "";
                try {
                    WebElement preElement = findElement(By.tagName("pre"));
                    content = preElement.getText();
                } catch (Exception e) {
                    // Try body text
                    content = driver.findElement(By.tagName("body")).getText();
                }

                // Close data window and return to popup
                driver.close();
                driver.switchTo().window(popupWindowHandle);

                return content;
            }

            return "";

        } catch (Exception e) {
            logger.error("Error extracting data from link: {}", e.getMessage());
            return "";
        }
    }

    /**
     * Closes popup window and returns to main window.
     */
    private void closePopupAndReturnToMain() {
        logger.debug("Closing popup and returning to main window");

        try {
            if (popupWindowHandle != null) {
                driver.close();
            }
            driver.switchTo().window(mainWindowHandle);
            logger.debug("Returned to main window");
        } catch (Exception e) {
            logger.error("Error closing popup: {}", e.getMessage());
        }
    }
}
