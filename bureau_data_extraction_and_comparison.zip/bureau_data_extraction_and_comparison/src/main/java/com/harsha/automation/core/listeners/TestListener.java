package com.harsha.automation.core.listeners;

import com.harsha.automation.config.TestConfiguration;
import com.harsha.automation.core.driver.DriverManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * TestNG Listener for test execution events.
 * Handles logging, screenshots, and test lifecycle events.
 */
public class TestListener implements ITestListener {
    private static final Logger logger = LogManager.getLogger(TestListener.class);
    private static final DateTimeFormatter TIMESTAMP_FORMATTER =
            DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");

    /**
     * Invoked when test suite starts.
     *
     * @param context Test context
     */
    @Override
    public void onStart(ITestContext context) {
        logger.info("========================================");
        logger.info("Test Suite Started: {}", context.getName());
        logger.info("========================================");
    }

    /**
     * Invoked when test suite finishes.
     *
     * @param context Test context
     */
    @Override
    public void onFinish(ITestContext context) {
        logger.info("========================================");
        logger.info("Test Suite Finished: {}", context.getName());
        logger.info("Total Tests: {}", context.getAllTestMethods().length);
        logger.info("Passed: {}", context.getPassedTests().size());
        logger.info("Failed: {}", context.getFailedTests().size());
        logger.info("Skipped: {}", context.getSkippedTests().size());
        logger.info("========================================");
    }

    /**
     * Invoked when test starts.
     *
     * @param result Test result
     */
    @Override
    public void onTestStart(ITestResult result) {
        logger.info(">>> Test Started: {}", result.getMethod().getMethodName());
        logger.info("Description: {}", result.getMethod().getDescription());
    }

    /**
     * Invoked when test succeeds.
     *
     * @param result Test result
     */
    @Override
    public void onTestSuccess(ITestResult result) {
        logger.info("✓ Test Passed: {}", result.getMethod().getMethodName());
        logger.info("Execution Time: {} ms", result.getEndMillis() - result.getStartMillis());

        // Capture screenshot on success if configured
        TestConfiguration config = new TestConfiguration();
        if (config.isCaptureScreenshotOnSuccess()) {
            captureScreenshot(result, "PASS");
        }
    }

    /**
     * Invoked when test fails.
     *
     * @param result Test result
     */
    @Override
    public void onTestFailure(ITestResult result) {
        logger.error("✗ Test Failed: {}", result.getMethod().getMethodName());
        logger.error("Failure Reason: {}", result.getThrowable().getMessage());
        logger.error("Execution Time: {} ms", result.getEndMillis() - result.getStartMillis());

        // Capture screenshot on failure
        TestConfiguration config = new TestConfiguration();
        if (config.isCaptureScreenshotOnFailure()) {
            captureScreenshot(result, "FAIL");
        }

        // Log stack trace
        if (result.getThrowable() != null) {
            logger.error("Stack Trace:", result.getThrowable());
        }
    }

    /**
     * Invoked when test is skipped.
     *
     * @param result Test result
     */
    @Override
    public void onTestSkipped(ITestResult result) {
        logger.warn("⊘ Test Skipped: {}", result.getMethod().getMethodName());
        if (result.getThrowable() != null) {
            logger.warn("Skip Reason: {}", result.getThrowable().getMessage());
        }
    }

    /**
     * Invoked when test fails but is within success percentage.
     *
     * @param result Test result
     */
    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        logger.warn("Test Failed but within success percentage: {}",
                result.getMethod().getMethodName());
    }

    /**
     * Captures screenshot and saves it to file.
     *
     * @param result Test result
     * @param status Test status (PASS/FAIL)
     */
    private void captureScreenshot(ITestResult result, String status) {
        try {
            DriverManager driverManager = DriverManager.getInstance();
            if (!driverManager.hasDriver()) {
                logger.warn("No WebDriver available for screenshot");
                return;
            }

            WebDriver driver = driverManager.getDriver();
            TakesScreenshot screenshot = (TakesScreenshot) driver;
            File srcFile = screenshot.getScreenshotAs(OutputType.FILE);

            String testName = result.getMethod().getMethodName();
            String timestamp = LocalDateTime.now().format(TIMESTAMP_FORMATTER);
            String fileName = String.format("%s_%s_%s.png", testName, status, timestamp);

            String screenshotDir = "screenshots";
            Files.createDirectories(Paths.get(screenshotDir));

            String destPath = screenshotDir + File.separator + fileName;
            Files.copy(srcFile.toPath(), Paths.get(destPath));

            logger.info("Screenshot captured: {}", destPath);

            // Attach to TestNG report
            result.setAttribute("screenshotPath", destPath);

        } catch (IOException e) {
            logger.error("Failed to capture screenshot: {}", e.getMessage());
        } catch (Exception e) {
            logger.error("Error during screenshot capture: {}", e.getMessage());
        }
    }
}
