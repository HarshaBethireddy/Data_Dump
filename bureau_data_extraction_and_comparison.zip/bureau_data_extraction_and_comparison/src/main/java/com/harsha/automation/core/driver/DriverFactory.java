package com.harsha.automation.core.driver;

import com.harsha.automation.config.TestConfiguration;
import com.harsha.automation.enums.BrowserType;
import com.harsha.automation.exceptions.DriverException;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

/**
 * Factory class for creating WebDriver instances based on browser type.
 * Implements Factory design pattern for WebDriver creation.
 */
public class DriverFactory {
    private static final Logger logger = LogManager.getLogger(DriverFactory.class);

    /**
     * Private constructor to prevent instantiation.
     */
    private DriverFactory() {
    }

    /**
     * Creates a new WebDriver instance based on the specified browser type.
     *
     * @param browserType Browser type to create
     * @param config      Test configuration
     * @return WebDriver instance
     * @throws DriverException if driver creation fails
     */
    public static WebDriver createDriver(BrowserType browserType, TestConfiguration config) {
        logger.info("Creating WebDriver for browser: {}", browserType);

        try {
            WebDriver driver;

            switch (browserType) {
                case CHROME:
                    driver = createChromeDriver(config);
                    break;

                case FIREFOX:
                    driver = createFirefoxDriver(config);
                    break;

                case EDGE:
                    driver = createEdgeDriver(config);
                    break;

                default:
                    throw new DriverException("Unsupported browser type: " + browserType);
            }

            configureDriver(driver, config);
            logger.info("WebDriver created successfully for: {}", browserType);
            return driver;

        } catch (Exception e) {
            logger.error("Failed to create WebDriver for {}: {}", browserType, e.getMessage(), e);
            throw new DriverException("Failed to create WebDriver for " + browserType, e);
        }
    }

    /**
     * Creates a Chrome WebDriver instance.
     *
     * @param config Test configuration
     * @return ChromeDriver instance
     */
    private static WebDriver createChromeDriver(TestConfiguration config) {
        logger.debug("Setting up ChromeDriver");
        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();

        if (config.isHeadless()) {
            options.addArguments("--headless");
            logger.debug("Chrome headless mode enabled");
        }

        if (config.isMaximized()) {
            options.addArguments("--start-maximized");
        }

        // Additional Chrome options for stability
        options.addArguments("--disable-blink-features=AutomationControlled");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-gpu");
        options.addArguments("--remote-allow-origins=*");

        // Disable automation flags
        options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
        options.setExperimentalOption("useAutomationExtension", false);

        return new ChromeDriver(options);
    }

    /**
     * Creates a Firefox WebDriver instance.
     *
     * @param config Test configuration
     * @return FirefoxDriver instance
     */
    private static WebDriver createFirefoxDriver(TestConfiguration config) {
        logger.debug("Setting up FirefoxDriver");
        WebDriverManager.firefoxdriver().setup();

        FirefoxOptions options = new FirefoxOptions();

        if (config.isHeadless()) {
            options.addArguments("--headless");
            logger.debug("Firefox headless mode enabled");
        }

        if (config.isMaximized()) {
            options.addArguments("--start-maximized");
        }

        return new FirefoxDriver(options);
    }

    /**
     * Creates an Edge WebDriver instance.
     *
     * @param config Test configuration
     * @return EdgeDriver instance
     */
    private static WebDriver createEdgeDriver(TestConfiguration config) {
        logger.debug("Setting up EdgeDriver");
        WebDriverManager.edgedriver().setup();

        EdgeOptions options = new EdgeOptions();

        if (config.isHeadless()) {
            options.addArguments("--headless");
            logger.debug("Edge headless mode enabled");
        }

        if (config.isMaximized()) {
            options.addArguments("--start-maximized");
        }

        // Additional Edge options for stability
        options.addArguments("--disable-blink-features=AutomationControlled");
        options.addArguments("--remote-allow-origins=*");

        return new EdgeDriver(options);
    }

    /**
     * Configures the WebDriver with timeouts and other settings.
     *
     * @param driver WebDriver to configure
     * @param config Test configuration
     */
    private static void configureDriver(WebDriver driver, TestConfiguration config) {
        logger.debug("Configuring WebDriver timeouts");

        // Set timeouts
        driver.manage().timeouts().implicitlyWait(config.getImplicitWait());
        driver.manage().timeouts().pageLoadTimeout(config.getPageLoadTimeout());
        driver.manage().timeouts().scriptTimeout(config.getScriptTimeout());

        // Maximize window if not in headless mode
        if (config.isMaximized() && !config.isHeadless()) {
            driver.manage().window().maximize();
            logger.debug("Browser window maximized");
        }

        logger.debug("WebDriver configuration complete");
    }
}
