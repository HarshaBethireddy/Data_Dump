package com.harsha.automation.models;

import lombok.*;

/**
 * Model class representing a bureau section in extracted data.
 * Contains information about bureau name, type, and line range.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class BureauSection {

    /**
     * Name of the bureau (e.g., Experian, Equifax, TransUnion)
     */
    private String bureauName;

    /**
     * Type of bureau data (e.g., request, response)
     */
    private String type;

    /**
     * Starting line number of this bureau section in the file
     */
    private int startLine;

    /**
     * Ending line number of this bureau section in the file
     */
    private int endLine;

    /**
     * Raw content of the bureau section
     */
    private String content;

    /**
     * Checks if a given line number falls within this bureau section.
     *
     * @param lineNumber Line number to check
     * @return true if line is within section, false otherwise
     */
    public boolean containsLine(int lineNumber) {
        return lineNumber >= startLine && lineNumber <= endLine;
    }

    /**
     * Gets the number of lines in this section.
     *
     * @return Line count
     */
    public int getLineCount() {
        return endLine - startLine + 1;
    }

    /**
     * Checks if this section is valid.
     *
     * @return true if bureau section has valid data, false otherwise
     */
    public boolean isValid() {
        return bureauName != null && !bureauName.trim().isEmpty() &&
               type != null && !type.trim().isEmpty() &&
               startLine >= 0 && endLine >= startLine;
    }

    /**
     * Gets a display name for this bureau section.
     *
     * @return Formatted display name
     */
    public String getDisplayName() {
        return String.format("%s - %s (Lines %d-%d)", bureauName, type, startLine, endLine);
    }
}
