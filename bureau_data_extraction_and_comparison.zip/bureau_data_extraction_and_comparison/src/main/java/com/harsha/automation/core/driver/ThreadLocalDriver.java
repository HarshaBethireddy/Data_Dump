package com.harsha.automation.core.driver;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

/**
 * Thread-safe WebDriver management using ThreadLocal.
 * Ensures each thread has its own WebDriver instance for parallel execution.
 */
public class ThreadLocalDriver {
    private static final Logger logger = LogManager.getLogger(ThreadLocalDriver.class);

    private static final ThreadLocal<WebDriver> driverThreadLocal = new ThreadLocal<>();

    /**
     * Private constructor to prevent instantiation.
     */
    private ThreadLocalDriver() {
    }

    /**
     * Sets the WebDriver instance for the current thread.
     *
     * @param driver WebDriver instance to set
     */
    public static void setDriver(WebDriver driver) {
        if (driver == null) {
            logger.warn("Attempted to set null WebDriver for thread: {}", Thread.currentThread().getName());
            return;
        }
        driverThreadLocal.set(driver);
        logger.debug("WebDriver set for thread: {}", Thread.currentThread().getName());
    }

    /**
     * Gets the WebDriver instance for the current thread.
     *
     * @return WebDriver instance
     * @throws IllegalStateException if no driver is set for the current thread
     */
    public static WebDriver getDriver() {
        WebDriver driver = driverThreadLocal.get();
        if (driver == null) {
            String errorMsg = "No WebDriver found for thread: " + Thread.currentThread().getName();
            logger.error(errorMsg);
            throw new IllegalStateException(errorMsg);
        }
        return driver;
    }

    /**
     * Checks if a WebDriver is set for the current thread.
     *
     * @return true if driver exists, false otherwise
     */
    public static boolean hasDriver() {
        return driverThreadLocal.get() != null;
    }

    /**
     * Removes the WebDriver instance for the current thread.
     * Should be called after test execution to prevent memory leaks.
     */
    public static void removeDriver() {
        WebDriver driver = driverThreadLocal.get();
        if (driver != null) {
            logger.debug("Removing WebDriver for thread: {}", Thread.currentThread().getName());
            driverThreadLocal.remove();
        }
    }

    /**
     * Quits the WebDriver and removes it from ThreadLocal.
     * Performs cleanup to prevent memory leaks.
     */
    public static void quitDriver() {
        WebDriver driver = driverThreadLocal.get();
        if (driver != null) {
            try {
                logger.info("Quitting WebDriver for thread: {}", Thread.currentThread().getName());
                driver.quit();
            } catch (Exception e) {
                logger.error("Error quitting WebDriver: {}", e.getMessage(), e);
            } finally {
                driverThreadLocal.remove();
            }
        }
    }
}
