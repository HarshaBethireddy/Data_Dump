package com.harsha.automation.exceptions;

/**
 * Custom exception for WebDriver-related errors.
 * Thrown when there are issues with driver initialization, configuration, or execution.
 */
public class DriverException extends RuntimeException {

    /**
     * Constructs a new DriverException with the specified detail message.
     *
     * @param message The detail message
     */
    public DriverException(String message) {
        super(message);
    }

    /**
     * Constructs a new DriverException with the specified detail message and cause.
     *
     * @param message The detail message
     * @param cause   The cause of the exception
     */
    public DriverException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new DriverException with the specified cause.
     *
     * @param cause The cause of the exception
     */
    public DriverException(Throwable cause) {
        super(cause);
    }
}
