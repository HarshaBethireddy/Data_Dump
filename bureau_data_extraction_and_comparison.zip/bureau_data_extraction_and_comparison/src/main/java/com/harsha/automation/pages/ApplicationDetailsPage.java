package com.harsha.automation.pages;

import com.harsha.automation.core.base.BasePage;
import com.harsha.automation.exceptions.PageNavigationException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Page Object for Application Details Page.
 * Handles application details viewing and bureau data access.
 */
public class ApplicationDetailsPage extends BasePage {

    @FindBy(xpath = "//table[@id='datagrid']//td//div//center//a")
    private WebElement openApplicationLink;

    @FindBy(xpath = "//button[.='View Bureau']")
    private WebElement viewBureauButton;

    @FindBy(xpath = "//button[.='Close']")
    private WebElement closeButton;

    /**
     * Constructor initializes the page.
     *
     * @param driver WebDriver instance
     */
    public ApplicationDetailsPage(WebDriver driver) {
        super(driver);
    }

    @Override
    public boolean isLoaded() {
        try {
            // Check if either the application link or view bureau button is displayed
            return isDisplayed(openApplicationLink) || isDisplayed(viewBureauButton);
        } catch (Exception e) {
            logger.debug("Application details page not loaded: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Clicks on the application link to open details.
     *
     * @return ApplicationDetailsPage (fluent interface)
     * @throws PageNavigationException if click fails
     */
    public ApplicationDetailsPage openApplication() {
        logger.info("Opening application details");

        try {
            openApplicationLink.click();
            logger.debug("Application link clicked");
            hardWait(3);
            logger.info("Application opened successfully");
            return this;
        } catch (Exception e) {
            logger.error("Failed to open application: {}", e.getMessage());
            throw new PageNavigationException("Failed to open application details", e);
        }
    }

    /**
     * Clicks the View Bureau button to open bureau data viewer.
     *
     * @return DataViewerPage
     * @throws PageNavigationException if click fails
     */
    public DataViewerPage viewBureauData() {
        logger.info("Clicking View Bureau button");

        try {
            viewBureauButton.click();
            logger.debug("View Bureau button clicked");
            hardWait(4);
            logger.info("Bureau data viewer opened");
            return new DataViewerPage(driver);
        } catch (Exception e) {
            logger.error("Failed to open bureau data viewer: {}", e.getMessage());
            throw new PageNavigationException("Failed to open bureau data viewer", e);
        }
    }

    /**
     * Closes the application details.
     *
     * @return SearchPage
     * @throws PageNavigationException if close fails
     */
    public SearchPage close() {
        logger.info("Closing application details");

        try {
            closeButton.click();
            logger.debug("Close button clicked");
            hardWait(2);

            // Handle confirmation modal
            handleConfirmationModal();

            // Wait for search page to be visible
            hardWait(2);

            logger.info("Application details closed successfully");
            return new SearchPage(driver);
        } catch (Exception e) {
            logger.error("Failed to close application details: {}", e.getMessage());
            throw new PageNavigationException("Failed to close application details", e);
        }
    }

    /**
     * Handles the confirmation modal after closing.
     */
    private void handleConfirmationModal() {
        logger.debug("Handling confirmation modal");

        try {
            // Wait for modal to appear
            WebElement modal = findElement(By.cssSelector(".wicket-modal"));

            if (isDisplayed(modal)) {
                // Click OK button
                WebElement okButton = findElement(By.xpath("//*[@name='ok']"));
                okButton.click();
                logger.debug("Confirmation modal OK button clicked");
                hardWait(2);
            }
        } catch (Exception e) {
            // Try alternative OK button
            try {
                WebElement okButton = findElement(By.xpath("//input[@type='button' and @value='OK']"));
                okButton.click();
                hardWait(2);
                logger.debug("Alternative OK button clicked");
            } catch (Exception altError) {
                logger.warn("No confirmation modal found or already closed");
            }
        }
    }

    /**
     * Checks if View Bureau button is displayed.
     *
     * @return true if displayed, false otherwise
     */
    public boolean isViewBureauButtonDisplayed() {
        return isDisplayed(viewBureauButton);
    }

    /**
     * Checks if Close button is displayed.
     *
     * @return true if displayed, false otherwise
     */
    public boolean isCloseButtonDisplayed() {
        return isDisplayed(closeButton);
    }
}
