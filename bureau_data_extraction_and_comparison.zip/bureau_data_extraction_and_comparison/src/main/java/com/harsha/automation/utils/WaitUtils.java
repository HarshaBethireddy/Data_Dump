package com.harsha.automation.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.function.Function;

/**
 * Utility class for WebDriver wait operations.
 * Provides custom wait methods for various scenarios.
 */
public class WaitUtils {
    private static final Logger logger = LogManager.getLogger(WaitUtils.class);
    private static final Duration DEFAULT_TIMEOUT = Duration.ofSeconds(60);
    private static final Duration DEFAULT_POLLING = Duration.ofMillis(500);

    /**
     * Private constructor to prevent instantiation.
     */
    private WaitUtils() {
    }

    /**
     * Waits for element to be visible.
     *
     * @param driver  WebDriver instance
     * @param locator Element locator
     * @return Visible WebElement
     */
    public static WebElement waitForVisibility(WebDriver driver, By locator) {
        return waitForVisibility(driver, locator, DEFAULT_TIMEOUT);
    }

    /**
     * Waits for element to be visible with custom timeout.
     *
     * @param driver  WebDriver instance
     * @param locator Element locator
     * @param timeout Timeout duration
     * @return Visible WebElement
     */
    public static WebElement waitForVisibility(WebDriver driver, By locator, Duration timeout) {
        logger.debug("Waiting for visibility of element: {}", locator);
        try {
            WebDriverWait wait = new WebDriverWait(driver, timeout);
            return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
        } catch (TimeoutException e) {
            logger.error("Element not visible within {} seconds: {}", timeout.getSeconds(), locator);
            throw e;
        }
    }

    /**
     * Waits for element to be clickable.
     *
     * @param driver  WebDriver instance
     * @param locator Element locator
     * @return Clickable WebElement
     */
    public static WebElement waitForClickability(WebDriver driver, By locator) {
        return waitForClickability(driver, locator, DEFAULT_TIMEOUT);
    }

    /**
     * Waits for element to be clickable with custom timeout.
     *
     * @param driver  WebDriver instance
     * @param locator Element locator
     * @param timeout Timeout duration
     * @return Clickable WebElement
     */
    public static WebElement waitForClickability(WebDriver driver, By locator, Duration timeout) {
        logger.debug("Waiting for element to be clickable: {}", locator);
        try {
            WebDriverWait wait = new WebDriverWait(driver, timeout);
            return wait.until(ExpectedConditions.elementToBeClickable(locator));
        } catch (TimeoutException e) {
            logger.error("Element not clickable within {} seconds: {}", timeout.getSeconds(), locator);
            throw e;
        }
    }

    /**
     * Waits for element to be present in DOM.
     *
     * @param driver  WebDriver instance
     * @param locator Element locator
     * @return WebElement that is present in DOM
     */
    public static WebElement waitForPresence(WebDriver driver, By locator) {
        return waitForPresence(driver, locator, DEFAULT_TIMEOUT);
    }

    /**
     * Waits for element to be present in DOM with custom timeout.
     *
     * @param driver  WebDriver instance
     * @param locator Element locator
     * @param timeout Timeout duration
     * @return WebElement that is present in DOM
     */
    public static WebElement waitForPresence(WebDriver driver, By locator, Duration timeout) {
        logger.debug("Waiting for presence of element: {}", locator);
        try {
            WebDriverWait wait = new WebDriverWait(driver, timeout);
            return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
        } catch (TimeoutException e) {
            logger.error("Element not present within {} seconds: {}", timeout.getSeconds(), locator);
            throw e;
        }
    }

    /**
     * Waits for element to be invisible.
     *
     * @param driver  WebDriver instance
     * @param locator Element locator
     * @return true if element is invisible, false otherwise
     */
    public static boolean waitForInvisibility(WebDriver driver, By locator) {
        return waitForInvisibility(driver, locator, DEFAULT_TIMEOUT);
    }

    /**
     * Waits for element to be invisible with custom timeout.
     *
     * @param driver  WebDriver instance
     * @param locator Element locator
     * @param timeout Timeout duration
     * @return true if element is invisible, false otherwise
     */
    public static boolean waitForInvisibility(WebDriver driver, By locator, Duration timeout) {
        logger.debug("Waiting for invisibility of element: {}", locator);
        try {
            WebDriverWait wait = new WebDriverWait(driver, timeout);
            return wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
        } catch (TimeoutException e) {
            logger.warn("Element still visible after {} seconds: {}", timeout.getSeconds(), locator);
            return false;
        }
    }

    /**
     * Waits for all elements to be present.
     *
     * @param driver  WebDriver instance
     * @param locator Element locator
     * @return List of WebElements
     */
    public static List<WebElement> waitForAllPresence(WebDriver driver, By locator) {
        return waitForAllPresence(driver, locator, DEFAULT_TIMEOUT);
    }

    /**
     * Waits for all elements to be present with custom timeout.
     *
     * @param driver  WebDriver instance
     * @param locator Element locator
     * @param timeout Timeout duration
     * @return List of WebElements
     */
    public static List<WebElement> waitForAllPresence(WebDriver driver, By locator, Duration timeout) {
        logger.debug("Waiting for all elements to be present: {}", locator);
        try {
            WebDriverWait wait = new WebDriverWait(driver, timeout);
            return wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(locator));
        } catch (TimeoutException e) {
            logger.error("Elements not present within {} seconds: {}", timeout.getSeconds(), locator);
            throw e;
        }
    }

    /**
     * Waits for text to be present in element.
     *
     * @param driver  WebDriver instance
     * @param locator Element locator
     * @param text    Expected text
     * @return true if text is present, false otherwise
     */
    public static boolean waitForTextPresence(WebDriver driver, By locator, String text) {
        return waitForTextPresence(driver, locator, text, DEFAULT_TIMEOUT);
    }

    /**
     * Waits for text to be present in element with custom timeout.
     *
     * @param driver  WebDriver instance
     * @param locator Element locator
     * @param text    Expected text
     * @param timeout Timeout duration
     * @return true if text is present, false otherwise
     */
    public static boolean waitForTextPresence(WebDriver driver, By locator, String text, Duration timeout) {
        logger.debug("Waiting for text '{}' in element: {}", text, locator);
        try {
            WebDriverWait wait = new WebDriverWait(driver, timeout);
            return wait.until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
        } catch (TimeoutException e) {
            logger.error("Text '{}' not present in element within {} seconds: {}", text, timeout.getSeconds(), locator);
            return false;
        }
    }

    /**
     * Waits for attribute to contain specific value.
     *
     * @param driver    WebDriver instance
     * @param locator   Element locator
     * @param attribute Attribute name
     * @param value     Expected value
     * @return true if attribute contains value, false otherwise
     */
    public static boolean waitForAttributeToBe(WebDriver driver, By locator, String attribute, String value) {
        return waitForAttributeToBe(driver, locator, attribute, value, DEFAULT_TIMEOUT);
    }

    /**
     * Waits for attribute to contain specific value with custom timeout.
     *
     * @param driver    WebDriver instance
     * @param locator   Element locator
     * @param attribute Attribute name
     * @param value     Expected value
     * @param timeout   Timeout duration
     * @return true if attribute contains value, false otherwise
     */
    public static boolean waitForAttributeToBe(WebDriver driver, By locator, String attribute,
                                               String value, Duration timeout) {
        logger.debug("Waiting for attribute '{}' to be '{}' in element: {}", attribute, value, locator);
        try {
            WebDriverWait wait = new WebDriverWait(driver, timeout);
            return wait.until(ExpectedConditions.attributeToBe(locator, attribute, value));
        } catch (TimeoutException e) {
            logger.error("Attribute '{}' not '{}' within {} seconds: {}", attribute, value, timeout.getSeconds(), locator);
            return false;
        }
    }

    /**
     * Fluent wait for custom condition.
     *
     * @param driver    WebDriver instance
     * @param condition Condition to wait for
     * @param timeout   Timeout duration
     * @param polling   Polling interval
     * @param <T>       Return type
     * @return Result of condition
     */
    public static <T> T fluentWait(WebDriver driver, Function<WebDriver, T> condition,
                                   Duration timeout, Duration polling) {
        logger.debug("Starting fluent wait with timeout: {} and polling: {}", timeout, polling);

        FluentWait<WebDriver> wait = new FluentWait<>(driver)
                .withTimeout(timeout)
                .pollingEvery(polling)
                .ignoring(NoSuchElementException.class)
                .ignoring(StaleElementReferenceException.class);

        try {
            return wait.until(condition);
        } catch (TimeoutException e) {
            logger.error("Fluent wait timed out after {} seconds", timeout.getSeconds());
            throw e;
        }
    }

    /**
     * Waits for custom condition.
     *
     * @param driver    WebDriver instance
     * @param condition Expected condition
     * @param timeout   Timeout duration
     * @param <T>       Return type
     * @return Result of condition
     */
    public static <T> T waitForCondition(WebDriver driver, ExpectedCondition<T> condition, Duration timeout) {
        logger.debug("Waiting for custom condition");
        WebDriverWait wait = new WebDriverWait(driver, timeout);
        return wait.until(condition);
    }

    /**
     * Hard wait (Thread.sleep) - Use sparingly, only when necessary.
     *
     * @param seconds Number of seconds to wait
     */
    public static void hardWait(int seconds) {
        try {
            logger.debug("Hard wait for {} seconds", seconds);
            Thread.sleep(seconds * 1000L);
        } catch (InterruptedException e) {
            logger.error("Hard wait interrupted: {}", e.getMessage());
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Hard wait in milliseconds - Use sparingly, only when necessary.
     *
     * @param milliseconds Number of milliseconds to wait
     */
    public static void hardWaitMillis(long milliseconds) {
        try {
            logger.debug("Hard wait for {} milliseconds", milliseconds);
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            logger.error("Hard wait interrupted: {}", e.getMessage());
            Thread.currentThread().interrupt();
        }
    }
}
