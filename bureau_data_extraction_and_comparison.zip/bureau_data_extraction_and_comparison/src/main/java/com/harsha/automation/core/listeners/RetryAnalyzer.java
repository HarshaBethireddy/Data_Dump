package com.harsha.automation.core.listeners;

import com.harsha.automation.config.ConfigurationManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

/**
 * Retry Analyzer for handling flaky tests.
 * Implements TestNG IRetryAnalyzer to retry failed tests.
 */
public class RetryAnalyzer implements IRetryAnalyzer {
    private static final Logger logger = LogManager.getLogger(RetryAnalyzer.class);
    private int retryCount = 0;
    private int maxRetryCount;

    /**
     * Constructor initializes max retry count from configuration.
     */
    public RetryAnalyzer() {
        ConfigurationManager config = ConfigurationManager.getInstance();
        this.maxRetryCount = config.getIntProperty("retry.max.count", 1);
        logger.debug("RetryAnalyzer initialized with maxRetryCount: {}", maxRetryCount);
    }

    /**
     * Determines if a test should be retried.
     *
     * @param result Test result
     * @return true if test should be retried, false otherwise
     */
    @Override
    public boolean retry(ITestResult result) {
        if (retryCount < maxRetryCount) {
            retryCount++;
            logger.warn("Retrying test '{}' - Attempt {}/{}",
                    result.getMethod().getMethodName(),
                    retryCount,
                    maxRetryCount);
            return true;
        }
        logger.info("Max retry count reached for test '{}'", result.getMethod().getMethodName());
        return false;
    }

    /**
     * Gets current retry count.
     *
     * @return Current retry count
     */
    public int getRetryCount() {
        return retryCount;
    }

    /**
     * Gets max retry count.
     *
     * @return Max retry count
     */
    public int getMaxRetryCount() {
        return maxRetryCount;
    }
}
