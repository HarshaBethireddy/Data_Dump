package com.harsha.automation.services;

import com.harsha.automation.models.ApplicationData;
import com.harsha.automation.models.BureauSection;
import com.harsha.automation.models.ComparisonResult;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Service class for comparing bureau data files.
 */
public class ComparisonService {
    private static final Logger logger = LogManager.getLogger(ComparisonService.class);
    private final FileService fileService;

    public ComparisonService() {
        this.fileService = new FileService();
    }

    /**
     * Compares PRE and POST files and generates comparison result.
     *
     * @param preFilePath  PRE file path
     * @param postFilePath POST file path
     * @param appData      Application data
     * @return ComparisonResult
     */
    public ComparisonResult compareFiles(String preFilePath, String postFilePath, ApplicationData appData) {
        logger.info("Comparing files for: {}", appData.getFileName());

        try {
            List<String> preLines = Files.readAllLines(Paths.get(preFilePath));
            List<String> postLines = Files.readAllLines(Paths.get(postFilePath));

            List<BureauSection> preSections = parseBureauSections(preLines);
            List<BureauSection> postSections = parseBureauSections(postLines);

            List<String> preNormalized = normalizeAndFilter(preLines);
            List<String> postNormalized = normalizeAndFilter(postLines);

            ComparisonResult.ComparisonResultBuilder resultBuilder = ComparisonResult.builder()
                    .fileName(appData.getFileName())
                    .preAppId(appData.getPreAppId())
                    .postAppId(appData.getPostAppId())
                    .preTotalLines(preLines.size())
                    .postTotalLines(postLines.size());

            if (preNormalized.equals(postNormalized)) {
                return resultBuilder
                        .status(ComparisonResult.ComparisonStatus.MATCHED)
                        .differenceCount(0)
                        .build();
            } else {
                List<ComparisonResult.Difference> differences = findDifferences(
                        preLines, postLines, preSections, postSections);

                return resultBuilder
                        .status(ComparisonResult.ComparisonStatus.DIFFERENCES_FOUND)
                        .differences(differences)
                        .differenceCount(differences.size())
                        .build();
            }

        } catch (IOException e) {
            logger.error("Comparison failed: {}", e.getMessage());
            return ComparisonResult.builder()
                    .fileName(appData.getFileName())
                    .status(ComparisonResult.ComparisonStatus.ERROR)
                    .errorMessage(e.getMessage())
                    .build();
        }
    }

    /**
     * Parses bureau sections from lines.
     *
     * @param lines File lines
     * @return List of BureauSection
     */
    private List<BureauSection> parseBureauSections(List<String> lines) {
        List<BureauSection> sections = new ArrayList<>();
        String currentBureau = "Unknown";
        String currentType = "Unknown";
        int sectionStart = -1;

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);

            if (line.startsWith("==================================================")) {
                if (i + 1 < lines.size() && lines.get(i + 1).startsWith("Bureau: ")) {
                    if (sectionStart >= 0) {
                        sections.add(BureauSection.builder()
                                .bureauName(currentBureau)
                                .type(currentType)
                                .startLine(sectionStart)
                                .endLine(i - 1)
                                .build());
                    }

                    currentBureau = lines.get(i + 1).substring("Bureau: ".length()).trim();
                    if (i + 2 < lines.size() && lines.get(i + 2).startsWith("Type: ")) {
                        currentType = lines.get(i + 2).substring("Type: ".length()).trim();
                    }
                    sectionStart = i;
                }
            }
        }

        if (sectionStart >= 0) {
            sections.add(BureauSection.builder()
                    .bureauName(currentBureau)
                    .type(currentType)
                    .startLine(sectionStart)
                    .endLine(lines.size() - 1)
                    .build());
        }

        return sections;
    }

    /**
     * Normalizes and filters lines for comparison.
     *
     * @param lines Original lines
     * @return Normalized lines
     */
    private List<String> normalizeAndFilter(List<String> lines) {
        return lines.stream()
                .map(String::trim)
                .filter(line -> !line.isEmpty())
                .filter(line -> !line.contains("Extraction Time:"))
                .filter(line -> !line.contains("Application ID:"))
                .filter(line -> !line.startsWith("Type:"))
                .collect(Collectors.toList());
    }

    /**
     * Finds differences between PRE and POST lines.
     *
     * @param preLines     PRE lines
     * @param postLines    POST lines
     * @param preSections  PRE sections
     * @param postSections POST sections
     * @return List of differences
     */
    private List<ComparisonResult.Difference> findDifferences(List<String> preLines, List<String> postLines,
                                                             List<BureauSection> preSections,
                                                             List<BureauSection> postSections) {
        List<ComparisonResult.Difference> differences = new ArrayList<>();
        int maxLines = Math.max(preLines.size(), postLines.size());

        for (int i = 0; i < maxLines && differences.size() < 20; i++) {
            String preLine = i < preLines.size() ? preLines.get(i).trim() : "[MISSING]";
            String postLine = i < postLines.size() ? postLines.get(i).trim() : "[MISSING]";

            if (shouldSkipLine(preLine, postLine)) {
                continue;
            }

            if (!preLine.equals(postLine)) {
                BureauSection section = findSectionForLine(i, preSections, postSections);

                differences.add(ComparisonResult.Difference.builder()
                        .lineNumber(i + 1)
                        .bureauSection(section)
                        .preContent(preLine)
                        .postContent(postLine)
                        .type(ComparisonResult.DifferenceType.MODIFIED)
                        .build());
            }
        }

        return differences;
    }

    /**
     * Checks if line should be skipped in comparison.
     *
     * @param preLine  PRE line
     * @param postLine POST line
     * @return true if should skip
     */
    private boolean shouldSkipLine(String preLine, String postLine) {
        return (preLine.isEmpty() && postLine.isEmpty()) ||
               preLine.contains("Extraction Time:") || postLine.contains("Extraction Time:") ||
               preLine.contains("Application ID:") || postLine.contains("Application ID:") ||
               (preLine.startsWith("Type:") && postLine.startsWith("Type:"));
    }

    /**
     * Finds bureau section for given line number.
     *
     * @param lineNum      Line number
     * @param preSections  PRE sections
     * @param postSections POST sections
     * @return BureauSection or null
     */
    private BureauSection findSectionForLine(int lineNum, List<BureauSection> preSections,
                                             List<BureauSection> postSections) {
        for (BureauSection section : preSections) {
            if (section.containsLine(lineNum)) {
                return section;
            }
        }

        for (BureauSection section : postSections) {
            if (section.containsLine(lineNum)) {
                return section;
            }
        }

        return null;
    }
}
