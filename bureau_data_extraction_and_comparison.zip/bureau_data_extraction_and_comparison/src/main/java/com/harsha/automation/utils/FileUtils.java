package com.harsha.automation.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/**
 * Utility class for file operations.
 */
public class FileUtils {
    private static final Logger logger = LogManager.getLogger(FileUtils.class);

    /**
     * Private constructor to prevent instantiation.
     */
    private FileUtils() {
    }

    /**
     * Reads file content with automatic encoding detection.
     * Tries UTF-8, Windows-1252, and ISO-8859-1 encodings.
     *
     * @param file File to read
     * @return File content as string
     * @throws IOException if file cannot be read
     */
    public static String readFileWithEncoding(File file) throws IOException {
        logger.debug("Reading file with encoding detection: {}", file.getAbsolutePath());

        // Try UTF-8 first
        try {
            String content = Files.readString(file.toPath(), StandardCharsets.UTF_8);
            if (!content.contains("\uFFFD")) {  // Check for replacement character
                logger.debug("File read successfully with UTF-8 encoding");
                return content;
            }
        } catch (Exception e) {
            logger.debug("UTF-8 encoding failed, trying Windows-1252");
        }

        // Try Windows-1252
        try {
            String content = Files.readString(file.toPath(), Charset.forName("Windows-1252"));
            logger.debug("File read successfully with Windows-1252 encoding");
            return content;
        } catch (Exception e) {
            logger.debug("Windows-1252 encoding failed, trying ISO-8859-1");
        }

        // Try ISO-8859-1 as last resort
        try {
            String content = Files.readString(file.toPath(), Charset.forName("ISO-8859-1"));
            logger.debug("File read successfully with ISO-8859-1 encoding");
            return content;
        } catch (Exception e) {
            logger.debug("ISO-8859-1 encoding failed, using default charset");
        }

        // Use default charset as final fallback
        return Files.readString(file.toPath(), Charset.defaultCharset());
    }

    /**
     * Reads all lines from a file.
     *
     * @param filePath Path to file
     * @return List of lines
     * @throws IOException if file cannot be read
     */
    public static List<String> readAllLines(String filePath) throws IOException {
        logger.debug("Reading all lines from: {}", filePath);
        return Files.readAllLines(Paths.get(filePath));
    }

    /**
     * Writes content to a file.
     *
     * @param filePath Path to file
     * @param content  Content to write
     * @throws IOException if file cannot be written
     */
    public static void writeToFile(String filePath, String content) throws IOException {
        logger.debug("Writing to file: {}", filePath);
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(content);
        }
        logger.info("File written successfully: {}", filePath);
    }

    /**
     * Creates directory if it doesn't exist.
     *
     * @param directoryPath Path to directory
     * @throws IOException if directory cannot be created
     */
    public static void createDirectoryIfNotExists(String directoryPath) throws IOException {
        logger.debug("Creating directory if not exists: {}", directoryPath);
        Path path = Paths.get(directoryPath);
        if (!Files.exists(path)) {
            Files.createDirectories(path);
            logger.info("Directory created: {}", directoryPath);
        } else {
            logger.debug("Directory already exists: {}", directoryPath);
        }
    }

    /**
     * Checks if file exists.
     *
     * @param filePath Path to file
     * @return true if file exists, false otherwise
     */
    public static boolean fileExists(String filePath) {
        return Files.exists(Paths.get(filePath));
    }

    /**
     * Checks if directory exists.
     *
     * @param directoryPath Path to directory
     * @return true if directory exists, false otherwise
     */
    public static boolean directoryExists(String directoryPath) {
        File dir = new File(directoryPath);
        return dir.exists() && dir.isDirectory();
    }

    /**
     * Deletes a file.
     *
     * @param filePath Path to file
     * @return true if file was deleted, false otherwise
     */
    public static boolean deleteFile(String filePath) {
        logger.debug("Deleting file: {}", filePath);
        try {
            Files.deleteIfExists(Paths.get(filePath));
            logger.info("File deleted: {}", filePath);
            return true;
        } catch (IOException e) {
            logger.error("Failed to delete file {}: {}", filePath, e.getMessage());
            return false;
        }
    }

    /**
     * Gets file extension.
     *
     * @param fileName File name
     * @return File extension (without dot) or empty string if no extension
     */
    public static String getFileExtension(String fileName) {
        if (fileName == null || fileName.isEmpty()) {
            return "";
        }
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex > 0 && lastDotIndex < fileName.length() - 1) {
            return fileName.substring(lastDotIndex + 1).toLowerCase();
        }
        return "";
    }

    /**
     * Gets file name without extension.
     *
     * @param fileName File name
     * @return File name without extension
     */
    public static String getFileNameWithoutExtension(String fileName) {
        if (fileName == null || fileName.isEmpty()) {
            return "";
        }
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex > 0) {
            return fileName.substring(0, lastDotIndex);
        }
        return fileName;
    }

    /**
     * Lists all files in a directory.
     *
     * @param directoryPath Path to directory
     * @return Array of files
     */
    public static File[] listFiles(String directoryPath) {
        File directory = new File(directoryPath);
        if (!directory.exists() || !directory.isDirectory()) {
            logger.warn("Directory not found: {}", directoryPath);
            return new File[0];
        }
        File[] files = directory.listFiles();
        return files != null ? files : new File[0];
    }

    /**
     * Filters files by extension.
     *
     * @param directoryPath Path to directory
     * @param extension     File extension to filter (without dot)
     * @return Array of filtered files
     */
    public static File[] listFilesByExtension(String directoryPath, String extension) {
        File[] allFiles = listFiles(directoryPath);
        return java.util.Arrays.stream(allFiles)
                .filter(f -> f.isFile() && getFileExtension(f.getName()).equals(extension.toLowerCase()))
                .toArray(File[]::new);
    }

    /**
     * Gets the size of a file in bytes.
     *
     * @param filePath Path to file
     * @return File size in bytes, or -1 if file doesn't exist
     */
    public static long getFileSize(String filePath) {
        try {
            return Files.size(Paths.get(filePath));
        } catch (IOException e) {
            logger.error("Failed to get file size for {}: {}", filePath, e.getMessage());
            return -1;
        }
    }

    /**
     * Copies a file from source to destination.
     *
     * @param sourcePath      Source file path
     * @param destinationPath Destination file path
     * @throws IOException if file cannot be copied
     */
    public static void copyFile(String sourcePath, String destinationPath) throws IOException {
        logger.debug("Copying file from {} to {}", sourcePath, destinationPath);
        Files.copy(Paths.get(sourcePath), Paths.get(destinationPath));
        logger.info("File copied successfully");
    }
}
