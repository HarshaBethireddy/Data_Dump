package com.harsha.automation.pages;

import com.harsha.automation.core.base.BasePage;
import com.harsha.automation.exceptions.PageNavigationException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

/**
 * Page Object for Group Selection Page.
 * Handles administrator group selection.
 */
public class GroupSelectionPage extends BasePage {

    @FindBy(id = "groups")
    private WebElement groupsDropdown;

    @FindBy(id = "id2")
    private WebElement submitButton;

    @FindBy(id = "menu-wrapper")
    private WebElement menuWrapper;

    @FindBy(id = "menu")
    private WebElement menu;

    /**
     * Constructor initializes the page.
     *
     * @param driver WebDriver instance
     */
    public GroupSelectionPage(WebDriver driver) {
        super(driver);
    }

    @Override
    public boolean isLoaded() {
        try {
            return isDisplayed(groupsDropdown) && isDisplayed(submitButton);
        } catch (Exception e) {
            logger.debug("Group selection page not loaded: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Selects administrator group and submits.
     *
     * @param groupName Group name to select
     * @return SearchPage
     * @throws PageNavigationException if group selection fails
     */
    public SearchPage selectGroup(String groupName) {
        logger.info("Selecting group: {}", groupName);

        try {
            // Wait for dropdown to be visible
            hardWait(2);

            // Select group
            Select groupsSelect = new Select(groupsDropdown);
            groupsSelect.selectByVisibleText(groupName);
            logger.debug("Group '{}' selected", groupName);

            // Click submit button
            submitButton.click();
            logger.debug("Submit button clicked");

            // Wait for menu to load
            hardWait(3);

            // Verify menu loaded
            if (!isDisplayed(menuWrapper) || !isDisplayed(menu)) {
                throw new PageNavigationException("Menu not loaded after group selection");
            }

            logger.info("Group selection successful");
            return new SearchPage(driver);

        } catch (Exception e) {
            logger.error("Group selection failed: {}", e.getMessage());
            throw new PageNavigationException("Failed to select group: " + groupName, e);
        }
    }

    /**
     * Checks if menu is displayed after group selection.
     *
     * @return true if menu is displayed, false otherwise
     */
    public boolean isMenuDisplayed() {
        return isDisplayed(menuWrapper) && isDisplayed(menu);
    }
}
