package com.harsha.automation.exceptions;

/**
 * Custom exception for data extraction-related errors.
 * Thrown when there are issues extracting, parsing, or processing data.
 */
public class DataExtractionException extends RuntimeException {

    /**
     * Constructs a new DataExtractionException with the specified detail message.
     *
     * @param message The detail message
     */
    public DataExtractionException(String message) {
        super(message);
    }

    /**
     * Constructs a new DataExtractionException with the specified detail message and cause.
     *
     * @param message The detail message
     * @param cause   The cause of the exception
     */
    public DataExtractionException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new DataExtractionException with the specified cause.
     *
     * @param cause The cause of the exception
     */
    public DataExtractionException(Throwable cause) {
        super(cause);
    }
}
