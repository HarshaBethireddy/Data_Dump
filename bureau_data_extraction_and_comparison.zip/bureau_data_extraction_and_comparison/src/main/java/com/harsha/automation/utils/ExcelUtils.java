package com.harsha.automation.utils;

import com.harsha.automation.exceptions.DataExtractionException;
import com.harsha.automation.models.ApplicationData;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for Excel operations using Apache POI.
 */
public class ExcelUtils {
    private static final Logger logger = LogManager.getLogger(ExcelUtils.class);

    /**
     * Private constructor to prevent instantiation.
     */
    private ExcelUtils() {
    }

    /**
     * Reads ApplicationData from Excel file.
     *
     * @param excelPath Path to Excel file
     * @return List of ApplicationData
     * @throws DataExtractionException if file cannot be read
     */
    public static List<ApplicationData> readApplicationData(String excelPath) {
        logger.info("Reading application data from Excel: {}", excelPath);
        List<ApplicationData> applications = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(excelPath);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);

            // Skip header row (row 0), start from row 1
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) {
                    continue;
                }

                String fileName = getCellValueAsString(row.getCell(0));
                String preAppId = getCellValueAsString(row.getCell(1));
                String postAppId = getCellValueAsString(row.getCell(2));

                ApplicationData appData = ApplicationData.builder()
                        .fileName(fileName)
                        .preAppId(preAppId)
                        .postAppId(postAppId)
                        .buildWithCategoryDetection();

                if (appData.isValid()) {
                    applications.add(appData);
                    logger.debug("Added application: {}", appData.getFileName());
                } else {
                    logger.warn("Skipping invalid application data at row {}", i + 1);
                }
            }

            logger.info("Successfully read {} applications from Excel", applications.size());
            return applications;

        } catch (IOException e) {
            logger.error("Failed to read Excel file {}: {}", excelPath, e.getMessage());
            throw new DataExtractionException("Failed to read Excel file: " + excelPath, e);
        }
    }

    /**
     * Writes comparison data to Excel file.
     *
     * @param applications List of ApplicationData
     * @param excelPath    Path to output Excel file
     * @throws DataExtractionException if file cannot be written
     */
    public static void writeComparisonData(List<ApplicationData> applications, String excelPath) {
        logger.info("Writing comparison data to Excel: {}", excelPath);

        try (Workbook workbook = new XSSFWorkbook();
             FileOutputStream fos = new FileOutputStream(excelPath)) {

            Sheet sheet = workbook.createSheet("AppID Comparison");

            // Create header row
            Row headerRow = sheet.createRow(0);
            CellStyle headerStyle = createHeaderStyle(workbook);
            createHeaderCell(headerRow, 0, "File Name", headerStyle);
            createHeaderCell(headerRow, 1, "Pre-AppID", headerStyle);
            createHeaderCell(headerRow, 2, "Post-AppID", headerStyle);
            createHeaderCell(headerRow, 3, "Category", headerStyle);

            // Write data rows
            int rowIndex = 1;
            for (ApplicationData app : applications) {
                Row row = sheet.createRow(rowIndex++);
                row.createCell(0).setCellValue(app.getFileName());
                row.createCell(1).setCellValue(app.getPreAppId());
                row.createCell(2).setCellValue(app.getPostAppId());
                row.createCell(3).setCellValue(app.getCategory().getCategoryName());
            }

            // Auto-size columns
            for (int i = 0; i < 4; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(fos);
            logger.info("Successfully wrote {} rows to Excel file", applications.size());

        } catch (IOException e) {
            logger.error("Failed to write Excel file {}: {}", excelPath, e.getMessage());
            throw new DataExtractionException("Failed to write Excel file: " + excelPath, e);
        }
    }

    /**
     * Writes APP ID comparison to Excel file.
     *
     * @param fileNames  List of file names
     * @param preAppIds  List of pre APP IDs
     * @param postAppIds List of post APP IDs
     * @param categories List of categories
     * @param excelPath  Path to output Excel file
     * @throws DataExtractionException if file cannot be written
     */
    public static void writeAppIdComparison(List<String> fileNames, List<String> preAppIds,
                                           List<String> postAppIds, List<String> categories,
                                           String excelPath) {
        logger.info("Writing APP ID comparison to Excel: {}", excelPath);

        try (Workbook workbook = new XSSFWorkbook();
             FileOutputStream fos = new FileOutputStream(excelPath)) {

            Sheet sheet = workbook.createSheet("AppID Comparison");

            // Create header row
            Row headerRow = sheet.createRow(0);
            CellStyle headerStyle = createHeaderStyle(workbook);
            createHeaderCell(headerRow, 0, "File Name", headerStyle);
            createHeaderCell(headerRow, 1, "Pre-AppID", headerStyle);
            createHeaderCell(headerRow, 2, "Post-AppID", headerStyle);
            createHeaderCell(headerRow, 3, "Category", headerStyle);

            // Write data rows
            int rowIndex = 1;
            for (int i = 0; i < fileNames.size(); i++) {
                Row row = sheet.createRow(rowIndex++);
                row.createCell(0).setCellValue(fileNames.get(i));
                row.createCell(1).setCellValue(preAppIds.get(i));
                row.createCell(2).setCellValue(postAppIds.get(i));
                row.createCell(3).setCellValue(categories.get(i));
            }

            // Auto-size columns
            for (int i = 0; i < 4; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(fos);
            logger.info("Successfully wrote {} rows to Excel file", fileNames.size());

        } catch (IOException e) {
            logger.error("Failed to write Excel file {}: {}", excelPath, e.getMessage());
            throw new DataExtractionException("Failed to write Excel file: " + excelPath, e);
        }
    }

    /**
     * Gets cell value as string, handling different cell types.
     *
     * @param cell Cell to read
     * @return Cell value as string
     */
    public static String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return "";
        }

        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();

            case NUMERIC:
                double numValue = cell.getNumericCellValue();
                // Check if it's a whole number
                if (numValue == Math.floor(numValue)) {
                    return String.valueOf((long) numValue);
                }
                return String.valueOf(numValue);

            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());

            case FORMULA:
                try {
                    return cell.getStringCellValue().trim();
                } catch (Exception e) {
                    return String.valueOf(cell.getNumericCellValue());
                }

            case BLANK:
                return "";

            default:
                return cell.toString().trim();
        }
    }

    /**
     * Creates a header style for Excel cells.
     *
     * @param workbook Workbook instance
     * @return CellStyle for headers
     */
    private static CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 11);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    /**
     * Creates a header cell with value and style.
     *
     * @param row       Row to create cell in
     * @param column    Column index
     * @param value     Cell value
     * @param cellStyle Cell style
     */
    private static void createHeaderCell(Row row, int column, String value, CellStyle cellStyle) {
        Cell cell = row.createCell(column);
        cell.setCellValue(value);
        cell.setCellStyle(cellStyle);
    }

    /**
     * Checks if Excel file exists and is readable.
     *
     * @param excelPath Path to Excel file
     * @return true if file exists and is readable, false otherwise
     */
    public static boolean isExcelFileValid(String excelPath) {
        try (FileInputStream fis = new FileInputStream(excelPath);
             Workbook workbook = new XSSFWorkbook(fis)) {
            return workbook.getNumberOfSheets() > 0;
        } catch (IOException e) {
            logger.error("Excel file validation failed for {}: {}", excelPath, e.getMessage());
            return false;
        }
    }

    /**
     * Gets the number of rows in an Excel file (excluding header).
     *
     * @param excelPath Path to Excel file
     * @return Number of data rows
     * @throws DataExtractionException if file cannot be read
     */
    public static int getRowCount(String excelPath) {
        try (FileInputStream fis = new FileInputStream(excelPath);
             Workbook workbook = new XSSFWorkbook(fis)) {
            Sheet sheet = workbook.getSheetAt(0);
            return sheet.getLastRowNum(); // This excludes the header row
        } catch (IOException e) {
            logger.error("Failed to get row count from {}: {}", excelPath, e.getMessage());
            throw new DataExtractionException("Failed to get row count from Excel file", e);
        }
    }
}
