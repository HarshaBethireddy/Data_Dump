package com.harsha.automation.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Singleton configuration manager for loading and accessing application properties.
 * Implements thread-safe lazy initialization pattern.
 */
public class ConfigurationManager {
    private static final Logger logger = LogManager.getLogger(ConfigurationManager.class);
    private static volatile ConfigurationManager instance;
    private final Properties properties;

    private static final String CONFIG_FILE = "config/application.properties";

    /**
     * Private constructor to prevent instantiation.
     * Loads properties from application.properties file.
     */
    private ConfigurationManager() {
        properties = new Properties();
        loadProperties();
    }

    /**
     * Gets the singleton instance of ConfigurationManager.
     * Implements double-checked locking for thread safety.
     *
     * @return ConfigurationManager instance
     */
    public static ConfigurationManager getInstance() {
        if (instance == null) {
            synchronized (ConfigurationManager.class) {
                if (instance == null) {
                    instance = new ConfigurationManager();
                }
            }
        }
        return instance;
    }

    /**
     * Loads properties from the configuration file.
     */
    private void loadProperties() {
        try (InputStream input = getClass().getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            if (input == null) {
                logger.error("Unable to find {}", CONFIG_FILE);
                throw new RuntimeException("Configuration file not found: " + CONFIG_FILE);
            }
            properties.load(input);
            logger.info("Configuration loaded successfully from {}", CONFIG_FILE);
        } catch (IOException e) {
            logger.error("Error loading configuration file: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to load configuration", e);
        }
    }

    /**
     * Gets a property value by key.
     *
     * @param key Property key
     * @return Property value or null if not found
     */
    public String getProperty(String key) {
        String value = properties.getProperty(key);
        if (value == null) {
            logger.warn("Property not found: {}", key);
        }
        return value;
    }

    /**
     * Gets a property value by key with a default value.
     *
     * @param key          Property key
     * @param defaultValue Default value if property not found
     * @return Property value or default value
     */
    public String getProperty(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }

    /**
     * Gets a property value as integer.
     *
     * @param key Property key
     * @return Integer value
     * @throws NumberFormatException if value cannot be parsed as integer
     */
    public int getIntProperty(String key) {
        String value = getProperty(key);
        if (value == null) {
            throw new IllegalArgumentException("Property not found: " + key);
        }
        return Integer.parseInt(value);
    }

    /**
     * Gets a property value as integer with default value.
     *
     * @param key          Property key
     * @param defaultValue Default value
     * @return Integer value or default
     */
    public int getIntProperty(String key, int defaultValue) {
        String value = getProperty(key);
        if (value == null) {
            return defaultValue;
        }
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            logger.warn("Invalid integer value for {}: {}. Using default: {}", key, value, defaultValue);
            return defaultValue;
        }
    }

    /**
     * Gets a property value as boolean.
     *
     * @param key Property key
     * @return Boolean value
     */
    public boolean getBooleanProperty(String key) {
        String value = getProperty(key);
        return Boolean.parseBoolean(value);
    }

    /**
     * Gets a property value as boolean with default value.
     *
     * @param key          Property key
     * @param defaultValue Default value
     * @return Boolean value or default
     */
    public boolean getBooleanProperty(String key, boolean defaultValue) {
        String value = getProperty(key);
        if (value == null) {
            return defaultValue;
        }
        return Boolean.parseBoolean(value);
    }

    /**
     * Gets a property value as long.
     *
     * @param key Property key
     * @return Long value
     * @throws NumberFormatException if value cannot be parsed as long
     */
    public long getLongProperty(String key) {
        String value = getProperty(key);
        if (value == null) {
            throw new IllegalArgumentException("Property not found: " + key);
        }
        return Long.parseLong(value);
    }

    /**
     * Gets a property value as long with default value.
     *
     * @param key          Property key
     * @param defaultValue Default value
     * @return Long value or default
     */
    public long getLongProperty(String key, long defaultValue) {
        String value = getProperty(key);
        if (value == null) {
            return defaultValue;
        }
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            logger.warn("Invalid long value for {}: {}. Using default: {}", key, value, defaultValue);
            return defaultValue;
        }
    }

    /**
     * Checks if a property exists.
     *
     * @param key Property key
     * @return true if property exists, false otherwise
     */
    public boolean hasProperty(String key) {
        return properties.containsKey(key);
    }

    /**
     * Gets all properties.
     *
     * @return Properties object
     */
    public Properties getAllProperties() {
        return (Properties) properties.clone();
    }
}
