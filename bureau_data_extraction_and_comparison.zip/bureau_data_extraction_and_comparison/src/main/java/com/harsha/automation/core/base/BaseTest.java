package com.harsha.automation.core.base;

import com.harsha.automation.config.TestConfiguration;
import com.harsha.automation.core.driver.DriverManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

/**
 * Base Test class that provides common setup and teardown for all test classes.
 * Manages WebDriver lifecycle and provides access to configuration.
 */
public abstract class BaseTest {
    protected final Logger logger = LogManager.getLogger(this.getClass());
    protected DriverManager driverManager;
    protected TestConfiguration config;
    protected WebDriver driver;

    /**
     * Setup method executed before each test method.
     * Initializes DriverManager, configuration, and WebDriver.
     */
    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        logger.info("=== Test Setup Started ===");
        logger.info("Test: {}", this.getClass().getSimpleName());

        // Initialize DriverManager and Configuration
        driverManager = DriverManager.getInstance();
        config = driverManager.getConfig();

        // Create WebDriver
        driverManager.createDriver();
        driver = driverManager.getDriver();

        logger.info("WebDriver initialized successfully");
        logger.info("Browser: {}", config.getBrowserType());
        logger.info("Base URL: {}", config.getBaseUrl());
        logger.info("=== Test Setup Complete ===");
    }

    /**
     * Teardown method executed after each test method.
     * Quits WebDriver and performs cleanup.
     */
    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        logger.info("=== Test Teardown Started ===");

        if (driverManager != null && driverManager.hasDriver()) {
            logger.info("Quitting WebDriver");
            driverManager.quitDriver();
        }

        logger.info("=== Test Teardown Complete ===");
    }

    /**
     * Gets the WebDriver instance for the current thread.
     *
     * @return WebDriver instance
     */
    protected WebDriver getDriver() {
        if (driver == null) {
            driver = driverManager.getDriver();
        }
        return driver;
    }

    /**
     * Gets the test configuration.
     *
     * @return TestConfiguration instance
     */
    protected TestConfiguration getConfig() {
        return config;
    }

    /**
     * Navigates to the base URL.
     */
    protected void navigateToBaseUrl() {
        logger.info("Navigating to base URL: {}", config.getBaseUrl());
        driverManager.navigateToBaseUrl();
    }

    /**
     * Navigates to a specific URL.
     *
     * @param url URL to navigate to
     */
    protected void navigateTo(String url) {
        logger.info("Navigating to: {}", url);
        driverManager.navigateTo(url);
    }

    /**
     * Logs test information.
     *
     * @param message Message to log
     */
    protected void logInfo(String message) {
        logger.info(message);
    }

    /**
     * Logs test error.
     *
     * @param message Error message
     */
    protected void logError(String message) {
        logger.error(message);
    }

    /**
     * Logs test warning.
     *
     * @param message Warning message
     */
    protected void logWarn(String message) {
        logger.warn(message);
    }

    /**
     * Logs test debug information.
     *
     * @param message Debug message
     */
    protected void logDebug(String message) {
        logger.debug(message);
    }
}
