package com.harsha.automation.models;

import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Model class representing the result of a bureau data comparison.
 * Contains detailed information about differences found between PRE and POST data.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ComparisonResult {

    /**
     * File name being compared
     */
    private String fileName;

    /**
     * Pre-deployment application ID
     */
    private String preAppId;

    /**
     * Post-deployment application ID
     */
    private String postAppId;

    /**
     * Comparison status (MATCHED, DIFFERENCES_FOUND, ERROR)
     */
    private ComparisonStatus status;

    /**
     * Total number of differences found
     */
    private int differenceCount;

    /**
     * List of detailed differences
     */
    @Builder.Default
    private List<Difference> differences = new ArrayList<>();

    /**
     * Error message if comparison failed
     */
    private String errorMessage;

    /**
     * Timestamp when comparison was performed
     */
    @Builder.Default
    private LocalDateTime comparisonTime = LocalDateTime.now();

    /**
     * Total lines in PRE file
     */
    private int preTotalLines;

    /**
     * Total lines in POST file
     */
    private int postTotalLines;

    /**
     * Enum for comparison status
     */
    public enum ComparisonStatus {
        MATCHED("No differences found"),
        DIFFERENCES_FOUND("Differences detected"),
        ERROR("Comparison failed");

        private final String description;

        ComparisonStatus(String description) {
            this.description = description;
        }

        public String getDescription() {
            return description;
        }
    }

    /**
     * Inner class representing a single difference.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Difference {
        /**
         * Line number where difference was found
         */
        private int lineNumber;

        /**
         * Bureau section information
         */
        private BureauSection bureauSection;

        /**
         * Content from PRE file
         */
        private String preContent;

        /**
         * Content from POST file
         */
        private String postContent;

        /**
         * Type of difference (MODIFIED, ADDED, DELETED)
         */
        private DifferenceType type;

        /**
         * Gets a formatted display string for this difference.
         *
         * @return Formatted difference string
         */
        public String toDisplayString() {
            StringBuilder sb = new StringBuilder();
            sb.append("Line ").append(lineNumber).append(": ");

            if (bureauSection != null) {
                sb.append("(Bureau: ").append(bureauSection.getBureauName())
                  .append(", Type: ").append(bureauSection.getType()).append(") ");
            }

            sb.append("\n  PRE:  ").append(truncate(preContent, 100));
            sb.append("\n  POST: ").append(truncate(postContent, 100));

            return sb.toString();
        }

        /**
         * Truncates a string to specified length.
         *
         * @param str       String to truncate
         * @param maxLength Maximum length
         * @return Truncated string
         */
        private String truncate(String str, int maxLength) {
            if (str == null) {
                return "[MISSING]";
            }
            if (str.length() <= maxLength) {
                return str;
            }
            return str.substring(0, maxLength) + "...";
        }
    }

    /**
     * Enum for difference types
     */
    public enum DifferenceType {
        MODIFIED,
        ADDED,
        DELETED
    }

    /**
     * Checks if comparison was successful (matched or differences found).
     *
     * @return true if comparison completed, false if error occurred
     */
    public boolean isSuccessful() {
        return status != ComparisonStatus.ERROR;
    }

    /**
     * Checks if files matched exactly.
     *
     * @return true if no differences found
     */
    public boolean isMatched() {
        return status == ComparisonStatus.MATCHED;
    }

    /**
     * Adds a difference to the result.
     *
     * @param difference Difference to add
     */
    public void addDifference(Difference difference) {
        if (this.differences == null) {
            this.differences = new ArrayList<>();
        }
        this.differences.add(difference);
        this.differenceCount = this.differences.size();
    }

    /**
     * Generates a summary report string.
     *
     * @return Summary report
     */
    public String generateSummary() {
        StringBuilder summary = new StringBuilder();
        summary.append("File: ").append(fileName).append("\n");
        summary.append("Status: ").append(status.getDescription()).append("\n");

        if (status == ComparisonStatus.ERROR) {
            summary.append("Error: ").append(errorMessage).append("\n");
        } else {
            summary.append("Pre Lines: ").append(preTotalLines).append("\n");
            summary.append("Post Lines: ").append(postTotalLines).append("\n");
            summary.append("Differences: ").append(differenceCount).append("\n");
        }

        return summary.toString();
    }
}
