package com.harsha.automation.enums;

/**
 * Enum representing the type of data extraction (PRE or POST).
 */
public enum ExtractionType {
    /**
     * Pre-deployment data extraction
     */
    PRE("PRE"),

    /**
     * Post-deployment data extraction
     */
    POST("POST");

    private final String typeName;

    /**
     * Constructor for ExtractionType enum.
     *
     * @param typeName Type name identifier
     */
    ExtractionType(String typeName) {
        this.typeName = typeName;
    }

    /**
     * Gets the type name identifier.
     *
     * @return Type name as string
     */
    public String getTypeName() {
        return typeName;
    }

    /**
     * Gets ExtractionType from string value.
     *
     * @param value String value to convert
     * @return Corresponding ExtractionType
     * @throws IllegalArgumentException if extraction type not found
     */
    public static ExtractionType fromString(String value) {
        for (ExtractionType type : ExtractionType.values()) {
            if (type.name().equalsIgnoreCase(value) || type.typeName.equalsIgnoreCase(value)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown extraction type: " + value);
    }

    /**
     * Checks if this is PRE extraction type.
     *
     * @return true if PRE, false otherwise
     */
    public boolean isPre() {
        return this == PRE;
    }

    /**
     * Checks if this is POST extraction type.
     *
     * @return true if POST, false otherwise
     */
    public boolean isPost() {
        return this == POST;
    }
}
