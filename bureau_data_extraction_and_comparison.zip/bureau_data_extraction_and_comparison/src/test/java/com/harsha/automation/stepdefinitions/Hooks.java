package com.harsha.automation.stepdefinitions;

import com.harsha.automation.config.TestConfiguration;
import com.harsha.automation.core.driver.DriverManager;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Cucumber hooks for test setup and teardown.
 */
public class Hooks {
    private static final Logger logger = LogManager.getLogger(Hooks.class);
    private DriverManager driverManager;
    private TestConfiguration config;

    /**
     * Before hook - executed before each scenario.
     *
     * @param scenario Cucumber scenario
     */
    @Before
    public void beforeScenario(Scenario scenario) {
        logger.info("========================================");
        logger.info("Starting Scenario: {}", scenario.getName());
        logger.info("Tags: {}", scenario.getSourceTagNames());
        logger.info("========================================");

        // Initialize DriverManager and Configuration
        driverManager = DriverManager.getInstance();
        config = driverManager.getConfig();

        // Create WebDriver
        driverManager.createDriver();

        logger.info("WebDriver initialized for scenario: {}", scenario.getName());

        // Reset TestContext
        TestContext.getInstance().reset();
    }

    /**
     * After hook - executed after each scenario.
     *
     * @param scenario Cucumber scenario
     */
    @After
    public void afterScenario(Scenario scenario) {
        logger.info("========================================");
        logger.info("Finished Scenario: {}", scenario.getName());
        logger.info("Status: {}", scenario.getStatus());
        logger.info("========================================");

        // Capture screenshot on failure
        if (scenario.isFailed()) {
            captureScreenshot(scenario);
        }

        // Quit WebDriver
        if (driverManager != null && driverManager.hasDriver()) {
            logger.info("Quitting WebDriver for scenario: {}", scenario.getName());
            driverManager.quitDriver();
        }

        // Clear TestContext
        TestContext.clear();
    }

    /**
     * Captures screenshot and embeds in Cucumber report.
     *
     * @param scenario Cucumber scenario
     */
    private void captureScreenshot(Scenario scenario) {
        try {
            if (driverManager != null && driverManager.hasDriver()) {
                byte[] screenshot = ((org.openqa.selenium.TakesScreenshot) driverManager.getDriver())
                        .getScreenshotAs(org.openqa.selenium.OutputType.BYTES);

                scenario.attach(screenshot, "image/png", scenario.getName() + "_failure");
                logger.info("Screenshot captured for failed scenario: {}", scenario.getName());
            }
        } catch (Exception e) {
            logger.error("Failed to capture screenshot: {}", e.getMessage());
        }
    }
}
