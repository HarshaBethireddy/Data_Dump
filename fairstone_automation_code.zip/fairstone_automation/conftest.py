"""
conftest.py  (project root)
───────────────────────────
Root-level pytest fixtures and plugin hooks.

Key fixtures
────────────
browser / page         — provided by pytest-playwright
login_page             — LoginPage opened at base URL
home_page              — HomePage POM
search_page            — SearchPage POM
customer_overview_page — CustomerOverviewPage POM
account_activity_page  — AccountActivityPage POM
logged_in_page         — page already authenticated as home page

Shared-state fixtures (pass data between BDD steps)
────────────────────────────────────────────────────
search_context         — stores last-searched account number so the
                         account-click step can match by ACCT_REFERENCE_SPAN
activity_context       — stores the FrameLocator of the opened iframe
                         so fill/ok/cancel steps can reuse it

Resolver fixtures (return the currently-active page at runtime)
───────────────────────────────────────────────────────────────
resolve_activities_page — returns CustomerOverviewPage or AccountActivityPage
                          depending on which is currently loaded;
                          used by shared activities_steps.py so the same
                          step text works on both pages

resolve_accordion_page  — same pattern for accordion_steps.py
"""
from __future__ import annotations

import pytest
from playwright.sync_api import Page

from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.search_page import SearchPage
from pages.search_modal_page import SearchModalPage
from pages.customer_overview_page import CustomerOverviewPage
from pages.account_activity_page import AccountActivityPage
from pages.person_profile_page import PersonProfilePage
from pages.admin_popover_page import AdminPopoverPage
from pages.reference_interfaces_page import ReferenceInterfacesPage
from utils.config import Config
from utils.logger import get_logger
from utils.report_generator import ReportGenerator
from utils.run_step_log import RunStepLog
from utils.screenshot_helper import ScreenshotHelper

log = get_logger(__name__)


# ──────────────────────────────────────────────────────────────
# Shared per-run step log singleton
# ──────────────────────────────────────────────────────────────
# A session-scoped fixture instance is not directly reachable from the
# pytest_sessionfinish hook, so the single shared RunStepLog for the run is
# held here as a module-level singleton. Both the session-scoped `run_step_log`
# fixture and the `pytest_sessionfinish` report hook reference this SAME
# instance, guaranteeing the report is built from exactly the entries recorded
# during the run (Requirements 9.9, 9.10, 10.1).
_RUN_STEP_LOG = RunStepLog()


# ──────────────────────────────────────────────────────────────
# Shared state objects (mutable, injected into step functions)
# ──────────────────────────────────────────────────────────────

class SearchContext:
    """Holds the last account number submitted via the search form."""
    def __init__(self) -> None:
        self.last_account_number: str = ""


class ActivityContext:
    """Holds the FrameLocator returned by wait_for_activity_iframe()."""
    def __init__(self) -> None:
        self.frame_loc = None


class AdminContext:
    """
    Holds state shared between Admin / Reference Interfaces steps.
    prefix      — safe screenshot prefix derived from the selected option name
    option_name — full option name as passed to the dropdown
    current_code — the Code value of the record currently being acted on
    last_description — the Description value last entered/acted on
    last_code — the Code value last entered/acted on
    prior_description — the previous Description value (e.g. before an edit)
    """
    def __init__(self) -> None:
        self.prefix: str = ""
        self.option_name: str = ""
        self.current_code: str = ""
        self.last_description: str = ""
        self.last_code: str = ""
        self.prior_description: str = ""


# ──────────────────────────────────────────────────────────────
# Playwright browser configuration
# ──────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def browser_type_launch_args(browser_type_launch_args: dict) -> dict:
    Config.validate()
    log.info(Config.summary())
    return {
        **browser_type_launch_args,
        "headless": Config.HEADLESS,
        "slow_mo": Config.SLOW_MO,
    }


@pytest.fixture(scope="session")
def browser_context_args(browser_context_args: dict) -> dict:
    return {
        **browser_context_args,
        "viewport": {"width": 1440, "height": 900},
        "ignore_https_errors": True,
    }


# ──────────────────────────────────────────────────────────────
# Page Object fixtures
# ──────────────────────────────────────────────────────────────

# @pytest.fixture()
# def login_page(page: Page) -> LoginPage:
#     lp = LoginPage(page)
#     lp.open()
#     return lp
@pytest.fixture()
def login_page(
    page: Page,
    run_step_log: RunStepLog,
) -> LoginPage:
    lp = LoginPage(page)
    lp.run_step_log = run_step_log
    lp.open()
    return lp


# @pytest.fixture()
# def home_page(page: Page) -> HomePage:
#     return HomePage(page)
@pytest.fixture()
def home_page(
    page: Page,
    run_step_log: RunStepLog,
) -> HomePage:
    page_obj = HomePage(page)
    page_obj.run_step_log = run_step_log
    return page_obj


# @pytest.fixture()
# def search_page(page: Page) -> SearchPage:
#     return SearchPage(page)
@pytest.fixture()
def search_page(
    page: Page,
    run_step_log: RunStepLog,
) -> SearchPage:
    page_obj = SearchPage(page)
    page_obj.run_step_log = run_step_log
    return page_obj



# @pytest.fixture()
# def search_modal_page(page: Page) -> SearchModalPage:
#     return SearchModalPage(page)
@pytest.fixture()
def search_modal_page(
    page: Page,
    run_step_log: RunStepLog,
) -> SearchModalPage:
    page_obj = SearchModalPage(page)
    page_obj.run_step_log = run_step_log
    return page_obj


@pytest.fixture(scope="session")
def run_step_log() -> RunStepLog:
    """
    Session-scoped ordered log of screenshot steps captured during the run.

    Returns the module-level shared :data:`_RUN_STEP_LOG` so every scenario
    appends to the same ordered log (Requirements 9.9, 9.10) and the
    ``pytest_sessionfinish`` report hook can build the per-run report from the
    exact same instance. It is injected into the Customer Overview and Account
    Activity page objects so the ActivitiesMixin's record_screenshot writes to
    this same log. The per-run Word report is generated from these entries at
    session end.
    """
    return _RUN_STEP_LOG


@pytest.fixture()
def customer_overview_page(
    page: Page, run_step_log: RunStepLog
) -> CustomerOverviewPage:
    page_obj = CustomerOverviewPage(page)
    page_obj.run_step_log = run_step_log
    return page_obj


@pytest.fixture()
def account_activity_page(
    page: Page, run_step_log: RunStepLog
) -> AccountActivityPage:
    page_obj = AccountActivityPage(page)
    page_obj.run_step_log = run_step_log
    return page_obj


# @pytest.fixture()
# def person_profile_page(page: Page) -> PersonProfilePage:
#     return PersonProfilePage(page)
@pytest.fixture()
def person_profile_page(
    page: Page,
    run_step_log: RunStepLog,
) -> PersonProfilePage:
    page_obj = PersonProfilePage(page)
    page_obj.run_step_log = run_step_log
    return page_obj



# @pytest.fixture()
# def admin_popover_page(page: Page) -> AdminPopoverPage:
#     return AdminPopoverPage(page)
@pytest.fixture()
def admin_popover_page(
    page: Page,
    run_step_log: RunStepLog,
) -> AdminPopoverPage:
    page_obj = AdminPopoverPage(page)
    page_obj.run_step_log = run_step_log
    return page_obj


@pytest.fixture()
def reference_interfaces_page(
    page: Page, run_step_log: RunStepLog
) -> ReferenceInterfacesPage:
    page_obj = ReferenceInterfacesPage(page)
    page_obj.run_step_log = run_step_log
    return page_obj


@pytest.fixture()
def logged_in_page(login_page: LoginPage, home_page: HomePage) -> HomePage:
    login_page.login()
    home_page.wait_until_loaded()
    return home_page


# ──────────────────────────────────────────────────────────────
# Shared-state fixtures
# ──────────────────────────────────────────────────────────────

@pytest.fixture()
def search_context() -> SearchContext:
    """Scenario-scoped: search step writes, click step reads last account number."""
    return SearchContext()


@pytest.fixture()
def activity_context() -> ActivityContext:
    """Scenario-scoped: wait_for_iframe step writes FrameLocator for reuse."""
    return ActivityContext()


@pytest.fixture()
def admin_context() -> AdminContext:
    """
    Scenario-scoped: carries the screenshot prefix and current code
    between Admin / Reference Interfaces steps so they stay in sync.
    """
    return AdminContext()


# ──────────────────────────────────────────────────────────────
# Resolver fixtures — return the currently-active page at call time
# ──────────────────────────────────────────────────────────────

@pytest.fixture()
def resolve_activities_page(
    customer_overview_page: CustomerOverviewPage,
    account_activity_page: AccountActivityPage,
):
    """
    Returns a zero-argument callable that, when called inside a step,
    inspects which page is currently loaded in the browser and returns
    the correct page object.

    Both CustomerOverviewPage and AccountActivityPage inherit ActivitiesMixin,
    so the returned object always has click_activities_sidebar_tab(),
    click_activity(), wait_for_activity_iframe(), etc.

    Why a callable rather than the page directly?
    The fixture is resolved at test-setup time, before any steps run and
    before any page has loaded.  Returning a factory lets the resolution
    happen at step-execution time when the browser state is known.
    """
    def _resolve():
        if customer_overview_page.page.locator(
            customer_overview_page.PAGE_ROOT
        ).count() > 0:
            return customer_overview_page

        if account_activity_page.page.locator(
            account_activity_page.PAGE_ROOT
        ).count() > 0:
            return account_activity_page
        raise RuntimeError(
            "resolve_activities_page: neither Customer Overview nor "
            "Account Activity page is currently loaded in the browser."
        )
    return _resolve


@pytest.fixture()
def resolve_accordion_page(
    customer_overview_page: CustomerOverviewPage,
    account_activity_page: AccountActivityPage,
):
    """
    Same pattern as resolve_activities_page but for accordion steps.
    Both pages inherit AccordionMixin so accordion steps work identically
    on both without any duplicated step code.
    """
    def _resolve():
        if account_activity_page.is_loaded():
            return account_activity_page
        if customer_overview_page.is_loaded():
            return customer_overview_page
        raise RuntimeError(
            "resolve_accordion_page: neither Customer Overview nor "
            "Account Activity page is currently loaded in the browser."
        )
    return _resolve


# ──────────────────────────────────────────────────────────────
# Auto-screenshot on failure / pass
# ──────────────────────────────────────────────────────────────

@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):  # noqa: ANN001
    outcome = yield
    report = outcome.get_result()

    if report.when == "call" and report.failed:
        page: Page | None = item.funcargs.get("page")
        if page is not None:
            test_name = item.nodeid.replace("::", "_").replace("/", "_")
            path = ScreenshotHelper.capture_on_failure(page, test_name)
            if path:
                try:
                    from pytest_html import extras  # type: ignore
                    report.extra = getattr(report, "extra", [])
                    report.extra.append(extras.image(str(path)))
                except ImportError:
                    pass

    if report.when == "call" and report.passed:
        page = item.funcargs.get("page")
        if page is not None:
            test_name = item.nodeid.replace("::", "_").replace("/", "_")
            ScreenshotHelper.capture_on_pass(page, test_name)


# ──────────────────────────────────────────────────────────────
# Per-run report generation
# ──────────────────────────────────────────────────────────────

def pytest_sessionfinish(session, exitstatus):  # noqa: ANN001
    """
    Generate exactly one per-run Word report at the end of the test session.

    Runs regardless of pass/fail (``exitstatus`` is accepted but not gated on)
    so a Run_Report is always produced (Requirement 10.1). The shared
    :data:`_RUN_STEP_LOG` populated by the ActivitiesMixin during the run is the
    single source of truth for the report's contents.

    The whole call is wrapped so that a single bad entry or a docx/write failure
    does not crash session teardown: any error is logged and swallowed instead
    of propagating out of the hook.
    """
    try:
        report_path = ReportGenerator.generate(_RUN_STEP_LOG)
        log.info("Per-run activity report generated: %s", report_path)
    except Exception as exc:  # noqa: BLE001 - teardown must never crash the run
        log.error("Failed to generate the per-run activity report: %s", exc)


# ──────────────────────────────────────────────────────────────
# Step-definition module discovery
# ──────────────────────────────────────────────────────────────

pytest_plugins = [
    "steps.common_steps",
    "steps.login_steps",
    "steps.navigation_steps",
    "steps.search_steps",
    "steps.customer_overview_steps",
    "steps.account_activity_steps",
    "steps.activities_steps",     # shared — Activities sidebar + iframe
    "steps.accordion_steps",      # shared — generalized accordion by name
    "steps.search_modal_steps",   # search modal — all 5 tabs
    "steps.admin_steps",          # admin nav + reference interfaces CRUD
    "steps.person_profile_steps", # person profile page
]
