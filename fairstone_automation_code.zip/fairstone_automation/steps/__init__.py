"""BDD step definitions for the Collections automation framework."""
