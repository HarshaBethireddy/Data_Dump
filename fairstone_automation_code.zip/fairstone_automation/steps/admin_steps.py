"""
steps/admin_steps.py
─────────────────────
Step definitions for features/admin.feature.

Covers:
  • Generic primary nav click by label
  • Admin popover item click
  • Reference Interfaces page: dropdown, Add/Edit/Delete with screenshots
"""
from __future__ import annotations

import pytest
from pytest_bdd import step, when, then, parsers

from pages.home_page import HomePage
from pages.admin_popover_page import AdminPopoverPage
from pages.reference_interfaces_page import ReferenceInterfacesPage
from utils.logger import get_logger

log = get_logger(__name__)


# ──────────────────────────────────────────────────────────────
# When — generic nav
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('I click the "{label}" nav item'))
def click_nav_item(home_page: HomePage, label: str) -> None:
    """
    Click any primary nav item by its aria-label.
    Works for: Search, Load Next, View Caselists, Admin, Pending cases
    """
    log.info("Step: clicking nav item '%s'", label)
    home_page.click_nav_item(label)


# ──────────────────────────────────────────────────────────────
# When — Admin popover
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('I click "{item_name}" in the Admin popover'))
def click_admin_popover_item(
    admin_popover_page: AdminPopoverPage,
    item_name: str,
) -> None:
    """
    Click an item in the Admin popover by its visible text.
    Valid item names: "Reference Interfaces", "Teams"
    """
    log.info("Step: clicking Admin popover item '%s'", item_name)
    admin_popover_page.wait_until_open()
    admin_popover_page.click_item(item_name)


# ──────────────────────────────────────────────────────────────
# When — Reference Interfaces page
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('I select reference type "{option_name}"'))
def select_reference_type(
    reference_interfaces_page: ReferenceInterfacesPage,
    option_name: str,
    admin_context,
) -> None:
    """
    Select a reference type from the dropdown.
    Stores the safe prefix in admin_context for all subsequent steps.

    Available options: Bankruptcy Types, Batch Outbound Config,
    Batch Task Config, Branch Update, DCA Marketshare, Product,
    Settlement Campaign, Settlement Paramters, Solution Parameters,
    UpdateDisasterCodes
    """
    log.info("Step: selecting reference type '%s'", option_name)
    reference_interfaces_page.wait_until_loaded()
    prefix = reference_interfaces_page.select_reference_type(option_name)
    admin_context.prefix = prefix
    admin_context.option_name = option_name


# ── Add flow ──────────────────────────────────────────────────

@step(parsers.parse('I click the Add button on the Reference Interfaces page'))
def click_add_button(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
) -> None:
    log.info("Step: clicking Add button")
    reference_interfaces_page.click_add_button(admin_context.prefix)


@step(parsers.parse('I fill the Add modal field "{label}" with "{value}"'))
def fill_add_modal_field(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
    label: str,
    value: str,
) -> None:
    log.info("Step: filling Add modal field '%s' = '%s'", label, value)
    reference_interfaces_page.fill_modal_field(label, value)
    # Store entered values into AdminContext for later verification steps.
    if label == "Code":
        admin_context.last_code = value
    elif label == "Description":
        admin_context.last_description = value


@step("I save the Add modal")
def save_add_modal(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
) -> None:
    log.info("Step: saving Add modal")
    reference_interfaces_page.save_add_modal(admin_context.prefix)


# ── Edit flow ─────────────────────────────────────────────────

@step(parsers.parse('I open the Edit modal for code "{code}"'))
def open_edit_modal(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
    code: str,
) -> None:
    log.info("Step: opening Edit modal for Code='%s'", code)
    admin_context.current_code = code
    reference_interfaces_page.open_edit_modal(code, admin_context.prefix)


@step(parsers.parse('I fill the Edit modal field "{label}" with "{value}"'))
def fill_edit_modal_field(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
    label: str,
    value: str,
) -> None:
    log.info("Step: filling Edit modal field '%s' = '%s'", label, value)
    # For edits, capture the prior Description before overwriting so a
    # cancel-with-verify can confirm the original value was preserved.
    if label == "Description":
        admin_context.prior_description = (
            reference_interfaces_page.get_modal_field_value(label)
        )
    reference_interfaces_page.fill_modal_field(label, value)
    # Store entered values into AdminContext for later verification steps.
    if label == "Code":
        admin_context.last_code = value
    elif label == "Description":
        admin_context.last_description = value


@step("I save the Edit modal")
def save_edit_modal(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
) -> None:
    log.info("Step: saving Edit modal")
    reference_interfaces_page.save_edit_modal(admin_context.prefix)


# ── Delete flow ───────────────────────────────────────────────

@step(parsers.parse('I open the Delete modal for code "{code}"'))
def open_delete_modal(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
    code: str,
) -> None:
    log.info("Step: opening Delete modal for Code='%s'", code)
    admin_context.current_code = code
    reference_interfaces_page.open_delete_modal(code, admin_context.prefix)


@step("I click Delete in the modal")
def click_delete(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
) -> None:
    log.info("Step: clicking Delete in modal")
    reference_interfaces_page.click_delete(admin_context.prefix)


@step("I cancel the modal")
def cancel_modal(reference_interfaces_page: ReferenceInterfacesPage) -> None:
    log.info("Step: cancelling modal")
    reference_interfaces_page.cancel_modal()


@step(parsers.parse('I cancel the Add modal entering code "{code}"'))
def cancel_add_modal_entering_code(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
    code: str,
) -> None:
    """
    Fill the Code field, capture pre-state, then cancel the Add modal and
    verify the entered code was not persisted to the grid.
    """
    log.info("Step: cancelling Add modal entering Code='%s'", code)
    reference_interfaces_page.fill_modal_field("Code", code)
    admin_context.last_code = code
    admin_context.current_code = code
    reference_interfaces_page.cancel_with_verify_add(code)


@step("I delete the record that was added")
def delete_added_record(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
) -> None:
    """Open the Delete modal for the added/current code and confirm deletion."""
    log.info("Step: deleting the added record Code='%s'", admin_context.current_code)
    reference_interfaces_page.delete_added_record(admin_context.current_code)


# ──────────────────────────────────────────────────────────────
# Then — assertions
# ──────────────────────────────────────────────────────────────

@step("I should be on the Reference Interfaces page")
def assert_on_reference_interfaces(
    reference_interfaces_page: ReferenceInterfacesPage,
) -> None:
    log.info("Step: asserting Reference Interfaces page")
    reference_interfaces_page.wait_until_loaded()
    reference_interfaces_page.assert_on_reference_interfaces()


@step(parsers.parse('the record with code "{code}" should be present in the grid'))
def assert_record_present(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
    code: str,
) -> None:
    log.info("Step: asserting record Code='%s' present", code)
    reference_interfaces_page.assert_row_present(
        code, prefix=f"{admin_context.prefix}_add"
    )


@step(parsers.parse('the record with code "{code}" should show description "{description}"'))
def assert_record_description(
    reference_interfaces_page: ReferenceInterfacesPage,
    code: str,
    description: str,
) -> None:
    log.info("Step: asserting Code='%s' has description '%s'", code, description)
    reference_interfaces_page.assert_cell_value(code, col=2, expected=description)


@step(parsers.parse('the record with code "{code}" should not be present in the grid'))
def assert_record_absent(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
    code: str,
) -> None:
    log.info("Step: asserting record Code='%s' absent", code)
    reference_interfaces_page.assert_row_absent(
        code, prefix=f"{admin_context.prefix}_delete"
    )


@step("the Admin popover should be open")
def assert_admin_popover_open(admin_popover_page: AdminPopoverPage) -> None:
    log.info("Step: asserting Admin popover open")
    admin_popover_page.assert_popover_open()


@step("the added record should be present with its entered description")
def assert_added_record_present(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
) -> None:
    log.info(
        "Step: asserting added record Code='%s' present with description '%s'",
        admin_context.last_code,
        admin_context.last_description,
    )
    reference_interfaces_page.search_and_verify_added(
        admin_context.last_code, admin_context.last_description
    )


@step("the edited record should show the updated description")
def assert_edited_record_updated(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
) -> None:
    log.info(
        "Step: asserting edited record Code='%s' shows description '%s'",
        admin_context.last_code,
        admin_context.last_description,
    )
    reference_interfaces_page.verify_edit(
        admin_context.last_code, admin_context.last_description
    )


@step("the deleted record should be absent from the grid")
def assert_deleted_record_absent(
    reference_interfaces_page: ReferenceInterfacesPage,
    admin_context,
) -> None:
    code = admin_context.current_code or admin_context.last_code
    log.info("Step: asserting deleted record Code='%s' absent", code)
    reference_interfaces_page.verify_deleted(code)
