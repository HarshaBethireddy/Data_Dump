"""
steps/account_activity_steps.py
─────────────────────────────────
Step definitions specific to features/account_activity.feature.

Activities sidebar + iframe  → steps/activities_steps.py  (shared)
Accordion scroll/assert      → steps/accordion_steps.py   (shared)
"""
from __future__ import annotations

from pytest_bdd import step, when, then, parsers

from pages.account_activity_page import AccountActivityPage
from pages.customer_overview_page import CustomerOverviewPage
from utils.logger import get_logger

log = get_logger(__name__)


# ──────────────────────────────────────────────────────────────
# When steps
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('I switch the account view to "{option}"'))
def switch_account_view(account_activity_page: AccountActivityPage, option: str) -> None:
    log.info("Step: switching account view to '%s'", option)
    account_activity_page.switch_view(option)


@step("I click the Activity History button")
def click_activity_history(account_activity_page: AccountActivityPage) -> None:
    log.info("Step: clicking Activity History button")
    account_activity_page.click_activity_history_button()


@step("I click the Account button")
def click_account_btn(account_activity_page: AccountActivityPage) -> None:
    log.info("Step: clicking Account button")
    account_activity_page.click_account_button()


@step("I click the Customer Overview tab from the account page")
def go_back_to_customer_overview(
    account_activity_page: AccountActivityPage,
    customer_overview_page: CustomerOverviewPage,
) -> None:
    log.info("Step: navigating back to Customer Overview")
    account_activity_page.click_customer_overview_tab()
    customer_overview_page.wait_until_loaded()


@step("I close the account tab")
def close_account_tab(
    account_activity_page: AccountActivityPage,
    customer_overview_page: CustomerOverviewPage,
) -> None:
    log.info("Step: closing active account tab")
    account_activity_page.close_account_tab()
    customer_overview_page.wait_until_loaded()


# ──────────────────────────────────────────────────────────────
# Then steps
# ──────────────────────────────────────────────────────────────

@step("I should be on the Account Activity page")
def assert_on_account_activity(account_activity_page: AccountActivityPage) -> None:
    log.info("Step: asserting Account Activity page loaded")
    account_activity_page.assert_on_account_activity()


@step("the active tab should correspond to the clicked account")
def assert_active_tab_matches(
    account_activity_page: AccountActivityPage,
    search_context,
) -> None:
    expected = search_context.last_account_number
    log.info("Step: asserting active tab matches '%s'", expected)
    if expected:
        account_activity_page.assert_account_number_in_tab(expected)
    else:
        account_activity_page.assert_tertiary_account_tab_active()


@step("the Account and Activity History action buttons should be visible")
def assert_action_buttons(account_activity_page: AccountActivityPage) -> None:
    log.info("Step: asserting action buttons visible")
    account_activity_page.assert_action_buttons_visible()


@step("the calendar widget should be visible")
def assert_calendar(account_activity_page: AccountActivityPage) -> None:
    log.info("Step: asserting calendar widget visible")
    account_activity_page.assert_calendar_visible()


@step(parsers.parse('the field "{label}" should have value "{expected_value}"'))
def assert_field_value(
    account_activity_page: AccountActivityPage,
    label: str,
    expected_value: str,
) -> None:
    log.info("Step: asserting field '%s' = '%s'", label, expected_value)
    actual = account_activity_page.get_field_value(label)
    assert actual == expected_value, (
        f"Field '{label}': expected '{expected_value}', got '{actual}'"
    )
