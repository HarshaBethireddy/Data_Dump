"""
steps/common_steps.py
─────────────────────
Shared / reusable step definitions used across multiple feature files.
"""
from __future__ import annotations

import pytest
from pytest_bdd import step, when, then, parsers
from playwright.sync_api import Page

from pages.login_page import LoginPage
from pages.home_page import HomePage
from utils.config import Config
from utils.logger import get_logger

log = get_logger(__name__)


# ──────────────────────────────────────────────────────────────
# Background steps
# ──────────────────────────────────────────────────────────────

@step("I open the Collections login page")
def open_login_page(page: Page, login_page: LoginPage) -> None:
    """Open the app at base URL — login_page fixture handles this."""
    log.info("Step: I open the Collections login page")


@step("I am logged in to the Collections application")
def logged_in(page: Page, logged_in_page: HomePage) -> None:
    """Login + wait for home page — logged_in_page fixture handles this."""
    log.info("Step: I am logged in to the Collections application")


# ──────────────────────────────────────────────────────────────
# Misc shared steps
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('I wait for {seconds:d} seconds'))
def wait_seconds(page: Page, seconds: int) -> None:
    page.wait_for_timeout(seconds * 1_000)


@step(parsers.parse('the page title should contain "{text}"'))
def assert_title_contains(page: Page, text: str) -> None:
    from playwright.sync_api import expect
    expect(page).to_have_title(f".*{text}.*")
