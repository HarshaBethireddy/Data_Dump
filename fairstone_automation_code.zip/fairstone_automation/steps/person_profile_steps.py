"""
steps/person_profile_steps.py
────────────────────────────
Step definitions for features/person_profile.feature.

Covers navigation to Person Profile page and verification of:
  • Page load
  • Tertiary tab active
  • Contact Details visibility
  • Accordion expansion (with screenshots)
"""

from __future__ import annotations

from pytest_bdd import step, then, parsers

from pages.customer_overview_page import CustomerOverviewPage
from pages.person_profile_page import PersonProfilePage
from utils.logger import get_logger

log = get_logger(__name__)


# ──────────────────────────────────────────────────────────────
# When — navigation to Person Profile
# ──────────────────────────────────────────────────────────────

@step("I open the Person Profile page from Customer Overview")
def open_person_profile(
    customer_overview_page: CustomerOverviewPage,
    person_profile_page: PersonProfilePage,
) -> None:
    log.info("Step: navigating to Person Profile page")
    customer_overview_page.click_person_profile_tab()
    person_profile_page.wait_until_loaded()


# ──────────────────────────────────────────────────────────────
# Then — page assertions
# ──────────────────────────────────────────────────────────────

@step("I should be on the Person Profile page")
def assert_person_profile_loaded(person_profile_page: PersonProfilePage) -> None:
    log.info("Step: asserting Person Profile page loaded")
    person_profile_page.assert_on_person_profile()


@step("the Person Profile tab should be active")
def assert_tab_active(person_profile_page: PersonProfilePage) -> None:
    log.info("Step: asserting Person Profile tab active")
    person_profile_page.assert_person_profile_tab_active()


@step("the Contact Details section should be visible")
def assert_contact_details(person_profile_page: PersonProfilePage) -> None:
    log.info("Step: asserting Contact Details visible")
    person_profile_page.assert_contact_details_visible()


@step("all contact detail panels should be visible")
def assert_all_panels(person_profile_page: PersonProfilePage) -> None:
    log.info("Step: asserting all contact panels visible")
    person_profile_page.assert_all_contact_panels_visible()


# ──────────────────────────────────────────────────────────────
# When — expand panels (with screenshots)
# ──────────────────────────────────────────────────────────────

@step("I expand all Person Profile contact panels")
def expand_all_panels(person_profile_page: PersonProfilePage) -> None:
    log.info("Step: expanding all contact panels")
    person_profile_page.expand_all_contact_details()


@step(parsers.parse('I expand the "{panel_name}" panel in Person Profile'))
def expand_single_panel(
    person_profile_page: PersonProfilePage, panel_name: str
) -> None:
    name = f" {panel_name.strip()} "
    log.info("Step: expanding panel '%s'", panel_name)
    person_profile_page.expand_contact_detail(name)


# ──────────────────────────────────────────────────────────────
# Then — verify panel expansion
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('the "{panel_name}" panel should be expanded'))
def assert_panel_expanded(
    person_profile_page: PersonProfilePage, panel_name: str
) -> None:
    name = f" {panel_name.strip()} "
    log.info("Step: asserting panel '%s' expanded", panel_name)
    person_profile_page.assert_contact_panel_expanded(name)