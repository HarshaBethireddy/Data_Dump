"""
steps/accordion_steps.py
─────────────────────────
Single shared step definitions for accordion interaction.

Works on both the Customer Overview page (Treatment, Hardship)
and the Account Activity page (Customer Overview, Payments,
Delinquency Information, Recent Communication, Exceptions, Treatment).

The `resolve_accordion_page` fixture (conftest.py) returns whichever
page is currently active so the same step text works everywhere.

Feature files use the SAME step text regardless of which page they are on:
    When I scroll to the "Payments" accordion
    Then the "Payments" accordion should be visible
    Then these accordions should be visible: "Customer Overview, Payments, Treatment"
    Then the field "Days Past Due" in the "Delinquency Information" accordion should be visible
"""
from __future__ import annotations

from pytest_bdd import step, step, parsers

from utils.logger import get_logger

log = get_logger(__name__)


# ──────────────────────────────────────────────────────────────
# When steps
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('I scroll to the "{name}" accordion'))
def scroll_to_accordion(resolve_accordion_page, name: str) -> None:
    """
    Scroll the named accordion into view and take a screenshot.
    Works on both Customer Overview and Account Activity pages.
    """
    page_obj = resolve_accordion_page()
    log.info(
        "Step: scrolling to '%s' accordion on %s",
        name, type(page_obj).__name__,
    )
    page_obj.scroll_to_accordion(name)


@step(parsers.parse('I expand the "{name}" accordion'))
def expand_accordion(resolve_accordion_page, name: str) -> None:
    page_obj = resolve_accordion_page()
    log.info("Step: expanding accordion '%s'", name)
    page_obj.expand_accordion(name)


@step(parsers.parse('I collapse the "{name}" accordion'))
def collapse_accordion(resolve_accordion_page, name: str) -> None:
    page_obj = resolve_accordion_page()
    log.info("Step: collapsing accordion '%s'", name)
    page_obj.collapse_accordion(name)


# ──────────────────────────────────────────────────────────────
# Then steps
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('the "{name}" accordion should be visible'))
def assert_accordion_visible(resolve_accordion_page, name: str) -> None:
    page_obj = resolve_accordion_page()
    log.info(
        "Step: asserting '%s' accordion visible on %s",
        name, type(page_obj).__name__,
    )
    page_obj.assert_accordion_visible(name)


@step(parsers.parse('these accordions should be visible: "{names_csv}"'))
def assert_multiple_accordions(resolve_accordion_page, names_csv: str) -> None:
    """
    Assert multiple accordions are visible using a comma-separated list.
    Example step:
        Then these accordions should be visible: "Customer Overview, Payments, Treatment"
    """
    page_obj = resolve_accordion_page()
    names = [n.strip() for n in names_csv.split(",")]
    log.info(
        "Step: asserting %d accordions visible on %s: %s",
        len(names), type(page_obj).__name__, names,
    )
    page_obj.assert_accordions_visible(names)


@step(
    parsers.parse(
        'the field "{field_label}" in the "{accordion_name}" accordion should be visible'
    )
)
def assert_field_in_accordion_visible(
    resolve_accordion_page, field_label: str, accordion_name: str
) -> None:
    page_obj = resolve_accordion_page()
    log.info(
        "Step: asserting field '%s' visible in '%s' accordion",
        field_label, accordion_name,
    )
    # Scroll to bring the accordion into view first
    page_obj.scroll_to_accordion(accordion_name)
    # Then assert the field value cell exists (non-empty means visible)
    value = page_obj.get_field_in_accordion(accordion_name, field_label)
    assert value is not None, (
        f"Field '{field_label}' not found in '{accordion_name}' accordion"
    )


@step(
    parsers.parse(
        'the field "{field_label}" in the "{accordion_name}" accordion should have value "{expected}"'
    )
)
def assert_field_value_in_accordion(
    resolve_accordion_page,
    field_label: str,
    accordion_name: str,
    expected: str,
) -> None:
    page_obj = resolve_accordion_page()
    log.info(
        "Step: asserting '%s' in '%s' = '%s'",
        field_label, accordion_name, expected,
    )
    page_obj.assert_field_value_in_accordion(accordion_name, field_label, expected)
