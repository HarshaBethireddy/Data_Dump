"""
steps/search_modal_steps.py
────────────────────────────
Step definitions for features/search_modal.feature.

Screenshot contract (enforced by the page object and steps):
  1. Clicking a tab     → screenshot taken inside click_tab()  (before fill)
  2. "I take a screenshot of the filled form"  → explicit step (after fill)
  3. "I submit the search modal"               → screenshot taken inside submit_search()

Partial inputs:
  Every fill step accepts a value that may be None/empty — the field is
  simply skipped.  This matches the requirement that "sometimes I may also
  provide partial inputs".  Use individual "I fill field … with …" steps
  to fill only what you want.

Destination pages after search:
  Account Search         → Customer Overview page
  Advanced Account Search → Customer Overview page
  Customer Search        → Customer Overview page
  Contact Search         → Person Profile page (tertiary nav active)
  Contact Search FS      → Person Profile page (tertiary nav active)
"""
from __future__ import annotations

from pytest_bdd import step, when, then, parsers

from pages.home_page import HomePage
from pages.search_modal_page import SearchModalPage
from pages.customer_overview_page import CustomerOverviewPage
from pages.person_profile_page import PersonProfilePage
from utils.logger import get_logger

log = get_logger(__name__)


# ──────────────────────────────────────────────────────────────
# Given — open the modal
# ──────────────────────────────────────────────────────────────

@step("I click the Search nav button")
def click_search_nav(home_page: HomePage, search_modal_page: SearchModalPage) -> None:
    """Click the Search icon in the header nav to open the search modal."""
    log.info("Step: clicking Search nav button")
    home_page.click_search_nav_button()
    search_modal_page.wait_until_open()


# ──────────────────────────────────────────────────────────────
# When — tab selection
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('I click the "{tab_name}" tab in the search modal'))
def click_search_modal_tab(
    search_modal_page: SearchModalPage, tab_name: str
) -> None:
    """
    Click the named tab in the search modal.
    A screenshot is automatically taken by click_tab() — this is the
    "before filling" screenshot required by the spec.
    """
    log.info("Step: clicking search modal tab '%s'", tab_name)
    search_modal_page.click_tab(tab_name)


# ──────────────────────────────────────────────────────────────
# When — generic per-field fill (works in any tab, partial input)
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('I fill field "{field_label}" with "{value}" in the modal'))
def fill_modal_field(
    search_modal_page: SearchModalPage, field_label: str, value: str
) -> None:
    """
    Fill a single modal input by its aria-label.
    Works in any tab.  Skips silently if value is empty.
    """
    log.info("Step: filling modal field '%s' = '%s'", field_label, value)
    search_modal_page.fill_field(field_label, value)


# ──────────────────────────────────────────────────────────────
# When — take screenshot after filling (explicit, before submit)
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('I take a screenshot of the filled "{tab_name}" form'))
def screenshot_filled_form(
    search_modal_page: SearchModalPage, tab_name: str
) -> None:
    """
    Capture the modal form after all fields have been filled.
    This is the "after filling" screenshot required by the spec.
    """
    log.info("Step: taking screenshot of filled form — tab '%s'", tab_name)
    search_modal_page.screenshot_filled_form(tab_name)


# ──────────────────────────────────────────────────────────────
# When — convenience all-in-one fill steps per tab
# ──────────────────────────────────────────────────────────────

@step(
    parsers.parse(
        'I fill the Account Search form with account number "{account_number}"'
    )
)
def fill_account_search_by_account(
    search_modal_page: SearchModalPage, account_number: str
) -> None:
    log.info("Step: filling Account Search with account number '%s'", account_number)
    search_modal_page.fill_account_search(account_number=account_number)
    search_modal_page.screenshot_filled_form("Account Search")


@step(
    parsers.parse(
        'I fill the Account Search form with phone number "{phone_number}"'
    )
)
def fill_account_search_by_phone(
    search_modal_page: SearchModalPage, phone_number: str
) -> None:
    log.info("Step: filling Account Search with phone number '%s'", phone_number)
    search_modal_page.fill_account_search(phone_number=phone_number)
    search_modal_page.screenshot_filled_form("Account Search")


@step(
    parsers.parse(
        'I fill the Account Search form with account number "{account_number}" '
        'and phone number "{phone_number}"'
    )
)
def fill_account_search_full(
    search_modal_page: SearchModalPage,
    account_number: str,
    phone_number: str,
) -> None:
    log.info(
        "Step: filling Account Search — account='%s' phone='%s'",
        account_number, phone_number,
    )
    search_modal_page.fill_account_search(
        account_number=account_number, phone_number=phone_number
    )
    search_modal_page.screenshot_filled_form("Account Search")


@step(
    parsers.parse(
        'I fill the Advanced Account Search form with account number "{account_number}"'
    )
)
def fill_advanced_account_search_by_account(
    search_modal_page: SearchModalPage, account_number: str
) -> None:
    log.info("Step: filling Advanced Account Search with account '%s'", account_number)
    search_modal_page.fill_advanced_account_search(account_number=account_number)
    search_modal_page.screenshot_filled_form("Advanced Account Search")


@step(
    parsers.parse(
        'I fill the Advanced Account Search form with first name "{first_name}" '
        'and last name "{last_name}"'
    )
)
def fill_advanced_account_search_by_name(
    search_modal_page: SearchModalPage, first_name: str, last_name: str
) -> None:
    log.info(
        "Step: filling Advanced Account Search — name='%s %s'",
        first_name, last_name,
    )
    search_modal_page.fill_advanced_account_search(
        first_name=first_name, last_name=last_name
    )
    search_modal_page.screenshot_filled_form("Advanced Account Search")


@step(
    parsers.parse(
        'I fill the Customer Search form with customer number "{customer_number}"'
    )
)
def fill_customer_search(
    search_modal_page: SearchModalPage, customer_number: str
) -> None:
    log.info("Step: filling Customer Search with customer number '%s'", customer_number)
    search_modal_page.fill_customer_search(customer_number=customer_number)
    search_modal_page.screenshot_filled_form("Customer Search")


@step(
    parsers.parse(
        'I fill the Contact Search form with first name "{first_name}" '
        'and last name "{last_name}"'
    )
)
def fill_contact_search_by_name(
    search_modal_page: SearchModalPage, first_name: str, last_name: str
) -> None:
    log.info(
        "Step: filling Contact Search — name='%s %s'", first_name, last_name
    )
    search_modal_page.fill_contact_search(
        first_name=first_name, last_name=last_name
    )
    search_modal_page.screenshot_filled_form("Contact Search")


@step(
    parsers.parse(
        'I fill the Contact Search form with contact reference "{contact_ref}"'
    )
)
def fill_contact_search_by_ref(
    search_modal_page: SearchModalPage, contact_ref: str
) -> None:
    log.info("Step: filling Contact Search with reference '%s'", contact_ref)
    search_modal_page.fill_contact_search(contact_reference=contact_ref)
    search_modal_page.screenshot_filled_form("Contact Search")


@step(
    parsers.parse(
        'I fill the Contact Search FS form with first name "{first_name}" '
        'and last name "{last_name}"'
    )
)
def fill_contact_search_fs_by_name(
    search_modal_page: SearchModalPage, first_name: str, last_name: str
) -> None:
    log.info(
        "Step: filling Contact Search FS — name='%s %s'", first_name, last_name
    )
    search_modal_page.fill_contact_search_fs(
        first_name=first_name, last_name=last_name
    )
    search_modal_page.screenshot_filled_form("Contact Search FS")


@step(
    parsers.parse(
        'I fill the Contact Search FS form with contact reference "{contact_ref}"'
    )
)
def fill_contact_search_fs_by_ref(
    search_modal_page: SearchModalPage, contact_ref: str
) -> None:
    log.info("Step: filling Contact Search FS with reference '%s'", contact_ref)
    search_modal_page.fill_contact_search_fs(contact_reference=contact_ref)
    search_modal_page.screenshot_filled_form("Contact Search FS")


# ──────────────────────────────────────────────────────────────
# When — submit
# ──────────────────────────────────────────────────────────────

@step("I submit the search modal")
def submit_search_modal(search_modal_page: SearchModalPage) -> None:
    """
    Click the Search button inside the modal.
    A screenshot is taken immediately after clicking (before navigation)
    — this is the "after clicking Search" screenshot required by the spec.
    """
    log.info("Step: submitting search modal")
    search_modal_page.submit_search()


@step("I reset the search modal form")
def reset_modal_form(search_modal_page: SearchModalPage) -> None:
    log.info("Step: resetting search modal form")
    search_modal_page.reset_form()


# ──────────────────────────────────────────────────────────────
# When — Person Profile accordion expansion
# ──────────────────────────────────────────────────────────────

@step("I expand all contact detail panels")
def expand_all_contact_details(person_profile_page: PersonProfilePage) -> None:
    """
    Expand Contact Address, Contact Email, Contact Phone in order.
    A screenshot is taken after each panel expands.
    """
    log.info("Step: expanding all contact detail panels")
    person_profile_page.expand_all_contact_details()


@step(parsers.parse('I expand the "{panel_name}" contact detail panel'))
def expand_contact_panel(
    person_profile_page: PersonProfilePage, panel_name: str
) -> None:
    """Expand a single Contact Detail accordion panel by name."""
    # Accept names with or without surrounding spaces (HTML has spaces)
    name = f" {panel_name.strip()} "
    log.info("Step: expanding contact detail panel '%s'", panel_name)
    person_profile_page.expand_contact_detail(name)


# ──────────────────────────────────────────────────────────────
# Then — assertions
# ──────────────────────────────────────────────────────────────

@step("the search modal should be open")
def assert_modal_open(search_modal_page: SearchModalPage) -> None:
    log.info("Step: asserting search modal is open")
    search_modal_page.assert_modal_open()


@step(parsers.parse('the "{tab_name}" tab should be active in the search modal'))
def assert_tab_active(search_modal_page: SearchModalPage, tab_name: str) -> None:
    log.info("Step: asserting tab '%s' is active", tab_name)
    search_modal_page.assert_tab_active(tab_name)


@step("I should be on the Person Profile page")
def assert_on_person_profile(person_profile_page: PersonProfilePage) -> None:
    log.info("Step: asserting Person Profile page loaded")
    person_profile_page.assert_on_person_profile()


@step("the Person Profile tertiary tab should be active")
def assert_person_profile_tab_active(
    person_profile_page: PersonProfilePage,
) -> None:
    log.info("Step: asserting Person Profile tab is active")
    person_profile_page.assert_person_profile_tab_active()


@step("the Contact Details section should be visible")
def assert_contact_details_visible(
    person_profile_page: PersonProfilePage,
) -> None:
    log.info("Step: asserting Contact Details section visible")
    person_profile_page.assert_contact_details_visible()


@step("all contact detail panels should be visible")
def assert_all_contact_panels(person_profile_page: PersonProfilePage) -> None:
    log.info("Step: asserting all contact panels visible")
    person_profile_page.assert_all_contact_panels_visible()


@step(parsers.parse('the "{panel_name}" contact detail panel should be expanded'))
def assert_contact_panel_expanded(
    person_profile_page: PersonProfilePage, panel_name: str
) -> None:
    name = f" {panel_name.strip()} "
    log.info("Step: asserting contact panel '%s' is expanded", panel_name)
    person_profile_page.assert_contact_panel_expanded(name)
