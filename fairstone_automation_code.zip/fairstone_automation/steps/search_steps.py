"""
steps/search_steps.py
─────────────────────
Step definitions for features/search.feature
"""
from __future__ import annotations

import pytest
from pytest_bdd import step, when, then, parsers
from playwright.sync_api import Page

from pages.home_page import HomePage
from pages.search_page import SearchPage
from utils.logger import get_logger

log = get_logger(__name__)


# ──────────────────────────────────────────────────────────────
# When steps
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('I search for account number "{account}"'))
def search_by_account(
    home_page: HomePage, search_page: SearchPage, account: str
) -> None:
    log.info("Step: searching for account '%s'", account)
    home_page.search_by_account(account)
    search_page.wait_for_results()


@step(parsers.parse('I set rows per page to "{value}"'))
def set_rows_per_page(search_page: SearchPage, value: str) -> None:
    log.info("Step: setting rows per page to %s", value)
    search_page.set_rows_per_page(value)


# ──────────────────────────────────────────────────────────────
# Then steps
# ──────────────────────────────────────────────────────────────

@step("the search results grid should be displayed")
def assert_grid_displayed(search_page: SearchPage) -> None:
    log.info("Step: asserting search results grid is visible")
    search_page.assert_visible(SearchPage.GRID_ROOT)


@step("the results should contain at least 1 row")
def assert_has_results(search_page: SearchPage) -> None:
    log.info("Step: asserting at least 1 result row")
    search_page.assert_results_present()


@step(parsers.parse('a "{title}" alert should be displayed'))
def assert_alert_title(search_page: SearchPage, title: str) -> None:
    log.info("Step: asserting alert title '%s'", title)
    search_page.assert_no_match_alert()


@step(parsers.parse('the alert body should say "{text}"'))
def assert_alert_body(search_page: SearchPage, text: str) -> None:
    log.info("Step: asserting alert body '%s'", text)
    actual = search_page.get_alert_body()
    assert text in actual, f"Alert body '{actual}' does not contain '{text}'"


@step("the Search button should be disabled")
def assert_search_disabled(home_page: HomePage) -> None:
    log.info("Step: asserting Search button is disabled")
    assert not home_page.is_search_button_enabled(), (
        "Expected Search button to be disabled but it was enabled"
    )


@step("pagination stats should be visible")
def assert_pagination_visible(search_page: SearchPage) -> None:
    log.info("Step: asserting pagination stats visible")
    search_page.assert_visible(SearchPage.PAGER_STATS)


@step("I should be able to navigate to the next page")
def navigate_to_next_page(search_page: SearchPage) -> None:
    log.info("Step: clicking next page")
    search_page.click_next_page()
    assert search_page.get_active_page() == "2", (
        "Expected active page to be '2' after clicking next"
    )


@step(parsers.parse('the grid should display up to {count:d} rows'))
def assert_max_rows(search_page: SearchPage, count: int) -> None:
    log.info("Step: asserting grid rows ≤ %d", count)
    actual = search_page.get_row_count()
    assert actual <= count, f"Grid shows {actual} rows; expected ≤ {count}"


@step(parsers.parse('the search outcome should be "{outcome}"'))
def assert_search_outcome(search_page: SearchPage, outcome: str) -> None:
    """
    Handles the Scenario Outline 'outcome' column:
      'results'  → grid must have rows
      'no_match' → no-match alert must be shown
    """
    log.info("Step: asserting search outcome is '%s'", outcome)
    if outcome == "results":
        search_page.assert_results_present()
    elif outcome == "no_match":
        search_page.assert_no_match_alert()
    else:
        raise ValueError(f"Unknown outcome value in Scenario Outline: '{outcome}'")
