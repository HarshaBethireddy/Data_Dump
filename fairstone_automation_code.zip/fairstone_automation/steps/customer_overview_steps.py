"""
steps/customer_overview_steps.py
──────────────────────────────────
Step definitions specific to features/customer_overview.feature.

Activities sidebar + iframe  → steps/activities_steps.py  (shared)
Accordion scroll/assert      → steps/accordion_steps.py   (shared)
"""
from __future__ import annotations

from pytest_bdd import given, step, when, then, parsers

from pages.home_page import HomePage
from pages.customer_overview_page import CustomerOverviewPage
from pages.account_activity_page import AccountActivityPage
from utils.logger import get_logger

log = get_logger(__name__)


# ──────────────────────────────────────────────────────────────
# When steps
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('I search for exact account number "{account}"'))
def search_exact_account(
    home_page: HomePage,
    customer_overview_page: CustomerOverviewPage,
    search_context,
    account: str,
) -> None:
    """
    Submit an exact account number from the home-page search form.
    The app navigates directly to Customer Overview (no results list).
    Stores the account number in search_context for use by the click step.
    """
    log.info("Step: searching for exact account '%s'", account)
    search_context.last_account_number = account
    home_page.search_by_account(account)
    customer_overview_page.wait_until_loaded()


@step("I click the matching account in the account list")
def click_matching_account(
    customer_overview_page: CustomerOverviewPage,
    account_activity_page: AccountActivityPage,
    search_context,
) -> None:
    """
    Read every ACCT_REFERENCE_SPAN in the account list.
    Find the row whose value equals search_context.last_account_number.
    Click only that specific row — never the first row blindly.
    Then wait for Account Activity page to load.
    """
    account_number = search_context.last_account_number
    if not account_number:
        raise ValueError(
            "search_context.last_account_number is empty. "
            "Run 'I search for exact account number' first."
        )
    log.info(
        "Step: finding account '%s' by ACCT_REFERENCE_SPAN and clicking it",
        account_number,
    )
    customer_overview_page.click_account_by_searched_number(account_number)
    account_activity_page.wait_until_loaded()


@step(parsers.parse('I click the account "{account_number}" in the account list'))
def click_specific_account(
    customer_overview_page: CustomerOverviewPage,
    account_activity_page: AccountActivityPage,
    account_number: str,
) -> None:
    """Explicit account-number variant — same ACCT_REFERENCE_SPAN matching logic."""
    log.info("Step: clicking account '%s' in account list", account_number)
    customer_overview_page.click_account_by_searched_number(account_number)
    account_activity_page.wait_until_loaded()


@step(parsers.parse('I switch the Customer Overview view to "{option}"'))
def switch_view(customer_overview_page: CustomerOverviewPage, option: str) -> None:
    log.info("Step: switching Customer Overview view to '%s'", option)
    customer_overview_page.switch_view(option)


# ──────────────────────────────────────────────────────────────
# Then steps
# ──────────────────────────────────────────────────────────────

@step("I should be on the Customer Overview page")
def assert_on_overview(customer_overview_page: CustomerOverviewPage) -> None:
    log.info("Step: asserting Customer Overview page")
    customer_overview_page.assert_on_customer_overview()


@step("I should still be on the Customer Overview page")
def assert_still_on_overview(customer_overview_page: CustomerOverviewPage) -> None:
    log.info("Step: asserting still on Customer Overview page")
    customer_overview_page.assert_on_customer_overview()


@step("the customer name heading should be visible")
def assert_customer_name(customer_overview_page: CustomerOverviewPage) -> None:
    customer_overview_page.assert_customer_name_heading_visible()


@step("the account list should be visible")
def assert_account_list(customer_overview_page: CustomerOverviewPage) -> None:
    customer_overview_page.assert_account_list_visible()


@step(parsers.parse('the account list should contain account "{account_number}"'))
def assert_account_in_list(
    customer_overview_page: CustomerOverviewPage, account_number: str
) -> None:
    customer_overview_page.assert_account_list_contains(account_number)


@step("the tertiary navigation tabs should be present")
def assert_tertiary_tabs(customer_overview_page: CustomerOverviewPage) -> None:
    customer_overview_page.assert_tertiary_tabs_present()
