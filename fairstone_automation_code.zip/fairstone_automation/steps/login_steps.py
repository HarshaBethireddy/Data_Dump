"""
steps/login_steps.py
────────────────────
Step definitions for features/login.feature
"""
from __future__ import annotations

import pytest
from pytest_bdd import step, when, then, parsers
from playwright.sync_api import Page, expect

from pages.login_page import LoginPage
from pages.home_page import HomePage
from utils.config import Config
from utils.logger import get_logger

log = get_logger(__name__)


# ──────────────────────────────────────────────────────────────
# When steps
# ──────────────────────────────────────────────────────────────

@step("I enter valid username and password")
def enter_valid_credentials(login_page: LoginPage) -> None:
    log.info("Step: entering valid credentials")
    login_page.enter_username(Config.USERNAME)
    login_page.enter_password(Config.PASSWORD)


@step(parsers.parse('I enter username "{username}" and password "{password}"'))
def enter_credentials(login_page: LoginPage, username: str, password: str) -> None:
    log.info("Step: entering credentials — user=%s", username)
    login_page.enter_username(username)
    login_page.enter_password(password)


@step("I click the Login button")
def click_login_button(login_page: LoginPage) -> None:
    log.info("Step: clicking Login button")
    login_page.click_login()


@step("I open the user menu and click logout")
def logout(page: Page, home_page: HomePage) -> None:
    log.info("Step: logging out via user menu")
    home_page.logout()


# ──────────────────────────────────────────────────────────────
# Then steps
# ──────────────────────────────────────────────────────────────

@step("I should be redirected to the Collections home page")
def assert_home_page(page: Page, home_page: HomePage) -> None:
    log.info("Step: asserting home page loaded")
    home_page.wait_until_loaded()
    home_page.assert_home_page_loaded()


@step(parsers.parse('the application name "{name}" should be visible'))
def assert_app_name(home_page: HomePage, name: str) -> None:
    log.info("Step: asserting app name '%s'", name)
    home_page.assert_contains_text(HomePage.APP_NAME, name)


@step("I should see a login error message")
def assert_login_error(login_page: LoginPage) -> None:
    log.info("Step: asserting login error visible")
    login_page.assert_error_visible()


@step("I should remain on the login page")
def assert_still_on_login(login_page: LoginPage) -> None:
    log.info("Step: asserting still on login page")
    login_page.assert_login_form_visible()


@step("the Login button should be visible on the page")
def assert_login_button_visible(login_page: LoginPage) -> None:
    log.info("Step: asserting login button visible")
    login_page.assert_visible(LoginPage.LOGIN_BUTTON)


@step("I should be redirected to the login page")
def assert_redirected_to_login(page: Page, login_page: LoginPage) -> None:
    log.info("Step: asserting redirected back to login")
    login_page.wait_for_element_visible(LoginPage.FORM_SELECTOR, timeout=30_000)
    login_page.assert_login_form_visible()
