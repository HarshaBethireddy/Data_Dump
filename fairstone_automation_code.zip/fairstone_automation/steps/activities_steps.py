"""
steps/activities_steps.py
──────────────────────────
Single, shared step definitions for the Activities sidebar panel and the
embedded-activity iframe flow (trigger → detect variant → fill → submit /
cancel → verify timeline → drill into details and iterate enabled tabs).

These steps work on BOTH the Customer Overview page and the Account Activity
page because both inherit ``ActivitiesMixin``. The ``resolve_activities_page``
fixture (defined in ``conftest.py``) returns whichever of the two pages is
currently active in the browser at the moment the step runs, so feature files
use the SAME step text regardless of which page they are on (Requirement 11.3).

Shared state
────────────
``activity_context`` carries data between steps:
    • ``frame_loc``      — the FrameLocator of the opened activity iframe, stored
                           by the trigger / wait steps and reused by the
                           variant / fill / OK / cancel steps.
    • ``activity_name``  — the label of the most-recently triggered activity, so
                           steps that need it (wait, submit, verify, drill) can
                           reference it without it being repeated in step text.

Iframe waiting (Requirements 11.4, 11.5)
────────────────────────────────────────
Every step that triggers an iframe waits up to 180,000 ms for it to become
ready. On timeout the step fails with a descriptive error AND a screenshot is
captured before the failure propagates.
"""
from __future__ import annotations

from pytest_bdd import step, parsers

from utils.logger import get_logger
from utils.screenshot_helper import ScreenshotHelper

log = get_logger(__name__)

# Wait up to 180,000 ms for the embedded activity iframe (Requirement 11.4).
IFRAME_TIMEOUT_MS = 180_000


# ──────────────────────────────────────────────────────────────
# Internal helpers (not steps)
# ──────────────────────────────────────────────────────────────

def _remember_activity(activity_context, name: str) -> None:
    """Track the most-recently triggered activity label on the shared context."""
    activity_context.activity_name = name


def _current_activity_label(activity_context, default: str = "activity") -> str:
    """Return the tracked activity label, falling back to a generic default."""
    return getattr(activity_context, "activity_name", None) or default


def _wait_for_iframe(page_obj, activity_context, activity_label: str):
    """
    Wait up to ``IFRAME_TIMEOUT_MS`` for the activity iframe to become ready,
    store the FrameLocator on ``activity_context`` for reuse, and remember the
    triggered activity label.

    On timeout the iframe wait raises a descriptive ``RuntimeError`` naming the
    activity; this helper captures a screenshot first and then fails the step
    with that descriptive error (Requirements 11.4, 11.5).
    """
    try:
        frame_loc = page_obj.wait_for_activity_iframe(
            activity_label, timeout=IFRAME_TIMEOUT_MS
        )
    except Exception as exc:  # noqa: BLE001 - re-raised after capturing evidence
        # Requirement 11.5 — capture a screenshot then fail with a descriptive error.
        try:
            ScreenshotHelper.capture(
                page_obj.page, f"iframe_timeout_{activity_label}"
            )
        except Exception:  # noqa: BLE001 - never mask the original failure
            log.warning(
                "Failed to capture iframe-timeout screenshot for '%s'",
                activity_label,
            )
        raise AssertionError(
            f"Activity iframe for '{activity_label}' did not become ready "
            f"within {IFRAME_TIMEOUT_MS} ms: {exc}"
        ) from exc

    activity_context.frame_loc = frame_loc
    _remember_activity(activity_context, activity_label)
    return frame_loc


def _frame_loc(page_obj, activity_context):
    """Return the stored FrameLocator, or re-acquire it from the page."""
    return activity_context.frame_loc or page_obj.get_activity_iframe()


def _datatable_to_field_values(datatable) -> dict[str, str]:
    """
    Convert a Gherkin data table into a ``{field: value}`` mapping.

    The table is a list of rows, each a list of cell strings. A leading
    ``| field | value |`` header row (case-insensitive) is ignored; every other
    row contributes its first cell as the field key and its second cell as the
    value.
    """
    field_values: dict[str, str] = {}
    for row in datatable:
        if len(row) < 2:
            continue
        key, value = row[0].strip(), row[1].strip()
        if key.casefold() == "field" and value.casefold() == "value":
            continue  # header row
        field_values[key] = value
    return field_values


# ──────────────────────────────────────────────────────────────
# Sidebar / low-level activity steps (existing text — preserved)
# ──────────────────────────────────────────────────────────────

@step("I click the Activities tab in the sidebar")
def click_activities_tab(resolve_activities_page) -> None:
    """Click the Activities tab on whichever page is currently active."""
    page_obj = resolve_activities_page()
    log.info("Step: clicking Activities tab on %s", type(page_obj).__name__)
    page_obj.click_activities_sidebar_tab()


@step(parsers.parse('I click the parent activity "{parent_label}"'))
def click_parent_activity(
    resolve_activities_page, activity_context, parent_label: str
) -> None:
    """Click a standalone parent activity (no dropdown required)."""
    page_obj = resolve_activities_page()
    log.info(
        "Step: clicking parent activity '%s' on %s",
        parent_label, type(page_obj).__name__,
    )
    page_obj.click_activity(parent_label)
    _remember_activity(activity_context, parent_label)


@step(parsers.parse(
    'I expand parent activity "{parent_label}" and click child "{child_label}"'
))
def click_child_activity(
    resolve_activities_page, activity_context,
    parent_label: str, child_label: str,
) -> None:
    """Expand a parent activity dropdown then click the child activity."""
    page_obj = resolve_activities_page()
    log.info(
        "Step: expanding parent '%s' → clicking child '%s' on %s",
        parent_label, child_label, type(page_obj).__name__,
    )
    page_obj.click_activity(parent_label, child_label)
    _remember_activity(activity_context, child_label)


@step("I wait for the activity iframe to load")
def wait_for_iframe(resolve_activities_page, activity_context) -> None:
    """
    Wait for the embedded activity iframe of the most-recently triggered
    activity. Stores the FrameLocator in ``activity_context`` so downstream
    steps (fill input, OK / Cancel) can reuse it. Waits up to 180,000 ms and
    fails with a descriptive error plus a screenshot on timeout.
    """
    page_obj = resolve_activities_page()
    activity_label = _current_activity_label(activity_context)
    log.info(
        "Step: waiting for activity iframe ('%s') on %s",
        activity_label, type(page_obj).__name__,
    )
    _wait_for_iframe(page_obj, activity_context, activity_label)


@step("I click OK in the activity iframe")
def click_iframe_ok(resolve_activities_page, activity_context) -> None:
    page_obj = resolve_activities_page()
    frame_loc = _frame_loc(page_obj, activity_context)
    log.info("Step: clicking OK in activity iframe")
    page_obj.click_iframe_ok(frame_loc)


@step("I click Cancel in the activity iframe")
def click_iframe_cancel(resolve_activities_page, activity_context) -> None:
    page_obj = resolve_activities_page()
    frame_loc = _frame_loc(page_obj, activity_context)
    log.info("Step: clicking Cancel in activity iframe")
    page_obj.click_iframe_cancel(frame_loc)


@step(parsers.parse('I fill iframe input "{selector}" with "{value}"'))
def fill_iframe_input(
    resolve_activities_page, activity_context, selector: str, value: str
) -> None:
    page_obj = resolve_activities_page()
    frame_loc = _frame_loc(page_obj, activity_context)
    log.info("Step: filling iframe input '%s' = '%s'", selector, value)
    page_obj.fill_iframe_input(frame_loc, selector, value)


# ──────────────────────────────────────────────────────────────
# Triggering an activity (Requirement 11.1 — triggering)
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('I trigger the activity "{activity}"'))
def trigger_activity(
    resolve_activities_page, activity_context, activity: str
) -> None:
    """
    Trigger a standalone (parent-only) activity and wait for its iframe.

    Clicks the activity in the sidebar, then waits up to 180,000 ms for the
    iframe to become ready, storing the FrameLocator and the activity label on
    ``activity_context`` for downstream steps (Requirements 11.1, 11.4, 11.5).
    """
    page_obj = resolve_activities_page()
    log.info(
        "Step: triggering activity '%s' on %s", activity, type(page_obj).__name__
    )
    page_obj.click_activity(activity)
    _wait_for_iframe(page_obj, activity_context, activity)


@step(parsers.parse('I trigger the activity "{parent}" with child "{child}"'))
def trigger_child_activity(
    resolve_activities_page, activity_context, parent: str, child: str
) -> None:
    """
    Trigger a child activity by expanding its parent, then wait for the iframe.

    The child label is the triggered Activity_Name and is what the iframe wait
    and downstream steps reference (Requirements 11.1, 11.4, 11.5).
    """
    page_obj = resolve_activities_page()
    log.info(
        "Step: triggering activity '%s' → child '%s' on %s",
        parent, child, type(page_obj).__name__,
    )
    page_obj.click_activity(parent, child)
    _wait_for_iframe(page_obj, activity_context, child)


@step(parsers.parse(
    'I trigger the activity "{activity}" with the following field values:'
))
def trigger_activity_with_values(
    resolve_activities_page, activity_context, activity: str, datatable
) -> None:
    """
    Trigger a standalone activity, wait for the iframe, then fill its
    Inputs_Variant fields from the supplied data table.

    The data table uses a ``| field | value |`` layout; an optional header row
    is ignored. Combines triggering and input filling for the Inputs_Variant
    flow (Requirements 11.1, 11.4, 11.5).
    """
    page_obj = resolve_activities_page()
    field_values = _datatable_to_field_values(datatable)
    log.info(
        "Step: triggering activity '%s' with field values %s on %s",
        activity, field_values, type(page_obj).__name__,
    )
    page_obj.click_activity(activity)
    frame_loc = _wait_for_iframe(page_obj, activity_context, activity)
    page_obj.fill_activity_inputs(frame_loc, field_values)


# ──────────────────────────────────────────────────────────────
# Variant detection assertion (Requirement 11.1 — variant detection)
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('the activity iframe variant should be "{variant}"'))
def assert_iframe_variant(
    resolve_activities_page, activity_context, variant: str
) -> None:
    """
    Detect the iframe variant and assert it matches the expected one.

    ``variant`` is one of ``inputs`` / ``confirmation`` (case-insensitive). The
    variant is detected before any field is filled or OK / Cancel is clicked.
    """
    page_obj = resolve_activities_page()
    frame_loc = _frame_loc(page_obj, activity_context)
    detected = page_obj.detect_iframe_variant(frame_loc)
    expected = variant.strip().casefold()
    log.info(
        "Step: asserting iframe variant is '%s' (detected '%s')",
        expected, detected.value,
    )
    assert detected.value == expected, (
        f"Expected activity iframe variant '{expected}', "
        f"but detected '{detected.value}'"
    )


# ──────────────────────────────────────────────────────────────
# Filling Inputs_Variant fields (Requirement 11.1 — input filling)
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('I fill the activity input "{field}" with "{value}"'))
def fill_activity_input_single(
    resolve_activities_page, activity_context, field: str, value: str
) -> None:
    """Fill a single Activity_Field (matched by id or label) with a value."""
    page_obj = resolve_activities_page()
    frame_loc = _frame_loc(page_obj, activity_context)
    log.info("Step: filling activity input '%s' = '%s'", field, value)
    page_obj.fill_activity_inputs(frame_loc, {field: value})


@step("I fill the activity inputs with the following values:")
def fill_activity_inputs_table(
    resolve_activities_page, activity_context, datatable
) -> None:
    """
    Fill multiple Activity_Fields from a ``| field | value |`` data table.

    Keys match Activity_Fields by id or label; an unmatched key or an unmatched
    select value raises a descriptive error from the mixin.
    """
    page_obj = resolve_activities_page()
    frame_loc = _frame_loc(page_obj, activity_context)
    field_values = _datatable_to_field_values(datatable)
    log.info("Step: filling activity inputs with %s", field_values)
    page_obj.fill_activity_inputs(frame_loc, field_values)


# ──────────────────────────────────────────────────────────────
# Submit / Cancel (Requirement 11.1 — OK submit, Cancel/abandon)
# ──────────────────────────────────────────────────────────────

@step("I submit the activity")
def submit_activity_step(resolve_activities_page, activity_context) -> None:
    """
    Submit the activity by clicking OK and waiting for the post-submission
    spinner to clear, using the tracked activity label for error reporting.
    """
    page_obj = resolve_activities_page()
    frame_loc = _frame_loc(page_obj, activity_context)
    activity_label = _current_activity_label(activity_context)
    log.info("Step: submitting activity '%s'", activity_label)
    page_obj.submit_activity(frame_loc, activity_label)


@step("I cancel the activity")
def cancel_activity_step(resolve_activities_page, activity_context) -> None:
    """Abandon the activity by clicking Cancel and confirming the iframe closed."""
    page_obj = resolve_activities_page()
    frame_loc = _frame_loc(page_obj, activity_context)
    log.info(
        "Step: cancelling activity '%s'",
        _current_activity_label(activity_context),
    )
    page_obj.cancel_activity(frame_loc)


# ──────────────────────────────────────────────────────────────
# Timeline verification (Requirement 11.1 — timeline verification)
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('the activity "{activity}" should appear in the timeline'))
def assert_activity_in_timeline(
    resolve_activities_page, activity_context, activity: str
) -> None:
    """
    Verify the performed activity appears in the timeline, matching by name and
    treating the top-most matching entry as the most recent. On the Account
    Activity page this transparently reveals the timeline behind the Activity
    History button before reading it.
    """
    page_obj = resolve_activities_page()
    log.info(
        "Step: verifying activity '%s' appears in timeline on %s",
        activity, type(page_obj).__name__,
    )
    item = page_obj.verify_activity_in_timeline(activity)
    _remember_activity(activity_context, activity)
    assert item is not None, (
        f"Activity '{activity}' was not found in the timeline"
    )


# ──────────────────────────────────────────────────────────────
# Details modal + enabled-tab iteration (Requirement 11.1 — tab iteration)
# ──────────────────────────────────────────────────────────────

@step(parsers.parse('I open the activity details modal for "{activity}"'))
def open_details_modal_step(
    resolve_activities_page, activity_context, activity: str
) -> None:
    """Drill into the Activity_Details_Modal for the matched timeline item."""  
    import time
    time.sleep(1)
    page_obj = resolve_activities_page()
    log.info("Step: opening activity details modal for '%s'", activity)
    page_obj.open_details_modal(activity)
    _remember_activity(activity_context, activity)


@step(parsers.parse(
    'I iterate every enabled tab in the activity details for "{activity}"'
))
def iterate_enabled_tabs_step(
    resolve_activities_page, activity: str
) -> None:
    """
    Visit every Enabled_Tab in the open Activity_Details_Modal (left-to-right),
    then close the modal. Asserts at least one enabled tab was visited.
    """
    page_obj = resolve_activities_page()
    log.info("Step: iterating enabled tabs in details modal for '%s'", activity)
    tabs = page_obj.iterate_enabled_tabs(activity)
    assert tabs, (
        f"Activity details modal for '{activity}' exposed no enabled tabs"
    )


# ──────────────────────────────────────────────────────────────
# Assertions (existing text — preserved)
# ──────────────────────────────────────────────────────────────

@step("the activity list should be visible in the sidebar")
def assert_activity_list_visible(resolve_activities_page) -> None:
    page_obj = resolve_activities_page()
    log.info(
        "Step: asserting activity list visible on %s", type(page_obj).__name__
    )
    page_obj.assert_activity_list_visible()


@step("the activity iframe should be loaded")
def assert_iframe_loaded(resolve_activities_page) -> None:
    page_obj = resolve_activities_page()
    log.info(
        "Step: asserting activity iframe loaded on %s", type(page_obj).__name__
    )
    page_obj.assert_activity_iframe_visible()
