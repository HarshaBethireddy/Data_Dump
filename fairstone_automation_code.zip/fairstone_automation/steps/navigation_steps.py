"""
steps/navigation_steps.py
──────────────────────────
Step definitions for features/navigation.feature
"""
from __future__ import annotations

from pytest_bdd import step, then, parsers
from playwright.sync_api import Page

from pages.home_page import HomePage
from utils.logger import get_logger

log = get_logger(__name__)


@step(parsers.parse('the "{label}" nav item should be visible'))
def assert_nav_item_visible(home_page: HomePage, label: str) -> None:
    log.info("Step: asserting nav item '%s' is visible", label)
    selector = f"a[aria-label='{label}']"
    home_page.assert_visible(selector, f"Nav item '{label}' should be visible")


@step("the notification bell should be visible")
def assert_notification_bell(home_page: HomePage) -> None:
    log.info("Step: asserting notification bell visible")
    home_page.assert_visible(HomePage.NOTIFICATION_ICON)


@step("the notification count should be displayed")
def assert_notification_count(home_page: HomePage) -> None:
    log.info("Step: asserting notification count displayed")
    home_page.assert_visible(HomePage.NOTIFICATION_COUNT)


@step("I open the user menu")
def open_user_menu(home_page: HomePage) -> None:
    log.info("Step: opening user menu")
    home_page.open_user_menu()


@step(parsers.parse('I select the language "{language}"'))
def select_language(home_page: HomePage, language: str) -> None:
    log.info("Step: selecting language '%s'", language)
    selector = (
        HomePage.LANG_ENGLISH if language == "English" else HomePage.LANG_FRENCH
    )
    home_page.click(selector)


@step(parsers.parse('the language should be set to "{language}"'))
def assert_language_set(home_page: HomePage, language: str) -> None:
    log.info("Step: asserting language is '%s'", language)
    selector = (
        HomePage.LANG_ENGLISH if language == "English" else HomePage.LANG_FRENCH
    )
    locator = home_page.page.locator(selector)
    assert locator.is_checked(), f"Language '{language}' radio is not checked"
