"""
tests/test_reference_interfaces.py
──────────────────────────────────
Binds features/reference_interfaces.feature to pytest-bdd.
Step implementations live in steps/admin_steps.py.
"""
from pytest_bdd import scenarios

scenarios("../features/reference_interfaces.feature")
