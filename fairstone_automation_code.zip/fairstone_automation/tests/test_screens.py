"""
tests/test_screens.py
────────────────────
"""
import pytest
from pytest_bdd import scenarios

scenarios("../features/screens.feature")