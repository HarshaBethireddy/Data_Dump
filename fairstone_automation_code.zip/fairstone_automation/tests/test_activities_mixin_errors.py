"""
tests/test_activities_mixin_errors.py
──────────────────────────────────────
Example tests for the *descriptive* error messages raised by
``pages.activities_mixin.ActivitiesMixin``.

Scope (task 6.7)
----------------
Assert that the failure paths of the mixin produce errors that name the thing
that failed, so an operator reading a stack trace can immediately tell which
activity / field went wrong:

  • ``wait_for_activity_iframe``  → RuntimeError naming the activity label
                                    (Requirements 1.7, 2.7)
  • ``submit_activity``           → RuntimeError naming the activity label
                                    (Requirement 5.4)
  • ``fill_activity_inputs``      → ValueError naming the unmatched key
                                    (Requirement 4.7 — input gate)
  • ``open_details_modal``        → RuntimeError naming the activity name
                                    (Requirement 8.3)

Environment note
----------------
The project pins ``playwright`` in requirements.txt, but it is not necessarily
installed in the test environment, and importing the mixin requires
``playwright.sync_api`` at module load time (the mixin and
``utils.screenshot_helper`` both import from it).

To exercise the *pure* error-message logic without a browser, when the real
package is absent we register a tiny fake ``playwright.sync_api`` module that
provides exactly the three symbols the imported modules reference:
``FrameLocator`` (a marker class), ``Page`` (a marker class) and ``TimeoutError``
(the exception the mixin catches to translate into its descriptive errors).

The fake-driven tests then call each mixin method with lightweight stub
page / frame-locator objects that implement only the minimal surface the method
touches, and make the relevant step raise the (fake) Playwright timeout — the
same trigger the real mixin translates into a descriptive RuntimeError.

A real-browser example (using Playwright routing) is included but skipped unless
a real Playwright install is present.
"""
from __future__ import annotations

import importlib.util
import os
import sys
import types

import pytest

# ──────────────────────────────────────────────────────────────
# Make ActivitiesMixin importable with or without a real Playwright install.
#
# Importing it through the ``pages`` package would eagerly drag in every page
# object (and optional third-party deps like ``dotenv``/``yaml``). Instead we
# load ``pages/activities_mixin.py`` as a standalone module: it uses only
# absolute imports (``playwright.sync_api`` and the pure ``utils.*`` logic
# modules), so it can be exercised in isolation.
#
# Detect the REAL Playwright package first (before any fake is injected) so
# browser-only tests can be skipped accurately.
# ──────────────────────────────────────────────────────────────
try:
    import playwright.sync_api as _real_sync_api  # noqa: F401

    HAS_REAL_PLAYWRIGHT = True
except Exception:  # pragma: no cover - exercised only when playwright is absent
    HAS_REAL_PLAYWRIGHT = False

    _pw = types.ModuleType("playwright")
    _sync_api = types.ModuleType("playwright.sync_api")

    class _FakePlaywrightTimeoutError(Exception):
        """Stand-in for playwright.sync_api.TimeoutError."""

    class FrameLocator:  # marker class — only used for type imports
        pass

    class Page:  # marker class — only used for type imports
        pass

    _sync_api.TimeoutError = _FakePlaywrightTimeoutError
    _sync_api.FrameLocator = FrameLocator
    _sync_api.Page = Page

    # Any other symbol the imported module references resolves to a harmless
    # marker class so the import never fails on an unforeseen name.
    def _sync_api_getattr(name):  # pragma: no cover - defensive
        return type(name, (), {})

    _sync_api.__getattr__ = _sync_api_getattr
    _pw.sync_api = _sync_api
    sys.modules["playwright"] = _pw
    sys.modules["playwright.sync_api"] = _sync_api

# ``utils.screenshot_helper`` pulls in ``utils.config`` → ``dotenv``, an optional
# third-party dependency that may be absent in a headless unit-test environment.
# The mixin only touches ``ScreenshotHelper`` inside ``record_screenshot``, which
# the harness below overrides to a no-op, so a lightweight stub module is enough
# to satisfy the import without exercising any of its real behaviour.
try:  # pragma: no cover - prefer the real module when its deps are installed
    import utils.screenshot_helper as _real_screenshot_helper  # noqa: F401
except Exception:
    _sh = types.ModuleType("utils.screenshot_helper")

    class ScreenshotHelper:  # minimal stand-in; never invoked by these tests
        @staticmethod
        def capture(page, label):  # pragma: no cover - never reached
            return None

    _sh.ScreenshotHelper = ScreenshotHelper
    sys.modules["utils.screenshot_helper"] = _sh


def _load_activities_mixin():
    """Load pages/activities_mixin.py as a standalone module and return it."""
    here = os.path.dirname(os.path.abspath(__file__))
    mixin_path = os.path.join(here, os.pardir, "pages", "activities_mixin.py")
    spec = importlib.util.spec_from_file_location(
        "activities_mixin_under_test", os.path.abspath(mixin_path)
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_mixin_module = _load_activities_mixin()
# The mixin re-exports the timeout class it catches as PlaywrightTimeoutError;
# raising THAT exact class from our stubs is what drives the descriptive-error
# branches.
PlaywrightTimeoutError = _mixin_module.PlaywrightTimeoutError
ActivitiesMixin = _mixin_module.ActivitiesMixin


# ──────────────────────────────────────────────────────────────
# Test harness: a concrete ActivitiesMixin with the BasePage-provided
# collaborators stubbed out so the error paths can run headless.
# ──────────────────────────────────────────────────────────────
class _MixinHarness(ActivitiesMixin):
    """
    Minimal concrete host for the mixin.

    Supplies the attributes/methods the mixin normally inherits from BasePage
    (``page``, ``timeout``, ``wait_for_spinner_gone``) and neutralises the
    screenshot side-effect so the pure error logic is what we observe.
    """

    def __init__(self, page: object, timeout: int = 5_000) -> None:
        self.page = page
        self.timeout = timeout

    def wait_for_spinner_gone(self, *args, **kwargs) -> None:
        # Non-blocking in real life; a no-op here.
        return None

    def record_screenshot(self, label: str) -> None:
        # Avoid touching the filesystem / ScreenshotHelper during unit tests.
        return None


# ──────────────────────────────────────────────────────────────
# Stubs for the iframe-timeout path (wait_for_activity_iframe)
# ──────────────────────────────────────────────────────────────
class _IframeTimeoutPage:
    """A page whose very first wait times out, simulating an iframe that
    never becomes ready."""

    def wait_for_selector(self, selector, timeout=None):
        raise PlaywrightTimeoutError(f"timeout waiting for {selector}")

    def frame_locator(self, selector):  # pragma: no cover - never reached
        raise AssertionError("frame_locator should not be reached on timeout")


# ──────────────────────────────────────────────────────────────
# Stubs for the submit-timeout path (submit_activity)
# ──────────────────────────────────────────────────────────────
class _ClickableLocator:
    """A locator that can be clicked (the iframe OK button)."""

    def click(self) -> None:
        return None


class _NeverHiddenLocator:
    """A locator whose wait_for(state='hidden') always times out, simulating a
    post-submission spinner that never clears."""

    def wait_for(self, **kwargs):
        raise PlaywrightTimeoutError("embedded spinner never disappeared")


class _SubmitTimeoutPage:
    def locator(self, selector):
        return _NeverHiddenLocator()


class _SubmitFrame:
    def locator(self, selector):
        return _ClickableLocator()


# ──────────────────────────────────────────────────────────────
# Stubs for the unmatched-key path (fill_activity_inputs)
# ──────────────────────────────────────────────────────────────
class _EmptyFieldsLocator:
    def all(self):
        return []  # an Inputs_Variant form with zero scrapeable fields


class _NoFieldsFrame:
    def locator(self, selector):
        return _EmptyFieldsLocator()


# ──────────────────────────────────────────────────────────────
# Stubs for the modal-timeout path (open_details_modal)
# ──────────────────────────────────────────────────────────────
class _SubtitleLocator:
    def __init__(self, text: str) -> None:
        self._text = text
        self.first = self

    def count(self) -> int:
        return 1

    def inner_text(self) -> str:
        return self._text


class _TitleLink:
    def __init__(self, subtitle: str) -> None:
        self._subtitle = subtitle

    def locator(self, selector):
        return _SubtitleLocator(self._subtitle)

    def get_attribute(self, name):
        return ""

    def click(self) -> None:
        return None


class _TitleLinks:
    def __init__(self, subtitles) -> None:
        self._subtitles = list(subtitles)

    def count(self) -> int:
        return len(self._subtitles)

    def nth(self, index: int) -> _TitleLink:
        return _TitleLink(self._subtitles[index])


class _ModalNeverPresentLocator:
    def wait_for(self, **kwargs):
        raise PlaywrightTimeoutError("activity-details modal never appeared")


class _ModalTimeoutPage:
    """Returns matching timeline links so a match is found, but the details
    modal never becomes present (its wait_for times out)."""

    def __init__(self, activity_name: str) -> None:
        self._activity_name = activity_name

    def locator(self, selector):
        if selector == ActivitiesMixin.TIMELINE_TITLE_LINK:
            return _TitleLinks([self._activity_name])
        # DETAILS_MODAL (or anything else) — never resolves.
        return _ModalNeverPresentLocator()


# ══════════════════════════════════════════════════════════════
# Example tests
# ══════════════════════════════════════════════════════════════
def test_wait_for_activity_iframe_error_names_activity_label():
    """A never-ready iframe raises RuntimeError naming the activity label.

    **Validates: Requirements 1.7, 2.7**
    """
    activity_label = "Report Bankrupt"
    harness = _MixinHarness(_IframeTimeoutPage())

    with pytest.raises(RuntimeError) as excinfo:
        harness.wait_for_activity_iframe(activity_label, timeout=5_000)

    message = str(excinfo.value)
    assert activity_label in message
    assert "did not become ready" in message


def test_submit_activity_error_names_activity_label():
    """A post-submission spinner that never clears raises RuntimeError naming
    the activity label.

    **Validates: Requirement 5.4**
    """
    activity_label = "Do Not Call"
    harness = _MixinHarness(_SubmitTimeoutPage())

    with pytest.raises(RuntimeError) as excinfo:
        harness.submit_activity(_SubmitFrame(), activity_label)

    message = str(excinfo.value)
    assert activity_label in message
    assert "failed to submit" in message


def test_fill_activity_inputs_error_names_unmatched_key():
    """A Field_Values key that matches no Activity_Field raises ValueError
    naming the unmatched key.

    **Validates: Requirement 4.7**
    """
    unmatched_key = "Totally Unknown Field"
    harness = _MixinHarness(page=object())  # page is unused on this path

    with pytest.raises(ValueError) as excinfo:
        harness.fill_activity_inputs(_NoFieldsFrame(), {unmatched_key: "value"})

    message = str(excinfo.value)
    assert unmatched_key in message
    assert "matches no Activity_Field" in message


def test_open_details_modal_error_names_activity_name():
    """A details modal that never becomes present raises RuntimeError naming
    the activity name.

    **Validates: Requirement 8.3**
    """
    activity_name = "Promise To Pay"
    harness = _MixinHarness(_ModalTimeoutPage(activity_name))

    with pytest.raises(RuntimeError) as excinfo:
        harness.open_details_modal(activity_name)

    message = str(excinfo.value)
    assert activity_name in message
    assert "did not become present" in message


# ══════════════════════════════════════════════════════════════
# Browser-only example (skipped unless a real Playwright install is present).
# Demonstrates the same assertions driven through Playwright routing against a
# minimal in-memory page that never renders the embedded activity container.
# ══════════════════════════════════════════════════════════════
@pytest.mark.skipif(
    not HAS_REAL_PLAYWRIGHT,
    reason="real Playwright not installed; covered by fake-driven tests above",
)
def test_wait_for_activity_iframe_error_with_real_browser():  # pragma: no cover
    """End-to-end example: a page that never serves the embedded activity
    iframe makes ``wait_for_activity_iframe`` raise a descriptive RuntimeError
    naming the activity label.

    **Validates: Requirements 1.7, 2.7**
    """
    from playwright.sync_api import sync_playwright

    activity_label = "Report Bankrupt"
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        # Route every request to an empty document so the embedded-activity
        # container/iframe selectors never resolve.
        page.route(
            "**/*",
            lambda route: route.fulfill(
                status=200,
                content_type="text/html",
                body="<html><body></body></html>",
            ),
        )
        page.goto("https://example.test/")
        harness = _MixinHarness(page, timeout=1_000)
        try:
            with pytest.raises(RuntimeError) as excinfo:
                harness.wait_for_activity_iframe(activity_label, timeout=1_000)
            assert activity_label in str(excinfo.value)
        finally:
            browser.close()
