"""
tests/test_person_profile.py
───────────────────────────
Binds features/person_profile.feature to pytest-bdd.
Step implementations live in steps/person_profile_steps.py.
"""
from pytest_bdd import scenarios

scenarios("../features/person_profile.feature")
