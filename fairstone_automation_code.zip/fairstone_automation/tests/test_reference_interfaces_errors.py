"""
tests/test_reference_interfaces_errors.py
───────────────────────────────────────────
Example/unit tests for the descriptive-error paths added in task 9.2 on
``ReferenceInterfacesPage`` (task 9.3).

Scope
-----
Each error path must raise a descriptive ``AssertionError`` whose message names
the offending option / label / Code / modal:

  • Missing dropdown option (Req 2.6) — ``select_reference_type`` raises naming
    the requested option and leaves the current selection unchanged (no option
    click, no grid load).
  • Unmatched field label (Req 3.4) — ``fill_modal_field`` raises naming the
    label and does NOT click Save (no fill, no Save click).
  • Save-stays-disabled timeout (Req 3.8) — ``_wait_for_save_enabled`` raises a
    descriptive timeout error naming the configured timeout; Save is not clicked.
  • Missing row on edit (Req 5.2) — the edit-verify path (``verify_edit``) raises
    naming the Code that could not be found in the grid.
  • Modal-not-closed timeout (Req 5.8) — ``save_edit_modal`` raises naming which
    modal (the Edit record modal) did not close after Save was clicked.

Environment note
----------------
``playwright`` is not necessarily installed, and ``ReferenceInterfacesPage``
imports ``playwright.sync_api`` (directly and via ``pages.base_page``) at module
load time. The root ``conftest.py`` imports Playwright and ``pytest.ini`` wires
in ``pytest-html``; this file is therefore designed to run standalone with
``--noconftest -o addopts=""``.

Mirroring ``tests/test_reference_interfaces_cancel.py`` and
``tests/test_reference_interfaces_delete.py``, when the real package is absent we
register lightweight fake modules for ``playwright.sync_api``, ``pages.base_page``,
``utils.screenshot_helper`` and ``utils.logger`` so the page module can be loaded
in isolation and the error-path methods exercised without a browser. Browser
interactions touched by these methods (``page.locator``/``.count()``/``.first.wait_for``,
``page.wait_for_selector``, the ``expect``-based save-enable wait, ``click`` and
``wait_for_element_hidden``) are stubbed on the page instance / module so we can
simulate a missing option, an unmatched label, a disabled Save, a missing row,
and a modal that never closes.
"""
from __future__ import annotations

import importlib.util
import os
import sys
import types


# ──────────────────────────────────────────────────────────────
# Register fakes (only when the real Playwright package is absent) so
# pages/reference_interfaces_page.py can be loaded standalone.
# ──────────────────────────────────────────────────────────────
try:  # pragma: no cover - prefer the real package when installed
    import playwright.sync_api as _real_sync_api  # noqa: F401
except Exception:
    _pw = types.ModuleType("playwright")
    _sync_api = types.ModuleType("playwright.sync_api")

    class _FakeTimeoutError(Exception):
        pass

    class Locator:  # marker — only referenced by type imports
        pass

    def expect(*args, **kwargs):  # overridden per-test via the module global
        raise AssertionError("expect should be overridden by the test")

    _sync_api.TimeoutError = _FakeTimeoutError
    _sync_api.Locator = Locator
    _sync_api.expect = expect

    def _sync_api_getattr(name):  # pragma: no cover - defensive
        return type(name, (), {})

    _sync_api.__getattr__ = _sync_api_getattr
    _pw.sync_api = _sync_api
    sys.modules["playwright"] = _pw
    sys.modules["playwright.sync_api"] = _sync_api


# ``pages.base_page`` drags in Playwright + config (dotenv); these methods only
# need a ``BasePage`` to subclass. Provide a trivial one.
try:  # pragma: no cover - prefer the real module when its deps are installed
    import pages.base_page as _real_base_page  # noqa: F401
except Exception:
    _bp = types.ModuleType("pages.base_page")

    class BasePage:  # minimal stand-in
        pass

    _bp.BasePage = BasePage
    sys.modules["pages.base_page"] = _bp


# ``utils.logger`` may pull in optional config deps; a no-op logger is enough.
try:  # pragma: no cover
    import utils.logger as _real_logger  # noqa: F401
except Exception:
    _lg = types.ModuleType("utils.logger")

    class _NullLogger:
        def __getattr__(self, _name):
            return lambda *a, **k: None

    _lg.get_logger = lambda *a, **k: _NullLogger()
    sys.modules["utils.logger"] = _lg


# A controllable ScreenshotHelper stub: the module under test binds this symbol
# at import via ``from utils.screenshot_helper import ScreenshotHelper``. None of
# the error paths under test should reach a screenshot capture, so any call is a
# signal that the method proceeded past its guard.
class _FakeScreenshotHelper:
    def __init__(self) -> None:
        self.calls: list[str] = []
        self.return_path = "/tmp/shot.png"

    def capture(self, page, name="screenshot"):
        self.calls.append(name)
        return self.return_path


_FAKE_SH = _FakeScreenshotHelper()
_sh_mod = types.ModuleType("utils.screenshot_helper")
_sh_mod.ScreenshotHelper = _FAKE_SH
sys.modules["utils.screenshot_helper"] = _sh_mod


def _load_reference_interfaces_page():
    """Load pages/reference_interfaces_page.py as a standalone module."""
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, os.pardir, "pages", "reference_interfaces_page.py")
    spec = importlib.util.spec_from_file_location(
        "reference_interfaces_page_errors_under_test", os.path.abspath(path)
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_rip_module = _load_reference_interfaces_page()
ReferenceInterfacesPage = _rip_module.ReferenceInterfacesPage
# The module's TimeoutError alias (the fake one when Playwright is absent), used
# to simulate the missing-row / disabled-Save / modal-not-closed timeouts.
PlaywrightTimeoutError = _rip_module.PlaywrightTimeoutError
# Preserve the module's original ``expect`` so tests can restore it.
_ORIGINAL_EXPECT = _rip_module.expect


# ──────────────────────────────────────────────────────────────
# Test doubles for the browser surface touched by the error paths.
# ──────────────────────────────────────────────────────────────
class _FakeFirst:
    """Stands in for ``locator.first`` — its ``wait_for`` can be made to raise."""

    def __init__(self, raise_on_wait: bool) -> None:
        self.raise_on_wait = raise_on_wait
        self.wait_calls: list[dict] = []
        self.click_calls = 0

    def wait_for(self, state=None, timeout=None):
        self.wait_calls.append({"state": state, "timeout": timeout})
        if self.raise_on_wait:
            raise PlaywrightTimeoutError("simulated wait timeout")

    def click(self):  # pragma: no cover - guarded paths never click the option
        self.click_calls += 1


class _FakeLocator:
    """Configurable locator with a controllable ``count()`` and ``first``."""

    def __init__(self, count: int, raise_on_wait: bool) -> None:
        self._count = count
        self.first = _FakeFirst(raise_on_wait)

    def count(self) -> int:
        return self._count


class _FakePage:
    """Minimal Playwright Page stand-in for the error-path methods."""

    def __init__(
        self,
        *,
        locator_count: int = 1,
        row_raise_on_wait: bool = False,
        wait_for_selector_raises: bool = False,
    ) -> None:
        self._locator_count = locator_count
        self._row_raise_on_wait = row_raise_on_wait
        self._wait_for_selector_raises = wait_for_selector_raises
        self.locator_selectors: list[str] = []
        self.selector_waits: list[str] = []

    def locator(self, selector: str):
        self.locator_selectors.append(selector)
        return _FakeLocator(self._locator_count, self._row_raise_on_wait)

    def wait_for_selector(self, selector: str, timeout=None):
        self.selector_waits.append(selector)
        if self._wait_for_selector_raises:
            raise PlaywrightTimeoutError("simulated selector wait timeout")


def _make_page(
    *,
    locator_count: int = 1,
    row_raise_on_wait: bool = False,
    wait_for_selector_raises: bool = False,
    modal_closes: bool = True,
) -> ReferenceInterfacesPage:
    """Build a ReferenceInterfacesPage with the browser surface stubbed."""
    page = ReferenceInterfacesPage.__new__(ReferenceInterfacesPage)
    page.page = _FakePage(
        locator_count=locator_count,
        row_raise_on_wait=row_raise_on_wait,
        wait_for_selector_raises=wait_for_selector_raises,
    )
    page.timeout = 30_000
    page.click_calls: list[str] = []
    page.hidden_waits: list[str] = []
    page.fill_calls: list[tuple[str, str]] = []

    def _click(selector):
        page.click_calls.append(selector)

    def _wait_for_element_hidden(selector, timeout=None):
        page.hidden_waits.append(selector)
        if not modal_closes:
            raise PlaywrightTimeoutError("simulated modal-hidden timeout")

    def _fill_and_trigger(selector, value):
        page.fill_calls.append((selector, value))

    def _wait_for_spinner_gone(selector, timeout=None):
        pass

    page.click = _click
    page.wait_for_element_hidden = _wait_for_element_hidden
    page.fill_and_trigger = _fill_and_trigger
    page.wait_for_spinner_gone = _wait_for_spinner_gone
    return page


def setup_function(_func):
    _FAKE_SH.calls.clear()
    # Always restore the module's original ``expect`` before each test so a test
    # that overrides it cannot leak into another.
    _rip_module.expect = _ORIGINAL_EXPECT


# ══════════════════════════════════════════════════════════════
# Req 2.6 — missing dropdown option
# ══════════════════════════════════════════════════════════════
def test_select_reference_type_raises_when_option_missing():
    """A requested option absent from the dropdown raises naming the option.

    Validates: Requirements 2.6
    """
    page = _make_page(locator_count=0)

    try:
        page.select_reference_type("Nonexistent Type")
        raised = None
    except AssertionError as exc:
        raised = exc

    assert raised is not None, "Expected an AssertionError for a missing option"
    message = str(raised)
    # Req 2.6 — message includes the missing option name.
    assert "Nonexistent Type" in message, message
    # Req 2.6 — current selection left unchanged: the option was never clicked.
    assert page.page.locator_selectors, "option lookup should have been attempted"
    # The dropdown trigger was opened, but no option/grid-load click happened
    # beyond it (only the trigger click was recorded).
    assert page.click_calls == [ReferenceInterfacesPage.DROPDOWN_TRIGGER]
    # No selection screenshot/step recorded.
    assert _FAKE_SH.calls == []


# ══════════════════════════════════════════════════════════════
# Req 3.4 — unmatched modal field label
# ══════════════════════════════════════════════════════════════
def test_fill_modal_field_raises_when_label_unmatched_and_does_not_save():
    """An unmatched field label raises naming the label and never clicks Save.

    Validates: Requirements 3.4
    """
    page = _make_page(locator_count=0)

    try:
        page.fill_modal_field("Bogus Label", "value")
        raised = None
    except AssertionError as exc:
        raised = exc

    assert raised is not None, "Expected an AssertionError for an unmatched label"
    message = str(raised)
    # Req 3.4 — message names the unmatched label.
    assert "Bogus Label" in message, message
    # Req 3.4 — the field was not filled and Save was not clicked.
    assert page.fill_calls == []
    assert ReferenceInterfacesPage.MODAL_SAVE not in page.click_calls
    assert page.click_calls == []


# ══════════════════════════════════════════════════════════════
# Req 3.8 — Save stays disabled (timeout)
# ══════════════════════════════════════════════════════════════
class _DisabledExpectation:
    """Stands in for ``expect(locator)`` whose ``to_be_enabled`` never passes."""

    def to_be_enabled(self, timeout=None):
        raise PlaywrightTimeoutError("Save remained disabled")


def _disabled_expect(_locator):
    return _DisabledExpectation()


def test_wait_for_save_enabled_raises_descriptive_timeout_when_disabled():
    """Save staying disabled raises a descriptive timeout naming the timeout.

    Validates: Requirements 3.8
    """
    page = _make_page()
    # Override the module-level ``expect`` so the save-enable wait times out.
    _rip_module.expect = _disabled_expect

    try:
        page._wait_for_save_enabled(timeout=10_000)
        raised = None
    except AssertionError as exc:
        raised = exc

    assert raised is not None, "Expected an AssertionError when Save stays disabled"
    message = str(raised)
    # Req 3.8 — descriptive: indicates the Save button remained disabled.
    assert "Save button remained" in message, message
    assert "disabled" in message, message
    # Req 3.8 — names the configured timeout it waited.
    assert "10000" in message, message
    # Req 3.8 — Save must NOT be clicked when it never enabled.
    assert ReferenceInterfacesPage.MODAL_SAVE not in page.click_calls


# ══════════════════════════════════════════════════════════════
# Req 5.2 — missing row on edit
# ══════════════════════════════════════════════════════════════
def test_verify_edit_raises_when_row_missing_naming_code():
    """A Code absent from the grid on the edit path raises naming the Code.

    Validates: Requirements 5.2
    """
    page = _make_page(row_raise_on_wait=True)

    try:
        page.verify_edit("MISSING-CODE", "Updated description")
        raised = None
    except AssertionError as exc:
        raised = exc

    assert raised is not None, "Expected an AssertionError when the row is missing"
    message = str(raised)
    # Req 5.2 — names the Code that could not be found.
    assert "MISSING-CODE" in message, message
    # Names the configured timeout it waited for the row.
    assert str(page.timeout) in message, message
    # No edit_verified screenshot on the failure path.
    assert _FAKE_SH.calls == []


# ══════════════════════════════════════════════════════════════
# Req 5.8 — Edit modal does not close (timeout)
# ══════════════════════════════════════════════════════════════
def test_save_edit_modal_raises_naming_modal_when_it_does_not_close():
    """An Edit modal that never closes after Save raises naming which modal.

    Validates: Requirements 5.8
    """
    page = _make_page(modal_closes=False)
    # The save-enable gate must pass so we reach the modal-close wait.
    page._wait_for_save_enabled = lambda *a, **k: None

    try:
        page.save_edit_modal("Bankruptcy_Types")
        raised = None
    except AssertionError as exc:
        raised = exc

    assert raised is not None, "Expected an AssertionError when the modal stays open"
    message = str(raised)
    # Req 5.8 — names which modal did not close.
    assert "Edit record modal" in message, message
    assert "did not close" in message, message
    # Names the configured timeout.
    assert str(page.timeout) in message, message
    # Save was clicked and the modal-hidden wait was attempted, but no
    # edit_saved screenshot was captured on the failure path.
    assert page.click_calls == [ReferenceInterfacesPage.MODAL_SAVE]
    assert page.hidden_waits == [ReferenceInterfacesPage.MODAL_BOX]
    assert _FAKE_SH.calls == []
