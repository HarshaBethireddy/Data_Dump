"""
tests/test_run_step_log_properties.py
─────────────────────────────────────
Property-based tests (Hypothesis) for the run-step-log data layer in
``utils/run_step_log.py``.

Each test runs a minimum of 100 examples and is tagged with a comment of the
form ``# Feature: activity-execution-and-reporting, Property {n}: {text}``.
"""
from __future__ import annotations

from typing import Optional

from hypothesis import given, settings
from hypothesis import strategies as st

from utils.run_step_log import RunStepLog, compose_label


# A token that is guaranteed to survive ``str.strip()`` with non-empty content,
# so the composed label provably contains the flow-step / activity tokens.
_non_blank_text = st.text(min_size=1, max_size=20).filter(lambda s: s.strip() != "")

# An activity name may be absent (None), blank, or a meaningful token.
_activity_name = st.one_of(
    st.none(),
    st.text(max_size=10),          # may be empty or whitespace-only
    _non_blank_text,               # a meaningful name
)

# A single recorded step:
#   (step_token, activity_name, should_fail, screenshot_path)
_step_op = st.tuples(
    _non_blank_text,                                  # flow-step token
    _activity_name,                                   # Activity_Name (or None)
    st.booleans(),                                    # capture raises?
    st.one_of(st.none(), st.text(max_size=40)),       # screenshot path on success
)


# Feature: activity-execution-and-reporting, Property 7: Run step log preserves order, composes labels, and survives capture failure
@settings(max_examples=200)
@given(ops=st.lists(_step_op, max_size=40))
def test_run_step_log_preserves_order_composes_labels_and_survives_failure(
    ops: list[tuple[str, Optional[str], bool, Optional[str]]],
) -> None:
    """Property 7: Run step log preserves order, composes labels, and survives
    capture failure.

    For any sequence of recorded steps — including steps whose underlying
    screenshot capture raises — ``RunStepLog.entries()`` contains exactly one
    entry per call in the exact order the calls were made; each entry's label
    contains both the flow-step token and the ``Activity_Name``; and a call
    whose capture raised yields an entry with ``failed=True`` and
    ``screenshot_path=None`` without propagating the exception.

    Validates: Requirements 9.9, 9.10, 9.11
    """
    log = RunStepLog()

    # Replay the generated sequence. Capture failures must NOT propagate
    # (Requirement 9.11) — if record_capture let an exception escape, this loop
    # would raise and the property would fail.
    for step, name, should_fail, path in ops:
        label = compose_label(step, name)

        if should_fail:
            def capture() -> Optional[str]:
                raise RuntimeError("simulated capture failure")
        else:
            def capture(_path: Optional[str] = path) -> Optional[str]:
                return _path

        log.record_capture(label, capture)

    entries = log.entries()

    # One entry per call (Requirement 9.10).
    assert len(entries) == len(ops)

    for entry, (step, name, should_fail, path) in zip(entries, ops):
        expected_label = compose_label(step, name)

        # Order preserved: the i-th entry corresponds to the i-th call, with the
        # exact label that was recorded (Requirements 9.9, 9.10).
        assert entry.label == expected_label

        # Label composes both tokens (Requirement 9.9): the flow-step token is
        # always present, and the Activity_Name is present whenever it is a
        # meaningful (non-blank) value.
        assert step.strip() in entry.label
        if name is not None and name.strip():
            assert name.strip() in entry.label

        # Capture failure survival (Requirement 9.11): a raised capture yields a
        # failure-labelled entry with no screenshot path; a successful capture
        # records the returned path and is not marked failed.
        if should_fail:
            assert entry.failed is True
            assert entry.screenshot_path is None
        else:
            assert entry.failed is False
            assert entry.screenshot_path == path


# ─────────────────────────────────────────────────────────────────────────────
# spa-reference-interfaces feature properties
#
# These properties cover the pure, browser-free recording behaviour of
# ``RunStepLog`` that underpins the per-step screenshot/report guarantees of the
# Reference Interfaces automation. Each runs a minimum of 100 examples.
# ─────────────────────────────────────────────────────────────────────────────

# A (label, screenshot_path) pair as recorded by a single ``record`` call.
# Labels may be any text; paths may be present or absent (None).
_label_path_pair = st.tuples(
    st.text(max_size=40),                          # step label
    st.one_of(st.none(), st.text(max_size=60)),    # screenshot path (or None)
)


# Feature: spa-reference-interfaces, Property 3: Recording a step appends exactly one ordered log entry per call
@settings(max_examples=200)
@given(pairs=st.lists(_label_path_pair, max_size=50))
def test_record_appends_exactly_one_ordered_entry_per_call(
    pairs: list[tuple[str, Optional[str]]],
) -> None:
    """Property 3: Recording a step appends exactly one ordered log entry per call.

    For any finite sequence of ``record(label, path)`` calls, the Run_Step_Log
    afterwards contains exactly one entry per call, in the same order they were
    recorded, and each entry carries the exact label and path it was recorded
    with (and is not failure-flagged).

    Validates: Requirements 9.1, 9.3
    """
    log = RunStepLog()

    # Record each pair, asserting the count grows by exactly one per call so the
    # "exactly one entry per call" guarantee holds incrementally, not just at the
    # end (Requirement 9.1).
    for index, (label, path) in enumerate(pairs):
        log.record(label, path)
        assert len(log.entries()) == index + 1

    entries = log.entries()

    # Exactly one entry per call overall (Requirement 9.1).
    assert len(entries) == len(pairs)

    # Order preserved one-to-one, each entry carrying its recorded label/path
    # and not marked as a capture failure (Requirement 9.3).
    for entry, (label, path) in zip(entries, pairs):
        assert entry.label == label
        assert entry.screenshot_path == path
        assert entry.failed is False


# Feature: spa-reference-interfaces, Property 4: A failed capture records exactly one failure-labelled entry and never aborts
@settings(max_examples=200)
@given(
    label=st.text(max_size=40),
    prior=st.lists(_label_path_pair, max_size=20),
)
def test_failed_capture_records_one_failure_entry_and_never_aborts(
    label: str,
    prior: list[tuple[str, Optional[str]]],
) -> None:
    """Property 4: A failed capture records exactly one failure-labelled entry
    and never aborts.

    For any step label, when the screenshot capture raises, ``record_capture``
    appends exactly one entry at that position with ``failed=True`` and no
    screenshot path, no exception escapes the call, and the entry count grows by
    exactly one (the flow continues).

    Validates: Requirements 7.7, 9.4
    """
    log = RunStepLog()

    # Seed the log with arbitrary prior entries so the failure entry is appended
    # at the correct position (after everything recorded so far).
    for prior_label, prior_path in prior:
        log.record(prior_label, prior_path)

    count_before = len(log.entries())

    def raising_capture() -> Optional[str]:
        raise RuntimeError("simulated capture failure")

    # Must not raise (Requirement 7.7: the flow is never aborted by a capture
    # failure). If record_capture let the exception escape, this line would
    # raise and fail the property.
    log.record_capture(label, raising_capture)

    entries = log.entries()

    # Entry count grew by exactly one — the flow continued (Requirements 7.7, 9.4).
    assert len(entries) == count_before + 1

    # The appended entry is the failure-labelled one at the final position.
    failure_entry = entries[-1]
    assert failure_entry.label == label
    assert failure_entry.failed is True
    assert failure_entry.screenshot_path is None

    # Prior entries are untouched (the failure was appended, not substituted).
    assert len(entries) == len(prior) + 1
