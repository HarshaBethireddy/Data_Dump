"""
tests/test_reference_interfaces_cancel.py
─────────────────────────────────────────
Example/unit tests for the cancel-with-verify error paths on
``ReferenceInterfacesPage`` (task 8.2).

Scope
-----
``cancel_with_verify_add(code)`` (and the shared ``_cancel_modal_within_timeout``
helper it delegates to) must surface two descriptive failures:

  • Modal-not-closed timeout — when the Cancel click does not close the modal
    within the configured timeout, a descriptive ``AssertionError`` naming which
    modal did not close is raised (Requirement 7.2).
  • Code present after a cancelled Add — when a record with the entered ``code``
    is still present in the grid after the Add modal was cancelled, a descriptive
    ``AssertionError`` naming the offending Code is raised (Requirement 7.4).

A success path is also pinned to confirm the happy flow records exactly one
``{prefix}_cancel`` step and raises nothing.

Environment note
----------------
``playwright`` is not necessarily installed, and ``ReferenceInterfacesPage``
imports ``playwright.sync_api`` (directly and via ``pages.base_page``) at module
load time. Mirroring ``tests/test_reference_interfaces_record_step.py``, when the
real package is absent we register lightweight fake modules for
``playwright.sync_api``, ``pages.base_page``, ``utils.screenshot_helper`` and
``utils.logger`` so the page module can be loaded in isolation and the cancel
methods exercised without a browser. Browser interactions used by the cancel
flow (``click``, ``wait_for_element_hidden`` and the row locator) are stubbed on
the page instance so we can simulate a timeout and a still-present row.
"""
from __future__ import annotations

import importlib.util
import os
import sys
import types

from utils.run_step_log import RunStepLog


# ──────────────────────────────────────────────────────────────
# Register fakes (only when the real Playwright package is absent) so
# pages/reference_interfaces_page.py can be loaded standalone.
# ──────────────────────────────────────────────────────────────
try:  # pragma: no cover - prefer the real package when installed
    import playwright.sync_api as _real_sync_api  # noqa: F401
except Exception:
    _pw = types.ModuleType("playwright")
    _sync_api = types.ModuleType("playwright.sync_api")

    class _FakeTimeoutError(Exception):
        pass

    class Locator:  # marker — only referenced by type imports
        pass

    def expect(*args, **kwargs):  # pragma: no cover - not invoked by cancel tests
        raise AssertionError("expect should not be invoked by cancel tests")

    _sync_api.TimeoutError = _FakeTimeoutError
    _sync_api.Locator = Locator
    _sync_api.expect = expect

    def _sync_api_getattr(name):  # pragma: no cover - defensive
        return type(name, (), {})

    _sync_api.__getattr__ = _sync_api_getattr
    _pw.sync_api = _sync_api
    sys.modules["playwright"] = _pw
    sys.modules["playwright.sync_api"] = _sync_api


# ``pages.base_page`` drags in Playwright + config (dotenv); the cancel methods
# only need a ``BasePage`` to subclass. Provide a trivial one.
try:  # pragma: no cover - prefer the real module when its deps are installed
    import pages.base_page as _real_base_page  # noqa: F401
except Exception:
    _bp = types.ModuleType("pages.base_page")

    class BasePage:  # minimal stand-in
        pass

    _bp.BasePage = BasePage
    sys.modules["pages.base_page"] = _bp


# ``utils.logger`` may pull in optional config deps; a no-op logger is enough.
try:  # pragma: no cover
    import utils.logger as _real_logger  # noqa: F401
except Exception:
    _lg = types.ModuleType("utils.logger")

    class _NullLogger:
        def __getattr__(self, _name):
            return lambda *a, **k: None

    _lg.get_logger = lambda *a, **k: _NullLogger()
    sys.modules["utils.logger"] = _lg


# A controllable ScreenshotHelper stub: the module under test binds this symbol
# at import via ``from utils.screenshot_helper import ScreenshotHelper``. The
# cancel flow records a ``{prefix}_cancel`` step via record_step on success.
class _FakeScreenshotHelper:
    def __init__(self) -> None:
        self.calls: list[str] = []
        self.raise_on_capture = False
        self.return_path = "/tmp/shot.png"

    def capture(self, page, name="screenshot"):
        self.calls.append(name)
        if self.raise_on_capture:
            raise RuntimeError("simulated capture failure")
        return self.return_path


_FAKE_SH = _FakeScreenshotHelper()
_sh_mod = types.ModuleType("utils.screenshot_helper")
_sh_mod.ScreenshotHelper = _FAKE_SH
sys.modules["utils.screenshot_helper"] = _sh_mod


def _load_reference_interfaces_page():
    """Load pages/reference_interfaces_page.py as a standalone module."""
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, os.pardir, "pages", "reference_interfaces_page.py")
    spec = importlib.util.spec_from_file_location(
        "reference_interfaces_page_cancel_under_test", os.path.abspath(path)
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_rip_module = _load_reference_interfaces_page()
ReferenceInterfacesPage = _rip_module.ReferenceInterfacesPage
# The module's TimeoutError alias (the fake one when Playwright is absent), used
# to simulate a modal that never closes / a row that never detaches.
PlaywrightTimeoutError = _rip_module.PlaywrightTimeoutError


# ──────────────────────────────────────────────────────────────
# Test doubles for the browser surface touched by the cancel flow.
# ──────────────────────────────────────────────────────────────
class _FakeFirst:
    """Stands in for ``locator.first`` — its ``wait_for`` can be made to raise."""

    def __init__(self, raise_on_wait: bool) -> None:
        self.raise_on_wait = raise_on_wait
        self.wait_calls: list[dict] = []

    def wait_for(self, state=None, timeout=None):
        self.wait_calls.append({"state": state, "timeout": timeout})
        if self.raise_on_wait:
            raise PlaywrightTimeoutError("simulated row wait timeout")


class _FakeRow:
    def __init__(self, raise_on_wait: bool) -> None:
        self.first = _FakeFirst(raise_on_wait)


class _FakePage:
    """Minimal Playwright Page stand-in returning a controllable row locator."""

    def __init__(self, row_still_present: bool) -> None:
        self._row_still_present = row_still_present
        self.locator_selectors: list[str] = []

    def locator(self, selector: str):
        self.locator_selectors.append(selector)
        # When the row is "still present" its detach wait never resolves → raise.
        return _FakeRow(raise_on_wait=self._row_still_present)


def _make_page(
    *,
    modal_closes: bool,
    row_still_present: bool,
    run_log: RunStepLog | None = None,
) -> ReferenceInterfacesPage:
    """Build a ReferenceInterfacesPage with the browser surface stubbed.

    Parameters
    ----------
    modal_closes:
        When False, ``wait_for_element_hidden`` raises a timeout so the Cancel
        path simulates a modal that never closes.
    row_still_present:
        When True, the row locator's detach ``wait_for`` raises a timeout so the
        Add-cancel verification simulates a record still present in the grid.
    """
    page = ReferenceInterfacesPage.__new__(ReferenceInterfacesPage)
    page.page = _FakePage(row_still_present=row_still_present)
    page.timeout = 30_000
    page.click_calls: list[str] = []
    page.hidden_waits: list[str] = []

    def _click(selector):
        page.click_calls.append(selector)

    def _wait_for_element_hidden(selector, timeout=None):
        page.hidden_waits.append(selector)
        if not modal_closes:
            raise PlaywrightTimeoutError("simulated modal-hidden timeout")

    page.click = _click
    page.wait_for_element_hidden = _wait_for_element_hidden
    # Provide the selected reference type used to derive the screenshot prefix.
    page.get_selected_option = lambda: "Bankruptcy Types"
    if run_log is not None:
        page.run_step_log = run_log
    return page


def setup_function(_func):
    _FAKE_SH.calls.clear()
    _FAKE_SH.raise_on_capture = False
    _FAKE_SH.return_path = "/tmp/shot.png"


# ══════════════════════════════════════════════════════════════
# Tests
# ══════════════════════════════════════════════════════════════
def test_cancel_with_verify_add_raises_when_modal_does_not_close():
    """A modal that never closes after Cancel raises a descriptive timeout error.

    Validates: Requirement 7.2
    """
    page = _make_page(modal_closes=False, row_still_present=False)

    try:
        page.cancel_with_verify_add("ABC")
        raised = None
    except AssertionError as exc:
        raised = exc

    assert raised is not None, "Expected an AssertionError when the modal stays open"
    message = str(raised)
    assert "Add record modal" in message, message
    assert "did not" in message and "close" in message, message
    # Cancel was clicked but no screenshot/verification happened past the timeout.
    assert page.click_calls == [ReferenceInterfacesPage.MODAL_CANCEL]
    assert _FAKE_SH.calls == []


def test_cancel_with_verify_add_timeout_message_names_configured_timeout():
    """The modal-not-closed error reports the configured timeout value.

    Validates: Requirement 7.2
    """
    page = _make_page(modal_closes=False, row_still_present=False)

    try:
        page.cancel_with_verify_add("ABC")
        raised = None
    except AssertionError as exc:
        raised = exc

    assert raised is not None
    assert str(page.timeout) in str(raised), str(raised)


def test_cancel_with_verify_add_raises_when_code_still_present():
    """A Code still present after a cancelled Add raises a descriptive error.

    Validates: Requirement 7.4
    """
    page = _make_page(modal_closes=True, row_still_present=True)

    try:
        page.cancel_with_verify_add("DUP-1")
        raised = None
    except AssertionError as exc:
        raised = exc

    assert raised is not None, "Expected an AssertionError when the Code remains"
    message = str(raised)
    assert "DUP-1" in message, message
    assert "present" in message, message
    # Modal closed (Cancel clicked + hidden wait), but no cancel screenshot was
    # taken because verification failed.
    assert page.click_calls == [ReferenceInterfacesPage.MODAL_CANCEL]
    assert page.hidden_waits == [ReferenceInterfacesPage.MODAL_BOX]
    assert _FAKE_SH.calls == []


def test_cancel_with_verify_add_success_records_single_cancel_step():
    """The happy path closes the modal, confirms absence, and records one step.

    Validates: Requirements 7.1, 7.3, 7.6
    """
    log = RunStepLog()
    page = _make_page(modal_closes=True, row_still_present=False, run_log=log)

    page.cancel_with_verify_add("GONE")  # must not raise

    # Cancel clicked, modal-hidden awaited.
    assert page.click_calls == [ReferenceInterfacesPage.MODAL_CANCEL]
    assert page.hidden_waits == [ReferenceInterfacesPage.MODAL_BOX]
    # Exactly one {prefix}_cancel screenshot/step recorded.
    assert _FAKE_SH.calls == ["Bankruptcy_Types_cancel"]
    entries = log.entries()
    assert len(entries) == 1
    assert entries[0].label == "Bankruptcy_Types_cancel"
    assert entries[0].failed is False


def test_cancel_modal_within_timeout_helper_names_supplied_label():
    """The shared helper surfaces the supplied modal label on timeout.

    Validates: Requirement 7.2
    """
    page = _make_page(modal_closes=False, row_still_present=False)

    try:
        page._cancel_modal_within_timeout("Edit record modal")
        raised = None
    except AssertionError as exc:
        raised = exc

    assert raised is not None
    assert "Edit record modal" in str(raised), str(raised)
    assert page.click_calls == [ReferenceInterfacesPage.MODAL_CANCEL]
