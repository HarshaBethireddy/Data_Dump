"""
tests/test_collection_smoke.py
───────────────────────────────
Smoke / collection regression guard for the activity-execution-and-reporting
feature (task 10.3).

Scope
-----
This is a wiring/regression test, not a behavioural one. It guards the
one-time setup and structural invariants the feature depends on:

  • ``python-docx`` and ``hypothesis`` are installed and importable, and pinned
    in ``requirements.txt``                                    (Requirement 10.6)
  • No NEW public helper has been added to ``BasePage`` — the activities feature
    is built strictly on the existing ``BasePage`` API, and ``ActivitiesMixin``
    does not shadow any generic ``BasePage`` helper          (Requirements 1.8)
  • All shared activity step phrases are registered (via ``@step`` decorators)
    in ``steps/activities_steps.py`` with no category missing, so the BDD suite
    binds every shared activity step                  (Requirements 1.9, 11.1)
  • The required activity-flow scenarios are present on both the Customer
    Overview and Account Activity features              (Requirements 11.2, 11.6)

Environment note
----------------
``pytest-bdd`` and ``playwright`` are pinned in ``requirements.txt`` but are not
necessarily installed in every environment (e.g. CI lint/unit stages). A real
subprocess ``pytest --collect-only`` of the full BDD suite therefore cannot
always run. To stay collectible and runnable everywhere, the collection-style
checks are performed **statically**:

  • ``BasePage`` public methods are read by parsing ``pages/base_page.py`` with
    the ``ast`` module — no ``playwright`` import required.
  • Registered step phrases are read by parsing ``steps/activities_steps.py``.
  • Required scenarios are read by parsing the ``.feature`` files directly.

A real ``pytest --collect-only`` is additionally attempted, but only when
``pytest_bdd`` and ``playwright`` are importable (otherwise it is skipped).
"""
from __future__ import annotations

import ast
import sys
import subprocess
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[1]
PAGES_DIR = PROJECT_ROOT / "pages"
STEPS_DIR = PROJECT_ROOT / "steps"
FEATURES_DIR = PROJECT_ROOT / "features"


# ──────────────────────────────────────────────────────────────
# Static-parsing helpers
# ──────────────────────────────────────────────────────────────

def _public_method_names(source: str, class_name: str) -> set[str]:
    """
    Return the set of public method names (not starting with ``_``) defined
    directly on ``class_name`` in the given Python ``source``, using ``ast`` so
    no module import (and thus no third-party dependency) is required.
    """
    tree = ast.parse(source)
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if not item.name.startswith("_"):
                        names.add(item.name)
            break
    return names


def _step_phrases(source: str) -> list[str]:
    """
    Extract the literal step phrases registered via ``@step(...)`` decorators in
    the given step-module ``source``.

    Handles both forms used in the codebase:
        @step("literal text")
        @step(parsers.parse('text with {placeholders}'))
    """
    tree = ast.parse(source)
    phrases: list[str] = []

    def _literal_from_arg(arg: ast.expr) -> str | None:
        # @step("...") — a bare string literal
        if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
            return arg.value
        # @step(parsers.parse("...")) — first arg of the inner call
        if isinstance(arg, ast.Call) and arg.args:
            inner = arg.args[0]
            if isinstance(inner, ast.Constant) and isinstance(inner.value, str):
                return inner.value
        return None

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for dec in node.decorator_list:
            if isinstance(dec, ast.Call):
                func = dec.func
                is_step = (
                    (isinstance(func, ast.Name) and func.id == "step")
                    or (isinstance(func, ast.Attribute) and func.attr == "step")
                )
                if is_step and dec.args:
                    phrase = _literal_from_arg(dec.args[0])
                    if phrase is not None:
                        phrases.append(phrase)
    return phrases


def _active_scenarios(feature_text: str) -> list[tuple[str, str]]:
    """
    Parse a ``.feature`` file's text into a list of ``(scenario_name, body)``
    tuples, ignoring Gherkin comment lines (those whose first non-space
    character is ``#``). The body is the concatenation of the scenario's
    (non-comment) step lines.
    """
    scenarios: list[tuple[str, str]] = []
    current_name: str | None = None
    current_lines: list[str] = []

    def _flush() -> None:
        if current_name is not None:
            scenarios.append((current_name, "\n".join(current_lines)))

    for raw in feature_text.splitlines():
        stripped = raw.strip()
        if stripped.startswith("#"):
            continue  # commented-out line — not executable
        if stripped.startswith("Scenario:") or stripped.startswith("Scenario Outline:"):
            _flush()
            current_name = stripped.split(":", 1)[1].strip()
            current_lines = []
        elif current_name is not None:
            if stripped.startswith("Feature:"):
                _flush()
                current_name = None
                current_lines = []
            else:
                current_lines.append(stripped)
    _flush()
    return scenarios


# Markers that indicate a scenario exercises the shared Activities flow.
_ACTIVITY_STEP_MARKERS = (
    "I click the Activities tab in the sidebar",
    "I click the parent activity",
    "I expand parent activity",
    "I wait for the activity iframe",
    "the activity iframe should be loaded",
    "the activity list should be visible",
    "I trigger the activity",
    "the activity iframe variant should be",
    "I submit the activity",
    "should appear in the timeline",
    "I iterate every enabled tab in the activity details",
)


def _activity_flow_scenarios(feature_text: str) -> list[str]:
    """Names of active scenarios whose body references any Activities-flow step."""
    matched: list[str] = []
    for name, body in _active_scenarios(feature_text):
        if any(marker in body for marker in _ACTIVITY_STEP_MARKERS):
            matched.append(name)
    return matched


# ──────────────────────────────────────────────────────────────
# Requirement 10.6 — dependencies installed and pinned
# ──────────────────────────────────────────────────────────────

def test_python_docx_is_importable() -> None:
    """python-docx (imported as ``docx``) must be installed (Req 10.6)."""
    try:
        import docx  # noqa: F401  (python-docx)
    except ImportError as exc:  # pragma: no cover - environment guard
        pytest.fail(
            "python-docx must be installed for the reporting layer "
            f"(Requirement 10.6): {exc}"
        )


def test_hypothesis_is_importable() -> None:
    """Hypothesis must be installed for the property-based tests (Req 10.6)."""
    try:
        import hypothesis  # noqa: F401
    except ImportError as exc:  # pragma: no cover - environment guard
        pytest.fail(
            "hypothesis must be installed for property-based tests "
            f"(Requirement 10.6): {exc}"
        )


def test_new_dependencies_pinned_in_requirements() -> None:
    """
    Both new dependencies are declared (pinned) in ``requirements.txt`` following
    the existing pinned-dependency convention (Requirement 10.6).
    """
    req_text = (PROJECT_ROOT / "requirements.txt").read_text(encoding="utf-8")
    assert "python-docx==1.1.2" in req_text, (
        "python-docx must be pinned in requirements.txt (Requirement 10.6)"
    )
    assert "hypothesis==6.103.1" in req_text, (
        "hypothesis must be pinned in requirements.txt (Requirement 10.6)"
    )


# ──────────────────────────────────────────────────────────────
# Requirement 1.8 — no new public helper on BasePage
# ──────────────────────────────────────────────────────────────

# Snapshot of the public BasePage helper surface. The activities feature must be
# built on these existing helpers WITHOUT introducing new generic helpers
# (Requirement 1.8). If a new public helper is genuinely required and approved,
# update this snapshot deliberately — the test then documents the change.
_EXPECTED_BASE_PAGE_PUBLIC_METHODS = {
    # navigation
    "navigate", "get_title", "get_url", "reload",
    # element lookups
    "find", "find_by_id", "find_by_label", "find_by_role",
    "find_by_text", "find_by_placeholder",
    # interactions
    "click", "fill", "fill_and_trigger", "slow_type", "clear",
    "select_option", "press_key",
    # waits
    "wait_for_selector", "wait_for_url", "wait_for_load_state",
    "wait_for_element_visible", "wait_for_element_hidden", "wait_ms",
    "wait_for_spinner_gone",
    # state queries
    "is_visible", "is_enabled", "get_text", "get_attribute",
    # screenshots
    "screenshot", "screenshot_full",
    # assertions
    "assert_visible", "assert_text", "assert_contains_text",
    "assert_url_contains", "assert_title_contains",
}


def test_no_new_public_helper_added_to_base_page() -> None:
    """
    The public method surface of ``BasePage`` must match the approved snapshot.
    Any new public helper (an addition) violates Requirement 1.8; any removal of
    a helper the mixin relies on would break the activities feature.
    """
    source = (PAGES_DIR / "base_page.py").read_text(encoding="utf-8")
    actual = _public_method_names(source, "BasePage")

    added = actual - _EXPECTED_BASE_PAGE_PUBLIC_METHODS
    removed = _EXPECTED_BASE_PAGE_PUBLIC_METHODS - actual

    assert not added, (
        "New public helper(s) added to BasePage — Requirement 1.8 forbids "
        f"introducing new generic BasePage helpers for this feature: {sorted(added)}"
    )
    assert not removed, (
        "Existing BasePage helper(s) the activities feature relies on were "
        f"removed: {sorted(removed)}"
    )


def test_activities_mixin_relies_on_existing_base_page_helpers() -> None:
    """
    The helpers the ``ActivitiesMixin`` composes on are real ``BasePage`` helpers
    (Requirement 1.8). Spot-check the key ones named in the design.
    """
    source = (PAGES_DIR / "base_page.py").read_text(encoding="utf-8")
    base_helpers = _public_method_names(source, "BasePage")
    for helper in ("click", "fill_and_trigger", "wait_for_spinner_gone",
                   "screenshot", "wait_for_element_visible", "is_visible",
                   "assert_visible", "select_option"):
        assert helper in base_helpers, (
            f"Expected BasePage helper '{helper}' used by ActivitiesMixin is missing"
        )


def test_activities_mixin_does_not_redefine_base_page_helpers() -> None:
    """
    ``ActivitiesMixin`` must not define a method that shadows a generic
    ``BasePage`` helper — new behaviour lives in mixin-specific methods, the
    feature reuses BasePage helpers rather than re-implementing them
    (Requirement 1.8).
    """
    base_source = (PAGES_DIR / "base_page.py").read_text(encoding="utf-8")
    mixin_source = (PAGES_DIR / "activities_mixin.py").read_text(encoding="utf-8")

    base_helpers = _public_method_names(base_source, "BasePage")
    mixin_methods = _public_method_names(mixin_source, "ActivitiesMixin")

    collisions = base_helpers & mixin_methods
    assert not collisions, (
        "ActivitiesMixin redefines generic BasePage helper(s) instead of "
        f"reusing them (Requirement 1.8): {sorted(collisions)}"
    )


# ──────────────────────────────────────────────────────────────
# Requirements 1.9, 11.1 — shared activity steps are bound
# ──────────────────────────────────────────────────────────────

# Each tuple is (category, phrase-fragment). Every Requirement 11.1 category
# must be covered by at least one registered @step phrase.
_REQUIRED_STEP_CATEGORIES = (
    ("activity triggering", "I trigger the activity"),
    ("variant detection", "the activity iframe variant should be"),
    ("inputs-variant input filling", "I fill the activity inputs with the following values"),
    ("OK submission", "I submit the activity"),
    ("Cancel/abandon", "I cancel the activity"),
    ("timeline verification", "should appear in the timeline"),
    ("enabled-tab iteration", "I iterate every enabled tab in the activity details"),
)


def test_shared_activity_steps_are_registered() -> None:
    """
    Every Requirement 11.1 shared-activity-step category is registered via a
    ``@step`` decorator in ``steps/activities_steps.py`` — so the BDD suite binds
    all shared activity steps with none undefined/unbound.
    """
    source = (STEPS_DIR / "activities_steps.py").read_text(encoding="utf-8")
    phrases = _step_phrases(source)
    assert phrases, "No @step phrases found in steps/activities_steps.py"

    joined = "\n".join(phrases)
    missing = [
        category
        for category, fragment in _REQUIRED_STEP_CATEGORIES
        if fragment not in joined
    ]
    assert not missing, (
        "Shared activity step(s) not registered in activities_steps.py "
        f"(Requirement 11.1): {missing}. Registered phrases: {phrases}"
    )


# ──────────────────────────────────────────────────────────────
# Requirements 11.2, 11.6 — required scenarios present on both features
# ──────────────────────────────────────────────────────────────

def test_customer_overview_has_activity_flow_scenario() -> None:
    """
    The Customer Overview feature contains at least one executable scenario that
    exercises the shared Activities flow (Requirement 11.2).
    """
    text = (FEATURES_DIR / "customer_overview.feature").read_text(encoding="utf-8")
    matched = _activity_flow_scenarios(text)
    assert matched, (
        "features/customer_overview.feature must contain at least one active "
        "activity-flow scenario (Requirement 11.2)"
    )


def test_account_activity_has_activity_flow_scenario() -> None:
    """
    The Account Activity feature must contain at least one executable scenario
    that exercises the shared Activities flow (Requirement 11.2).

    The full trigger→submit→verify→drill scenario is added by task 10.2. Until
    that task lands, the feature has no *active* activity scenario, so this guard
    skips with an explicit, actionable reason rather than failing spuriously —
    keeping the regression suite green while still asserting quality once the
    scenario is present.
    """
    text = (FEATURES_DIR / "account_activity.feature").read_text(encoding="utf-8")
    matched = _activity_flow_scenarios(text)
    if not matched:
        pytest.skip(
            "No active activity-flow scenario in features/account_activity.feature "
            "yet; it is added by task 10.2 (Requirement 11.2)."
        )
    assert matched, (
        "features/account_activity.feature must contain at least one active "
        "activity-flow scenario (Requirement 11.2)"
    )


# ──────────────────────────────────────────────────────────────
# Requirement 11.6 — real `pytest --collect-only` (only when BDD deps present)
# ──────────────────────────────────────────────────────────────

def test_full_bdd_collection_has_no_unbound_steps() -> None:
    """
    When ``pytest_bdd`` and ``playwright`` are installed, a real subprocess
    ``pytest --collect-only`` of the BDD suite must succeed with no
    collection errors (no undefined/unbound steps) (Requirements 1.9, 11.6).

    In environments without those packages (e.g. unit-only CI), the full suite
    cannot be collected, so this check is skipped — the static checks above
    cover the same invariants structurally.
    """
    pytest.importorskip("pytest_bdd", reason="pytest-bdd not installed")
    pytest.importorskip("playwright", reason="playwright not installed")

    result = subprocess.run(
        [sys.executable, "-m", "pytest", "--collect-only", "-q",
         "tests/test_customer_overview.py", "tests/test_account_activity.py"],
        cwd=str(PROJECT_ROOT),
        capture_output=True,
        text=True,
    )
    combined = result.stdout + result.stderr
    assert result.returncode == 0, (
        f"pytest --collect-only reported collection errors "
        f"(possible unbound/undefined steps):\n{combined}"
    )
    assert "error" not in combined.lower(), (
        f"pytest --collect-only output contains errors:\n{combined}"
    )
