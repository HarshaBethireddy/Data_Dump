"""
tests/test_reference_interfaces_delete.py
──────────────────────────────────────────
Example/unit tests for the delete-flow error paths on
``ReferenceInterfacesPage`` (task 7.3).

Scope
-----
Two delete-flow methods must surface descriptive failures:

  • ``delete_added_record(code)`` — when the Delete action surfaces a validation
    error so the Edit_Modal does not close within the configured timeout, a
    descriptive ``AssertionError`` naming the offending Code is raised; the modal
    is left open and the record is retained in the grid (Requirement 6.5).
  • ``verify_deleted(code)`` — when a record with the deleted ``code`` is still
    present in the Record_Grid after the Delete operation, a descriptive
    ``AssertionError`` naming the Code expected to be absent is raised
    (Requirement 6.7).

Success paths are also pinned: ``delete_added_record`` records exactly the
``{prefix}_delete_modal_open`` and ``{prefix}_delete_confirmed`` steps, and
``verify_deleted`` records exactly one ``{prefix}_delete_verified`` step.

Environment note
----------------
``playwright`` is not necessarily installed, and ``ReferenceInterfacesPage``
imports ``playwright.sync_api`` (directly and via ``pages.base_page``) at module
load time. Mirroring ``tests/test_reference_interfaces_cancel.py``, when the real
package is absent we register lightweight fake modules for
``playwright.sync_api``, ``pages.base_page``, ``utils.screenshot_helper`` and
``utils.logger`` so the page module can be loaded in isolation and the delete
methods exercised without a browser. Browser interactions used by the delete
flow (``click_row_by_code``, ``_wait_for_modal``, ``wait_for_element_visible``,
``click``, ``_confirm_delete_if_required``, ``wait_for_element_hidden``,
``wait_for_spinner_gone`` and the row locator) are stubbed on the page instance
so we can simulate a modal that never closes and a row that never detaches.
"""
from __future__ import annotations

import importlib.util
import os
import sys
import types

from utils.run_step_log import RunStepLog


# ──────────────────────────────────────────────────────────────
# Register fakes (only when the real Playwright package is absent) so
# pages/reference_interfaces_page.py can be loaded standalone.
# ──────────────────────────────────────────────────────────────
try:  # pragma: no cover - prefer the real package when installed
    import playwright.sync_api as _real_sync_api  # noqa: F401
except Exception:
    _pw = types.ModuleType("playwright")
    _sync_api = types.ModuleType("playwright.sync_api")

    class _FakeTimeoutError(Exception):
        pass

    class Locator:  # marker — only referenced by type imports
        pass

    def expect(*args, **kwargs):  # pragma: no cover - not invoked by delete tests
        raise AssertionError("expect should not be invoked by delete tests")

    _sync_api.TimeoutError = _FakeTimeoutError
    _sync_api.Locator = Locator
    _sync_api.expect = expect

    def _sync_api_getattr(name):  # pragma: no cover - defensive
        return type(name, (), {})

    _sync_api.__getattr__ = _sync_api_getattr
    _pw.sync_api = _sync_api
    sys.modules["playwright"] = _pw
    sys.modules["playwright.sync_api"] = _sync_api


# ``pages.base_page`` drags in Playwright + config (dotenv); the delete methods
# only need a ``BasePage`` to subclass. Provide a trivial one.
try:  # pragma: no cover - prefer the real module when its deps are installed
    import pages.base_page as _real_base_page  # noqa: F401
except Exception:
    _bp = types.ModuleType("pages.base_page")

    class BasePage:  # minimal stand-in
        pass

    _bp.BasePage = BasePage
    sys.modules["pages.base_page"] = _bp


# ``utils.logger`` may pull in optional config deps; a no-op logger is enough.
try:  # pragma: no cover
    import utils.logger as _real_logger  # noqa: F401
except Exception:
    _lg = types.ModuleType("utils.logger")

    class _NullLogger:
        def __getattr__(self, _name):
            return lambda *a, **k: None

    _lg.get_logger = lambda *a, **k: _NullLogger()
    sys.modules["utils.logger"] = _lg


# A controllable ScreenshotHelper stub: the module under test binds this symbol
# at import via ``from utils.screenshot_helper import ScreenshotHelper``. The
# delete flow records steps via record_step on success.
class _FakeScreenshotHelper:
    def __init__(self) -> None:
        self.calls: list[str] = []
        self.raise_on_capture = False
        self.return_path = "/tmp/shot.png"

    def capture(self, page, name="screenshot"):
        self.calls.append(name)
        if self.raise_on_capture:
            raise RuntimeError("simulated capture failure")
        return self.return_path


_FAKE_SH = _FakeScreenshotHelper()
_sh_mod = types.ModuleType("utils.screenshot_helper")
_sh_mod.ScreenshotHelper = _FAKE_SH
sys.modules["utils.screenshot_helper"] = _sh_mod


def _load_reference_interfaces_page():
    """Load pages/reference_interfaces_page.py as a standalone module."""
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, os.pardir, "pages", "reference_interfaces_page.py")
    spec = importlib.util.spec_from_file_location(
        "reference_interfaces_page_delete_under_test", os.path.abspath(path)
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_rip_module = _load_reference_interfaces_page()
ReferenceInterfacesPage = _rip_module.ReferenceInterfacesPage
# The module's TimeoutError alias (the fake one when Playwright is absent), used
# to simulate a modal that never closes / a row that never detaches.
PlaywrightTimeoutError = _rip_module.PlaywrightTimeoutError


# ──────────────────────────────────────────────────────────────
# Test doubles for the browser surface touched by the delete flow.
# ──────────────────────────────────────────────────────────────
class _FakeFirst:
    """Stands in for ``locator.first`` — its ``wait_for`` can be made to raise."""

    def __init__(self, raise_on_wait: bool) -> None:
        self.raise_on_wait = raise_on_wait
        self.wait_calls: list[dict] = []

    def wait_for(self, state=None, timeout=None):
        self.wait_calls.append({"state": state, "timeout": timeout})
        if self.raise_on_wait:
            raise PlaywrightTimeoutError("simulated row wait timeout")


class _FakeRow:
    def __init__(self, raise_on_wait: bool) -> None:
        self.first = _FakeFirst(raise_on_wait)


class _FakePage:
    """Minimal Playwright Page stand-in returning a controllable row locator."""

    def __init__(self, row_still_present: bool) -> None:
        self._row_still_present = row_still_present
        self.locator_selectors: list[str] = []

    def locator(self, selector: str):
        self.locator_selectors.append(selector)
        # When the row is "still present" its detach wait never resolves → raise.
        return _FakeRow(raise_on_wait=self._row_still_present)


def _make_page(
    *,
    modal_closes: bool = True,
    row_still_present: bool = False,
    run_log: RunStepLog | None = None,
) -> ReferenceInterfacesPage:
    """Build a ReferenceInterfacesPage with the browser surface stubbed.

    Parameters
    ----------
    modal_closes:
        When False, ``wait_for_element_hidden`` raises a timeout so the Delete
        path simulates a modal that never closes (validation error).
    row_still_present:
        When True, the row locator's detach ``wait_for`` raises a timeout so the
        delete verification simulates a record still present in the grid.
    """
    page = ReferenceInterfacesPage.__new__(ReferenceInterfacesPage)
    page.page = _FakePage(row_still_present=row_still_present)
    page.timeout = 30_000
    page.click_calls: list[str] = []
    page.visible_waits: list[str] = []
    page.hidden_waits: list[str] = []
    page.spinner_waits: list[str] = []
    page.row_clicks: list[str] = []
    page.confirm_calls = 0
    page.modal_waits = 0

    def _click(selector):
        page.click_calls.append(selector)

    def _wait_for_element_visible(selector, timeout=None):
        page.visible_waits.append(selector)

    def _wait_for_element_hidden(selector, timeout=None):
        page.hidden_waits.append(selector)
        if not modal_closes:
            raise PlaywrightTimeoutError("simulated modal-hidden timeout")

    def _wait_for_spinner_gone(selector, timeout=None):
        page.spinner_waits.append(selector)

    def _click_row_by_code(code):
        page.row_clicks.append(code)

    def _wait_for_modal(timeout=None):
        page.modal_waits += 1

    def _confirm_delete_if_required(timeout=None):
        page.confirm_calls += 1

    page.click = _click
    page.wait_for_element_visible = _wait_for_element_visible
    page.wait_for_element_hidden = _wait_for_element_hidden
    page.wait_for_spinner_gone = _wait_for_spinner_gone
    page.click_row_by_code = _click_row_by_code
    page._wait_for_modal = _wait_for_modal
    page._confirm_delete_if_required = _confirm_delete_if_required
    # Provide the selected reference type used to derive the screenshot prefix.
    page.get_selected_option = lambda: "Bankruptcy Types"
    if run_log is not None:
        page.run_step_log = run_log
    return page


def setup_function(_func):
    _FAKE_SH.calls.clear()
    _FAKE_SH.raise_on_capture = False
    _FAKE_SH.return_path = "/tmp/shot.png"


# ══════════════════════════════════════════════════════════════
# delete_added_record — validation error keeps modal open (Req 6.5)
# ══════════════════════════════════════════════════════════════
def test_delete_added_record_raises_when_modal_does_not_close():
    """A modal that never closes after Delete raises a descriptive error.

    Validates: Requirements 6.5
    """
    page = _make_page(modal_closes=False)

    try:
        page.delete_added_record("ABC")
        raised = None
    except AssertionError as exc:
        raised = exc

    assert raised is not None, "Expected an AssertionError when the modal stays open"
    message = str(raised)
    # Req 6.5 — message names the offending Code.
    assert "ABC" in message, message
    # Req 6.5 — message describes the modal not closing / record retained.
    assert "did not close" in message, message
    assert "retained" in message, message
    # Only the delete_modal_open screenshot is taken before the timeout; the
    # delete_confirmed screenshot must NOT be captured on the failure path.
    assert _FAKE_SH.calls == ["Bankruptcy_Types_delete_modal_open"]
    # The Delete button was clicked and the modal-hidden wait was attempted.
    assert ReferenceInterfacesPage.MODAL_DELETE in page.click_calls
    assert page.hidden_waits == [ReferenceInterfacesPage.MODAL_BOX]


def test_delete_added_record_timeout_message_names_configured_timeout():
    """The validation-error message reports the configured timeout value.

    Validates: Requirements 6.5
    """
    page = _make_page(modal_closes=False)

    try:
        page.delete_added_record("ABC")
        raised = None
    except AssertionError as exc:
        raised = exc

    assert raised is not None
    assert str(page.timeout) in str(raised), str(raised)


def test_delete_added_record_targets_only_the_supplied_code():
    """Only the supplied Code's row is opened on the validation-error path.

    Validates: Requirements 6.5
    """
    page = _make_page(modal_closes=False)

    try:
        page.delete_added_record("ONLY-ME")
    except AssertionError:
        pass

    # Req 6.2/6.5 — exactly the supplied Code is targeted, no other record.
    assert page.row_clicks == ["ONLY-ME"]


def test_delete_added_record_success_records_open_and_confirmed_steps():
    """The happy path opens the modal, deletes, and records two ordered steps.

    Validates: Requirements 6.5 (success path companion)
    """
    log = RunStepLog()
    page = _make_page(modal_closes=True, run_log=log)

    page.delete_added_record("GONE")  # must not raise

    # Two screenshots, in order: delete_modal_open then delete_confirmed.
    assert _FAKE_SH.calls == [
        "Bankruptcy_Types_delete_modal_open",
        "Bankruptcy_Types_delete_confirmed",
    ]
    labels = [e.label for e in log.entries()]
    assert labels == [
        "Bankruptcy_Types_delete_modal_open",
        "Bankruptcy_Types_delete_confirmed",
    ]
    assert all(e.failed is False for e in log.entries())
    # Confirmation probe ran, spinner wait happened on success.
    assert page.confirm_calls == 1
    assert page.spinner_waits == [ReferenceInterfacesPage.SPINNER]


# ══════════════════════════════════════════════════════════════
# verify_deleted — still-present Code raises (Req 6.7)
# ══════════════════════════════════════════════════════════════
def test_verify_deleted_raises_when_code_still_present():
    """A Code still present after Delete raises a descriptive error.

    Validates: Requirements 6.7
    """
    page = _make_page(row_still_present=True)

    try:
        page.verify_deleted("STILL-HERE")
        raised = None
    except AssertionError as exc:
        raised = exc

    assert raised is not None, "Expected an AssertionError when the Code remains"
    message = str(raised)
    # Req 6.7 — message names the Code expected to be absent.
    assert "STILL-HERE" in message, message
    assert "still present" in message, message
    # No delete_verified screenshot on the failure path.
    assert _FAKE_SH.calls == []


def test_verify_deleted_message_names_configured_timeout():
    """The still-present error reports the configured timeout value.

    Validates: Requirements 6.7
    """
    page = _make_page(row_still_present=True)

    try:
        page.verify_deleted("STILL-HERE")
        raised = None
    except AssertionError as exc:
        raised = exc

    assert raised is not None
    assert str(page.timeout) in str(raised), str(raised)


def test_verify_deleted_success_records_single_verified_step():
    """When the Code is absent, exactly one delete_verified step is recorded.

    Validates: Requirements 6.7 (success path companion)
    """
    log = RunStepLog()
    page = _make_page(row_still_present=False, run_log=log)

    page.verify_deleted("GONE")  # must not raise

    assert _FAKE_SH.calls == ["Bankruptcy_Types_delete_verified"]
    entries = log.entries()
    assert len(entries) == 1
    assert entries[0].label == "Bankruptcy_Types_delete_verified"
    assert entries[0].failed is False
