"""
tests/test_account_activity.py
────────────────────────────────
Binds features/account_activity.feature to pytest-bdd.
Step implementations live in steps/account_activity_steps.py
and steps/customer_overview_steps.py (for the shared Background steps).
"""
from pytest_bdd import scenarios

scenarios("../features/account_activity.feature")
