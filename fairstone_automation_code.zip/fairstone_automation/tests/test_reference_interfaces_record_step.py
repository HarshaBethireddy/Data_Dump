"""
tests/test_reference_interfaces_record_step.py
──────────────────────────────────────────────
Example tests for ``ReferenceInterfacesPage.record_step`` (task 3.1).

Scope
-----
``record_step(label)`` is the single recording point for every mandated
Reference Interfaces step. These tests pin its three guarantees:

  • Success path — captures exactly one screenshot and appends exactly one
    ordered Run_Step_Log entry carrying the label and the captured path
    (Requirements 9.1, 9.2, 9.3).
  • Capture-failure path — when ``ScreenshotHelper.capture`` raises, exactly one
    failure-labelled entry (``failed=True``, no screenshot path) is appended and
    no exception escapes (Requirement 9.4).
  • Defensive log read — with no ``run_step_log`` injected the method never
    fails, whether capture succeeds or raises.

Environment note
----------------
The project pins ``playwright`` in requirements.txt, but it is not necessarily
installed in the test environment, and ``ReferenceInterfacesPage`` imports
``playwright.sync_api`` (directly and via ``pages.base_page``) at module load
time. Mirroring ``tests/test_activities_mixin_errors.py``, when the real package
is absent we register lightweight fake modules for ``playwright.sync_api``,
``pages.base_page``, ``utils.screenshot_helper`` and ``utils.logger`` so the
page module can be loaded in isolation and its pure recording logic exercised
without a browser.
"""
from __future__ import annotations

import importlib.util
import os
import sys
import types

# The real RunStepLog has no browser dependency, so it is used as-is to assert
# the actual recorded entries.
from utils.run_step_log import RunStepLog


# ──────────────────────────────────────────────────────────────
# Register fakes (only when the real Playwright package is absent) so
# pages/reference_interfaces_page.py can be loaded standalone.
# ──────────────────────────────────────────────────────────────
try:  # pragma: no cover - prefer the real package when installed
    import playwright.sync_api as _real_sync_api  # noqa: F401
except Exception:
    _pw = types.ModuleType("playwright")
    _sync_api = types.ModuleType("playwright.sync_api")

    class _FakeTimeoutError(Exception):
        pass

    class Locator:  # marker — only referenced by type imports
        pass

    def expect(*args, **kwargs):  # pragma: no cover - never called here
        raise AssertionError("expect should not be invoked by record_step tests")

    _sync_api.TimeoutError = _FakeTimeoutError
    _sync_api.Locator = Locator
    _sync_api.expect = expect

    def _sync_api_getattr(name):  # pragma: no cover - defensive
        return type(name, (), {})

    _sync_api.__getattr__ = _sync_api_getattr
    _pw.sync_api = _sync_api
    sys.modules["playwright"] = _pw
    sys.modules["playwright.sync_api"] = _sync_api


# ``pages.base_page`` drags in Playwright + config (dotenv); the only thing
# record_step needs from it is a ``BasePage`` to subclass. Provide a trivial one.
try:  # pragma: no cover - prefer the real module when its deps are installed
    import pages.base_page as _real_base_page  # noqa: F401
except Exception:
    _bp = types.ModuleType("pages.base_page")

    class BasePage:  # minimal stand-in — record_step only uses self.page
        pass

    _bp.BasePage = BasePage
    sys.modules["pages.base_page"] = _bp


# ``utils.logger`` may pull in optional config deps; a no-op logger is enough.
try:  # pragma: no cover
    import utils.logger as _real_logger  # noqa: F401
except Exception:
    _lg = types.ModuleType("utils.logger")

    class _NullLogger:
        def __getattr__(self, _name):
            return lambda *a, **k: None

    _lg.get_logger = lambda *a, **k: _NullLogger()
    sys.modules["utils.logger"] = _lg


# A controllable ScreenshotHelper stub: the module under test binds this symbol
# at import via ``from utils.screenshot_helper import ScreenshotHelper``.
class _FakeScreenshotHelper:
    """Records capture calls and can be switched to raise on demand."""

    def __init__(self) -> None:
        self.calls: list[str] = []
        self.raise_on_capture = False
        self.return_path = "/tmp/shot.png"

    def capture(self, page, name="screenshot"):
        self.calls.append(name)
        if self.raise_on_capture:
            raise RuntimeError("simulated capture failure")
        return self.return_path


_FAKE_SH = _FakeScreenshotHelper()
_sh_mod = types.ModuleType("utils.screenshot_helper")
_sh_mod.ScreenshotHelper = _FAKE_SH
sys.modules["utils.screenshot_helper"] = _sh_mod


def _load_reference_interfaces_page():
    """Load pages/reference_interfaces_page.py as a standalone module."""
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, os.pardir, "pages", "reference_interfaces_page.py")
    spec = importlib.util.spec_from_file_location(
        "reference_interfaces_page_under_test", os.path.abspath(path)
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_rip_module = _load_reference_interfaces_page()
ReferenceInterfacesPage = _rip_module.ReferenceInterfacesPage


# ──────────────────────────────────────────────────────────────
# Harness: a ReferenceInterfacesPage without running BasePage.__init__.
# record_step only touches self.page, self.run_step_log and ScreenshotHelper.
# ──────────────────────────────────────────────────────────────
def _make_page(run_log: RunStepLog | None) -> ReferenceInterfacesPage:
    page = ReferenceInterfacesPage.__new__(ReferenceInterfacesPage)
    page.page = object()  # opaque stand-in for the Playwright Page
    if run_log is not None:
        page.run_step_log = run_log
    return page


def setup_function(_func):
    # Reset the shared fake before each test.
    _FAKE_SH.calls.clear()
    _FAKE_SH.raise_on_capture = False
    _FAKE_SH.return_path = "/tmp/shot.png"


# ══════════════════════════════════════════════════════════════
# Tests
# ══════════════════════════════════════════════════════════════
def test_record_step_success_captures_once_and_records_one_entry():
    """A successful capture appends exactly one entry with the label and path.

    Validates: Requirements 9.1, 9.2, 9.3
    """
    log = RunStepLog()
    page = _make_page(log)
    _FAKE_SH.return_path = "/tmp/Bankruptcy_Types_add_verified.png"

    page.record_step("Bankruptcy_Types_add_verified")

    assert _FAKE_SH.calls == ["Bankruptcy_Types_add_verified"]
    entries = log.entries()
    assert len(entries) == 1
    assert entries[0].label == "Bankruptcy_Types_add_verified"
    assert entries[0].screenshot_path == "/tmp/Bankruptcy_Types_add_verified.png"
    assert entries[0].failed is False


def test_record_step_preserves_order_one_entry_per_call():
    """Successive calls append one ordered entry each.

    Validates: Requirements 9.1, 9.3
    """
    log = RunStepLog()
    page = _make_page(log)

    for label in ("Product_selected", "Product_add_modal_open", "Product_add_saved"):
        page.record_step(label)

    labels = [e.label for e in log.entries()]
    assert labels == ["Product_selected", "Product_add_modal_open", "Product_add_saved"]
    assert all(e.failed is False for e in log.entries())


def test_record_step_capture_failure_records_failure_entry_without_raising():
    """A raising capture appends one failure entry (no path) and never aborts.

    Validates: Requirement 9.4
    """
    log = RunStepLog()
    page = _make_page(log)
    _FAKE_SH.raise_on_capture = True

    # Must not raise.
    page.record_step("Product_cancel")

    entries = log.entries()
    assert len(entries) == 1
    assert entries[0].label == "Product_cancel"
    assert entries[0].screenshot_path is None
    assert entries[0].failed is True


def test_record_step_without_log_does_not_fail_on_success_or_failure():
    """With no Run_Step_Log injected the method never fails.

    Validates: Requirement 9.4 (defensive log read)
    """
    page = _make_page(run_log=None)

    # Success path — capture happens, nothing recorded, no error.
    page.record_step("Branch_Update_selected")
    assert _FAKE_SH.calls == ["Branch_Update_selected"]

    # Failure path — capture raises, swallowed, no error.
    _FAKE_SH.raise_on_capture = True
    page.record_step("Branch_Update_cancel")  # must not raise
