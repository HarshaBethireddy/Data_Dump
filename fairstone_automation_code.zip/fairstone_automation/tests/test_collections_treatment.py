from pytest_bdd import scenarios

scenarios("../features/collections_treatment.feature")