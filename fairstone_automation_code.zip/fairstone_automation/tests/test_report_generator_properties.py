"""
tests/test_report_generator_properties.py
──────────────────────────────────────────
Property-based tests (Hypothesis) for the report build-plan and Run_Report
filename generation in ``utils/report_generator.py``.

These tests exercise only the pure, browser-free logic:

* ``build_report_plan(log)`` — the order-preserving, one-to-one plan derived
  from a Run_Step_Log.
* ``generate_report_filename(timestamp)`` — the timestamped, collision-free
  ``activity_report_<YYYYmmdd_HHMMSS>.docx`` file name.

Each test runs a minimum of 100 examples and is tagged with a comment of the
form ``# Feature: activity-execution-and-reporting, Property {n}: {text}``.
"""
from __future__ import annotations

import os
import re
import tempfile
from datetime import datetime, timedelta

from hypothesis import given, settings
from hypothesis import strategies as st

from utils.report_generator import (
    MISSING_SCREENSHOT_CAPTION,
    NO_STEPS_CAPTION,
    ReportElementKind,
    build_report_plan,
    generate_report_filename,
)
from utils.run_step_log import RunStepLog


# ── Generators ─────────────────────────────────────────────────────────────

# A recorded step is a (label, path_kind) pair. ``path_kind`` decides whether
# the entry's screenshot file will exist on disk, be ``None``, or point at a
# path that does not exist (a missing / failed capture).
_label = st.text(max_size=30)
_path_kind = st.sampled_from(["exists", "none", "missing"])
_step_spec = st.tuples(_label, _path_kind)

# The Run_Report filename pattern: activity_report_<YYYYmmdd_HHMMSS>.docx.
_FILENAME_RE = re.compile(r"^activity_report_\d{8}_\d{6}\.docx$")

# Constrain to a 4-digit-year range so %Y formatting is unambiguous and the
# 8-digit date portion of the pattern always holds across platforms.
_datetimes = st.datetimes(
    min_value=datetime(2000, 1, 1),
    max_value=datetime(9999, 12, 31, 23, 59, 59),
)


# Feature: activity-execution-and-reporting, Property 8: Report build-plan mirrors the step log and filenames are unique
@settings(max_examples=200)
@given(specs=st.lists(_step_spec, max_size=15))
def test_build_report_plan_mirrors_step_log(
    specs: list[tuple[str, str]],
) -> None:
    """Property 8 (build-plan half): the report plan is in one-to-one,
    order-preserving correspondence with ``log.entries()``.

    Each entry yields exactly one plan element in the same position: a
    SCREENSHOT element carrying the entry's exact recorded label as caption when
    the file exists, a MISSING_SCREENSHOT element (caption only) when the file is
    absent, and — for an empty log — exactly one EMPTY_LOG element.

    Validates: Requirements 10.2, 10.3, 10.7, 10.8
    """
    with tempfile.TemporaryDirectory() as tmp:
        log = RunStepLog()
        # expected: list of (kind, label, path) mirroring each recorded step.
        expected: list[tuple[str, str, str | None]] = []

        for i, (label, kind) in enumerate(specs):
            if kind == "exists":
                path = os.path.join(tmp, f"shot_{i}.png")
                with open(path, "wb") as fh:
                    fh.write(b"\x89PNG\r\n")
                log.record(label, path)
                expected.append(("screenshot", label, path))
            elif kind == "none":
                log.record(label, None)
                expected.append(("missing", label, None))
            else:  # "missing": recorded path that does not exist on disk
                path = os.path.join(tmp, f"absent_{i}.png")
                log.record(label, path)
                expected.append(("missing", label, None))

        plan = build_report_plan(log)

        # Empty log → exactly one EMPTY_LOG element (Requirement 10.8).
        if not specs:
            assert len(plan) == 1
            assert plan[0].kind is ReportElementKind.EMPTY_LOG
            assert plan[0].caption == NO_STEPS_CAPTION
            return

        # One-to-one, order-preserving correspondence (Requirement 10.2).
        assert len(plan) == len(expected)

        for element, (exp_kind, label, path) in zip(plan, expected):
            if exp_kind == "screenshot":
                # Existing file → SCREENSHOT with the exact recorded label as
                # caption and the recorded path embedded (Requirements 10.2, 10.3).
                assert element.kind is ReportElementKind.SCREENSHOT
                assert element.caption == label
                assert element.screenshot_path == path
            else:
                # Absent file → MISSING_SCREENSHOT in the same position, caption
                # only, noting the screenshot is missing (Requirement 10.7).
                assert element.kind is ReportElementKind.MISSING_SCREENSHOT
                assert element.screenshot_path is None
                assert MISSING_SCREENSHOT_CAPTION in element.caption
                assert label in element.caption


# Feature: activity-execution-and-reporting, Property 8: Report build-plan mirrors the step log and filenames are unique
@settings(max_examples=200)
@given(moments=st.lists(_datetimes, min_size=1, max_size=20))
def test_report_filenames_unique_and_patterned(
    moments: list[datetime],
) -> None:
    """Property 8 (filename half): for any set of distinct timestamps at
    one-second-or-coarser resolution, the generated report filenames are
    pairwise distinct and match ``activity_report_<YYYYmmdd_HHMMSS>.docx``.

    Validates: Requirements 10.5
    """
    # Distinct timestamps at one-second resolution.
    distinct_seconds = {m.replace(microsecond=0) for m in moments}

    names = [generate_report_filename(ts) for ts in distinct_seconds]

    # Every name matches the required pattern (Requirement 10.5).
    for name in names:
        assert _FILENAME_RE.match(name), name

    # Distinct seconds yield pairwise-distinct names, so no prior run's report
    # is overwritten (Requirement 10.5).
    assert len(set(names)) == len(names)


# ─────────────────────────────────────────────────────────────────────────────
# spa-reference-interfaces feature properties (Properties 5 & 6)
#
# These extend the suite to cover the report-layer behaviour relied on by the
# Reference Interfaces feature: the report plan built from a Run_Step_Log
# preserves order one-to-one and flags absent files in place, and distinct run
# timestamps yield distinct, non-overwriting report file names.
# ─────────────────────────────────────────────────────────────────────────────


@st.composite
def _distinct_second_datetime_pairs(draw: st.DrawFn) -> tuple[datetime, datetime]:
    """Generate a pair of datetimes that are at least one second apart.

    A base moment is drawn from a 4-digit-year range and a strictly-positive
    delta of >= 1 second (whole seconds plus arbitrary microseconds) is added to
    produce the second moment. Two moments that differ by >= 1 second can never
    floor to the same second, so their second-resolution timestamps — and hence
    their generated file names — are guaranteed distinct.
    """
    base = draw(
        st.datetimes(
            # Leave head-room below the max so adding the delta cannot overflow.
            min_value=datetime(2000, 1, 1),
            max_value=datetime(9990, 12, 31, 23, 59, 59),
        )
    )
    extra_seconds = draw(st.integers(min_value=1, max_value=60 * 60 * 24 * 365))
    extra_micros = draw(st.integers(min_value=0, max_value=999_999))
    later = base + timedelta(seconds=extra_seconds, microseconds=extra_micros)
    return base, later


# Feature: spa-reference-interfaces, Property 5: The report plan preserves order one-to-one and flags absent files in place
@settings(max_examples=200)
@given(specs=st.lists(_step_spec, max_size=15))
def test_report_plan_preserves_order_and_flags_absent_files(
    specs: list[tuple[str, str]],
) -> None:
    """Property 5: for any Run_Step_Log mixing existing-file, missing-file, and
    None-path entries, the report plan has exactly one element per recorded
    entry in the same order. An entry whose screenshot file exists yields a
    SCREENSHOT element whose caption is that entry's label; an entry whose file
    is absent (None path or non-existent file) yields, in that same position, a
    MISSING_SCREENSHOT element, while every other element is unaffected.

    Validates: Requirements 10.4, 10.5
    """
    with tempfile.TemporaryDirectory() as tmp:
        log = RunStepLog()
        # expected[i] mirrors recorded step i as (kind, label, path).
        expected: list[tuple[str, str, str | None]] = []

        for i, (label, kind) in enumerate(specs):
            if kind == "exists":
                path = os.path.join(tmp, f"shot_{i}.png")
                with open(path, "wb") as fh:
                    fh.write(b"\x89PNG\r\n")
                log.record(label, path)
                expected.append(("screenshot", label, path))
            elif kind == "none":
                log.record(label, None)
                expected.append(("missing", label, None))
            else:  # "missing": recorded path that does not exist on disk
                path = os.path.join(tmp, f"absent_{i}.png")
                log.record(label, path)
                expected.append(("missing", label, None))

        plan = build_report_plan(log)

        # Empty log → exactly one EMPTY_LOG element (degenerate position case).
        if not specs:
            assert len(plan) == 1
            assert plan[0].kind is ReportElementKind.EMPTY_LOG
            assert plan[0].caption == NO_STEPS_CAPTION
            return

        # One element per recorded entry, in the same order (Requirement 10.4).
        assert len(plan) == len(expected)

        for element, (exp_kind, label, path) in zip(plan, expected):
            if exp_kind == "screenshot":
                # Existing file → embeddable SCREENSHOT keeping the exact label
                # as caption and the recorded path in place (Requirement 10.4).
                assert element.kind is ReportElementKind.SCREENSHOT
                assert element.caption == label
                assert element.screenshot_path == path
            else:
                # Absent file → MISSING_SCREENSHOT in the very same position,
                # caption only, naming the step and noting the missing file
                # (Requirement 10.5); the position is preserved, not dropped.
                assert element.kind is ReportElementKind.MISSING_SCREENSHOT
                assert element.screenshot_path is None
                assert MISSING_SCREENSHOT_CAPTION in element.caption
                assert label in element.caption


# Feature: spa-reference-interfaces, Property 6: Distinct run timestamps yield distinct, non-overwriting report file names
@settings(max_examples=200)
@given(pair=_distinct_second_datetime_pairs())
def test_distinct_timestamps_yield_distinct_report_filenames(
    pair: tuple[datetime, datetime],
) -> None:
    """Property 6: for any two run timestamps that differ at one-second
    resolution (here, at least one second apart), the generated report file
    names differ, and every generated name matches the timestamped
    ``activity_report_<YYYYmmdd_HHMMSS>.docx`` pattern — so no prior run's report
    is overwritten.

    Validates: Requirements 10.3
    """
    earlier, later = pair

    name_earlier = generate_report_filename(earlier)
    name_later = generate_report_filename(later)

    # Both names match the required timestamped pattern (Requirement 10.3).
    assert _FILENAME_RE.match(name_earlier), name_earlier
    assert _FILENAME_RE.match(name_later), name_later

    # Timestamps >= 1 s apart cannot share a one-second floor, so the names are
    # distinct and the later run never overwrites the earlier (Requirement 10.3).
    assert name_earlier != name_later
