"""
tests/test_reference_interfaces_add_verify.py
─────────────────────────────────────────────
Example / unit tests for ``ReferenceInterfacesPage.search_and_verify_added``
(task 5.2).

Scope
-----
``search_and_verify_added(code, expected_description)`` is the deliberate
improvement over the Java reference: after an Add it locates the new record and
confirms its Description before continuing. These tests pin its two error paths:

  • Missing Code — when the row whose Code cell exactly equals ``code`` is not
    found within the configured timeout, a descriptive ``AssertionError`` is
    raised that names the missing Code and the ``{prefix}_add_verified``
    screenshot is *not* captured (Requirement 4.3).
  • Description mismatch — when the located row's Description does not exactly
    equal ``expected_description``, a descriptive ``AssertionError`` is raised
    that names the Code, the expected Description, and the actual Description
    found, and again no ``add_verified`` screenshot is captured (Requirement
    4.5).

Environment note
----------------
The project pins ``playwright`` in requirements.txt, but it is not necessarily
installed in the test environment, and ``ReferenceInterfacesPage`` imports
``playwright.sync_api`` (directly and via ``pages.base_page``) at module load
time. Mirroring ``tests/test_reference_interfaces_record_step.py``, when the
real package is absent we register lightweight fake modules for
``playwright.sync_api``, ``pages.base_page``, ``utils.screenshot_helper`` and
``utils.logger`` so the page module can be loaded in isolation and its pure
verification logic exercised without a browser.
"""
from __future__ import annotations

import importlib.util
import os
import sys
import types

import pytest

# The real RunStepLog has no browser dependency, so it is used as-is to assert
# that no `add_verified` entry is recorded on the error paths.
from utils.run_step_log import RunStepLog


# ──────────────────────────────────────────────────────────────
# Register fakes (only when the real Playwright package is absent) so
# pages/reference_interfaces_page.py can be loaded standalone.
# ──────────────────────────────────────────────────────────────
try:  # pragma: no cover - prefer the real package when installed
    import playwright.sync_api as _real_sync_api  # noqa: F401
except Exception:
    _pw = types.ModuleType("playwright")
    _sync_api = types.ModuleType("playwright.sync_api")

    class _FakeTimeoutError(Exception):
        pass

    class Locator:  # marker — only referenced by type imports
        pass

    def expect(*args, **kwargs):  # pragma: no cover - never called here
        raise AssertionError("expect should not be invoked by add-verify tests")

    _sync_api.TimeoutError = _FakeTimeoutError
    _sync_api.Locator = Locator
    _sync_api.expect = expect

    def _sync_api_getattr(name):  # pragma: no cover - defensive
        return type(name, (), {})

    _sync_api.__getattr__ = _sync_api_getattr
    _pw.sync_api = _sync_api
    sys.modules["playwright"] = _pw
    sys.modules["playwright.sync_api"] = _sync_api


# ``pages.base_page`` drags in Playwright + config (dotenv); the only thing the
# verify methods need from it is a ``BasePage`` to subclass. Provide a trivial
# stand-in when the real module's dependencies are unavailable.
try:  # pragma: no cover - prefer the real module when its deps are installed
    import pages.base_page as _real_base_page  # noqa: F401
except Exception:
    _bp = types.ModuleType("pages.base_page")

    class BasePage:  # minimal stand-in — search_and_verify_added drives via self
        pass

    _bp.BasePage = BasePage
    sys.modules["pages.base_page"] = _bp


# ``utils.logger`` may pull in optional config deps; a no-op logger is enough.
try:  # pragma: no cover
    import utils.logger as _real_logger  # noqa: F401
except Exception:
    _lg = types.ModuleType("utils.logger")

    class _NullLogger:
        def __getattr__(self, _name):
            return lambda *a, **k: None

    _lg.get_logger = lambda *a, **k: _NullLogger()
    sys.modules["utils.logger"] = _lg


# A controllable ScreenshotHelper stub. The error paths must NEVER capture, so
# any call here is a defect; record calls so the tests can assert zero captures.
class _FakeScreenshotHelper:
    def __init__(self) -> None:
        self.calls: list[str] = []

    def capture(self, page, name="screenshot"):
        self.calls.append(name)
        return f"/tmp/{name}.png"


_FAKE_SH = _FakeScreenshotHelper()
_sh_mod = types.ModuleType("utils.screenshot_helper")
_sh_mod.ScreenshotHelper = _FAKE_SH
sys.modules["utils.screenshot_helper"] = _sh_mod


def _load_reference_interfaces_page():
    """Load pages/reference_interfaces_page.py as a standalone module."""
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, os.pardir, "pages", "reference_interfaces_page.py")
    spec = importlib.util.spec_from_file_location(
        "reference_interfaces_page_under_test_add_verify", os.path.abspath(path)
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_rip_module = _load_reference_interfaces_page()
ReferenceInterfacesPage = _rip_module.ReferenceInterfacesPage
# The TimeoutError the module catches — exactly what the fake row must raise so
# the "missing Code" branch is taken.
_PW_TIMEOUT = _rip_module.PlaywrightTimeoutError


# ──────────────────────────────────────────────────────────────
# Fake grid row locator
# ──────────────────────────────────────────────────────────────
class _FakeCell:
    """Stands in for the Description cell locator (CELL_DESC)."""

    def __init__(self, text: str) -> None:
        self._text = text

    def inner_text(self) -> str:
        return self._text


class _FakeRowHandle:
    """Stands in for ``row.first`` — the handle the page waits on / reads."""

    def __init__(self, *, raise_timeout: bool = False, desc_text: str = "") -> None:
        self.raise_timeout = raise_timeout
        self._desc_text = desc_text

    def wait_for(self, state=None, timeout=None):
        if self.raise_timeout:
            raise _PW_TIMEOUT("row not visible within timeout")

    def locator(self, selector):
        # Only the Description cell is read by search_and_verify_added.
        assert selector == ReferenceInterfacesPage.CELL_DESC
        return _FakeCell(self._desc_text)


class _FakeRow:
    """Stands in for the Locator returned by ``_get_row_by_code``."""

    def __init__(self, first: _FakeRowHandle) -> None:
        self.first = first


# ──────────────────────────────────────────────────────────────
# Harness: a ReferenceInterfacesPage without running BasePage.__init__.
# search_and_verify_added only needs self.timeout, self._get_row_by_code,
# a Run_Step_Log to confirm no add_verified entry is recorded, and (on the
# success path only) get_selected_option/record_step which the error paths
# never reach.
# ──────────────────────────────────────────────────────────────
def _make_page(fake_row: _FakeRow, run_log: RunStepLog) -> ReferenceInterfacesPage:
    page = ReferenceInterfacesPage.__new__(ReferenceInterfacesPage)
    page.page = object()  # opaque stand-in for the Playwright Page
    page.timeout = 5_000
    page.run_step_log = run_log
    # Shadow the bound method with a stub returning our fake row regardless of code.
    page._get_row_by_code = lambda code: fake_row
    return page


def setup_function(_func):
    _FAKE_SH.calls.clear()


# ══════════════════════════════════════════════════════════════
# Tests
# ══════════════════════════════════════════════════════════════
def test_missing_code_raises_descriptive_error_and_skips_add_verified():
    """A missing Code raises an error naming it and never captures add_verified.

    Validates: Requirements 4.3
    """
    log = RunStepLog()
    fake_row = _FakeRow(_FakeRowHandle(raise_timeout=True))
    page = _make_page(fake_row, log)

    with pytest.raises(AssertionError) as exc_info:
        page.search_and_verify_added("BNKR01", "Chapter 7")

    message = str(exc_info.value)
    # Descriptive error that names the missing Code (Req 4.3).
    assert "BNKR01" in message
    # No `add_verified` screenshot captured on the missing-Code path (Req 4.3).
    assert _FAKE_SH.calls == []
    assert not any("add_verified" in e.label for e in log.entries())
    assert log.entries() == []


def test_description_mismatch_raises_error_naming_code_expected_actual():
    """A Description mismatch raises an error naming Code, expected, and actual.

    Validates: Requirements 4.5
    """
    log = RunStepLog()
    fake_row = _FakeRow(
        _FakeRowHandle(raise_timeout=False, desc_text="Chapter 13")
    )
    page = _make_page(fake_row, log)

    with pytest.raises(AssertionError) as exc_info:
        page.search_and_verify_added("BNKR01", "Chapter 7")

    message = str(exc_info.value)
    # Names the Code, the expected Description, and the actual found (Req 4.5).
    assert "BNKR01" in message
    assert "Chapter 7" in message    # expected
    assert "Chapter 13" in message   # actual found
    # No `add_verified` screenshot captured on the mismatch path.
    assert _FAKE_SH.calls == []
    assert not any("add_verified" in e.label for e in log.entries())
    assert log.entries() == []
