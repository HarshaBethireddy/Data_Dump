"""
tests/test_navigation.py
────────────────────────
Binds features/navigation.feature to pytest-bdd.
All step implementations live in steps/navigation_steps.py
"""
import pytest
from pytest_bdd import scenarios

scenarios("../features/navigation.feature")
