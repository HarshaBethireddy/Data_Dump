"""
tests/test_reference_interfaces_edit_verify.py
──────────────────────────────────────────────
Example tests for ``ReferenceInterfacesPage.verify_edit`` (task 6.2).

Scope
-----
``verify_edit(code, expected_description)`` runs after the Edit modal has
closed. It locates the grid row whose Code cell exactly equals ``code`` and
confirms the row's Description cell exactly equals the updated value.

This file pins the *mismatch* guarantee (Requirement 5.10):

  • When the located row's Description does NOT exactly equal the updated
    ``expected_description``, ``verify_edit`` raises a descriptive
    ``AssertionError`` whose message names both the Code and the expected
    updated Description value.

A companion success-path test confirms that an exact match does NOT raise and
records the ``{prefix}_edit_verified`` step — demonstrating the error is
specific to the mismatch condition.

Environment note
----------------
The project pins ``playwright`` in requirements.txt, but it is not necessarily
installed in the test environment, and ``ReferenceInterfacesPage`` imports
``playwright.sync_api`` (directly and via ``pages.base_page``) at module load
time. Mirroring ``tests/test_reference_interfaces_record_step.py``, when the
real package is absent we register lightweight fake modules for
``playwright.sync_api``, ``pages.base_page``, ``utils.screenshot_helper`` and
``utils.logger`` so the page module can be loaded in isolation and
``verify_edit`` exercised without a browser. The grid row locator and the
Description cell are stubbed so the pure comparison logic can be driven
directly.

Run with:
    python -m pytest tests/test_reference_interfaces_edit_verify.py \
        --noconftest -o addopts="" -v
"""
from __future__ import annotations

import importlib.util
import os
import sys
import types

import pytest


# ──────────────────────────────────────────────────────────────
# Register fakes (only when the real Playwright package is absent) so
# pages/reference_interfaces_page.py can be loaded standalone.
# ──────────────────────────────────────────────────────────────
try:  # pragma: no cover - prefer the real package when installed
    import playwright.sync_api as _real_sync_api  # noqa: F401
except Exception:
    _pw = types.ModuleType("playwright")
    _sync_api = types.ModuleType("playwright.sync_api")

    class _FakeTimeoutError(Exception):
        pass

    class Locator:  # marker — only referenced by type imports
        pass

    def expect(*args, **kwargs):  # pragma: no cover - never called here
        raise AssertionError("expect should not be invoked by verify_edit tests")

    _sync_api.TimeoutError = _FakeTimeoutError
    _sync_api.Locator = Locator
    _sync_api.expect = expect

    def _sync_api_getattr(name):  # pragma: no cover - defensive
        return type(name, (), {})

    _sync_api.__getattr__ = _sync_api_getattr
    _pw.sync_api = _sync_api
    sys.modules["playwright"] = _pw
    sys.modules["playwright.sync_api"] = _sync_api


# ``pages.base_page`` drags in Playwright + config (dotenv); the only thing
# verify_edit needs from it is a ``BasePage`` to subclass. Provide a trivial one.
try:  # pragma: no cover - prefer the real module when its deps are installed
    import pages.base_page as _real_base_page  # noqa: F401
except Exception:
    _bp = types.ModuleType("pages.base_page")

    class BasePage:  # minimal stand-in
        pass

    _bp.BasePage = BasePage
    sys.modules["pages.base_page"] = _bp


# ``utils.logger`` may pull in optional config deps; a no-op logger is enough.
try:  # pragma: no cover
    import utils.logger as _real_logger  # noqa: F401
except Exception:
    _lg = types.ModuleType("utils.logger")

    class _NullLogger:
        def __getattr__(self, _name):
            return lambda *a, **k: None

    _lg.get_logger = lambda *a, **k: _NullLogger()
    sys.modules["utils.logger"] = _lg


# A no-op ScreenshotHelper stub: the module binds this symbol at import via
# ``from utils.screenshot_helper import ScreenshotHelper`` and the success path
# of verify_edit reaches record_step → ScreenshotHelper.capture.
class _FakeScreenshotHelper:
    @staticmethod
    def capture(page, name="screenshot"):
        return f"/tmp/{name}.png"


_sh_mod = types.ModuleType("utils.screenshot_helper")
_sh_mod.ScreenshotHelper = _FakeScreenshotHelper
sys.modules["utils.screenshot_helper"] = _sh_mod


def _load_reference_interfaces_page():
    """Load pages/reference_interfaces_page.py as a standalone module."""
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, os.pardir, "pages", "reference_interfaces_page.py")
    spec = importlib.util.spec_from_file_location(
        "reference_interfaces_page_under_test_edit_verify", os.path.abspath(path)
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_rip_module = _load_reference_interfaces_page()
ReferenceInterfacesPage = _rip_module.ReferenceInterfacesPage


# ──────────────────────────────────────────────────────────────
# Fake grid-row / cell locators driving verify_edit's comparison logic.
# verify_edit does:
#   row = self._get_row_by_code(code)          → self.page.locator(...)
#   row.first.wait_for(state="visible", ...)   → row found
#   row.first.locator(CELL_DESC).inner_text()  → the Description cell text
# ──────────────────────────────────────────────────────────────
class _FakeCell:
    def __init__(self, text: str) -> None:
        self._text = text

    def inner_text(self) -> str:
        return self._text


class _FakeRow:
    def __init__(self, description: str) -> None:
        self._description = description

    @property
    def first(self) -> "_FakeRow":
        return self

    def wait_for(self, state=None, timeout=None) -> None:
        # Row is present and visible for these tests.
        return None

    def locator(self, _selector: str) -> _FakeCell:
        # Whatever cell selector is asked for, return the Description text.
        return _FakeCell(self._description)


class _FakePage:
    def __init__(self, row: _FakeRow) -> None:
        self._row = row

    def locator(self, _selector: str) -> _FakeRow:
        return self._row


def _make_page(grid_description: str) -> ReferenceInterfacesPage:
    """Build a ReferenceInterfacesPage whose grid row reports ``grid_description``.

    BasePage.__init__ is bypassed; verify_edit only touches ``self.page``,
    ``self.timeout`` and (on success) ``self.get_selected_option`` /
    ``self.record_step``.
    """
    page = ReferenceInterfacesPage.__new__(ReferenceInterfacesPage)
    page.page = _FakePage(_FakeRow(grid_description))
    page.timeout = 1_000
    # Capture recorded steps without a real screenshot/log dependency.
    page._recorded_steps = []
    page.record_step = lambda label: page._recorded_steps.append(label)
    page.get_selected_option = lambda: "Bankruptcy Types"
    return page


# ══════════════════════════════════════════════════════════════
# Tests — Requirement 5.10 (mismatch)
# ══════════════════════════════════════════════════════════════
def test_verify_edit_mismatch_raises_naming_code_and_expected_description():
    """A Description mismatch raises an error naming the Code and expected value.

    Validates: Requirements 5.10
    """
    # Grid shows the stale/old Description; we expected the updated one.
    page = _make_page(grid_description="Old description")

    with pytest.raises(AssertionError) as exc_info:
        page.verify_edit("BK01", "Updated description")

    message = str(exc_info.value)
    # Names the offending Code …
    assert "BK01" in message
    # … and the expected updated Description value.
    assert "Updated description" in message
    # No edit_verified step is recorded on the mismatch path.
    assert page._recorded_steps == []


def test_verify_edit_mismatch_message_includes_actual_found_description():
    """The mismatch error also surfaces the actual Description found in the grid.

    Validates: Requirements 5.10
    """
    page = _make_page(grid_description="Totally different")

    with pytest.raises(AssertionError) as exc_info:
        page.verify_edit("PROD-9", "Renamed product")

    message = str(exc_info.value)
    assert "PROD-9" in message
    assert "Renamed product" in message
    assert "Totally different" in message


def test_verify_edit_mismatch_on_whitespace_difference_is_descriptive():
    """An inexact (extra/trailing) Description still counts as a mismatch.

    The grid cell text is ``.strip()``-ed, so a leading/trailing-whitespace-only
    difference matches, but a substantive difference does not. Here the expected
    value differs by an interior word, so it must raise.

    Validates: Requirements 5.10
    """
    page = _make_page(grid_description="Active flag enabled")

    with pytest.raises(AssertionError) as exc_info:
        page.verify_edit("CFG-1", "Active flag disabled")

    message = str(exc_info.value)
    assert "CFG-1" in message
    assert "Active flag disabled" in message


# ── Companion success-path test (error is mismatch-specific) ─────────────
def test_verify_edit_exact_match_does_not_raise_and_records_step():
    """An exact Description match does NOT raise and records edit_verified.

    Confirms the mismatch error is specific to the mismatch condition.

    Validates: Requirements 5.10 (negative control)
    """
    page = _make_page(grid_description="Updated description")

    # Must not raise.
    page.verify_edit("BK01", "Updated description")

    # Exactly one {prefix}_edit_verified step recorded on success.
    assert page._recorded_steps == ["Bankruptcy_Types_edit_verified"]


def test_verify_edit_exact_match_ignores_surrounding_whitespace():
    """Surrounding whitespace on the grid cell is trimmed before comparison.

    The grid cell text is ``.strip()``-ed before the equality check, so a value
    that differs only by leading/trailing whitespace is treated as a match.

    Validates: Requirements 5.10 (negative control)
    """
    page = _make_page(grid_description="  Updated description  ")

    # Must not raise — trimmed cell text equals the expected value.
    page.verify_edit("BK01", "Updated description")

    assert page._recorded_steps == ["Bankruptcy_Types_edit_verified"]
