"""
tests/test_customer_overview.py
────────────────────────────────
Binds features/customer_overview.feature to pytest-bdd.
Step implementations live in steps/customer_overview_steps.py
"""
from pytest_bdd import scenarios

scenarios("../features/customer_overview.feature")
