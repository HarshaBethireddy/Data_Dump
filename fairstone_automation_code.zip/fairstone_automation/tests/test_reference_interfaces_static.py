"""
tests/test_reference_interfaces_static.py
──────────────────────────────────────────
Static structural guard for ``features/reference_interfaces.feature``
(task 13.3).

Scope
-----
This is a structural/wiring test, not a behavioural one. It parses the
``.feature`` file and the ``steps/*.py`` modules **statically** (with ``ast``
and plain text), so it imports neither ``pytest_bdd`` nor ``playwright`` and can
run in any environment — mirroring the static-parsing approach used in
``tests/test_collection_smoke.py``.

Invariants asserted
--------------------
  • Exactly five CRUD scenarios — the five per-type
    Add → Verify → Edit → Delete cycles (the Cancel scenario is excluded
    from this count)                                          (Requirement 8.1)
  • Each CRUD scenario follows the fixed Add → Verify → Edit → Delete
    order                                                     (Requirement 8.2)
  • Each CRUD scenario supplies a non-empty Code              (Requirement 8.3)
  • Each CRUD scenario's updated Description differs from its initial
    Description                                               (Requirement 8.4)
  • Each CRUD scenario contains its own login/nav/select steps
    (login via the shared ``Background``)                     (Requirement 8.7)
  • Every step phrase in the feature resolves to a ``@step`` registration —
    CRUD phrases to ``steps/admin_steps.py`` and the Background login line to
    another registered step module                           (Requirement 8.6)

Run standalone with:
    python -m pytest tests/test_reference_interfaces_static.py \\
        --noconftest -o addopts="" -v
"""
from __future__ import annotations

import ast
import re
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[1]
STEPS_DIR = PROJECT_ROOT / "steps"
FEATURES_DIR = PROJECT_ROOT / "features"
FEATURE_PATH = FEATURES_DIR / "reference_interfaces.feature"

# Step modules registered in conftest.py's pytest_plugins. We resolve feature
# phrases against ALL of them (admin_steps plus the shared modules where the
# Background login line and nav steps are registered), parsed statically.
_STEP_MODULES = (
    "common_steps",
    "login_steps",
    "navigation_steps",
    "search_steps",
    "customer_overview_steps",
    "account_activity_steps",
    "activities_steps",
    "accordion_steps",
    "search_modal_steps",
    "admin_steps",
    "person_profile_steps",
)

# The shared Background login line — registered in steps/common_steps.py.
_BACKGROUND_LOGIN = "I am logged in to the Collections application"


# ──────────────────────────────────────────────────────────────
# Static-parsing helpers (mirrors tests/test_collection_smoke.py)
# ──────────────────────────────────────────────────────────────

def _step_phrases(source: str) -> list[str]:
    """
    Extract the literal step phrases registered via ``@step(...)`` (and the
    ``@when``/``@then``/``@given`` aliases) in a step-module ``source``.

    Handles both forms used in the codebase:
        @step("literal text")
        @step(parsers.parse('text with {placeholders}'))
    """
    tree = ast.parse(source)
    phrases: list[str] = []

    def _literal_from_arg(arg: ast.expr) -> str | None:
        # @step("...") — a bare string literal
        if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
            return arg.value
        # @step(parsers.parse("...")) — first arg of the inner call
        if isinstance(arg, ast.Call) and arg.args:
            inner = arg.args[0]
            if isinstance(inner, ast.Constant) and isinstance(inner.value, str):
                return inner.value
        return None

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for dec in node.decorator_list:
            if isinstance(dec, ast.Call):
                func = dec.func
                name = None
                if isinstance(func, ast.Name):
                    name = func.id
                elif isinstance(func, ast.Attribute):
                    name = func.attr
                if name in {"step", "given", "when", "then"} and dec.args:
                    phrase = _literal_from_arg(dec.args[0])
                    if phrase is not None:
                        phrases.append(phrase)
    return phrases


def _all_registered_phrases() -> list[str]:
    """All @step phrases across every registered step module."""
    phrases: list[str] = []
    for module in _STEP_MODULES:
        path = STEPS_DIR / f"{module}.py"
        if path.exists():
            phrases.extend(_step_phrases(path.read_text(encoding="utf-8")))
    return phrases


def _phrase_to_regex(phrase: str) -> re.Pattern[str]:
    """
    Turn a registered phrase into a full-match regex, accounting for
    ``parsers.parse`` placeholders like ``{code}``, ``{value}``, ``{label}``,
    ``{option_name}`` and typed placeholders like ``{seconds:d}``.
    """
    parts = re.split(r"(\{[^}]*\})", phrase)
    out: list[str] = []
    for part in parts:
        if part.startswith("{") and part.endswith("}"):
            out.append(r"\d+" if part.endswith(":d}") else r".+?")
        else:
            out.append(re.escape(part))
    return re.compile("^" + "".join(out) + "$")


def _resolves(step_text: str, patterns: list[re.Pattern[str]]) -> bool:
    """True if ``step_text`` matches at least one registered-phrase pattern."""
    return any(p.match(step_text) for p in patterns)


# ──────────────────────────────────────────────────────────────
# Feature-file parsing
# ──────────────────────────────────────────────────────────────

_STEP_KEYWORD = re.compile(r"^(Given|When|Then|And|But)\s+(.*)$")


def _parse_feature(text: str) -> tuple[list[str], list[tuple[str, list[str]]]]:
    """
    Parse a ``.feature`` file into ``(background_steps, scenarios)`` where each
    scenario is ``(name, [step_phrase, ...])``. Gherkin keywords are stripped
    from each step (so ``And I save the Add modal`` → ``I save the Add modal``);
    comment and tag lines are ignored.
    """
    background_steps: list[str] = []
    scenarios: list[tuple[str, list[str]]] = []
    current: list[str] | None = None

    for raw in text.splitlines():
        stripped = raw.strip()
        if not stripped or stripped.startswith("#") or stripped.startswith("@"):
            continue
        if stripped.startswith("Feature:"):
            current = None
            continue
        if stripped.startswith("Background:"):
            current = background_steps
            continue
        if stripped.startswith("Scenario Outline:") or stripped.startswith("Scenario:"):
            name = stripped.split(":", 1)[1].strip()
            steps: list[str] = []
            scenarios.append((name, steps))
            current = steps
            continue
        match = _STEP_KEYWORD.match(stripped)
        if match and current is not None:
            current.append(match.group(2).strip())
    return background_steps, scenarios


# Phrase markers used to classify and order the CRUD lifecycle.
_ADD_SAVE = "I save the Add modal"
_ADD_VERIFY = "the added record should be present with its entered description"
_EDIT_SAVE = "I save the Edit modal"
_EDIT_VERIFY = "the edited record should show the updated description"
_DELETE = "I delete the record that was added"
_DELETE_VERIFY = "the deleted record should be absent from the grid"

_ADD_OPEN = "I click the Add button on the Reference Interfaces page"
_EDIT_OPEN_PREFIX = "I open the Edit modal for code "

_NAV_ADMIN = 'I click the "Admin" nav item'
_NAV_POPOVER = 'I click "Reference Interfaces" in the Admin popover'
_SELECT_PREFIX = "I select reference type "

_CODE_FILL_RE = re.compile(r'^I fill the Add modal field "Code" with "(?P<code>[^"]*)"$')
_ADD_DESC_RE = re.compile(r'^I fill the Add modal field "Description" with "(?P<desc>[^"]*)"$')
_EDIT_DESC_RE = re.compile(r'^I fill the Edit modal field "Description" with "(?P<desc>[^"]*)"$')


def _is_crud_scenario(steps: list[str]) -> bool:
    """A CRUD scenario runs the full Add→Verify→Edit→Delete lifecycle."""
    return _ADD_SAVE in steps and _EDIT_SAVE in steps and _DELETE in steps


# ──────────────────────────────────────────────────────────────
# Module-level parse (shared across tests)
# ──────────────────────────────────────────────────────────────

_FEATURE_TEXT = FEATURE_PATH.read_text(encoding="utf-8")
_BACKGROUND_STEPS, _SCENARIOS = _parse_feature(_FEATURE_TEXT)
_CRUD_SCENARIOS = [(n, s) for n, s in _SCENARIOS if _is_crud_scenario(s)]


# ──────────────────────────────────────────────────────────────
# Requirement 8.1 — exactly five CRUD scenarios
# ──────────────────────────────────────────────────────────────

def test_feature_file_exists() -> None:
    assert FEATURE_PATH.exists(), f"Missing feature file: {FEATURE_PATH}"


def test_exactly_five_crud_scenarios() -> None:
    """
    The feature must contain exactly five per-type CRUD scenarios — the Cancel
    scenario is not a CRUD cycle and is excluded from this count (Req 8.1).
    """
    names = [n for n, _ in _CRUD_SCENARIOS]
    assert len(_CRUD_SCENARIOS) == 5, (
        "Expected exactly 5 Add→Verify→Edit→Delete CRUD scenarios "
        f"(Requirement 8.1); found {len(_CRUD_SCENARIOS)}: {names}"
    )
    # The Cancel scenario must exist but must NOT be counted as CRUD.
    cancel = [n for n, s in _SCENARIOS if not _is_crud_scenario(s)]
    assert cancel, "Expected a separate Cancel scenario to be present"


# ──────────────────────────────────────────────────────────────
# Requirement 8.2 — fixed Add → Verify → Edit → Delete order
# ──────────────────────────────────────────────────────────────

@pytest.mark.parametrize("name,steps", _CRUD_SCENARIOS, ids=lambda v: v if isinstance(v, str) else "")
def test_crud_scenarios_follow_fixed_order(name: str, steps: list[str]) -> None:
    """Each CRUD scenario follows Add → Verify → Edit → Delete in order (Req 8.2)."""
    def _idx(phrase: str) -> int:
        assert phrase in steps, (
            f"Scenario '{name}' is missing required step '{phrase}' (Requirement 8.2)"
        )
        return steps.index(phrase)

    add_open = next((i for i, s in enumerate(steps) if s == _ADD_OPEN), None)
    edit_open = next((i for i, s in enumerate(steps) if s.startswith(_EDIT_OPEN_PREFIX)), None)
    assert add_open is not None, f"Scenario '{name}' missing the Add open step"
    assert edit_open is not None, f"Scenario '{name}' missing the Edit open step"

    add_save = _idx(_ADD_SAVE)
    add_verify = _idx(_ADD_VERIFY)
    edit_save = _idx(_EDIT_SAVE)
    edit_verify = _idx(_EDIT_VERIFY)
    delete = _idx(_DELETE)
    delete_verify = _idx(_DELETE_VERIFY)

    ordered = [
        ("Add open", add_open),
        ("Add save", add_save),
        ("Add verify", add_verify),
        ("Edit open", edit_open),
        ("Edit save", edit_save),
        ("Edit verify", edit_verify),
        ("Delete", delete),
        ("Delete verify", delete_verify),
    ]
    positions = [pos for _, pos in ordered]
    assert positions == sorted(positions), (
        f"Scenario '{name}' does not follow the fixed Add→Verify→Edit→Delete "
        f"order (Requirement 8.2). Observed positions: {ordered}"
    )


# ──────────────────────────────────────────────────────────────
# Requirement 8.3 — each CRUD scenario supplies a non-empty Code
# ──────────────────────────────────────────────────────────────

@pytest.mark.parametrize("name,steps", _CRUD_SCENARIOS, ids=lambda v: v if isinstance(v, str) else "")
def test_crud_scenarios_supply_non_empty_code(name: str, steps: list[str]) -> None:
    """Each CRUD scenario fills a non-empty Code in the Add modal (Req 8.3)."""
    codes = [m.group("code") for m in (_CODE_FILL_RE.match(s) for s in steps) if m]
    assert codes, f"Scenario '{name}' has no Add-modal Code step (Requirement 8.3)"
    for code in codes:
        assert code.strip(), (
            f"Scenario '{name}' supplies an empty Code (Requirement 8.3)"
        )


# ──────────────────────────────────────────────────────────────
# Requirement 8.4 — updated Description differs from the initial
# ──────────────────────────────────────────────────────────────

@pytest.mark.parametrize("name,steps", _CRUD_SCENARIOS, ids=lambda v: v if isinstance(v, str) else "")
def test_crud_scenarios_update_description(name: str, steps: list[str]) -> None:
    """The edited Description must differ from the initial Description (Req 8.4)."""
    add_desc = next((m.group("desc") for m in (_ADD_DESC_RE.match(s) for s in steps) if m), None)
    edit_desc = next((m.group("desc") for m in (_EDIT_DESC_RE.match(s) for s in steps) if m), None)
    assert add_desc is not None, f"Scenario '{name}' missing initial Description"
    assert edit_desc is not None, f"Scenario '{name}' missing updated Description"
    assert add_desc != edit_desc, (
        f"Scenario '{name}' updated Description '{edit_desc}' must differ from "
        f"the initial Description '{add_desc}' (Requirement 8.4)"
    )


# ──────────────────────────────────────────────────────────────
# Requirement 8.7 — each scenario has its own login/nav/select steps
# ──────────────────────────────────────────────────────────────

def test_background_provides_login() -> None:
    """Login is supplied to every scenario via the shared Background (Req 8.7)."""
    assert _BACKGROUND_LOGIN in _BACKGROUND_STEPS, (
        "The feature Background must log in via "
        f"'{_BACKGROUND_LOGIN}' (Requirement 8.7)"
    )


@pytest.mark.parametrize("name,steps", _CRUD_SCENARIOS, ids=lambda v: v if isinstance(v, str) else "")
def test_crud_scenarios_have_nav_and_select_steps(name: str, steps: list[str]) -> None:
    """Each CRUD scenario does its own Admin nav, popover, and type select (Req 8.7)."""
    assert _NAV_ADMIN in steps, (
        f"Scenario '{name}' missing the Admin nav step (Requirement 8.7)"
    )
    assert _NAV_POPOVER in steps, (
        f"Scenario '{name}' missing the Reference Interfaces popover step "
        "(Requirement 8.7)"
    )
    assert any(s.startswith(_SELECT_PREFIX) for s in steps), (
        f"Scenario '{name}' missing its own reference-type select step "
        "(Requirement 8.7)"
    )


# ──────────────────────────────────────────────────────────────
# Requirement 8.6 — every step phrase resolves to a @step registration
# ──────────────────────────────────────────────────────────────

def test_every_feature_step_resolves_to_a_registration() -> None:
    """
    Every step phrase used in the feature (Background + all scenarios) resolves
    to a ``@step`` registration across the registered step modules — accounting
    for ``parsers.parse`` placeholders (Requirement 8.6).
    """
    patterns = [_phrase_to_regex(p) for p in _all_registered_phrases()]
    assert patterns, "No @step phrases found across the step modules"

    all_steps: list[str] = list(_BACKGROUND_STEPS)
    for _, steps in _SCENARIOS:
        all_steps.extend(steps)

    unresolved = sorted({s for s in all_steps if not _resolves(s, patterns)})
    assert not unresolved, (
        "Feature step phrase(s) do not resolve to any registered @step "
        f"(Requirement 8.6): {unresolved}"
    )


def test_crud_phrases_resolve_in_admin_steps() -> None:
    """
    The CRUD-specific phrases (everything except the shared Background login)
    resolve specifically to a ``@step`` in ``steps/admin_steps.py`` (Req 8.6).
    """
    admin_patterns = [
        _phrase_to_regex(p)
        for p in _step_phrases((STEPS_DIR / "admin_steps.py").read_text(encoding="utf-8"))
    ]
    assert admin_patterns, "No @step phrases found in steps/admin_steps.py"

    crud_steps: set[str] = set()
    for _, steps in _CRUD_SCENARIOS:
        crud_steps.update(steps)
    # The Background login line is registered elsewhere (common_steps.py).
    crud_steps.discard(_BACKGROUND_LOGIN)

    unresolved = sorted(s for s in crud_steps if not _resolves(s, admin_patterns))
    assert not unresolved, (
        "CRUD step phrase(s) not registered in steps/admin_steps.py "
        f"(Requirement 8.6): {unresolved}"
    )


def test_background_login_registered_outside_admin_steps() -> None:
    """The Background login line is registered in a shared step module (Req 8.6)."""
    common_patterns = [
        _phrase_to_regex(p)
        for p in _step_phrases((STEPS_DIR / "common_steps.py").read_text(encoding="utf-8"))
    ]
    assert _resolves(_BACKGROUND_LOGIN, common_patterns), (
        f"Background login '{_BACKGROUND_LOGIN}' must resolve to a @step in "
        "steps/common_steps.py (Requirement 8.6)"
    )
