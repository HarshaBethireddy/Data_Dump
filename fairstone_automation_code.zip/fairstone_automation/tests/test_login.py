"""
tests/test_login.py
───────────────────
Binds features/login.feature to pytest-bdd.
All step implementations live in steps/login_steps.py
"""
import pytest
from pytest_bdd import scenarios

# Register all scenarios from the feature file
scenarios("../features/login.feature")
