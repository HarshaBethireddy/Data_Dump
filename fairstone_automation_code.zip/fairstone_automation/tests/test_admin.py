"""
tests/test_admin.py
────────────────────
Binds features/admin.feature to pytest-bdd.
Step implementations live in steps/admin_steps.py.
"""
from pytest_bdd import scenarios

scenarios("../features/admin.feature")
