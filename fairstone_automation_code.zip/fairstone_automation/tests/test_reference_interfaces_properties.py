"""
tests/test_reference_interfaces_properties.py
─────────────────────────────────────────────
Property-based tests (Hypothesis) for the pure, browser-free screenshot-naming
helpers in ``utils/screenshot_naming.py``.

Each test runs a minimum of 100 examples and is tagged with a comment of the
form ``# Feature: spa-reference-interfaces, Property {n}: {text}``.
"""
from __future__ import annotations

from hypothesis import given, settings
from hypothesis import strategies as st

from utils.screenshot_naming import derive_screenshot_prefix, screenshot_name


# ---------------------------------------------------------------------------
# Generators
# ---------------------------------------------------------------------------

# Arbitrary text that deliberately over-samples the space character so the
# generated option names include multiple, leading, trailing, and consecutive
# spaces alongside ordinary characters.
_space_heavy_chars = st.one_of(
    st.just(" "),                       # bias toward spaces
    st.characters(),                    # arbitrary unicode (incl. more spaces)
)
_option_name = st.text(alphabet=_space_heavy_chars, max_size=60)

# Arbitrary prefix / suffix strings for name composition.
_arbitrary_text = st.text(max_size=40)


# ---------------------------------------------------------------------------
# Property 1 (Task 1.2)
# ---------------------------------------------------------------------------

# Feature: spa-reference-interfaces, Property 1: Screenshot prefix derivation replaces every space with one underscore
@settings(max_examples=200)
@given(option_name=_option_name)
def test_prefix_derivation_replaces_every_space_with_one_underscore(
    option_name: str,
) -> None:
    """Property 1: Screenshot prefix derivation replaces every space with one
    underscore.

    For any reference-type option name, the derived Screenshot_Prefix contains
    no space characters, has the same length as the input, preserves every
    non-space character in order, and carries an underscore at exactly the
    positions where the input had a space.

    Validates: Requirements 2.4
    """
    prefix = derive_screenshot_prefix(option_name)

    # No spaces survive in the derived prefix.
    assert " " not in prefix

    # Length is preserved: each space maps to exactly one underscore, every
    # other character is preserved one-for-one.
    assert len(prefix) == len(option_name)

    # Position-by-position: spaces become underscores, all other characters are
    # preserved exactly and in order.
    for original_char, derived_char in zip(option_name, prefix):
        if original_char == " ":
            assert derived_char == "_"
        else:
            assert derived_char == original_char


# ---------------------------------------------------------------------------
# Property 2 (Task 1.3)
# ---------------------------------------------------------------------------

# Feature: spa-reference-interfaces, Property 2: Screenshot name is the prefix and step suffix joined by a single underscore
@settings(max_examples=200)
@given(prefix=_arbitrary_text, suffix=_arbitrary_text)
def test_screenshot_name_joins_prefix_and_suffix_with_single_underscore(
    prefix: str,
    suffix: str,
) -> None:
    """Property 2: Screenshot name is the prefix and step suffix joined by a
    single underscore.

    For any Screenshot_Prefix and step suffix, the composed screenshot name
    equals ``{prefix}_{suffix}`` — it starts with the prefix, ends with the
    suffix, and joins them with exactly one underscore at the boundary.

    Validates: Requirements 9.2
    """
    name = screenshot_name(prefix, suffix)

    # Canonical composition.
    assert name == f"{prefix}_{suffix}"

    # Starts with the prefix and ends with the suffix.
    assert name.startswith(prefix)
    assert name.endswith(suffix)

    # Exactly one underscore joins them: the character at the prefix boundary is
    # an underscore, and the split around it reconstructs both halves.
    assert name[len(prefix)] == "_"
    assert name[: len(prefix)] == prefix
    assert name[len(prefix) + 1 :] == suffix
