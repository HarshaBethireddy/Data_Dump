"""
tests/test_search.py
────────────────────
Binds features/search.feature to pytest-bdd.
All step implementations live in steps/search_steps.py
"""
import pytest
from pytest_bdd import scenarios

scenarios("../features/home_page_search.feature")
