"""
tests/test_search_modal.py
───────────────────────────
Binds features/search_modal.feature to pytest-bdd.
Step implementations live in steps/search_modal_steps.py.
"""
from pytest_bdd import scenarios

scenarios("../features/search_modal.feature")
