"""
tests/test_report_generator_filesystem.py
──────────────────────────────────────────
Example (pytest) tests for the filesystem-facing behavior of
``ReportGenerator.generate`` in ``utils/report_generator.py``.

Unlike the property-based tests for the pure build-plan/filename logic, these
exercise the python-docx-driven ``generate`` method against a real (temporary)
directory to assert the concrete side effects required by the spec:

* the ``reports/docs/`` sub-directory is created on demand (Requirement 10.4);
* a write failure surfaces a descriptive ``OSError`` and leaves existing
  reports untouched (Requirement 10.9);
* a recorded-but-missing screenshot yields a "screenshot missing" caption in
  that step's position rather than aborting (Requirement 10.7);
* an empty log still produces one report containing a "no steps were captured"
  indication (Requirement 10.8).

python-docx is installed, so ``generate`` renders an actual ``.docx`` which we
re-open to inspect its captions.
"""
from __future__ import annotations

import struct
import zlib
from pathlib import Path

import pytest
from docx import Document

from utils.report_generator import (
    MISSING_SCREENSHOT_CAPTION,
    NO_STEPS_CAPTION,
    ReportGenerator,
)
from utils.run_step_log import RunStepLog


# ── Helpers ──────────────────────────────────────────────────────────────────

def _make_png(width: int = 1, height: int = 1) -> bytes:
    """Build a minimal but fully valid 8-bit grayscale PNG with correct CRCs.

    Generated rather than hard-coded so ``python-docx``'s strict PNG parser can
    embed it via ``add_picture`` without depending on Pillow or an external
    screenshot file.
    """
    def _chunk(tag: bytes, data: bytes) -> bytes:
        return (
            struct.pack(">I", len(data))
            + tag
            + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
        )

    signature = b"\x89PNG\r\n\x1a\n"
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 0, 0, 0, 0)  # grayscale, 8-bit
    raw = b"".join(b"\x00" + b"\x00" * width for _ in range(height))  # filter byte + pixels
    idat = zlib.compress(raw)
    return signature + _chunk(b"IHDR", ihdr) + _chunk(b"IDAT", idat) + _chunk(b"IEND", b"")


def _write_png(path: Path) -> None:
    path.write_bytes(_make_png())


def _paragraph_texts(docx_path: Path) -> list[str]:
    """Return all paragraph texts from a saved ``.docx`` for caption assertions."""
    document = Document(str(docx_path))
    return [p.text for p in document.paragraphs]


# ── reports/docs/ creation (Requirement 10.4) ───────────────────────────────

def test_generate_creates_reports_docs_directory(tmp_path: Path) -> None:
    """generate() creates the ``docs/`` sub-directory under a reports dir that
    does not yet contain it, and writes the report there (Requirement 10.4)."""
    reports_dir = tmp_path / "reports"
    # reports/docs/ does not exist yet.
    assert not (reports_dir / "docs").exists()

    log = RunStepLog()
    log.record("Triggered activity [Do Not Call]", str(tmp_path / "missing.png"))

    report_path = ReportGenerator.generate(log, reports_dir=reports_dir)

    docs_dir = reports_dir / "docs"
    assert docs_dir.is_dir(), "reports/docs/ should be created on demand"
    assert report_path.parent == docs_dir
    assert report_path.exists()
    assert report_path.name.startswith("activity_report_")
    assert report_path.suffix == ".docx"


# ── Unwritable target → descriptive OSError (Requirement 10.9) ───────────────

def test_generate_raises_descriptive_oserror_on_unwritable_target(
    tmp_path: Path,
) -> None:
    """When the ``docs/`` directory cannot be created (a plain file already
    occupies its path), generate() raises a descriptive ``OSError`` naming the
    directory, and leaves the existing artifact untouched (Requirement 10.9)."""
    reports_dir = tmp_path / "reports"
    reports_dir.mkdir()
    # Occupy the docs/ path with a regular file so mkdir() cannot create the
    # directory there — a portable way to force a filesystem write failure.
    blocking_file = reports_dir / "docs"
    blocking_file.write_text("pre-existing content")

    log = RunStepLog()
    log.record("Triggered activity [Do Not Call]", None)

    with pytest.raises(OSError) as exc_info:
        ReportGenerator.generate(log, reports_dir=reports_dir)

    message = str(exc_info.value)
    # Descriptive: identifies the failure and the offending directory path.
    assert "docs" in message
    assert str(blocking_file) in message

    # The pre-existing artifact is left untouched (Requirement 10.9).
    assert blocking_file.is_file()
    assert blocking_file.read_text() == "pre-existing content"


# ── Missing screenshot → "screenshot missing" caption (Requirement 10.7) ─────

def test_generate_inserts_missing_caption_for_absent_screenshot(
    tmp_path: Path,
) -> None:
    """A recorded screenshot whose file is absent at report time produces a
    "screenshot missing" caption in that step's position, while present
    screenshots are still embedded and the report is fully generated
    (Requirement 10.7)."""
    reports_dir = tmp_path / "reports"

    present = tmp_path / "present.png"
    _write_png(present)
    absent = tmp_path / "absent.png"  # never created on disk

    log = RunStepLog()
    log.record("Iframe ready [Report Bankrupt]", str(present))
    log.record("Inputs filled [Report Bankrupt]", str(absent))

    report_path = ReportGenerator.generate(log, reports_dir=reports_dir)

    texts = _paragraph_texts(report_path)
    joined = "\n".join(texts)

    # The present screenshot's caption is rendered.
    assert any("Iframe ready [Report Bankrupt]" == t for t in texts)
    # The absent screenshot yields a missing-screenshot caption that still names
    # the step it stood in for (Requirement 10.7).
    assert MISSING_SCREENSHOT_CAPTION in joined
    assert any(
        MISSING_SCREENSHOT_CAPTION in t and "Inputs filled [Report Bankrupt]" in t
        for t in texts
    )


# ── Empty log → one report with "no steps were captured" (Requirement 10.8) ──

def test_generate_empty_log_produces_no_steps_report(tmp_path: Path) -> None:
    """An empty Run_Step_Log still produces exactly one report containing a
    textual indication that no steps were captured (Requirement 10.8)."""
    reports_dir = tmp_path / "reports"
    log = RunStepLog()  # no entries recorded

    report_path = ReportGenerator.generate(log, reports_dir=reports_dir)

    assert report_path.exists()
    texts = _paragraph_texts(report_path)
    assert any(NO_STEPS_CAPTION in t for t in texts), (
        f"empty-log report should contain '{NO_STEPS_CAPTION}'; got {texts!r}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# spa-reference-interfaces feature — report integration tests
# ─────────────────────────────────────────────────────────────────────────────
# These tests cover the same side-effecting ``ReportGenerator.generate`` from the
# perspective of the spa-reference-interfaces feature requirements. That feature
# reuses the existing report layer unchanged, so the requirement numbering differs
# from the activity-feature tests above:
#   * Req 10.1 — exactly one ``.docx`` Run_Report is produced per run.
#   * Req 10.2 — the report is written to ``reports/docs/``, created if absent.
#   * Req 10.6 — an empty log yields a "no steps were captured" notice.
#   * Req 10.7 — a write failure is TOLERATED at session teardown without raising
#                and leaves all existing reports unmodified.


def _tolerant_session_finish(log: RunStepLog, reports_dir: Path) -> Path | None:
    """Mirror conftest.py's ``pytest_sessionfinish`` toleration wrapper.

    The real session-end hook invokes ``ReportGenerator.generate`` inside a
    try/except that logs and swallows any error so test-session teardown always
    completes without raising (spa-reference-interfaces Requirement 10.7). This
    helper reproduces that exact toleration so the test can assert teardown does
    not raise on a write failure.
    """
    try:
        return ReportGenerator.generate(log, reports_dir=reports_dir)
    except Exception:  # noqa: BLE001 - teardown must never crash the run
        return None


# ── Exactly one .docx per run (spa-reference-interfaces Req 10.1) ────────────

def test_generate_produces_exactly_one_docx_report_spa(tmp_path: Path) -> None:
    """A finished run produces exactly one ``.docx`` Run_Report
    (spa-reference-interfaces Requirement 10.1)."""
    reports_dir = tmp_path / "reports"

    present = tmp_path / "product_types_selected.png"
    _write_png(present)
    log = RunStepLog()
    log.record("Product_Types_selected", str(present))

    report_path = ReportGenerator.generate(log, reports_dir=reports_dir)

    docx_files = sorted((reports_dir / "docs").glob("*.docx"))
    assert len(docx_files) == 1, f"expected exactly one report, got {docx_files!r}"
    assert docx_files[0] == report_path
    assert report_path.is_file()
    assert report_path.suffix == ".docx"


# ── reports/docs/ created on demand (spa-reference-interfaces Req 10.2) ──────

def test_generate_creates_reports_docs_directory_spa(tmp_path: Path) -> None:
    """The Run_Report is written under ``reports/docs/``, creating that
    directory when it is absent (spa-reference-interfaces Requirement 10.2)."""
    reports_dir = tmp_path / "reports"
    assert not (reports_dir / "docs").exists()

    log = RunStepLog()
    log.record("Branch_Update_add_modal_open", None)

    report_path = ReportGenerator.generate(log, reports_dir=reports_dir)

    docs_dir = reports_dir / "docs"
    assert docs_dir.is_dir(), "reports/docs/ should be created on demand"
    assert report_path.parent == docs_dir
    assert report_path.exists()


# ── Empty log → "no steps were captured" notice (spa-ref-interfaces Req 10.6) ─

def test_generate_empty_log_emits_no_steps_notice_spa(tmp_path: Path) -> None:
    """A run that captured zero steps still produces one report whose body
    states that no steps were captured (spa-reference-interfaces Req 10.6)."""
    reports_dir = tmp_path / "reports"
    log = RunStepLog()  # no entries recorded

    report_path = ReportGenerator.generate(log, reports_dir=reports_dir)

    assert report_path.exists()
    texts = _paragraph_texts(report_path)
    assert any(NO_STEPS_CAPTION in t for t in texts), (
        f"empty-log report should contain '{NO_STEPS_CAPTION}'; got {texts!r}"
    )


# ── Write failure tolerated, existing reports untouched (Req 10.7) ───────────

def test_generate_write_failure_tolerated_leaves_reports_unmodified_spa(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A write failure during report generation is TOLERATED by session
    teardown without raising, and all existing reports are left unmodified
    (spa-reference-interfaces Requirement 10.7).

    Unlike the activity feature (which surfaces the OSError to its caller), this
    feature's requirement is that the ``pytest_sessionfinish`` hook swallows the
    error so teardown completes cleanly. The unique, timestamped filename means a
    failed write can never clobber a prior run's report.
    """
    import docx.document

    reports_dir = tmp_path / "reports"
    docs_dir = reports_dir / "docs"
    docs_dir.mkdir(parents=True)

    # A report produced by an earlier run that must survive a later failed write.
    existing = docs_dir / "activity_report_20200101_000000.docx"
    existing_bytes = b"prior run report bytes - must remain unchanged"
    existing.write_bytes(existing_bytes)

    # Force the document save to fail, simulating a filesystem write failure.
    def _failing_save(self, path):  # noqa: ANN001
        raise OSError("simulated write failure while saving the run report")

    monkeypatch.setattr(docx.document.Document, "save", _failing_save)

    log = RunStepLog()
    log.record("Solution_Parameters_selected", None)

    # The write genuinely fails: generate() surfaces a descriptive OSError ...
    with pytest.raises(OSError):
        ReportGenerator.generate(log, reports_dir=reports_dir)

    # ... but the session-teardown toleration wrapper swallows it so teardown
    # completes WITHOUT raising (Requirement 10.7).
    result = _tolerant_session_finish(log, reports_dir)
    assert result is None, "a tolerated write failure should yield no report path"

    # Existing reports are left byte-for-byte unmodified, and no partial file for
    # the failed run is left behind alongside the prior report (Requirement 10.7).
    assert existing.read_bytes() == existing_bytes
    remaining = sorted(p.name for p in docs_dir.glob("*.docx"))
    assert remaining == ["activity_report_20200101_000000.docx"]
