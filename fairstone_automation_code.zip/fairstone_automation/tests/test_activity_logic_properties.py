"""
tests/test_activity_logic_properties.py
───────────────────────────────────────
Property-based tests (Hypothesis) for the pure-logic layer in
``utils/activity_logic.py``.

This file is built up incrementally: each task in the
activity-execution-and-reporting plan appends exactly one property-based test
for one numbered correctness property from the design document. Each test runs a
minimum of 100 examples and is tagged with a comment of the form
``# Feature: activity-execution-and-reporting, Property {n}: {text}``.
"""
from __future__ import annotations

from hypothesis import given, settings
from hypothesis import strategies as st

from utils.activity_logic import (
    build_fill_plan,
    detect_variant_from_shape,
    filter_enabled_tabs,
    match_field_value,
    match_select_option,
    match_timeline_items,
    normalize,
    select_most_recent,
)
from utils.activity_models import (
    ActivityField,
    DetailTab,
    FieldKind,
    IframeVariant,
    SelectOption,
    TimelineItem,
)


# Feature: activity-execution-and-reporting, Property 1: Variant classification is total and correct
@settings(max_examples=200)
@given(
    has_user_updates_form=st.booleans(),
    input_count=st.integers(min_value=0, max_value=1000),
)
def test_variant_classification_is_total_and_correct(
    has_user_updates_form: bool,
    input_count: int,
) -> None:
    """Property 1: Variant classification is total and correct.

    For any iframe DOM-shape descriptor ``{has_user_updates_form, input_count}``
    with ``input_count >= 0``, ``detect_variant_from_shape`` returns
    ``IframeVariant.INPUTS`` if and only if the user-updates form is present and
    ``input_count >= 1``, and returns ``IframeVariant.CONFIRMATION`` in every
    other case — i.e. it always returns exactly one variant.

    Validates: Requirements 3.1, 3.2, 3.3
    """
    result = detect_variant_from_shape(has_user_updates_form, input_count)

    # Totality: the result is always exactly one of the two variants.
    assert result in (IframeVariant.INPUTS, IframeVariant.CONFIRMATION)

    # Correctness: INPUTS iff (form present AND at least one input), else CONFIRMATION.
    expected_inputs = has_user_updates_form and input_count >= 1
    if expected_inputs:
        assert result is IframeVariant.INPUTS
    else:
        assert result is IframeVariant.CONFIRMATION


# ---------------------------------------------------------------------------
# Property 2 strategies
# ---------------------------------------------------------------------------

# A small alphabet that mixes case and a space so that generated ids/labels
# collide often (exercising the id-over-label preference) and carry casefold /
# whitespace significance.
_TOKEN_ALPHABET = "abAB cD"

# Tokens used for field ids and labels.
_tokens = st.text(alphabet=_TOKEN_ALPHABET, min_size=0, max_size=4)

# Whitespace runs used to pad a key so trimming behaviour is exercised.
_whitespace = st.text(alphabet=" \t\n", max_size=3)


@st.composite
def _activity_fields(draw: st.DrawFn) -> ActivityField:
    """Generate an ActivityField with colliding-prone id/label tokens."""
    return ActivityField(
        field_id=draw(_tokens),
        label=draw(_tokens),
        kind=draw(st.sampled_from(list(FieldKind))),
        dom_order=draw(st.integers(min_value=0, max_value=50)),
    )


@st.composite
def _perturb(draw: st.DrawFn, base: str) -> str:
    """Return ``base`` with random per-character case flips and surrounding whitespace."""
    flipped = "".join(
        ch.swapcase() if draw(st.booleans()) else ch for ch in base
    )
    return draw(_whitespace) + flipped + draw(_whitespace)


@st.composite
def _fields_and_key(draw: st.DrawFn) -> tuple[list[ActivityField], str]:
    """Generate a (fields, key) pair, biasing keys to often match a field."""
    fields = draw(st.lists(_activity_fields(), min_size=0, max_size=6))
    if fields and draw(st.booleans()):
        source = draw(st.sampled_from(fields))
        base = draw(st.sampled_from([source.field_id, source.label]))
        key = draw(_perturb(base))
    else:
        # A free-form key that may or may not match anything.
        key = draw(_perturb(draw(_tokens)))
    return fields, key


# Feature: activity-execution-and-reporting, Property 2: Field-value key matching with id-over-label preference
@settings(max_examples=200)
@given(data=_fields_and_key())
def test_field_value_key_matching_prefers_id_over_label(
    data: tuple[list[ActivityField], str],
) -> None:
    """Property 2: Field-value key matching with id-over-label preference.

    For any list of ActivityFields and any key string (including case and
    surrounding-whitespace perturbations), ``match_field_value(key, fields)``
    returns the field whose ``field_id`` equals the normalized key when such a
    field exists (preferred even when a different field's ``label`` also
    matches the key), otherwise the field whose ``label`` matches, and returns
    ``None`` when the normalized key equals neither any field id nor any field
    label.

    Validates: Requirements 4.2, 4.7
    """
    fields, key = data
    result = match_field_value(key, fields)

    normalized_key = normalize(key)
    id_matches = [f for f in fields if normalize(f.field_id) == normalized_key]
    label_matches = [f for f in fields if normalize(f.label) == normalized_key]

    if id_matches:
        # An id match exists: it must be returned (preferred over any label
        # match), specifically the first such field in document order.
        assert result is id_matches[0]
        assert normalize(result.field_id) == normalized_key
    elif label_matches:
        # No id match, but a label match exists: the first label match wins.
        assert result is label_matches[0]
        assert normalize(result.label) == normalized_key
    else:
        # Neither an id nor a label matches: no field is returned.
        assert result is None

    # When a field is returned it is always a member of the input list and
    # matches the key on its id or its label.
    if result is not None:
        assert result in fields
        assert (
            normalize(result.field_id) == normalized_key
            or normalize(result.label) == normalized_key
        )


# ---------------------------------------------------------------------------
# Property 3 strategies
# ---------------------------------------------------------------------------


@st.composite
def _select_options(draw: st.DrawFn) -> SelectOption:
    """Generate a SelectOption with collision-prone text/value tokens."""
    return SelectOption(
        text=draw(_tokens),
        value=draw(_tokens),
    )


@st.composite
def _options_and_value(draw: st.DrawFn) -> tuple[list[SelectOption], str]:
    """Generate an (options, value) pair, biasing values to often match an option."""
    options = draw(st.lists(_select_options(), min_size=0, max_size=6))
    if options and draw(st.booleans()):
        source = draw(st.sampled_from(options))
        base = draw(st.sampled_from([source.text, source.value]))
        value = draw(_perturb(base))
    else:
        # A free-form value that may or may not match anything.
        value = draw(_perturb(draw(_tokens)))
    return options, value


# Feature: activity-execution-and-reporting, Property 3: Select-option matching by text or value
@settings(max_examples=200)
@given(data=_options_and_value())
def test_select_option_matching_by_text_or_value(
    data: tuple[list[SelectOption], str],
) -> None:
    """Property 3: Select-option matching by text or value.

    For any list of SelectOptions and any value string (with case/whitespace
    noise), ``match_select_option(value, options)`` returns an option whose
    normalized visible ``text`` or normalized ``value`` equals the normalized
    input, and returns ``None`` exactly when no option's text or value matches.

    Validates: Requirements 4.4, 4.5
    """
    options, value = data
    result = match_select_option(value, options)

    normalized_value = normalize(value)
    matches = [
        opt
        for opt in options
        if normalize(opt.text) == normalized_value
        or normalize(opt.value) == normalized_value
    ]

    if matches:
        # A match exists: the first matching option in document order is returned.
        assert result is matches[0]
        # The returned option genuinely matches on its text or value.
        assert (
            normalize(result.text) == normalized_value
            or normalize(result.value) == normalized_value
        )
        # The returned option is a member of the input list.
        assert result in options
    else:
        # No option matches: None is returned exactly in that case.
        assert result is None


# ---------------------------------------------------------------------------
# Property 4 strategies
# ---------------------------------------------------------------------------


@st.composite
def _fields_and_matching_values(
    draw: st.DrawFn,
) -> tuple[list[ActivityField], dict[str, str]]:
    """Generate a (fields, field_values) pair where every key matches some field.

    Fields are generated with collision-prone id/label tokens (so a key may
    resolve to a different field than the one it was derived from, and several
    keys may resolve to the same field). Each key is built by perturbing the
    ``field_id`` or ``label`` of an existing field with case flips and
    surrounding whitespace, so after normalization it is guaranteed to match at
    least one field — satisfying the property's "keys all match some field"
    precondition. When no fields are generated, the mapping is necessarily
    empty.
    """
    fields = draw(st.lists(_activity_fields(), min_size=0, max_size=6))

    field_values: dict[str, str] = {}
    if fields:
        # Draw a handful of (key, value) pairs, each key derived from a field.
        n = draw(st.integers(min_value=0, max_value=8))
        for _ in range(n):
            source = draw(st.sampled_from(fields))
            base = draw(st.sampled_from([source.field_id, source.label]))
            key = draw(_perturb(base))
            value = draw(_tokens)
            field_values[key] = value

    return fields, field_values


# Feature: activity-execution-and-reporting, Property 4: Inputs fill-plan covers matched fields only, in DOM order
@settings(max_examples=200)
@given(data=_fields_and_matching_values())
def test_inputs_fill_plan_covers_matched_fields_only_in_dom_order(
    data: tuple[list[ActivityField], dict[str, str]],
) -> None:
    """Property 4: Inputs fill-plan covers matched fields only, in DOM order.

    For any list of ActivityFields and any Field_Values mapping whose keys all
    match some field, ``build_fill_plan(fields, field_values)`` produces fill
    operations exactly for the fields matched by some key (no unmatched field is
    ever included), and those operations appear in ascending ``dom_order`` — so
    fields with no corresponding key are left untouched and ordering is
    preserved.

    Validates: Requirements 4.1, 4.8
    """
    fields, field_values = data
    plan = build_fill_plan(fields, field_values)

    # Independently determine which fields each key resolves to.
    matched_fields = {
        match_field_value(key, fields)
        for key in field_values
    }
    matched_fields.discard(None)

    plan_fields = [op.field for op in plan]

    # Coverage: the plan's fields are exactly the matched fields — no unmatched
    # field is included, and every matched field appears.
    assert set(plan_fields) == matched_fields

    # One operation per matched field (no duplicates), so unmatched fields are
    # left untouched (absent from the plan).
    assert len(plan_fields) == len(matched_fields)

    # Every operation targets a field that is a member of the input list.
    for op in plan:
        assert op.field in fields

    # Ordering: operations appear in ascending DOM order.
    dom_orders = [op.field.dom_order for op in plan]
    assert dom_orders == sorted(dom_orders)

    # Value correctness: each operation carries the value of the last key (in
    # iteration order) that resolved to its field — mirroring the builder's
    # last-key-wins behaviour.
    expected_value: dict[ActivityField, str] = {}
    for key, value in field_values.items():
        field = match_field_value(key, fields)
        if field is not None:
            expected_value[field] = value
    for op in plan:
        assert op.value == expected_value[op.field]


# ---------------------------------------------------------------------------
# Property 5 strategies
# ---------------------------------------------------------------------------


@st.composite
def _timeline_items(draw: st.DrawFn) -> TimelineItem:
    """Generate a TimelineItem with a collision-prone subtitle and arbitrary index.

    Subtitles are drawn from the same small, case/whitespace-significant alphabet
    used elsewhere so that many items share a normalized subtitle (exercising the
    multi-match path). The ``index`` is drawn independently of list position so
    that ``select_most_recent``'s smallest-index selection is tested without
    assuming the input is already sorted by index.
    """
    return TimelineItem(
        subtitle=draw(_tokens),
        index=draw(st.integers(min_value=0, max_value=50)),
    )


@st.composite
def _items_and_name(draw: st.DrawFn) -> tuple[list[TimelineItem], str]:
    """Generate an (items, activity_name) pair, biasing the name to often match."""
    items = draw(st.lists(_timeline_items(), min_size=0, max_size=8))
    if items and draw(st.booleans()):
        source = draw(st.sampled_from(items))
        name = draw(_perturb(source.subtitle))
    else:
        # A free-form name that may or may not match anything.
        name = draw(_perturb(draw(_tokens)))
    return items, name


# Feature: activity-execution-and-reporting, Property 5: Timeline matching and most-recent selection
@settings(max_examples=200)
@given(data=_items_and_name())
def test_timeline_matching_and_most_recent_selection(
    data: tuple[list[TimelineItem], str],
) -> None:
    """Property 5: Timeline matching and most-recent selection.

    For any list of TimelineItems and any requested Activity_Name (with
    case/whitespace noise), ``match_timeline_items(items, name)`` returns exactly
    the items whose trimmed subtitle equals the requested name under a
    case-insensitive comparison, preserving document (input) order; and
    ``select_most_recent(matches)`` returns the match with the smallest ``index``
    (the top-most, index 0) when matches is non-empty, and ``None`` when it is
    empty.

    Validates: Requirements 6.2, 6.3, 6.4, 6.5, 7.5
    """
    items, name = data
    matches = match_timeline_items(items, name)

    normalized_name = normalize(name)
    expected = [item for item in items if normalize(item.subtitle) == normalized_name]

    # Correctness + order preservation: the matches are exactly the items whose
    # normalized subtitle equals the normalized name, in their original document
    # order (object identity, so position and content both line up).
    assert matches == expected
    assert [id(m) for m in matches] == [id(e) for e in expected]

    # Every returned item genuinely matches; no returned item fails to match.
    for item in matches:
        assert normalize(item.subtitle) == normalized_name
        assert item in items

    # Completeness: no matching item from the input is ever omitted.
    for item in items:
        if normalize(item.subtitle) == normalized_name:
            assert item in matches

    # Most-recent selection over the matches.
    most_recent = select_most_recent(matches)

    if not matches:
        # Empty matches yields no Most_Recent_Item.
        assert most_recent is None
    else:
        # Non-empty: the selected item is the match with the smallest index, and
        # is itself one of the matches.
        assert most_recent is not None
        assert most_recent in matches
        smallest_index = min(item.index for item in matches)
        assert most_recent.index == smallest_index
        # No other match has a strictly smaller index.
        assert all(most_recent.index <= item.index for item in matches)


# select_most_recent operates purely on index, independent of input ordering:
# shuffling the matches must not change which item (by index) is selected.
# Feature: activity-execution-and-reporting, Property 5: Timeline matching and most-recent selection
@settings(max_examples=200)
@given(matches=st.lists(_timeline_items(), min_size=0, max_size=8))
def test_select_most_recent_is_order_independent_min_index(
    matches: list[TimelineItem],
) -> None:
    """Property 5 (selection robustness): ``select_most_recent`` picks the
    smallest-``index`` item regardless of the order the matches are supplied in,
    and returns ``None`` for an empty list.

    Validates: Requirements 6.3, 6.4, 7.5
    """
    result = select_most_recent(matches)

    if not matches:
        assert result is None
        return

    reversed_result = select_most_recent(list(reversed(matches)))

    # The selection depends only on index, not on the order of the input.
    assert result is not None and reversed_result is not None
    assert result.index == reversed_result.index == min(m.index for m in matches)
    assert result in matches


# ---------------------------------------------------------------------------
# Property 6 strategies
# ---------------------------------------------------------------------------


@st.composite
def _detail_tabs(draw: st.DrawFn) -> DetailTab:
    """Generate a DetailTab with an arbitrary label, index, and disabled flag.

    Labels are drawn from the same small alphabet used elsewhere (so duplicate
    labels and case/whitespace variation occur), ``index`` is drawn
    independently of list position, and ``disabled`` is a free boolean so that
    all-enabled, all-disabled, and mixed tab strips are all exercised.
    """
    return DetailTab(
        label=draw(_tokens),
        index=draw(st.integers(min_value=0, max_value=50)),
        disabled=draw(st.booleans()),
    )


# Feature: activity-execution-and-reporting, Property 6: Enabled-tab filtering preserves order and excludes disabled
@settings(max_examples=200)
@given(tabs=st.lists(_detail_tabs(), min_size=0, max_size=10))
def test_enabled_tab_filtering_preserves_order_and_excludes_disabled(
    tabs: list[DetailTab],
) -> None:
    """Property 6: Enabled-tab filtering preserves order and excludes disabled.

    For any list of DetailTabs, ``filter_enabled_tabs(tabs)`` returns exactly
    the tabs whose ``disabled`` flag is ``False``, in their original
    left-to-right order; no disabled tab ever appears in the output, and the
    output is empty when every tab is disabled.

    Validates: Requirements 8.4, 8.5, 8.7
    """
    result = filter_enabled_tabs(tabs)

    # Correctness + order preservation: the result is exactly the non-disabled
    # tabs in their original order (object identity, so position and content
    # both line up).
    expected = [tab for tab in tabs if not tab.disabled]
    assert result == expected
    assert [id(t) for t in result] == [id(e) for e in expected]

    # Exclusion: no disabled tab ever appears in the output.
    assert all(not tab.disabled for tab in result)

    # Membership: every returned tab came from the input list.
    for tab in result:
        assert tab in tabs

    # Completeness: no enabled tab from the input is ever omitted.
    for tab in tabs:
        if not tab.disabled:
            assert tab in result

    # Output is a subsequence of the input (relative order strictly preserved).
    input_positions = [i for i, tab in enumerate(tabs) if not tab.disabled]
    assert input_positions == sorted(input_positions)
    assert len(result) == len(input_positions)

    # Empty when every tab is disabled (and, conversely, identical to input
    # when none are disabled).
    if tabs and all(tab.disabled for tab in tabs):
        assert result == []
    if tabs and all(not tab.disabled for tab in tabs):
        assert result == tabs
