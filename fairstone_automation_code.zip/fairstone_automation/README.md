# Collections Automation Framework

A **production-grade, BDD-driven Playwright + pytest-bdd** automation
framework for the Experian Collections web application.

---

## 📁 Project Structure

```
collections_automation/
├── features/               # Gherkin feature files (BDD scenarios)
│   ├── login.feature
│   ├── search.feature
│   └── navigation.feature
├── pages/                  # Page Object Models (one per screen)
│   ├── base_page.py        ← all shared helpers live here
│   ├── login_page.py
│   ├── home_page.py
│   └── search_page.py
├── steps/                  # pytest-bdd step definitions
│   ├── common_steps.py     ← shared Given/When/Then steps
│   ├── login_steps.py
│   ├── search_steps.py
│   └── navigation_steps.py
├── tests/                  # pytest-bdd scenario binders
│   ├── test_login.py
│   ├── test_search.py
│   └── test_navigation.py
├── utils/
│   ├── config.py           ← single config source (reads .env)
│   ├── logger.py           ← structured logger
│   └── screenshot_helper.py
├── screenshots/            # auto-created; failure/pass screenshots
├── reports/                # HTML report + logs
├── .env.example            ← copy to .env and fill credentials
├── pytest.ini
└── requirements.txt
```

---

## ⚙️ Setup

### 1. Prerequisites
- Python 3.9+
- pip

### 2. Install dependencies
```bash
pip install -r requirements.txt
playwright install chromium   # or: playwright install  (all browsers)
```

### 3. Configure environment
```bash
cp .env.example .env
# Edit .env — set BASE_URL, USERNAME, PASSWORD
```

---

## 🚀 Running Tests

### Run all tests
```bash
pytest tests/
```

### Run by tag / marker
```bash
pytest tests/ -m smoke          # smoke tests only
pytest tests/ -m "login"        # login feature only
pytest tests/ -m "search"       # search feature only
pytest tests/ -m "not negative" # exclude negative tests
```

### Run a specific feature
```bash
pytest tests/test_login.py
pytest tests/test_search.py
```

### Run with a specific browser
```bash
BROWSER=firefox pytest tests/
BROWSER=webkit  pytest tests/
```

### Run headless (CI)
```bash
HEADLESS=true pytest tests/
```

### Run in parallel (requires pytest-xdist)
```bash
pytest tests/ -n 4
```

### Generate Allure report
```bash
pytest tests/ --alluredir=reports/allure-results
allure serve reports/allure-results
```

---

## 📸 Screenshots

| Situation | Config flag | Default |
|-----------|-------------|---------|
| Test fails | `SCREENSHOT_ON_FAILURE` | `true` |
| Test passes | `SCREENSHOT_ON_PASS` | `false` |

Screenshots are saved to `screenshots/` with timestamps.

Manual capture inside a page object or step:
```python
page_obj.screenshot("my_label")          # viewport
page_obj.screenshot_full("full_page")    # full page
```

---

## ✍️ Adding a New Feature

1. **Write the feature file** in `features/my_feature.feature`
2. **Create a Page Object** in `pages/my_page.py` (extend `BasePage`)
3. **Write step definitions** in `steps/my_steps.py`
4. **Create a test binder** in `tests/test_my_feature.py`:
   ```python
   from pytest_bdd import scenarios
   scenarios("../features/my_feature.feature")
   ```
5. Register the step module in `conftest.py` → `pytest_plugins` list
6. Run `pytest tests/test_my_feature.py -v`

---

## 🔧 Key Design Decisions

| Concern | Solution |
|---------|----------|
| Slow typing (login fields) | `BasePage.slow_type()` — character-by-character with random delay |
| Single config source | `utils/config.py` — reads from `.env` |
| Fail-fast screenshots | `conftest.pytest_runtest_makereport` hook |
| Flaky waits | `BasePage.wait_for_*` wraps Playwright's built-in retry |
| Parallel-safe screenshots | Thread lock in `ScreenshotHelper` |
| No hardcoded waits | All timeouts come from `Config.TIMEOUT` |

---

## 🧩 Environment Variables Reference

| Variable | Default | Description |
|----------|---------|-------------|
| `BASE_URL` | `http://usaea1daplda654...` | App URL |
| `USERNAME` | — | LDAP username |
| `PASSWORD` | — | LDAP password |
| `BROWSER` | `chromium` | `chromium` / `firefox` / `webkit` |
| `HEADLESS` | `false` | `true` for CI |
| `SLOW_MO` | `50` | ms delay between Playwright actions |
| `TIMEOUT` | `30000` | Default element timeout (ms) |
| `SCREENSHOT_ON_FAILURE` | `true` | Capture screenshot on test failure |
| `SCREENSHOT_ON_PASS` | `false` | Capture screenshot on test pass |
