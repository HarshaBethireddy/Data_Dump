"""
pages/reference_interfaces_page.py
────────────────────────────────────
Page Object for the Reference Interfaces admin page.

URL / root element: collections-reference-interfaces#ReferenceInterfacesPage

Reached via: Admin nav → Admin popover → "Reference Interfaces"

Layout
------
  Header
    Title:  "Reference Interfaces"
    Dropdown: selects the reference type
              (Bankruptcy Types, Batch Outbound Config, …)
    Add button: opens "Add record" modal
    Close button: closes the page

  AG-Grid table: records for the selected reference type
    Columns: Code | Description

  Pagination: pcc-eds-pager (same structure as search results)

Modals
------
  Add record modal
    Fields: Code (required), Description
    Buttons: Cancel | Save (disabled until Code filled)

  Edit record modal  (opened by clicking a grid row)
    Fields: Code (disabled/read-only), Description
    Buttons: Cancel | Delete | Save (disabled until changed)

Screenshot naming convention
-----------------------------
  All screenshot methods accept a `prefix` string which should be the
  selected dropdown option name (e.g. "BankruptcyTypes").

  {prefix}_selected            — after dropdown option is selected
  {prefix}_add_modal_open      — Add modal just opened
  {prefix}_add_filled          — Add modal after all fields filled
  {prefix}_add_saved           — after clicking Save in Add modal
  {prefix}_add_verified        — new record confirmed in grid
  {prefix}_edit_modal_open     — Edit modal just opened
  {prefix}_edit_filled         — Edit modal after fields updated
  {prefix}_edit_saved          — after clicking Save in Edit modal
  {prefix}_edit_verified       — update confirmed in grid
  {prefix}_delete_modal_open   — Edit modal opened for delete
  {prefix}_delete_confirmed    — after clicking Delete
  {prefix}_delete_verified     — record confirmed gone from grid
"""
from __future__ import annotations

from playwright.sync_api import (
    Locator,
    TimeoutError as PlaywrightTimeoutError,
    expect,
)

from pages.base_page import BasePage
from utils.logger import get_logger
from utils.screenshot_helper import ScreenshotHelper
from utils.screenshot_naming import derive_screenshot_prefix, screenshot_name

log = get_logger(__name__)


class ReferenceInterfacesPage(BasePage):
    """Models the Reference Interfaces admin page."""

    # ── Page root ─────────────────────────────────────────────────
    PAGE_ROOT  = "collections-reference-interfaces#ReferenceInterfacesPage"
    PAGE_TITLE = "h1.collections-reference-interfaces__title"

    # ── Header controls ───────────────────────────────────────────
    CLOSE_BTN = "button.collections-reference-interfaces__button-close"
    ADD_BTN   = "button.collections-reference-interfaces__button-add"

    # ── Reference type dropdown ───────────────────────────────────
    # Scoped to the header dropdown wrapper
    DROPDOWN_WRAPPER = ".collections-reference-interfaces__dropdown"
    DROPDOWN_TRIGGER = ".collections-reference-interfaces__dropdown .eds-dropdown-trigger"
    DROPDOWN_VALUE   = ".collections-reference-interfaces__dropdown .eds-dropdown-value"
    # Options rendered inside the dropdown list (only visible when open)
    DROPDOWN_OPTION  = ".collections-reference-interfaces__dropdown li[role='option']"

    # ── AG-Grid table ─────────────────────────────────────────────
    GRID_ROOT      = "ag-grid-angular"
    # All data rows (use same proven pattern from search_page)
    GRID_ROWS      = ".ag-center-cols-container [role='row']"
    # Cell selectors — by aria-colindex (1=Code, 2=Description)
    CELL_CODE      = ".ag-cell[aria-colindex='1']"
    CELL_DESC      = ".ag-cell[aria-colindex='2']"

    # ── Pagination ────────────────────────────────────────────────
    PAGER          = "pcc-eds-pager[class='pager']"
    PAGER_STATS    = ".stats[aria-label='Pagination information: ']"

    # ── Modal (shared by Add and Edit) ────────────────────────────
    MODAL_BOX      = "pcc-modal .eds-modal-box"
    MODAL_CLOSE    = "pcc-modal button.eds-close-modal[aria-label='close']"
    MODAL_HEADER   = "pcc-modal h2"

    # Form field articles — generic, filled by label text
    MODAL_ARTICLES = "collections-interfaces-form article.interface-characteristic"

    # Footer buttons
    # MODAL_CANCEL   = (
    #     "collections-interfaces-form "
    #     "button[eds-button][motif='tertiary']"
    # )
    # MODAL_SAVE     = (
    #     "collections-interfaces-form "
    #     "button[eds-button][motif='primary']"
    # )
    # MODAL_DELETE   = (
    #     "collections-interfaces-form "
    #     "button[eds-button][motif='basic']"
    # )
    MODAL_SAVE = "button:has-text('Save')"
    MODAL_DELETE = "button:has-text('Delete')"
    MODAL_CANCEL = "button:has-text('Cancel')"

    # Optional secondary confirmation dialog presented by some Delete flows.
    # Scoped to confirmation labels that are distinct from the form's own
    # "Delete" button so the initial Delete click is never matched here.
    DELETE_CONFIRM_BTN = (
        "pcc-modal button:has-text('Confirm'), "
        "pcc-modal button:has-text('Yes'), "
        "pcc-modal button:has-text('OK')"
    )

    # ── Spinner ───────────────────────────────────────────────────
    SPINNER = (
        "collections-spinner.collections-spinner__rendering--full_screen"
        ":not(.sr-only)"
    )

    # ──────────────────────────────────────────────────────────────
    # Page load
    # ──────────────────────────────────────────────────────────────

    def wait_until_loaded(self, timeout: int = 180_000) -> "ReferenceInterfacesPage":
        """Wait for the page's required elements to appear before treating it as loaded.

        The page title, the Reference_Type dropdown, and the Add button must all
        be present within ``timeout`` (Requirement 1.5). If any one of them fails
        to appear, a timeout error is raised that names the specific element that
        did not appear and the page is *not* treated as loaded — the
        ``reference_interfaces_loaded`` screenshot is only captured once every
        required element is present.
        """
        log.info("Waiting for Reference Interfaces page …")

        # Req 1.5 — wait for each required element, naming the offender on timeout.
        # The page root must exist before any of the named elements can appear.
        for selector, element_name in (
            (self.PAGE_ROOT, "page root"),
            (self.PAGE_TITLE, "page title"),
            (self.DROPDOWN_TRIGGER, "Reference_Type dropdown"),
            (self.ADD_BTN, "Add button"),
        ):
            try:
                self.page.wait_for_selector(selector, timeout=timeout)
            except PlaywrightTimeoutError:
                # Page is not treated as loaded: raise before screenshot/return.
                raise AssertionError(
                    f"Reference Interfaces page failed to load: the {element_name} "
                    f"did not appear within {timeout} ms."
                )

        self.wait_for_spinner_gone(self.SPINNER, timeout=timeout)
        self.screenshot("reference_interfaces_loaded")
        log.info("Reference Interfaces page loaded ✓")
        return self

    def is_loaded(self) -> bool:
        return self.is_visible(self.PAGE_ROOT)

    # ──────────────────────────────────────────────────────────────
    # Per-step screenshot recording (Requirement 9)
    # ──────────────────────────────────────────────────────────────

    def record_step(self, label: str) -> None:
        """Single recording point for every mandated Reference Interfaces step.

        Captures exactly one screenshot via :class:`ScreenshotHelper` and appends
        exactly one ordered entry to the injected ``Run_Step_Log`` (Requirements
        9.1–9.3). The screenshot file name and the recorded label are the step's
        ``{Screenshot_Prefix}_{step_suffix}`` value (Requirement 9.2).

        The ``Run_Step_Log`` reference is read defensively via
        ``getattr(self, "run_step_log", None)`` so the method never fails when no
        log has been injected: in that case the screenshot is still captured but
        no entry is recorded.

        Capture is fault-tolerant: if :meth:`ScreenshotHelper.capture` raises (or
        times out), a single failure-labelled entry (``failed=True``,
        ``screenshot_path=None``) is recorded when a log is present and the flow
        continues without aborting the run (Requirement 9.4).

        Parameters
        ----------
        label : str
            The step's screenshot name / log label, e.g.
            ``"Bankruptcy_Types_add_verified"``.
        """
        run_log = getattr(self, "run_step_log", None)
        try:
            path = ScreenshotHelper.capture(self.page, label)
        except Exception as exc:  # Req 9.4 — capture must never abort the run
            log.warning(
                "[ReferenceInterfacesPage] Screenshot capture failed for step "
                "'%s': %s; recording a failure entry and continuing.",
                label, exc,
            )
            if run_log is not None:
                run_log.record(label, None, failed=True)
            return

        if run_log is not None:
            run_log.record(label, str(path), failed=False)

    # ──────────────────────────────────────────────────────────────
    # Dropdown — reference type selection
    # ──────────────────────────────────────────────────────────────

    def get_selected_option(self) -> str:
        return self.get_text(self.DROPDOWN_VALUE).strip()

    def select_reference_type(self, option_name: str) -> str:
        """
        Open the dropdown, select the option matching `option_name`,
        wait for the grid to reload, and take a screenshot.

        Returns a safe prefix string for use in subsequent screenshot names.
        E.g. "Bankruptcy Types" → "Bankruptcy_Types"

        Available options (from HTML):
          Bankruptcy Types, Batch Outbound Config, Batch Task Config,
          Branch Update, DCA Marketshare, Product, Settlement Campaign,
          Settlement Paramters, Solution Parameters, UpdateDisasterCodes
        """
        log.info("Selecting reference type: '%s'", option_name)
        self.click(self.DROPDOWN_TRIGGER)
        # Req 2.3 — wait for the option list to render.
        try:
            self.page.wait_for_selector(self.DROPDOWN_OPTION, timeout=10_000)
        except PlaywrightTimeoutError:
            # Req 2.7 — selection step failed: do not load the grid; propagate
            # an error that identifies the failed step (rendering the options).
            raise AssertionError(
                f"Reference Interfaces select failed for option '{option_name}': "
                f"the Reference_Type dropdown option list did not render within "
                f"10000 ms."
            )

        option_sel = (
            f".collections-reference-interfaces__dropdown "
            f"li[role='option']:has-text('{option_name}')"
        )
        option = self.page.locator(option_sel)
        # Req 2.6 — requested option not present: raise naming the option and
        # leave the current selection unchanged (do not click / load the grid).
        if option.count() == 0:
            raise AssertionError(
                f"Reference Interfaces select failed: the requested Reference_Type "
                f"option '{option_name}' is not present in the dropdown; the "
                f"current selection is left unchanged."
            )

        option.first.click()
        self.wait_for_spinner_gone(self.SPINNER)
        prefix = option_name.replace(" ", "_")
        self.record_step(f"{prefix}_selected")
        log.info("Reference type '%s' selected ✓", option_name)
        return prefix

    # ──────────────────────────────────────────────────────────────
    # Grid interaction
    # ──────────────────────────────────────────────────────────────

    def get_row_count(self) -> int:
        return self.page.locator(self.GRID_ROWS).count()

    def _get_row_by_code(self, code: str) -> Locator:
        """
        Return the Locator for the grid row whose Code cell text equals `code`.
        The Code cell is aria-colindex='1'.
        """
        return self.page.locator(
            f".ag-center-cols-container [role='row']"
            f":has(.ag-cell[aria-colindex='1']:text-is('{code}'))"
        )

    def click_row_by_code(self, code: str) -> None:
        """Click the grid row whose Code column equals `code`."""
        log.info("Clicking row with Code='%s'", code)
        row = self._get_row_by_code(code)
        row.scroll_into_view_if_needed()
        row.click()

    def is_row_present(self, code: str) -> bool:
        return self._get_row_by_code(code).count() > 0

    # ──────────────────────────────────────────────────────────────
    # Modal: shared wait and field helpers
    # ──────────────────────────────────────────────────────────────

    def _wait_for_modal(self, timeout: int = 30_000) -> None:
        self.page.wait_for_selector(self.MODAL_BOX, timeout=timeout)
        self.wait_for_element_visible(self.MODAL_HEADER, timeout=timeout)

    def get_modal_title(self) -> str:
        return self.get_text(self.MODAL_HEADER).strip()

    def fill_modal_field(self, label: str, value: str) -> None:
        """
        Fill a form field in the Add/Edit modal by its label text.

        HTML structure per field:
            <article class="interface-characteristic">
              <label class="interface-characteristic__name"> Code * </label>
              <input class="interface-characteristic__value" ...>
            </article>

        Uses has-text (contains) so you can pass "Code" and it matches
        " Code * " without needing exact whitespace/asterisk.
        Uses fill_and_trigger so Angular's form validators re-evaluate.
        """
        input_sel = (
            f"article.interface-characteristic"
            f":has(label.interface-characteristic__name:has-text('{label}'))"
            f" input.interface-characteristic__value"
        )
        # Req 3.4 — an unmatched label is a hard error: name the label and do
        # NOT proceed to fill or click Save.
        if self.page.locator(input_sel).count() == 0:
            raise AssertionError(
                f"Reference Interfaces modal field error: no field with label "
                f"'{label}' was found in the modal; Save will not be clicked."
            )
        log.info("Filling modal field '%s' = '%s'", label, value)
        self.fill_and_trigger(input_sel, value)

    def get_modal_field_value(self, label: str) -> str:
        """Read the current value of a modal form field."""
        input_sel = (
            f"article.interface-characteristic"
            f":has(label.interface-characteristic__name:has-text('{label}'))"
            f" input.interface-characteristic__value"
        )
        return self.page.locator(input_sel).input_value()

    def _wait_for_save_enabled(self, timeout: int = 10_000) -> None:
        """Wait until the Save button becomes enabled, else raise descriptively.

        The Save button is treated as disabled while the required Code field is
        empty or any modal validation rule is unsatisfied (Requirements 3.6,
        3.7); this method waits up to ``timeout`` for it to become enabled before
        a caller clicks it.

        Raises
        ------
        AssertionError
            If the Save button does not become enabled within ``timeout`` — the
            message indicates the Save button remained disabled. The caller must
            not click Save, leaving the modal open without persisting a record
            (Requirement 3.8).
        """
        try:
            expect(
                self.page.locator(self.MODAL_SAVE)
            ).to_be_enabled(timeout=timeout)
        except (PlaywrightTimeoutError, AssertionError):
            # Req 3.8 — Save stayed disabled: descriptive timeout error; the
            # modal is left open and no record is persisted (Save not clicked).
            raise AssertionError(
                f"Reference Interfaces save failed: the Save button remained "
                f"disabled and did not become enabled within {timeout} ms; the "
                f"modal is left open without persisting a record."
            )

    # ──────────────────────────────────────────────────────────────
    # Add Record flow
    # ──────────────────────────────────────────────────────────────

    def click_add_button(self, prefix: str) -> None:
        """Click the Add button and wait for the 'Add record' modal."""
        log.info("Clicking Add button")
        self.click(self.ADD_BTN)
        self._wait_for_modal()
        self.record_step(f"{prefix}_add_modal_open")
        assert self.get_modal_title() == "Add record", (
            f"Expected 'Add record' modal, got: '{self.get_modal_title()}'"
        )

    def fill_add_modal(self, fields: dict[str, str], prefix: str) -> None:
        """
        Fill all provided fields in the Add record modal.
        `fields` = { "Code": "ABC", "Description": "My desc" }
        Skips any field where value is None or empty.
        Takes a screenshot after all fields are filled.
        """
        for label, value in fields.items():
            if value:
                self.fill_modal_field(label, value)
        self.record_step(f"{prefix}_add_filled")

    def save_add_modal(self, prefix: str) -> None:
        """Wait for Save to be enabled, click it, wait for modal to close."""
        self._wait_for_save_enabled()
        log.info("Clicking Save in Add modal")
        self.click(self.MODAL_SAVE)
        self.wait_for_element_hidden(self.MODAL_BOX)
        self.wait_for_spinner_gone(self.SPINNER)
        self.record_step(f"{prefix}_add_saved")

    # ──────────────────────────────────────────────────────────────
    # Search / verify after Add (Requirement 4)
    # ──────────────────────────────────────────────────────────────

    def search_and_verify_added(self, code: str, expected_description: str) -> None:
        """Search for and verify the record that was just added.

        This is the deliberate improvement over the Java reference: after an Add
        operation the automation locates the new record and confirms its data
        before acting on it further.

        The grid row whose Code cell text *exactly* equals ``code`` is located
        within the configured timeout (Requirement 4.1). On success the located
        row's Description cell is read and confirmed to equal
        ``expected_description`` character-for-character (Requirement 4.4), then a
        single ``{Screenshot_Prefix}_add_verified`` screenshot is recorded
        (Requirement 4.2).

        Parameters
        ----------
        code : str
            The Code that was entered during the Add operation.
        expected_description : str
            The Description that was entered during the Add operation.

        Raises
        ------
        AssertionError
            If no row with the exact ``code`` is present within the configured
            timeout — the message names the missing Code and the
            ``add_verified`` screenshot is *not* captured (Requirement 4.3).
            If the located row's Description does not exactly equal
            ``expected_description`` — the message names the Code, the expected
            Description, and the actual Description found (Requirement 4.5).
        """
        log.info("Search-and-verify added record Code='%s'", code)
        row = self._get_row_by_code(code)

        # Req 4.1 — locate the row whose Code exactly equals `code` within timeout.
        try:
            row.first.wait_for(state="visible", timeout=self.timeout)
        except PlaywrightTimeoutError:
            # Req 4.3 — missing Code: descriptive error; do NOT capture add_verified.
            raise AssertionError(
                f"Reference Interfaces add-verify failed: no record with "
                f"Code='{code}' was found in the grid within {self.timeout} ms."
            )

        # Req 4.4 — read the located row's Description cell and compare exactly.
        actual_description = (
            row.first.locator(self.CELL_DESC).inner_text().strip()
        )
        if actual_description != expected_description:
            # Req 4.5 — mismatch: name the Code, expected, and actual Description.
            raise AssertionError(
                f"Reference Interfaces add-verify failed for Code='{code}': "
                f"expected Description '{expected_description}', but found "
                f"'{actual_description}'."
            )

        # Req 4.2 — success only: capture exactly one {prefix}_add_verified.
        prefix = derive_screenshot_prefix(self.get_selected_option())
        self.record_step(screenshot_name(prefix, "add_verified"))
        log.info(
            "Add-verify confirmed Code='%s' with expected description ✓", code
        )

    # ──────────────────────────────────────────────────────────────
    # Edit Record flow
    # ──────────────────────────────────────────────────────────────

    def open_edit_modal(self, code: str, prefix: str) -> None:
        """Click the row with the given Code to open the Edit record modal."""
        log.info("Opening Edit modal for Code='%s'", code)
        self.click_row_by_code(code)
        self._wait_for_modal()
        self.record_step(f"{prefix}_edit_modal_open")
        assert self.get_modal_title() == "Edit record", (
            f"Expected 'Edit record' modal, got: '{self.get_modal_title()}'"
        )

    def fill_edit_modal(self, fields: dict[str, str], prefix: str) -> None:
        """
        Fill editable fields in the Edit record modal.
        Note: the Code field is disabled in Edit mode — passing it in
        `fields` is silently ignored (fill_and_trigger handles disabled inputs
        by catching the error).
        """
        for label, value in fields.items():
            if value:
                try:
                    self.fill_modal_field(label, value)
                except Exception as exc:
                    log.warning(
                        "Could not fill field '%s' (may be disabled): %s",
                        label, exc,
                    )
        self.record_step(f"{prefix}_edit_filled")

    def save_edit_modal(self, prefix: str) -> None:
        """Wait for Save to be enabled, click it, wait for the modal to close.

        After Save is clicked the Edit_Modal must close within the configured
        timeout (Requirement 5.7); if it does not, a descriptive timeout error is
        raised indicating that the Edit_Modal did not close (Requirement 5.8).
        """
        self._wait_for_save_enabled()
        log.info("Clicking Save in Edit modal")
        self.click(self.MODAL_SAVE)
        try:
            self.wait_for_element_hidden(self.MODAL_BOX)
        except (PlaywrightTimeoutError, AssertionError):
            # Req 5.8 — descriptive timeout naming which modal did not close.
            raise AssertionError(
                f"Reference Interfaces edit save failed: the Edit record modal "
                f"did not close within {self.timeout} ms after Save was clicked."
            )
        self.wait_for_spinner_gone(self.SPINNER)
        self.record_step(f"{prefix}_edit_saved")

    # ──────────────────────────────────────────────────────────────
    # Verify after Edit (Requirement 5.9, 5.10)
    # ──────────────────────────────────────────────────────────────

    def verify_edit(self, code: str, expected_description: str) -> None:
        """Verify the record's Description after the Edit modal has closed.

        Once the Edit_Modal has closed, the grid row whose Code cell text
        *exactly* equals ``code`` is located and its Description cell is read and
        confirmed to equal ``expected_description`` character-for-character
        (Requirement 5.9). On success a single ``{Screenshot_Prefix}_edit_verified``
        screenshot is recorded.

        Parameters
        ----------
        code : str
            The Code of the record that was edited (unchanged by the edit).
        expected_description : str
            The updated Description value that was supplied during the Edit
            operation.

        Raises
        ------
        AssertionError
            If the located row's Description does not exactly equal
            ``expected_description`` — the message names the Code and the expected
            updated Description (Requirement 5.10).
        """
        log.info("Verify edited record Code='%s'", code)
        row = self._get_row_by_code(code)

        # Req 5.9 — locate the edited row within the configured timeout.
        try:
            row.first.wait_for(state="visible", timeout=self.timeout)
        except PlaywrightTimeoutError:
            # Edited row absent: descriptive error naming the Code and expected.
            raise AssertionError(
                f"Reference Interfaces edit-verify failed: no record with "
                f"Code='{code}' was found in the grid within {self.timeout} ms "
                f"(expected updated Description '{expected_description}')."
            )

        # Req 5.9 — read the edited row's Description cell and compare exactly.
        actual_description = (
            row.first.locator(self.CELL_DESC).inner_text().strip()
        )
        if actual_description != expected_description:
            # Req 5.10 — mismatch: name the Code and the expected updated Description.
            raise AssertionError(
                f"Reference Interfaces edit-verify failed for Code='{code}': "
                f"expected updated Description '{expected_description}', but found "
                f"'{actual_description}'."
            )

        # Req 5.9 — success only: capture exactly one {prefix}_edit_verified.
        prefix = derive_screenshot_prefix(self.get_selected_option())
        self.record_step(screenshot_name(prefix, "edit_verified"))
        log.info(
            "Edit-verify confirmed Code='%s' with updated description ✓", code
        )

    # ──────────────────────────────────────────────────────────────
    # Delete Record flow
    # ──────────────────────────────────────────────────────────────

    def open_delete_modal(self, code: str, prefix: str) -> None:
        """Click the row to open the Edit modal, then screenshot (delete variant)."""
        log.info("Opening modal to delete Code='%s'", code)
        self.click_row_by_code(code)
        self._wait_for_modal()
        self.record_step(f"{prefix}_delete_modal_open")

    def click_delete(self, prefix: str) -> None:
        """Click the Delete button and wait for the modal to close."""
        log.info("Clicking Delete in modal")
        self.wait_for_element_visible(self.MODAL_DELETE)
        self.click(self.MODAL_DELETE)
        self.wait_for_element_hidden(self.MODAL_BOX)
        self.wait_for_spinner_gone(self.SPINNER)
        self.record_step(f"{prefix}_delete_confirmed")

    def _confirm_delete_if_required(self, timeout: int = 2_000) -> None:
        """Complete a secondary delete confirmation dialog if one is presented.

        Best-effort (Requirement 6.4): if no additional confirmation appears
        within a short window the flow proceeds unchanged. Any error raised
        while probing for the optional dialog is swallowed so it never aborts
        the delete flow.
        """
        confirm = self.page.locator(self.DELETE_CONFIRM_BTN)
        try:
            confirm.first.wait_for(state="visible", timeout=timeout)
        except PlaywrightTimeoutError:
            return  # No additional confirmation required.
        except Exception as exc:  # pragma: no cover - defensive only
            log.debug("Delete-confirmation probe ignored: %s", exc)
            return
        log.info("Completing additional delete confirmation")
        confirm.first.click()

    def delete_added_record(self, code: str) -> None:
        """Delete the exact record created earlier in the same CRUD cycle.

        This is the self-cleaning improvement over the Java reference: the
        Delete flow targets only the ``code`` that was added and confirmed
        earlier in the cycle and never any other Reference_Record
        (Requirement 6.2).

        The Edit_Modal is opened for ``code`` and a single
        ``{Screenshot_Prefix}_delete_modal_open`` screenshot is recorded
        (Requirement 6.1). The Delete button is then clicked; any additional
        confirmation that the application surfaces is completed (Requirement
        6.4). Once the modal closes, a single
        ``{Screenshot_Prefix}_delete_confirmed`` screenshot is recorded
        (Requirement 6.3).

        Parameters
        ----------
        code : str
            The Code of the record to delete — the one added and confirmed
            earlier in this CRUD cycle.

        Raises
        ------
        AssertionError
            If the Delete action surfaces a validation error so the modal does
            not close within the configured timeout. In that case the modal is
            left open, the record is retained in the grid, and the message
            names the offending Code (Requirement 6.5).
        """
        log.info("Delete-added-record flow for Code='%s'", code)
        prefix = derive_screenshot_prefix(self.get_selected_option())

        # Req 6.1 / 6.2 — open the Edit modal for the exact added Code only.
        self.click_row_by_code(code)
        self._wait_for_modal()
        self.record_step(screenshot_name(prefix, "delete_modal_open"))

        # Req 6.3 — click Delete in the Edit modal.
        self.wait_for_element_visible(self.MODAL_DELETE)
        self.click(self.MODAL_DELETE)

        # Req 6.4 — complete any additional confirmation that is presented.
        self._confirm_delete_if_required()

        # Req 6.3 / 6.5 — wait for the modal to close. If it stays open the
        # Delete surfaced a validation error: keep the modal open, retain the
        # record, and raise a descriptive error naming the Code.
        try:
            self.wait_for_element_hidden(self.MODAL_BOX)
        except (PlaywrightTimeoutError, AssertionError):
            raise AssertionError(
                f"Reference Interfaces delete failed for Code='{code}': the "
                f"Delete action surfaced a validation error and the modal did "
                f"not close within {self.timeout} ms. The modal remains open "
                f"and the record is retained in the grid."
            )

        self.wait_for_spinner_gone(self.SPINNER)
        # Req 6.3 — record exactly one {prefix}_delete_confirmed on success.
        self.record_step(screenshot_name(prefix, "delete_confirmed"))
        log.info("Delete confirmed for Code='%s' ✓", code)

    def verify_deleted(self, code: str) -> None:
        """Confirm the deleted Code is absent from the grid.

        Performs a Search_Verification that the row whose Code cell text equals
        ``code`` is absent from the Record_Grid within the configured timeout
        (Requirement 6.6). On success a single
        ``{Screenshot_Prefix}_delete_verified`` screenshot is recorded.

        Parameters
        ----------
        code : str
            The Code that was just deleted and is expected to be absent.

        Raises
        ------
        AssertionError
            If a record with ``code`` is still present in the grid after the
            Delete operation — the message names the Code that was expected to
            be absent (Requirement 6.7).
        """
        log.info("Verify-deleted Code='%s'", code)
        row = self._get_row_by_code(code)

        # Req 6.6 — assert the Code is absent within the configured timeout.
        try:
            row.first.wait_for(state="detached", timeout=self.timeout)
        except (PlaywrightTimeoutError, AssertionError):
            # Req 6.7 — still present: descriptive error naming the Code.
            raise AssertionError(
                f"Reference Interfaces delete-verify failed: a record with "
                f"Code='{code}' is still present in the grid after the Delete "
                f"operation; it was expected to be absent within "
                f"{self.timeout} ms."
            )

        # Req 6.6 — success only: capture exactly one {prefix}_delete_verified.
        prefix = derive_screenshot_prefix(self.get_selected_option())
        self.record_step(screenshot_name(prefix, "delete_verified"))
        log.info("Delete-verify confirmed Code='%s' absent ✓", code)

    def cancel_modal(self) -> None:
        """Click the Cancel button and wait for modal to close."""
        self.click(self.MODAL_CANCEL)
        self.wait_for_element_hidden(self.MODAL_BOX)

    # ──────────────────────────────────────────────────────────────
    # Cancel with verification (Requirement 7)
    # ──────────────────────────────────────────────────────────────

    def _cancel_modal_within_timeout(self, modal_label: str) -> None:
        """Click Cancel and wait for the modal to close within the timeout.

        Closes the open Add_Modal or Edit_Modal via its Cancel button so that no
        record change is persisted (Requirement 7.1).

        Parameters
        ----------
        modal_label : str
            Human-readable name of the modal being cancelled, used in the
            timeout error message (e.g. ``"Add record modal"``).

        Raises
        ------
        AssertionError
            If the modal does not close within the configured timeout after
            Cancel is clicked — the message names which modal did not close
            (Requirement 7.2).
        """
        log.info("Cancelling %s without saving", modal_label)
        self.click(self.MODAL_CANCEL)
        try:
            self.wait_for_element_hidden(self.MODAL_BOX)
        except (PlaywrightTimeoutError, AssertionError):
            # Req 7.2 — descriptive timeout error naming which modal did not close.
            raise AssertionError(
                f"Reference Interfaces cancel failed: the {modal_label} did not "
                f"close within {self.timeout} ms after Cancel was clicked."
            )

    def cancel_with_verify_add(self, code: str) -> None:
        """Cancel an Add_Modal and verify the entered Code was not persisted.

        Closes the open Add_Modal via Cancel within the configured timeout
        without saving (Requirement 7.1); raises a descriptive timeout error if
        it does not close (Requirement 7.2). After the Cancel_Path completes, the
        grid is searched to confirm the ``code`` entered during the cancelled Add
        is absent (Requirement 7.3). A single ``{Screenshot_Prefix}_cancel``
        screenshot is then recorded documenting the cancelled state (Requirement
        7.6); a screenshot-capture failure is recorded as a failure-labelled
        ``Run_Step_Log`` entry by :meth:`record_step` without aborting the flow
        (Requirement 7.7).

        Parameters
        ----------
        code : str
            The Code that was entered into the Add_Modal before it was cancelled.

        Raises
        ------
        AssertionError
            If the Add_Modal does not close within the configured timeout
            (Requirement 7.2), or if a record with ``code`` is present in the
            grid after the cancel — the message names the Code that should have
            been absent (Requirement 7.4).
        """
        log.info("Cancel-with-verify (Add) for Code='%s'", code)
        prefix = derive_screenshot_prefix(self.get_selected_option())

        # Req 7.1 / 7.2 — close the Add modal within the timeout without saving.
        self._cancel_modal_within_timeout("Add record modal")

        # Req 7.3 — confirm the entered Code is absent from the grid.
        row = self._get_row_by_code(code)
        try:
            row.first.wait_for(state="detached", timeout=self.timeout)
        except (PlaywrightTimeoutError, AssertionError):
            # Req 7.4 — present after cancel: descriptive error naming the Code.
            raise AssertionError(
                f"Reference Interfaces add-cancel verify failed: a record with "
                f"Code='{code}' is present in the grid after the Add modal was "
                f"cancelled; it should have been absent because the Add was not "
                f"saved."
            )

        # Req 7.6 / 7.7 — record exactly one {prefix}_cancel (fault-tolerant).
        self.record_step(screenshot_name(prefix, "cancel"))
        log.info("Add-cancel verify confirmed Code='%s' absent ✓", code)

    def cancel_with_verify_edit(self, code: str, prior_description: str) -> None:
        """Cancel an Edit_Modal and verify the record's Description is unchanged.

        Closes the open Edit_Modal via Cancel within the configured timeout
        without saving (Requirement 7.1); raises a descriptive timeout error if
        it does not close (Requirement 7.2). After the Cancel_Path completes, the
        Description cell of the affected record is read and confirmed to equal
        ``prior_description`` — its value before the Edit_Modal was opened
        (Requirement 7.5). A single ``{Screenshot_Prefix}_cancel`` screenshot is
        then recorded documenting the cancelled state (Requirement 7.6); a
        screenshot-capture failure is recorded as a failure-labelled
        ``Run_Step_Log`` entry by :meth:`record_step` without aborting the flow
        (Requirement 7.7).

        Parameters
        ----------
        code : str
            The Code of the record whose Edit_Modal was cancelled.
        prior_description : str
            The Description cell value of the record before the Edit_Modal was
            opened, expected to be unchanged after the cancel.

        Raises
        ------
        AssertionError
            If the Edit_Modal does not close within the configured timeout
            (Requirement 7.2), or if the Description cell of the affected record
            does not exactly equal ``prior_description`` after the cancel — the
            message names the Code, the expected unchanged Description, and the
            actual Description found (Requirement 7.5).
        """
        log.info("Cancel-with-verify (Edit) for Code='%s'", code)
        prefix = derive_screenshot_prefix(self.get_selected_option())

        # Req 7.1 / 7.2 — close the Edit modal within the timeout without saving.
        self._cancel_modal_within_timeout("Edit record modal")

        # Req 7.5 — locate the affected record within the configured timeout.
        row = self._get_row_by_code(code)
        try:
            row.first.wait_for(state="visible", timeout=self.timeout)
        except (PlaywrightTimeoutError, AssertionError):
            raise AssertionError(
                f"Reference Interfaces edit-cancel verify failed: no record with "
                f"Code='{code}' was found in the grid within {self.timeout} ms "
                f"(expected its Description to be unchanged at "
                f"'{prior_description}')."
            )

        # Req 7.5 — confirm the Description cell is unchanged from its pre-open value.
        actual_description = (
            row.first.locator(self.CELL_DESC).inner_text().strip()
        )
        if actual_description != prior_description:
            raise AssertionError(
                f"Reference Interfaces edit-cancel verify failed for Code='{code}': "
                f"expected the Description to be unchanged at '{prior_description}', "
                f"but found '{actual_description}' after the Edit modal was "
                f"cancelled."
            )

        # Req 7.6 / 7.7 — record exactly one {prefix}_cancel (fault-tolerant).
        self.record_step(screenshot_name(prefix, "cancel"))
        log.info(
            "Edit-cancel verify confirmed Code='%s' Description unchanged ✓", code
        )

    # ──────────────────────────────────────────────────────────────
    # Assertions
    # ──────────────────────────────────────────────────────────────

    def assert_on_reference_interfaces(self) -> None:
        self.assert_visible(self.PAGE_ROOT, "Reference Interfaces page must be visible")

    def assert_row_present(self, code: str, prefix: str = "") -> None:
        """Assert the row with Code=`code` is present in the grid."""
        assert self.is_row_present(code), (
            f"Expected row with Code='{code}' to be present in the grid"
        )
        if prefix:
            self.screenshot(f"{prefix}_verified")
        log.info("Row Code='%s' confirmed present in grid ✓", code)

    def assert_row_absent(self, code: str, prefix: str = "") -> None:
        """Assert the row with Code=`code` is NOT present in the grid."""
        assert not self.is_row_present(code), (
            f"Expected row with Code='{code}' to be absent, but it was found"
        )
        if prefix:
            self.screenshot(f"{prefix}_verified")
        log.info("Row Code='%s' confirmed absent from grid ✓", code)

    def assert_cell_value(self, code: str, col: int, expected: str) -> None:
        """Assert the value of column `col` (1=Code, 2=Description) for a row."""
        row = self._get_row_by_code(code)
        cell = row.locator(f".ag-cell[aria-colindex='{col}']")
        actual = cell.inner_text().strip()
        assert actual == expected, (
            f"Row Code='{code}' col {col}: expected '{expected}', got '{actual}'"
        )
