"""
pages/accordion_mixin.py
────────────────────────
Mixin providing generalized accordion interaction for any page that
renders collections-accordion-type-1-widget sections.

Instead of hardcoded per-accordion constants, every method takes the
accordion heading text as a plain string parameter.  Feature files
and step definitions simply pass the name — no page-object changes
are needed when new accordion sections are added to the app.

Accordion name examples (from live HTML):
    "Customer Overview"
    "Payments"
    "Delinquency Information"
    "Recent Communication"
    "Exceptions"
    "Treatment"
    "Hardship"

Usage
-----
    class MyPage(BasePage, AccordionMixin):
        ...

    # In a step:
    page.scroll_to_accordion("Payments")        # scroll + screenshot
    page.expand_accordion("Treatment")          # expand if collapsed
    page.toggle_accordion("Exceptions")         # flip current state
    val = page.get_field_in_accordion(
        "Delinquency Information", "Days Past Due"
    )
    page.assert_accordion_visible("Payments")
"""
from __future__ import annotations

from playwright.sync_api import Locator, expect

from utils.logger import get_logger

log = get_logger(__name__)


class AccordionMixin:
    """
    Generalized accordion mixin.
    Both CustomerOverviewPage and AccountActivityPage inherit this.
    """

    # One generic root selector — heading name is injected at call time
    ACCORDION_ROOT    = "collections-accordion-type-1-widget"
    ACCORDION_HEADING = "h2.pcc-widget__header-accordion"
    ACCORDION_CARET   = "a.collections-accordion-caret"

    # ──────────────────────────────────────────────────────────────
    # Locator factory
    # ──────────────────────────────────────────────────────────────

    def get_accordion(self, name: str) -> Locator:
        """
        Return the Playwright Locator for the accordion whose h2
        heading text exactly matches `name`.
        """
        return self.page.locator(
                f"h2.pcc-widget__header-accordion:has-text('{name}')"
            ).locator("xpath=ancestor::div[contains(@class,'base-grid')]")


    # ──────────────────────────────────────────────────────────────
    # Scroll + screenshot
    # ──────────────────────────────────────────────────────────────

    def scroll_to_accordion(self, name: str) -> None:
        """
        Scroll the accordion named `name` into the viewport, then
        take a screenshot capturing its current state.

        This is the primary method called by feature steps like:
            When I scroll to the "Payments" accordion
        """
        log.info("[AccordionMixin] Scrolling to accordion: '%s'", name)
        accordion = self.get_accordion(name)
        accordion.scroll_into_view_if_needed()
        # Small settle pause — lets Angular finish re-rendering after scroll
        self.page.wait_for_timeout(300)
        safe_name = name.replace(" ", "_")
        self.screenshot(f"accordion_{safe_name}")
        log.info("[AccordionMixin] Scrolled to accordion '%s' and screenshot taken ✓", name)

    # ──────────────────────────────────────────────────────────────
    # Expand / collapse
    # ──────────────────────────────────────────────────────────────

    def expand_accordion(self, name: str) -> None:
        """
        Expand the accordion if it is currently collapsed.
        Checks aria-expanded on the caret so we never accidentally
        collapse an accordion that is already open.
        """
        caret = self.get_accordion(name).locator(self.ACCORDION_CARET)
        expanded = caret.get_attribute("aria-expanded")
        if expanded == "false":
            log.info("[AccordionMixin] Expanding accordion: '%s'", name)
            caret.click()
        else:
            log.debug("[AccordionMixin] Accordion '%s' already expanded", name)

    def collapse_accordion(self, name: str) -> None:
        """Collapse the accordion if it is currently expanded."""
        caret = self.get_accordion(name).locator(self.ACCORDION_CARET)
        expanded = caret.get_attribute("aria-expanded")
        if expanded != "false":
            log.info("[AccordionMixin] Collapsing accordion: '%s'", name)
            caret.click()
        else:
            log.debug("[AccordionMixin] Accordion '%s' already collapsed", name)

    def toggle_accordion(self, name: str) -> None:
        """Flip the current expand/collapse state of the accordion."""
        log.info("[AccordionMixin] Toggling accordion: '%s'", name)
        self.get_accordion(name).locator(self.ACCORDION_CARET).click()

    # ──────────────────────────────────────────────────────────────
    # Field value lookup scoped to a named accordion
    # ──────────────────────────────────────────────────────────────

    def get_field_in_accordion(self, accordion_name: str, field_label: str) -> str:
        """
        Return the display value for `field_label` inside the named accordion.

        Scoping to the accordion prevents false matches when the same
        label appears in multiple sections (e.g. "Full Name" could
        theoretically appear in both Customer Overview and another section).

        HTML structure of each row:
            <li class="pcc-widget__row">
              <div class="pcc-widget__cell">
                <span data-raw_value="...">Full Name</span>   ← label cell
              </div>
              <div class="pcc-widget__cell">
                <span data-raw_value="...">JOHN DOE</span>    ← value cell
              </div>
            </li>
        """
        row = self.get_accordion(accordion_name).locator(
            f"li.pcc-widget__row"
            f":has(.pcc-widget__cell span:text-is('{field_label}'))"
        )
        return (
            row.locator(".pcc-widget__cell:last-child span")
            .first.inner_text()
            .strip()
        )

    # ──────────────────────────────────────────────────────────────
    # Assertions
    # ──────────────────────────────────────────────────────────────

    def assert_accordion_visible(self, name: str) -> None:
        """Assert the accordion with heading `name` is visible on the page."""
        locator = self.get_accordion(name)
        locator.scroll_into_view_if_needed()
        self.page.wait_for_timeout(300)
        
        safe_name = name.replace(" ", "_")
        self.screenshot(f"accordion_{safe_name}")

        log.info("[AccordionMixin] Asserting accordion visible: '%s'", name)
        expect(self.get_accordion(name)).to_be_visible(timeout=self.timeout)

    def assert_accordions_visible(self, names: list[str]) -> None:
        """Assert every accordion in `names` is visible. Fails on first miss."""
        for name in names:
            self.assert_accordion_visible(name)

    def assert_field_value_in_accordion(
        self, accordion_name: str, field_label: str, expected: str
    ) -> None:
        actual = self.get_field_in_accordion(accordion_name, field_label)
        assert actual == expected, (
            f"[AccordionMixin] Accordion '{accordion_name}' field '{field_label}': "
            f"expected '{expected}', got '{actual}'"
        )
