"""
pages/customer_overview_page.py
────────────────────────────────
Page Object for the Customer Overview page.

URL pattern : /collections/persons/{personId}/overview
Root element: collections-customer-overview#CustomerOverviewPage

Inherits
--------
BasePage        — core Playwright helpers, waits, screenshots
ActivitiesMixin — Activities sidebar tab + embedded-activity iframe
AccordionMixin  — generalized scroll-to / expand / field-value by name

Layout
------
  Secondary header  — person-name tab
  Tertiary nav      — Customer Overview | Person Profile

  LEFT panel                   RIGHT panel
  ─────────────────────────    ─────────────────────────────────
  Card: customer details       View-switcher dropdown
  Card: business details       Account list  ← click row → Account Activity
  Accordion: Treatment         Combined-activities-history (timeline)
  Accordion: Hardship

  RIGHT SIDEBAR — Alerts tab | Activities tab  (from ActivitiesMixin)
  STICKY BOTTOM — Notes widget
"""
from __future__ import annotations

import time

from playwright.sync_api import Page
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

from pages.base_page import BasePage
from pages.activities_mixin import ActivitiesMixin
from pages.accordion_mixin import AccordionMixin
from utils.activity_logic import match_timeline_items, select_most_recent
from utils.activity_models import TimelineItem
from utils.logger import get_logger

log = get_logger(__name__)


class CustomerOverviewPage(BasePage, ActivitiesMixin, AccordionMixin):
    """Models the Collections Customer Overview page."""

    # ── Page root / identity ──────────────────────────────────────
    PAGE_ROOT    = "collections-customer-overview#CustomerOverviewPage"
    PAGE_HEADING = "h1.sr-only"

    # ── Secondary header ─────────────────────────────────────────
    PERSON_NAME_LABEL = "collections-secondary-header span.person-name"

    # ── Tertiary navigation ───────────────────────────────────────
    TERTIARY_NAV          = "collections-tertiary-navigation"
    TAB_CUSTOMER_OVERVIEW = "collections-tertiary-navigation a[aria-label=' Customer Overview']"
    TAB_PERSON_PROFILE    = "collections-tertiary-navigation a[aria-label=' Person Profile']"

    # ── Left panel — Customer detail card ────────────────────────
    CUSTOMER_NAME_HEADING = "collections-card-type-1 h2.pcc-widget__header-card"

    # ── Right panel — view-switcher dropdown ─────────────────────
    VIEW_SWITCHER_TRIGGER = ".dropdown-container .eds-dropdown-trigger"
    VIEW_SWITCHER_VALUE   = ".dropdown-container .eds-dropdown-value"

    # ── Right panel — account list ────────────────────────────────
    ACCOUNT_LIST_TITLE  = "h3.list-title"
    ACCOUNT_LIST_ITEMS  = "a.list[role='listitem']"
    # Cells scoped relative to each list item
    ACCT_REFERENCE_SPAN = ".cell-account .slots.account .primary span"
    ACCT_PRODUCT_SPAN   = ".cell-col-5.cell-info:nth-child(2) .slots.info .primary span"
    ACCT_BALANCE_SPAN   = ".cell-col-5.cell-info:nth-child(3) .slots.info .primary span"
    ACCT_PURSUABLE_SPAN = ".cell-col-5.cell-info:nth-child(4) .slots.info .primary span"
    ACCT_SEGMENT_SPAN   = ".cell-col-5.cell-info:nth-child(5) .slots.info .primary span"

    # ── Right panel — combined activities / timeline ──────────────
    COMBINED_HISTORY   = "collections-combined-activities-history"
    TIMELINE_FILTER_DD = (
        "collections-combined-activities-history "
        "collections-dropdown[aria-label='All'] .eds-dropdown-trigger"
    )
    USER_FILTER_DD = (
        "collections-combined-activities-history "
        "collections-dropdown[aria-label='All Users'] .eds-dropdown-trigger"
    )

    # ── Timeline (within the combined-activities-history widget) ──
    # Real DOM: the timeline lives at
    #   collections-combined-activities-history > collections-timeline
    # and contains one collections-timeline-item per recorded activity.
    TIMELINE_ROOT = (
        "collections-combined-activities-history > collections-timeline"
    )
    TIMELINE_ITEM = (
        "collections-entity-events-timeline collections-timeline-item"
    )
    # Each Timeline_Item exposes a title link (div[role='link'].title) whose
    # subtitle span (class like 'subtitle0', 'subtitle1', …) carries the
    # Activity_Name.
    TIMELINE_ITEM_TITLE_LINK = "collections-timeline-item div.title"
    TIMELINE_ITEM_SUBTITLE = ".subtitle-text"
    TIMELINE_ITEM_TITLE_TEXT = ".title-text"

    TIMELINE_TIMEOUT = 180_000

    # ── Notes widget ──────────────────────────────────────────────
    NOTES_EXPAND_BTN    = "eds-button[aria-label='Notes panel'] button"
    NOTES_TEXTAREA      = "textarea[name='collections-textarea']"
    NOTES_SAVE_AS_ALERT = "eds-checkbox[label='Save as Alert'] input[type='checkbox']"
    NOTES_SAVE_BTN      = "button.pcc-notes__submit-btn"

    # ── Page-level spinner (excludes the embedded-activity spinner) ─
    SPINNER = (
        "collections-spinner"
        ":not(.sr-only)"
        ":not(.collections-spinner__rendering--embedded)"
    )

    # ──────────────────────────────────────────────────────────────
    # Wait / page load
    # ──────────────────────────────────────────────────────────────

    def wait_until_loaded(self, timeout: int = 180_000) -> "CustomerOverviewPage":
        log.info("Waiting for Customer Overview page …")
        self.page.wait_for_selector(self.PAGE_ROOT, timeout=timeout)
        self.page.wait_for_selector(self.TERTIARY_NAV, timeout=timeout)
        self.wait_for_spinner_gone(self.SPINNER, timeout=timeout)
        self.screenshot("customer_overview_loaded")
        log.info("Customer Overview page loaded ✓")
        return self

    def is_loaded(self) -> bool:
        try:
            return self.page.locator(self.PAGE_ROOT).count() > 0
        except:
            return False

    # ──────────────────────────────────────────────────────────────
    # Customer identity
    # ──────────────────────────────────────────────────────────────

    def get_person_name(self) -> str:
        return self.get_text(self.PERSON_NAME_LABEL).strip()

    def get_customer_name_heading(self) -> str:
        return self.page.locator(self.CUSTOMER_NAME_HEADING).first.inner_text().strip()

    # ──────────────────────────────────────────────────────────────
    # Generic field-value lookup (cards & non-accordion rows)
    # ──────────────────────────────────────────────────────────────

    def get_field_value(self, label: str) -> str:
        """
        Return the value for any label in a pcc-widget__row on this page.
        For accordion-scoped lookups use AccordionMixin.get_field_in_accordion().
        """
        row = self.page.locator(
            f"li.pcc-widget__row"
            f":has(.pcc-widget__cell span:text-is('{label}'))"
        )
        return row.locator(".pcc-widget__cell:last-child span").first.inner_text().strip()

    # ──────────────────────────────────────────────────────────────
    # Account list — match by ACCT_REFERENCE_SPAN (never by index)
    # ──────────────────────────────────────────────────────────────

    def get_account_count(self) -> int:
        return self.page.locator(self.ACCOUNT_LIST_ITEMS).count()

    def get_account_numbers(self) -> list[str]:
        """Read every ACCT_REFERENCE_SPAN and return the list in display order."""
        items = self.page.locator(self.ACCOUNT_LIST_ITEMS)
        refs: list[str] = []
        for i in range(items.count()):
            refs.append(
                items.nth(i).locator(self.ACCT_REFERENCE_SPAN).inner_text().strip()
            )
        log.debug("Account list contains: %s", refs)
        return refs

    def get_account_row_data(self, index: int = 0) -> dict:
        row = self.page.locator(self.ACCOUNT_LIST_ITEMS).nth(index)
        return {
            "account_reference": row.locator(self.ACCT_REFERENCE_SPAN).inner_text().strip(),
            "product_type":      row.locator(self.ACCT_PRODUCT_SPAN).inner_text().strip(),
            "balance":           row.locator(self.ACCT_BALANCE_SPAN).inner_text().strip(),
            "pursuable_balance": row.locator(self.ACCT_PURSUABLE_SPAN).inner_text().strip(),
            "segment_name":      row.locator(self.ACCT_SEGMENT_SPAN).inner_text().strip(),
        }

    def find_account_row_index(self, account_number: str) -> int:
        """
        Scan every ACCT_REFERENCE_SPAN and return the zero-based index
        of the row matching `account_number`.  Raises ValueError if absent.
        """
        items = self.page.locator(self.ACCOUNT_LIST_ITEMS)
        count = items.count()
        for i in range(count):
            ref = items.nth(i).locator(self.ACCT_REFERENCE_SPAN).inner_text().strip()
            if ref == account_number:
                log.debug("Found account '%s' at row index %d", account_number, i)
                return i
        available = [
            items.nth(i).locator(self.ACCT_REFERENCE_SPAN).inner_text().strip()
            for i in range(count)
        ]
        raise ValueError(
            f"Account '{account_number}' not found in account list. "
            f"Available: {available}"
        )

    def click_account_by_searched_number(self, account_number: str) -> None:
        """
        Read every ACCT_REFERENCE_SPAN, locate the row whose value
        matches `account_number`, and click that specific row.

        Never assumes the target is the first row.
        """
        log.info("Locating account '%s' in list by ACCT_REFERENCE_SPAN …", account_number)
        self.screenshot(f"before_find_account_{account_number}")
        index = self.find_account_row_index(account_number)
        log.info("Clicking account '%s' at row index %d", account_number, index)
        self.page.locator(self.ACCOUNT_LIST_ITEMS).nth(index).click()

    # ──────────────────────────────────────────────────────────────
    # View-switcher dropdown
    # ──────────────────────────────────────────────────────────────

    def get_current_view(self) -> str:
        return self.get_text(self.VIEW_SWITCHER_VALUE).strip()

    def switch_view(self, option_text: str) -> None:
        """Options: Customer Overview | Customer Decisioning | Customer Exceptions"""
        log.info("Switching view to: %s", option_text)
        self.click(self.VIEW_SWITCHER_TRIGGER)
        self.page.locator(
            f".dropdown-container li[role='option']:text-is('{option_text}')"
        ).click()
        self.page.screenshot(f"after_switch_view_{option_text.replace(' ', '_')}")
        self.wait_for_spinner_gone(self.SPINNER)

    # ──────────────────────────────────────────────────────────────
    # Tertiary nav
    # ──────────────────────────────────────────────────────────────

    def click_customer_overview_tab(self) -> None:
        self.click(self.TAB_CUSTOMER_OVERVIEW)

    def click_person_profile_tab(self) -> None:
        self.click(self.TAB_PERSON_PROFILE)

    # ──────────────────────────────────────────────────────────────
    # Timeline activity verification (Requirement 6)
    # ──────────────────────────────────────────────────────────────

    def _scrape_timeline_items(self) -> list[TimelineItem]:
        """
        Scrape the Customer Overview Timeline into :class:`TimelineItem` models.

        Each ``collections-timeline-item`` (in document order, top-to-bottom) is
        read into a TimelineItem whose:

          • ``subtitle`` — the Activity_Name from the item's title-link subtitle
            span, trimmed; empty string when absent.
          • ``index``    — the item's document position (0 = top-most, i.e. the
            Most_Recent_Item).
          • ``title_aria_label`` — the title link's ``aria-label`` when present.

        Returns
        -------
        list[TimelineItem]
            The timeline items in top-to-bottom document order.
        """
        item_locs = self.page.locator(self.TIMELINE_ITEM)
        count = item_locs.count()

        items: list[TimelineItem] = []
        for index in range(count):
            item = item_locs.nth(index)

            title = ""
            subtitle = ""
            subtitle_loc = item.locator(self.TIMELINE_ITEM_SUBTITLE)
            if subtitle_loc.count() > 0:
                subtitle = (subtitle_loc.first.inner_text() or "").strip()

            
            title_loc_text = item.locator(self.TIMELINE_ITEM_TITLE_TEXT)
            if title_loc_text.count() > 0:
                title = title_loc_text.first.inner_text().strip()

            final_text = subtitle if subtitle else title

            aria_label = ""
            title_loc = item.locator(self.TIMELINE_ITEM_TITLE_LINK)
            if title_loc.count() > 0:
                aria_label = title_loc.first.get_attribute("aria-label") or ""

            items.append(
                TimelineItem(
                    subtitle=final_text,
                    index=index,
                    title_aria_label=aria_label,
                )
            )

        return items

    def verify_activity_in_timeline(
        self, activity_name: str, timeout: int = TIMELINE_TIMEOUT
    ) -> TimelineItem:
        """
        Verify ``activity_name`` appears in the Customer Overview Timeline.

        Reads the Timeline at
        ``collections-combined-activities-history > collections-timeline`` and
        waits up to ``timeout`` (default 30 000 ms) for at least one
        ``collections-timeline-item`` to be present (Requirement 6.1). The items
        are scraped into :class:`TimelineItem` models and the match is decided by
        the pure-logic layer:

          • :func:`match_timeline_items` keeps the items whose trimmed subtitle
            equals ``activity_name`` under a case-insensitive comparison
            (Requirement 6.2).
          • :func:`select_most_recent` picks the top-most match (smallest
            ``index``, i.e. index 0) as the Most_Recent_Item (Requirement 6.3).

        Because the timeline may render items progressively after submission, the
        scrape/match is polled until a match is found or ``timeout`` elapses. A
        screenshot of the timeline is captured once items are present, and a
        screenshot of the matched item is captured on success (Requirement 6.4).

        Parameters
        ----------
        activity_name : str
            The Activity_Name to verify, matched case-insensitively after
            trimming.
        timeout : int
            Maximum time in milliseconds to wait for a matching item (default
            30 000 ms).

        Returns
        -------
        TimelineItem
            The Most_Recent_Item matching ``activity_name``.

        Raises
        ------
        RuntimeError
            If no ``collections-timeline-item`` becomes present, or no item's
            subtitle matches ``activity_name``, within ``timeout``. The message
            names the missing Activity_Name and the elapsed timeout duration; the
            Timeline state is left unchanged (Requirement 6.5).
        """
        log.info(
            "[CustomerOverviewPage] Verifying activity '%s' in timeline "
            "(timeout=%dms) …",
            activity_name, timeout,
        )
        start = time.monotonic()
        safe_name = activity_name.strip().replace(" ", "_") or "activity"

        # Requirement 6.1 — wait up to `timeout` for >=1 timeline item.
        try:
            self.page.wait_for_selector(self.TIMELINE_ITEM, timeout=timeout)
        except PlaywrightTimeoutError as exc:
            elapsed_ms = (time.monotonic() - start) * 1000
            raise RuntimeError(
                f"Activity '{activity_name}' could not be verified in the "
                f"Customer Overview timeline: no timeline item appeared within "
                f"{elapsed_ms:.0f} ms (configured timeout {timeout} ms)."
            ) from exc

        # Requirement 6.1/6.4 — capture the timeline once items are present.
        self.screenshot(f"timeline_read_{safe_name}")

        # Poll scrape + match until a match is found or the timeout elapses —
        # the timeline can render entries progressively after submission.
        deadline = start + (timeout / 1000)
        most_recent: TimelineItem | None = None
        while True:
            items = self._scrape_timeline_items()
            matches = match_timeline_items(items, activity_name)
            most_recent = select_most_recent(matches)
            if most_recent is not None:
                break
            if time.monotonic() >= deadline:
                break
            self.page.wait_for_timeout(500)

        # Requirement 6.5 — no match within the timeout.
        if most_recent is None:
            elapsed_ms = (time.monotonic() - start) * 1000
            available = [item.subtitle for item in self._scrape_timeline_items()]
            raise RuntimeError(
                f"Activity '{activity_name}' was not found in the Customer "
                f"Overview timeline within {elapsed_ms:.0f} ms (configured "
                f"timeout {timeout} ms). Timeline subtitles present: {available}."
            )

        # Requirement 6.4 — report success and capture the matched item.
        self.screenshot(f"matched_timeline_item_{safe_name}")
        log.info(
            "[CustomerOverviewPage] Activity '%s' verified in timeline "
            "(Most_Recent_Item at index %d) ✓",
            activity_name, most_recent.index,
        )
        return most_recent

    # ──────────────────────────────────────────────────────────────
    # Notes widget
    # ──────────────────────────────────────────────────────────────

    def expand_notes_panel(self) -> None:
        self.click(self.NOTES_EXPAND_BTN)
        self.wait_for_element_visible(self.NOTES_TEXTAREA)

    def type_note(self, text: str) -> None:
        self.fill_and_trigger(self.NOTES_TEXTAREA, text)

    def save_note(self) -> None:
        self.click(self.NOTES_SAVE_BTN)

    # ──────────────────────────────────────────────────────────────
    # Assertions
    # ──────────────────────────────────────────────────────────────

    def assert_on_customer_overview(self) -> None:
        self.assert_visible(self.PAGE_ROOT, "Customer Overview page root must be visible")

    def assert_account_list_visible(self) -> None:
        self.assert_visible(self.ACCOUNT_LIST_ITEMS, "Account list must have at least one item")

    def assert_account_list_contains(self, account_number: str) -> None:
        numbers = self.get_account_numbers()
        assert account_number in numbers, (
            f"Account '{account_number}' not found in list: {numbers}"
        )

    def assert_customer_name_heading_visible(self) -> None:
        self.assert_visible(self.CUSTOMER_NAME_HEADING)

    def assert_tertiary_tabs_present(self) -> None:
        self.assert_visible(self.TAB_CUSTOMER_OVERVIEW)
        self.assert_visible(self.TAB_PERSON_PROFILE)
