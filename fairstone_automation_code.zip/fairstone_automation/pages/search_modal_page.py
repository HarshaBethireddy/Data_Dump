"""
pages/search_modal_page.py
───────────────────────────
Page Object for the Search Modal that opens when the Search nav button
is clicked in the header.

Trigger  : a[aria-label='Search'] in the primary header nav
Modal root: collections-modal-search#ModalSearchPage

5 Tabs and their inputs
───────────────────────
Tab 0 — Account Search
    Account Number, Phone Number
    → Customer Overview Page

Tab 1 — Advanced Account Search
    Account Number, SIN, First Name, Last Name, Phone Number,
    Email, Address Line 1, City, Province, Postal Code
    → Customer Overview Page

Tab 2 — Customer Search
    Customer Number
    → Customer Overview Page

Tab 3 — Contact Search
    Contact Reference, Email, First Name, Last Name,
    Address Line 1, City, Province, Postal Code
    → Customer Overview Page (Person Profile tertiary tab active)

Tab 4 — Contact Search FS
    Contact Reference, Email, First Name, Last Name, SIN,
    Address Line 1, City, Province, Postal Code
    → Customer Overview Page (Person Profile tertiary tab active)

Screenshot flow (enforced by the page object):
    1. click_tab()          → screenshot  (state before filling)
    2. fill_field(s)        → (caller fills as many as needed — partial OK)
    3. screenshot_filled()  → screenshot  (state after filling)
    4. submit_search()      → screenshot  (state immediately after click)
"""
from __future__ import annotations

from typing import Optional

from playwright.sync_api import Page

from pages.base_page import BasePage
from utils.logger import get_logger

log = get_logger(__name__)


class SearchModalPage(BasePage):
    """Models the Collections Search Modal."""

    # ── Modal root ────────────────────────────────────────────────
    MODAL_ROOT   = ".eds-modal-box[closable='true']" #"collections-modal-search#ModalSearchPage"
    MODAL_DIALOG = "pcc-modal[role='dialog']"
    CLOSE_BTN    = "collections-modal-search button.eds-close-modal[aria-label='close']"
    MODAL_HEADER = "collections-modal-search h1.pcc-advanced-search-form__header"

    # ── Tab selectors (data-index matches the tab order 0-4) ──────
    # Scope to modal so there is no clash with sidebar/account tabs
    TAB = "collections-modal-search pcc-eds-tabs a[data-index='{idx}']"

    TAB_ACCOUNT_SEARCH          = "collections-modal-search pcc-eds-tabs a[data-index='0']"
    TAB_ADVANCED_ACCOUNT_SEARCH = "collections-modal-search pcc-eds-tabs a[data-index='1']"
    TAB_CUSTOMER_SEARCH         = "collections-modal-search pcc-eds-tabs a[data-index='2']"
    TAB_CONTACT_SEARCH          = "collections-modal-search pcc-eds-tabs a[data-index='3']"
    TAB_CONTACT_SEARCH_FS       = "collections-modal-search pcc-eds-tabs a[data-index='4']"

    # Map tab names to their selectors (used by the generic click_tab step)
    TAB_MAP: dict[str, str] = {
        "Account Search":          "collections-modal-search pcc-eds-tabs a[data-index='0']",
        "Advanced Account Search": "collections-modal-search pcc-eds-tabs a[data-index='1']",
        "Customer Search":         "collections-modal-search pcc-eds-tabs a[data-index='2']",
        "Contact Search":          "collections-modal-search pcc-eds-tabs a[data-index='3']",
        "Contact Search FS":       "collections-modal-search pcc-eds-tabs a[data-index='4']",
    }

    # ── Form action buttons (scoped to modal) ─────────────────────
    SEARCH_BTN = "collections-modal-search button[type='submit']"
    RESET_BTN  = "collections-modal-search button[type='button']:text-is(' Reset ')"

    # ── Input fields — all addressed by aria-label scoped to modal ─
    # The same selector pattern works in every tab; the modal only
    # renders the fields relevant to the currently-active tab.
    def _input(self, aria_label: str) -> str:
        return f"collections-modal-search input[aria-label='{aria_label}']"

    # Convenient named field selectors (for direct use)
    # Account Search + Advanced Account Search + Contact Search FS
    ACCOUNT_NUMBER  = "collections-modal-search input[aria-label='Account Number']"
    PHONE_NUMBER    = "collections-modal-search input[aria-label='Phone Number']"
    SIN             = "collections-modal-search input[aria-label='SIN']"
    FIRST_NAME      = "collections-modal-search input[aria-label='First Name']"
    LAST_NAME       = "collections-modal-search input[aria-label='Last Name']"
    EMAIL           = "collections-modal-search input[aria-label='Email']"
    ADDRESS_LINE_1  = "collections-modal-search input[aria-label='Address Line 1']"
    CITY            = "collections-modal-search input[aria-label='City']"
    PROVINCE        = "collections-modal-search input[aria-label='Province']"
    POSTAL_CODE     = "collections-modal-search input[aria-label='Postal Code']"
    # Customer Search only
    CUSTOMER_NUMBER = "collections-modal-search input[aria-label='Customer Number']"
    # Contact Search (both)
    CONTACT_REFERENCE = "collections-modal-search input[aria-label='Contact Reference']"

    # Spinner inside modal
    SPINNER = "collections-modal-search collections-spinner:not(.sr-only)"

    # ──────────────────────────────────────────────────────────────
    # Wait / open
    # ──────────────────────────────────────────────────────────────

    def wait_until_open(self, timeout: int = 30_000) -> "SearchModalPage":
        """Wait for the modal to appear and the first tab to be ready."""
        log.info("Waiting for Search modal to open …")
        self.page.wait_for_selector(self.MODAL_ROOT, timeout=timeout)
        self.page.wait_for_selector(self.MODAL_DIALOG, timeout=timeout)
        self.wait_for_spinner_gone(self.SPINNER, timeout=timeout)
        self.screenshot("search_modal_opened")
        log.info("Search modal open ✓")
        return self

    def is_open(self) -> bool:
        return self.is_visible(self.MODAL_ROOT)

    def close(self) -> None:
        log.info("Closing search modal")
        self.click(self.CLOSE_BTN)
        self.wait_for_element_hidden(self.MODAL_DIALOG)

    # ──────────────────────────────────────────────────────────────
    # Tab navigation
    # ──────────────────────────────────────────────────────────────

    def click_tab(self, tab_name: str) -> None:
        """
        Click the named search tab and take a screenshot of the empty form.

        Screenshot is taken here (before filling) so the caller captures
        the clean state of the form right after the tab is selected.
        """
        selector = self.TAB_MAP.get(tab_name)
        if selector is None:
            raise ValueError(
                f"Unknown search tab '{tab_name}'. "
                f"Valid names: {list(self.TAB_MAP.keys())}"
            )
        log.info("Clicking search modal tab: '%s'", tab_name)
        self.click(selector)
        self.wait_for_spinner_gone(self.SPINNER)
        safe = tab_name.replace(" ", "_")
        self.screenshot(f"modal_tab_{safe}_before_fill")

    # ──────────────────────────────────────────────────────────────
    # Generic field filler
    # ──────────────────────────────────────────────────────────────

    def fill_field(self, aria_label: str, value: Optional[str]) -> None:
        """
        Fill one modal input field identified by its aria-label.
        If value is None or empty, the field is skipped (partial input support).
        Uses press_sequentially so Angular enables the Search button.
        """
        if not value:
            log.debug("Skipping modal field '%s' (no value provided)", aria_label)
            return
        selector = self._input(aria_label)
        log.info("Filling modal field '%s' = '%s'", aria_label, value)
        self.fill_and_trigger(selector, value)

    def screenshot_filled_form(self, tab_name: str) -> None:
        """
        Explicit screenshot of the form after all fields have been filled.
        Call this between the last fill_field() and submit_search().
        """
        safe = tab_name.replace(" ", "_")
        log.info("Screenshot of filled form — tab: '%s'", tab_name)
        self.screenshot(f"modal_tab_{safe}_after_fill")

    # ──────────────────────────────────────────────────────────────
    # Submit
    # ──────────────────────────────────────────────────────────────

    def submit_search(self) -> None:
        """
        Click the Search button inside the modal.
        Takes a screenshot immediately after clicking (before the page
        navigates) so the intermediate state is captured.
        """
        log.info("Clicking Search button in modal")
        self.screenshot("modal_after_search_click")
        self.click(self.SEARCH_BTN)

    def reset_form(self) -> None:
        """Click the Reset button to clear all fields in the active tab."""
        log.info("Clicking Reset button in modal")
        self.click(self.RESET_BTN)

    # ──────────────────────────────────────────────────────────────
    # Convenience all-in-one helpers (full input per tab)
    # ──────────────────────────────────────────────────────────────

    def fill_account_search(
        self,
        account_number: str = None,
        phone_number: str = None,
    ) -> None:
        """Fill Account Search tab — pass None for any field to skip it."""
        self.fill_field("Account Number", account_number)
        self.fill_field("Phone Number", phone_number)

    def fill_advanced_account_search(
        self,
        account_number: str = None,
        sin: str = None,
        first_name: str = None,
        last_name: str = None,
        phone_number: str = None,
        email: str = None,
        address_line_1: str = None,
        city: str = None,
        province: str = None,
        postal_code: str = None,
    ) -> None:
        """Fill Advanced Account Search tab — any field can be None (partial)."""
        self.fill_field("Account Number",  account_number)
        self.fill_field("SIN",             sin)
        self.fill_field("First Name",      first_name)
        self.fill_field("Last Name",       last_name)
        self.fill_field("Phone Number",    phone_number)
        self.fill_field("Email",           email)
        self.fill_field("Address Line 1",  address_line_1)
        self.fill_field("City",            city)
        self.fill_field("Province",        province)
        self.fill_field("Postal Code",     postal_code)

    def fill_customer_search(self, customer_number: str = None) -> None:
        """Fill Customer Search tab."""
        self.fill_field("Customer Number", customer_number)

    def fill_contact_search(
        self,
        contact_reference: str = None,
        email: str = None,
        first_name: str = None,
        last_name: str = None,
        address_line_1: str = None,
        city: str = None,
        province: str = None,
        postal_code: str = None,
    ) -> None:
        """Fill Contact Search tab — any field can be None (partial)."""
        self.fill_field("Contact Reference", contact_reference)
        self.fill_field("Email",             email)
        self.fill_field("First Name",        first_name)
        self.fill_field("Last Name",         last_name)
        self.fill_field("Address Line 1",    address_line_1)
        self.fill_field("City",              city)
        self.fill_field("Province",          province)
        self.fill_field("Postal Code",       postal_code)

    def fill_contact_search_fs(
        self,
        contact_reference: str = None,
        email: str = None,
        first_name: str = None,
        last_name: str = None,
        sin: str = None,
        address_line_1: str = None,
        city: str = None,
        province: str = None,
        postal_code: str = None,
    ) -> None:
        """Fill Contact Search FS tab — any field can be None (partial)."""
        self.fill_field("Contact Reference", contact_reference)
        self.fill_field("Email",             email)
        self.fill_field("First Name",        first_name)
        self.fill_field("Last Name",         last_name)
        self.fill_field("SIN",               sin)
        self.fill_field("Address Line 1",    address_line_1)
        self.fill_field("City",              city)
        self.fill_field("Province",          province)
        self.fill_field("Postal Code",       postal_code)

    # ──────────────────────────────────────────────────────────────
    # Assertions
    # ──────────────────────────────────────────────────────────────

    def assert_modal_open(self) -> None:
        self.assert_visible(self.MODAL_ROOT, "Search modal must be open")

    def assert_search_button_enabled(self) -> None:
        assert self.is_enabled(self.SEARCH_BTN), "Search button must be enabled"

    def assert_tab_active(self, tab_name: str) -> None:
        selector = self.TAB_MAP.get(tab_name)
        if not selector:
            raise ValueError(f"Unknown tab name: '{tab_name}'")
        locator = self.page.locator(selector)
        aria_selected = locator.get_attribute("aria-selected")
        assert aria_selected == "true", (
            f"Tab '{tab_name}' should be active (aria-selected='true'), "
            f"got: '{aria_selected}'"
        )
