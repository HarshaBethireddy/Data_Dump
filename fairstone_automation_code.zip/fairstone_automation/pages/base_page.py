"""
pages/base_page.py
──────────────────
Base Page Object Model class.
Every page class inherits from this to get:
  • typed Playwright helpers
  • built-in waits & retry
  • screenshot shortcuts
  • slow-type simulation (mimic human typing)
"""
from __future__ import annotations

import time
import random
from typing import Optional

from playwright.sync_api import Page, Locator, expect

from utils.config import Config
from utils.logger import get_logger
from utils.screenshot_helper import ScreenshotHelper
from utils.run_step_log import RunStepLog

log = get_logger(__name__)


class BasePage:
    """
    Abstract base for all page objects.

    Parameters
    ----------
    page : playwright.sync_api.Page
        The Playwright page instance injected by the fixture.
    """

    # def __init__(self, page: Page) -> None:
    #     self.page = page
    #     self.timeout = Config.TIMEOUT
    def __init__(
    self,
    page: Page,
    run_step_log: Optional[RunStepLog] = None,
) -> None:
        self.page = page
        self.timeout = Config.TIMEOUT
        self.run_step_log = run_step_log

    # ──────────────────────────────────────────────────────────────
    # Navigation helpers
    # ──────────────────────────────────────────────────────────────

    def navigate(self, url: str = "") -> None:
        target = url or Config.BASE_URL
        log.info("Navigating to: %s", target)
        self.page.goto(target, timeout=self.timeout, wait_until="domcontentloaded")

    def get_title(self) -> str:
        return self.page.title()

    def get_url(self) -> str:
        return self.page.url

    def reload(self) -> None:
        log.info("Reloading page: %s", self.page.url)
        self.page.reload(timeout=self.timeout, wait_until="domcontentloaded")

    # ──────────────────────────────────────────────────────────────
    # Element helpers
    # ──────────────────────────────────────────────────────────────

    def find(self, selector: str) -> Locator:
        return self.page.locator(selector)

    def find_by_id(self, element_id: str) -> Locator:
        return self.page.locator(f"#{element_id}")

    def find_by_label(self, label: str) -> Locator:
        return self.page.get_by_label(label)

    def find_by_role(self, role: str, **kwargs) -> Locator:
        return self.page.get_by_role(role, **kwargs)

    def find_by_text(self, text: str, exact: bool = False) -> Locator:
        return self.page.get_by_text(text, exact=exact)

    def find_by_placeholder(self, placeholder: str) -> Locator:
        return self.page.get_by_placeholder(placeholder)

    # ──────────────────────────────────────────────────────────────
    # Interaction helpers
    # ──────────────────────────────────────────────────────────────

    def click(self, selector: str, timeout: Optional[int] = None) -> None:
        log.debug("Clicking: %s", selector)
        self.page.locator(selector).click(timeout=timeout or self.timeout)

    def fill(self, selector: str, value: str) -> None:
        log.debug("Filling '%s' with: %s", selector, value)
        self.page.locator(selector).fill(value)

    def fill_and_trigger(self, selector: str, value: str) -> None:
        """
        Fill a field AND fire the keyboard/input events that Angular's
        form validators listen to.

        Plain `.fill()` sets the DOM value programmatically but some
        Angular components only re-evaluate their state when they receive
        real browser events (keydown → keypress → input → keyup).
        `press_sequentially` types character-by-character so every event
        fires naturally — this is why the Search button becomes enabled.
        """
        log.debug("fill_and_trigger '%s' with: %s", selector, value)
        locator = self.page.locator(selector)
        locator.click()
        locator.clear()
        locator.press_sequentially(value, delay=40)   # 40 ms between chars

    def slow_type(
        self,
        selector: str,
        text: str,
        min_delay: int = 80,
        max_delay: int = 180,
    ) -> None:
        """
        Mimics a human typing character-by-character with random delays.
        Ideal for login fields that have keystroke validation.
        """
        locator = self.page.locator(selector)
        locator.click()
        locator.clear()
        log.debug("Slow-typing into '%s'", selector)
        for char in text:
            locator.press(char)
            time.sleep(random.randint(min_delay, max_delay) / 1000)

    def clear(self, selector: str) -> None:
        self.page.locator(selector).clear()

    def select_option(self, selector: str, value: str) -> None:
        self.page.locator(selector).select_option(value)

    def press_key(self, selector: str, key: str) -> None:
        self.page.locator(selector).press(key)

    # ──────────────────────────────────────────────────────────────
    # Wait helpers
    # ──────────────────────────────────────────────────────────────

    def wait_for_selector(self, selector: str, timeout: Optional[int] = None) -> None:
        self.page.wait_for_selector(selector, timeout=timeout or self.timeout)

    def wait_for_url(self, url_pattern: str, timeout: Optional[int] = None) -> None:
        self.page.wait_for_url(url_pattern, timeout=timeout or self.timeout)

    def wait_for_load_state(self, state: str = "networkidle") -> None:
        self.page.wait_for_load_state(state, timeout=self.timeout)

    def wait_for_element_visible(
        self, selector: str, timeout: Optional[int] = None
    ) -> None:
        expect(self.page.locator(selector)).to_be_visible(
            timeout=timeout or self.timeout
        )

    def wait_for_element_hidden(
        self, selector: str, timeout: Optional[int] = None
    ) -> None:
        expect(self.page.locator(selector)).to_be_hidden(
            timeout=timeout or self.timeout
        )

    def wait_ms(self, ms: int) -> None:
        self.page.wait_for_timeout(ms)

    def wait_for_spinner_gone(
        self,
        spinner_selector: str = "collections-spinner:not(.sr-only)",
        timeout: Optional[int] = None,
    ) -> None:
        """
        Safely waits for a loading spinner to disappear.

        Why this exists:
          • `expect().to_be_hidden()` with a 180 s timeout will hang the whole
            test if the spinner is never rendered in the first place.
          • This helper checks visibility first; if the spinner isn't present
            it returns immediately — no waiting, no timeout error.
        """
        loc = self.page.locator(spinner_selector)
        try:
            # is_visible() is synchronous and never throws — returns False if absent
            if loc.is_visible():
                expect(loc).to_be_hidden(timeout=timeout or self.timeout)
        except Exception as exc:
            log.debug("wait_for_spinner_gone: %s", exc)

    # ──────────────────────────────────────────────────────────────
    # State queries
    # ──────────────────────────────────────────────────────────────

    def is_visible(self, selector: str) -> bool:
        return self.page.locator(selector).is_visible()

    def is_enabled(self, selector: str) -> bool:
        return self.page.locator(selector).is_enabled()

    def get_text(self, selector: str) -> str:
        return self.page.locator(selector).inner_text()

    def get_attribute(self, selector: str, attr: str) -> Optional[str]:
        return self.page.locator(selector).get_attribute(attr)

    # ──────────────────────────────────────────────────────────────
    # Screenshot shortcuts
    # ──────────────────────────────────────────────────────────────

    # def screenshot(self, name: str = "screenshot") -> None:
    #     ScreenshotHelper.capture(self.page, name)
    def screenshot(self, name: str = "screenshot") -> None:
        path = ScreenshotHelper.capture(self.page, name)

        if self.run_step_log is not None:
            self.run_step_log.record(
                label=name,
                screenshot_path=str(path) if path else None,
                failed=not bool(path),
            )

    # def screenshot_full(self, name: str = "full_page") -> None:
    #     ScreenshotHelper.capture_full_page(self.page, name)
    def screenshot_full(self, name: str = "full_page") -> None:
        path = ScreenshotHelper.capture_full_page(self.page, name)

        if self.run_step_log is not None:
            self.run_step_log.record(
                label=name,
                screenshot_path=str(path) if path else None,
                failed=not bool(path),
            )

    # ──────────────────────────────────────────────────────────────
    # Assertions (fluent, built on Playwright's expect)
    # ──────────────────────────────────────────────────────────────

    def assert_visible(self, selector: str, msg: str = "") -> None:
        expect(self.page.locator(selector)).to_be_visible(
            timeout=self.timeout
        )
        log.debug("Visible ✓ %s %s", selector, f"| {msg}" if msg else "")

    def assert_text(self, selector: str, text: str) -> None:
        expect(self.page.locator(selector)).to_have_text(text, timeout=self.timeout)

    def assert_contains_text(self, selector: str, text: str) -> None:
        expect(self.page.locator(selector)).to_contain_text(text, timeout=self.timeout)

    def assert_url_contains(self, fragment: str) -> None:
        expect(self.page).to_have_url(
            # Simple contains check via regex
            f".*{fragment}.*", timeout=self.timeout
        )

    def assert_title_contains(self, fragment: str) -> None:
        expect(self.page).to_have_title(f".*{fragment}.*", timeout=self.timeout)
