"""
pages/admin_popover_page.py
────────────────────────────
Page Object for the Admin popover that opens when the Admin nav item
is clicked in the primary header.

HTML (from Ref.txt):
    <collections-admin-popover>
      <div class="admin-menu-wrapper">
        <div id="reference-interfaces" role="link" class="popover-menu-item">
          Reference Interfaces
        </div>
        <div id="teams-and-users" role="link" class="popover-menu-item">
          Teams
        </div>
      </div>
    </collections-admin-popover>

Usage:
    home_page.click_nav_item("Admin")
    admin_popover.wait_until_open()
    admin_popover.click_item("Reference Interfaces")   # generic — pass any label
"""
from __future__ import annotations

from pages.base_page import BasePage
from utils.logger import get_logger

log = get_logger(__name__)


class AdminPopoverPage(BasePage):
    """Models the Admin popover menu."""

    # ── Selectors ─────────────────────────────────────────────────
    POPOVER_ROOT     = "collections-admin-popover"
    POPOVER_WRAPPER  = "collections-admin-popover .admin-menu-wrapper"

    # All clickable items in the popover share this class
    POPOVER_ITEM     = "collections-admin-popover div.popover-menu-item"

    # Known items (by id) — kept as constants for direct use if needed
    ITEM_REFERENCE_INTERFACES = "#reference-interfaces"
    ITEM_TEAMS                = "#teams-and-users"

    # ──────────────────────────────────────────────────────────────
    # Wait
    # ──────────────────────────────────────────────────────────────

    def wait_until_open(self, timeout: int = 10_000) -> "AdminPopoverPage":
        """Wait for the admin popover to be visible."""
        log.info("Waiting for Admin popover …")
        self.page.wait_for_selector(self.POPOVER_ROOT, timeout=timeout)
        self.wait_for_element_visible(self.POPOVER_WRAPPER, timeout=timeout)
        self.screenshot("admin_popover_open")
        return self

    def is_open(self) -> bool:
        return self.is_visible(self.POPOVER_ROOT)

    # ──────────────────────────────────────────────────────────────
    # Actions
    # ──────────────────────────────────────────────────────────────

    def click_item(self, item_name: str) -> None:
        """
        Click any item in the Admin popover by its visible text.

        The item text in HTML has surrounding whitespace, e.g.:
            ' Reference Interfaces '
        We use :has-text() (contains) so the caller can pass the
        clean name without worrying about padding.

        Valid item names: "Reference Interfaces", "Teams"
        """
        selector = (
            f"collections-admin-popover "
            f"div.popover-menu-item:has-text('{item_name}')"
        )
        log.info("Clicking Admin popover item: '%s'", item_name)
        self.wait_for_element_visible(selector)
        self.screenshot(f"admin_popover_before_click_{item_name.replace(' ', '_')}")
        self.click(selector)

    # ──────────────────────────────────────────────────────────────
    # Assertions
    # ──────────────────────────────────────────────────────────────

    def assert_popover_open(self) -> None:
        self.assert_visible(self.POPOVER_ROOT, "Admin popover must be open")

    def assert_item_visible(self, item_name: str) -> None:
        selector = f"collections-admin-popover div.popover-menu-item:has-text('{item_name}')"
        self.assert_visible(selector, f"Admin popover item '{item_name}' must be visible")
