"""
pages/account_activity_page.py
───────────────────────────────
Page Object for the Account Activity page.

URL pattern : /collections/persons/{personId}/accounts/{accountId}
Root element: collections-account#AccountPage

Reached by clicking the matching account row (identified by
ACCT_REFERENCE_SPAN) on the Customer Overview page.

Inherits
--------
BasePage        — core Playwright helpers, waits, screenshots
ActivitiesMixin — Activities sidebar tab + embedded-activity iframe
AccordionMixin  — generalized scroll-to / expand / field-value by name

Left-panel accordion names (passed as strings to AccordionMixin methods):
    "Customer Overview"
    "Payments"
    "Delinquency Information"
    "Recent Communication"
    "Exceptions"
    "Treatment"
"""
from __future__ import annotations

import time

from playwright.sync_api import Page
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

from pages.base_page import BasePage
from pages.activities_mixin import ActivitiesMixin
from pages.accordion_mixin import AccordionMixin
from utils.activity_logic import match_timeline_items, select_most_recent
from utils.activity_models import TimelineItem
from utils.logger import get_logger

log = get_logger(__name__)


class AccountActivityPage(BasePage, ActivitiesMixin, AccordionMixin):
    """Models the Collections Account Activity page."""

    # ── Page root / identity ──────────────────────────────────────
    PAGE_ROOT    = "collections-account#AccountPage"
    PAGE_HEADING = "h1.sr-only"   # "Details for account {number}"

    # ── Secondary header ─────────────────────────────────────────
    PERSON_NAME_LABEL = "collections-secondary-header span.person-name"

    # ── Tertiary navigation ───────────────────────────────────────
    TERTIARY_NAV          = "collections-tertiary-navigation"
    TAB_CUSTOMER_OVERVIEW = "collections-tertiary-navigation a[aria-label=' Customer Overview']"
    TAB_PERSON_PROFILE    = "collections-tertiary-navigation a[aria-label=' Person Profile']"
    # Active account tab — aria-label="Account Number: <number>"
    TAB_ACTIVE_ACCOUNT    = "collections-tertiary-navigation a[aria-selected='true']"
    TAB_CLOSE_ACCOUNT_BTN = (
        "collections-tertiary-navigation "
        "a[aria-selected='true'] button.close-button-tertiary-header"
    )

    # ── Right panel — Action buttons ─────────────────────────────
    BTN_ACCOUNT          = "eds-button[name='Account'] button"
    BTN_ACTIVITY_HISTORY = "eds-button[name='Activity History'] button"

    # ── Activity History timeline (revealed by BTN_ACTIVITY_HISTORY) ─
    # Real DOM: the Account Activity timeline lives at collections-activities-history.
    # Its Timeline_Items expose the same title-link / subtitle structure used on
    # the Customer Overview timeline (see ActivitiesMixin.TIMELINE_TITLE_LINK /
    # TIMELINE_SUBTITLE), so the same matching semantics apply.
    ACTIVITY_HISTORY_TIMELINE = "collections-activities-history"

    # ── Right panel — View-switcher dropdown ─────────────────────
    VIEW_SWITCHER_TRIGGER = ".dropdown-container .eds-dropdown-trigger"
    VIEW_SWITCHER_VALUE   = ".dropdown-container .eds-dropdown-value"
    VIEW_SWITCHER_OPTION  = ".dropdown-container li[role='option']"

    # ── Right panel — Calendar widget ────────────────────────────
    CALENDAR_WIDGET   = "collections-calendar-widget"
    CALENDAR_PREV_BTN = "collections-calendar button.pika-prev"
    CALENDAR_NEXT_BTN = "collections-calendar button.pika-next"

    # ── Notes widget ──────────────────────────────────────────────
    NOTES_EXPAND_BTN    = "eds-button[aria-label='Notes panel'] button"
    NOTES_TEXTAREA      = "textarea[name='collections-textarea']"
    NOTES_SAVE_AS_ALERT = "eds-checkbox[label='Save as Alert'] input[type='checkbox']"
    NOTES_SAVE_BTN      = "button.pcc-notes__submit-btn"

    # ── Page-level spinner (excludes the embedded-activity spinner) ─
    SPINNER = (
        "collections-spinner"
        ":not(.sr-only)"
        ":not(.collections-spinner__rendering--embedded)"
    )

    # ──────────────────────────────────────────────────────────────
    # Wait / page load
    # ──────────────────────────────────────────────────────────────

    def wait_until_loaded(self, timeout: int = 180_000) -> "AccountActivityPage":
        log.info("Waiting for Account Activity page …")
        self.page.wait_for_selector(self.PAGE_ROOT, timeout=timeout)
        self.page.wait_for_selector(self.TERTIARY_NAV, timeout=timeout)
        # At least one accordion heading must be present before we proceed
        self.page.wait_for_selector(self.ACCORDION_HEADING, timeout=timeout)
        self.wait_for_spinner_gone(self.SPINNER, timeout=timeout)
        self.screenshot("account_activity_loaded")
        log.info("Account Activity page loaded ✓")
        return self

    def is_loaded(self) -> bool:
        return self.is_visible(self.PAGE_ROOT)

    # ──────────────────────────────────────────────────────────────
    # Page identity
    # ──────────────────────────────────────────────────────────────

    def get_page_heading(self) -> str:
        """Returns 'Details for account {number}'."""
        return self.get_text(self.PAGE_HEADING).strip()

    def get_active_account_number(self) -> str:
        """
        Reads the active tertiary-nav tab aria-label.
        "Account Number: 6030491050833922" → "6030491050833922"
        """
        label = (
            self.page.locator(self.TAB_ACTIVE_ACCOUNT)
            .get_attribute("aria-label") or ""
        )
        return label.replace("Account Number:", "").strip()

    def get_person_name(self) -> str:
        return self.get_text(self.PERSON_NAME_LABEL).strip()

    # ──────────────────────────────────────────────────────────────
    # Generic field-value lookup (all left-panel rows)
    # ──────────────────────────────────────────────────────────────

    def get_field_value(self, label: str) -> str:
        """
        Return the value for any label across all left-panel accordions.
        Use AccordionMixin.get_field_in_accordion() when you need to
        scope to a specific accordion section.
        """
        row = self.page.locator(
            f"li.pcc-widget__row"
            f":has(.pcc-widget__cell span:text-is('{label}'))"
        )
        return row.locator(".pcc-widget__cell:last-child span").first.inner_text().strip()

    # ──────────────────────────────────────────────────────────────
    # Action buttons
    # ──────────────────────────────────────────────────────────────

    def click_account_button(self) -> None:
        log.info("Clicking Account button")
        self.click(self.BTN_ACCOUNT)

    def click_activity_history_button(self) -> None:
        log.info("Clicking Activity History button")
        self.click(self.BTN_ACTIVITY_HISTORY)
        self.wait_for_spinner_gone(self.SPINNER)
        self.screenshot("activity_history_view")

    # ──────────────────────────────────────────────────────────────
    # Activity History timeline verification (gated)
    # ──────────────────────────────────────────────────────────────

    def _scrape_timeline_items(self, root) -> list[TimelineItem]:
        """
        Scrape the Account Activity timeline title links into TimelineItem models.

        Each ``div[role='link'].title`` within ``collections-activities-history``
        is read in document order — its subtitle span (``[class*='subtitle']``)
        holds the Activity_Name and its position is the index (0 = top-most).
        Mirrors the scraping semantics used by ``ActivitiesMixin`` so the same
        :func:`match_timeline_items` / :func:`select_most_recent` logic applies.

        Parameters
        ----------
        root : Locator
            Locator scoped to the ``collections-activities-history`` timeline.

        Returns
        -------
        list[TimelineItem]
            The Timeline_Items in document order.
        """
        self.page.wait_for_selector(
            "collections-timeline-item",
            timeout=180000
        )
        title_links = root.locator(self.TIMELINE_TITLE_LINK)
        count = title_links.count()

        items: list[TimelineItem] = []
        for index in range(count):
            link = title_links.nth(index)
            subtitle = ""
            title = ""

            subtitle_loc = link.locator(self.TIMELINE_SUBTITLE)
            if subtitle_loc.count() > 0:
                subtitle = subtitle_loc.first.inner_text().strip()

            title_loc = link.locator(self.TIMELINE_TITLE_TEXT)
            if title_loc.count() > 0:
                title = title_loc.first.inner_text().strip()

            final_text = subtitle if subtitle else title

            aria_label = link.get_attribute("aria-label") or ""
            items.append(
                TimelineItem(
                    subtitle=final_text,
                    index=index,
                    title_aria_label=aria_label,
                )
            )
        return items

    def verify_activity_in_timeline(
        self, activity_name: str, timeline_timeout: int = 30_000
    ) -> TimelineItem:
        """
        Verify that ``activity_name`` appears in the Account Activity timeline,
        gating the read behind the Activity History button.

        On the Account Activity page the timeline is hidden until the Activity
        History button is clicked, so this method:

          1. Treats the timeline as not yet available — it never reads any
             Timeline_Item before the Activity History button has been clicked
             (Requirement 7.1). The ``self._activity_history_opened`` guard is
             reset on entry and only set once the timeline has been revealed.
          2. Clicks ``BTN_ACTIVITY_HISTORY`` (``eds-button[name='Activity
             History'] button``) to reveal the timeline (Requirement 7.2),
             raising a descriptive error if the button cannot be activated
             within the configured timeout (Requirement 7.6).
          3. Waits out the page spinner with the existing
             :meth:`wait_for_spinner_gone` helper (Requirement 7.3).
          4. Reads the timeline at ``collections-activities-history``
             (Requirement 7.4), raising a descriptive error if the timeline does
             not appear within ``timeline_timeout`` (Requirement 7.7).
          5. Applies the same Activity_Name matching and Most_Recent_Item
             semantics as the Customer Overview timeline (Requirement 7.5): the
             items are scraped into :class:`TimelineItem` models and delegated to
             :func:`match_timeline_items` and :func:`select_most_recent`.

        Screenshots are captured of the revealed timeline and of the matched
        Timeline_Item.

        Parameters
        ----------
        activity_name : str
            The Activity_Name to verify in the timeline.
        timeline_timeout : int
            Time in milliseconds to wait for the timeline to appear and for a
            matching Timeline_Item to be present (default 30 000 ms).

        Returns
        -------
        TimelineItem
            The Most_Recent_Item (top-most, smallest index) whose subtitle
            matches ``activity_name``.

        Raises
        ------
        RuntimeError
            If the Activity History button cannot be activated (Requirement
            7.6), if the timeline does not appear after the click (Requirement
            7.7), or if no Timeline_Item subtitle matches ``activity_name``
            within ``timeline_timeout`` (Requirements 7.5, naming the missing
            Activity_Name and the elapsed timeout).
        """
        # Requirement 7.1 — the timeline is not available until the button is
        # clicked; never read a Timeline_Item before then.
        self._activity_history_opened = False

        # Requirements 7.2 / 7.6 — reveal the timeline via the Activity History button.
        log.info(
            "[AccountActivity] Revealing Activity History timeline to verify '%s' …",
            activity_name,
        )
        try:
            self.click(self.BTN_ACTIVITY_HISTORY)
        except PlaywrightTimeoutError as exc:
            raise RuntimeError(
                f"Activity History button ('{self.BTN_ACTIVITY_HISTORY}') could "
                f"not be activated within {self.timeout} ms; the Account Activity "
                f"timeline cannot be revealed to verify activity "
                f"'{activity_name}': {exc}"
            ) from exc

        # Requirement 7.3 — wait out the page spinner (non-blocking if absent).
        self.wait_for_spinner_gone(self.SPINNER)

        # Requirements 7.4 / 7.7 — the timeline must appear after the click.
        try:
            self.page.wait_for_selector(
                self.ACTIVITY_HISTORY_TIMELINE, timeout=timeline_timeout
            )
        except PlaywrightTimeoutError as exc:
            raise RuntimeError(
                f"Account Activity timeline ('{self.ACTIVITY_HISTORY_TIMELINE}') "
                f"did not appear within {timeline_timeout} ms after clicking the "
                f"Activity History button while verifying activity "
                f"'{activity_name}': {exc}"
            ) from exc

        # The timeline is now revealed — reads are permitted (Requirement 7.1).
        self._activity_history_opened = True
        self.screenshot("activity_history_timeline")

        # Requirement 7.5 — same matching / most-recent semantics as Customer
        # Overview. Poll up to timeline_timeout for a matching Timeline_Item so
        # incrementally-rendered timelines are handled.
        root = self.page.locator(self.ACTIVITY_HISTORY_TIMELINE)
        deadline = time.monotonic() + (timeline_timeout / 1000)
        most_recent: TimelineItem | None = None
        items: list[TimelineItem] = []
        while True:
            items = self._scrape_timeline_items(root)
            most_recent = select_most_recent(
                match_timeline_items(items, activity_name)
            )
            if most_recent is not None or time.monotonic() >= deadline:
                break
            self.page.wait_for_timeout(500)

        if most_recent is None:
            raise RuntimeError(
                f"No Timeline_Item subtitle matches activity '{activity_name}' in "
                f"the Account Activity timeline within {timeline_timeout} ms. "
                f"Available subtitles: {[item.subtitle for item in items]}"
            )

        log.info(
            "[AccountActivity] Matched activity '%s' as Most_Recent_Item at "
            "index %d ✓", activity_name, most_recent.index,
        )
        self.screenshot("matched_timeline_item")
        return most_recent

    # ──────────────────────────────────────────────────────────────
    # View-switcher dropdown
    # ──────────────────────────────────────────────────────────────

    def get_current_view(self) -> str:
        return self.get_text(self.VIEW_SWITCHER_VALUE).strip()

    def switch_view(self, option_text: str) -> None:
        """
        Valid options: Calendar | Account Customers | Account Securities |
        Account Details | Customer Details | Account Decisioning |
        Account Exceptions | Delinquency Bucket Details | Arrangements |
        Scrub Details | Plan Details | Memo History | Files
        """
        log.info("Switching view to: %s", option_text)
        self.click(self.VIEW_SWITCHER_TRIGGER)
        self.page.locator(
            f".dropdown-container li[role='option']:text-is('{option_text}')"
        ).click()
        self.wait_for_spinner_gone(self.SPINNER)
        self.screenshot(f"view_{option_text.replace(' ', '_')}")

    def get_all_view_options(self) -> list[str]:
        self.click(self.VIEW_SWITCHER_TRIGGER)
        options = self.page.locator(self.VIEW_SWITCHER_OPTION)
        texts = [options.nth(i).inner_text().strip() for i in range(options.count())]
        self.page.keyboard.press("Escape")
        return texts

    # ──────────────────────────────────────────────────────────────
    # Calendar widget
    # ──────────────────────────────────────────────────────────────

    def is_calendar_visible(self) -> bool:
        return self.is_visible(self.CALENDAR_WIDGET)

    def click_calendar_prev(self) -> None:
        self.click(self.CALENDAR_PREV_BTN)

    def click_calendar_next(self) -> None:
        self.click(self.CALENDAR_NEXT_BTN)

    def click_calendar_day(self, day: int, month_index: int = 0) -> None:
        self.page.locator("collections-month").nth(month_index).locator(
            f"button.pika-button.pika-day[data-pika-day='{day}']"
        ).click()

    # ──────────────────────────────────────────────────────────────
    # Tertiary nav
    # ──────────────────────────────────────────────────────────────

    def click_customer_overview_tab(self) -> None:
        log.info("Clicking Customer Overview tertiary tab")
        self.click(self.TAB_CUSTOMER_OVERVIEW)

    def click_person_profile_tab(self) -> None:
        self.click(self.TAB_PERSON_PROFILE)

    def close_account_tab(self) -> None:
        log.info("Closing active account tab")
        self.click(self.TAB_CLOSE_ACCOUNT_BTN)

    # ──────────────────────────────────────────────────────────────
    # Notes widget
    # ──────────────────────────────────────────────────────────────

    def expand_notes_panel(self) -> None:
        self.click(self.NOTES_EXPAND_BTN)
        self.wait_for_element_visible(self.NOTES_TEXTAREA)

    def type_note(self, text: str) -> None:
        self.fill_and_trigger(self.NOTES_TEXTAREA, text)

    def save_note(self) -> None:
        self.click(self.NOTES_SAVE_BTN)

    # ──────────────────────────────────────────────────────────────
    # Assertions
    # ──────────────────────────────────────────────────────────────

    def assert_on_account_activity(self) -> None:
        self.assert_visible(self.PAGE_ROOT, "Account Activity page root must be visible")

    def assert_account_number_in_tab(self, expected: str) -> None:
        actual = self.get_active_account_number()
        assert expected in actual, (
            f"Expected account number '{expected}' in tab, got: '{actual}'"
        )

    def assert_heading_contains_account(self, account_number: str) -> None:
        heading = self.get_page_heading()
        assert account_number in heading, (
            f"Expected '{account_number}' in heading, got: '{heading}'"
        )

    def assert_action_buttons_visible(self) -> None:
        self.assert_visible(self.BTN_ACCOUNT, "Account button must be visible")
        self.assert_visible(self.BTN_ACTIVITY_HISTORY, "Activity History button must be visible")

    def assert_calendar_visible(self) -> None:
        self.assert_visible(self.CALENDAR_WIDGET, "Calendar widget must be visible")

    def assert_tertiary_account_tab_active(self) -> None:
        self.assert_visible(self.TAB_ACTIVE_ACCOUNT, "An active account tab must exist")
