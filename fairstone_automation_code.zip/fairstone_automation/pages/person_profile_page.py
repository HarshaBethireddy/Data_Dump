"""
pages/person_profile_page.py
─────────────────────────────
Page Object for the Person Profile page.

URL pattern : /collections/persons/{personId}/profile
Root element: collections-person-profile#PersonProfilePage

Reached via:
  Contact Search      → Customer Overview page, Person Profile tertiary tab active
  Contact Search FS   → Customer Overview page, Person Profile tertiary tab active

Layout (from live HTML):
  ┌─────────────────────────────────────────────────────────────────┐
  │  Secondary header  — person-name tab (active)                   │
  │  Tertiary nav      — Customer Overview | Person Profile(active)  │
  ├───────────────────────────┬─────────────────────────────────────┤
  │  LEFT  (collections-main- │  RIGHT (collections-main-right)     │
  │  left)                    │                                     │
  │  collections-contact-     │  collections-contact-details        │
  │  summary                  │    Header: "Contact Details"        │
  │    h2: person name        │    Add button                       │
  │    Rows: Title, First     │    Accordion panels:                │
  │    Name, Middle Name,     │      • Contact Address  ← expand   │
  │    Last Name              │      • Contact Email    ← expand   │
  │                           │      • Contact Phone    ← expand   │
  │  collections-card-type-1  │                                     │
  │    Customer Reference     │                                     │
  ├───────────────────────────┴─────────────────────────────────────┤
  │  STICKY BOTTOM — Notes widget                                   │
  └─────────────────────────────────────────────────────────────────┘

NOTE: The Contact Details accordions here use a different HTML structure
      from the Account Activity page accordions:
        collections-accordion-panel:has(h3:text('...')) a.collections-accordion-caret
      They do NOT use collections-accordion-type-1-widget, so AccordionMixin
      does NOT apply to this page.
"""
from __future__ import annotations

from playwright.sync_api import Page

from pages.base_page import BasePage
from utils.logger import get_logger

log = get_logger(__name__)


class PersonProfilePage(BasePage):
    """Models the Collections Person Profile page."""

    # ── Page root / identity ──────────────────────────────────────
    PAGE_ROOT    = "collections-person-profile#PersonProfilePage"
    PAGE_HEADING = "h1.sr-only"   # "  profile"

    # ── Secondary header ─────────────────────────────────────────
    PERSON_NAME_LABEL = "collections-secondary-header span.person-name"

    # ── Tertiary navigation ───────────────────────────────────────
    TERTIARY_NAV              = "collections-tertiary-navigation"
    TAB_CUSTOMER_OVERVIEW     = "collections-tertiary-navigation a[aria-label=' Customer Overview']"
    TAB_PERSON_PROFILE_ACTIVE = "collections-tertiary-navigation a[aria-label=' Person Profile'][aria-selected='true']"

    # ── Left panel — Contact Summary ──────────────────────────────
    CONTACT_SUMMARY    = "collections-contact-summary"
    PERSON_NAME_HEADING = "collections-contact-summary h2.pcc-heading__bold"
    # Edit button in the contact summary header
    CONTACT_EDIT_BTN   = "collections-contact-summary button[motif='tertiary']:has(eds-icon)"

    # ── Left panel — Card Type 1 (Customer Reference) ─────────────
    CARD_TYPE_1 = "collections-card-type-1"
    # Warning header text: "Warning: If you edit anything on this page..."
    CARD_WARNING_HEADER = "collections-card-type-1 h2.pcc-widget__header-card"

    # ── Right panel — Contact Details ────────────────────────────
    CONTACT_DETAILS_SECTION  = "collections-contact-details"
    CONTACT_DETAILS_HEADER   = "collections-contact-details h2.collections-contact-details__header__title"
    CONTACT_DETAILS_ADD_BTN  = "collections-contact-details eds-button[motif='basic'] button"

    # Contact accordion panels (different structure from Account Activity accordions)
    # Each panel identified by the h3 text inside accordion-header-content
    CONTACT_ACCORDION_PANEL  = "collections-contact-details collections-accordion-panel"
    CONTACT_ACCORDION_CARET  = "a.collections-accordion-caret"   # relative to panel

    # The three contact accordion names (exactly as rendered in h3)
    CONTACT_ADDRESS = "Contact Address"
    CONTACT_EMAIL   = "Contact Email"
    CONTACT_PHONE   = "Contact Phone"

    # ── Notes widget ──────────────────────────────────────────────
    NOTES_EXPAND_BTN    = "eds-button[aria-label='Notes panel'] button"
    NOTES_TEXTAREA      = "textarea[name='collections-textarea']"
    NOTES_SAVE_BTN      = "button.pcc-notes__submit-btn"

    # ── Spinner ───────────────────────────────────────────────────
    SPINNER = "collections-spinner:not(.sr-only):not(.collections-spinner__rendering--embedded)"

    # ──────────────────────────────────────────────────────────────
    # Wait / page load
    # ──────────────────────────────────────────────────────────────

    def wait_until_loaded(self, timeout: int = 180_000) -> "PersonProfilePage":
        """
        Wait for the Person Profile page to be fully rendered.
        Anchors on the page root and the Contact Details section.
        """
        log.info("Waiting for Person Profile page …")
        self.page.wait_for_selector(self.PAGE_ROOT, timeout=timeout)
        self.page.wait_for_selector(self.TERTIARY_NAV, timeout=timeout)
        self.page.wait_for_selector(self.CONTACT_DETAILS_SECTION, timeout=timeout)
        self.wait_for_spinner_gone(self.SPINNER, timeout=timeout)
        self.screenshot("person_profile_loaded")
        log.info("Person Profile page loaded ✓")
        return self

    def is_loaded(self) -> bool:
        return self.is_visible(self.PAGE_ROOT)

    # ──────────────────────────────────────────────────────────────
    # Person identity
    # ──────────────────────────────────────────────────────────────

    def get_person_name(self) -> str:
        """Person name from the secondary header tab."""
        return self.get_text(self.PERSON_NAME_LABEL).strip()

    def get_person_name_heading(self) -> str:
        """Person name from the Contact Summary card heading."""
        return self.get_text(self.PERSON_NAME_HEADING).strip()

    # ──────────────────────────────────────────────────────────────
    # Generic field-value lookup (left panel rows)
    # ──────────────────────────────────────────────────────────────

    def get_field_value(self, label: str) -> str:
        """
        Return the value for any label in a pcc-widget__row on this page.
        E.g.  get_field_value("First Name")
              get_field_value("Customer Reference")
        """
        row = self.page.locator(
            f"li.pcc-widget__row"
            f":has(.pcc-widget__cell span:text-is('{label}'))"
        )
        return row.locator(".pcc-widget__cell:last-child span").first.inner_text().strip()

    # ──────────────────────────────────────────────────────────────
    # Contact Detail accordion helpers
    # ──────────────────────────────────────────────────────────────

    def _get_contact_panel(self, name: str):
        """
        Return the Playwright Locator for the contact accordion panel
        whose h3 text matches `name`.

        The contact accordion structure is:
          collections-accordion-panel
            div.accordion-header
              a.collections-accordion-caret  (aria-expanded="false"/"true")
              div.accordion-header-content
                h3 → " Contact Address " / " Contact Email " / " Contact Phone "
            div.accordion-body
        """
        name = name.strip()
        return self.page.locator(
            "collections-contact-details collections-accordion-panel"
        ).filter(has=self.page.locator("h3", has_text=name)).first

    def is_contact_panel_expanded(self, name: str) -> bool:
        """Returns True if the contact accordion panel is currently expanded."""
        name = name.strip()
        panel = self._get_contact_panel(name)
        panel.wait_for(state="visible")

        caret = panel.locator("a.collections-accordion-caret").first
        caret.wait_for(state="visible")

        return caret.first.get_attribute("aria-expanded") == "true"


    def expand_contact_detail(self, name: str) -> None:
        """
        Expand the named Contact Detail accordion panel if it is collapsed,
        then take a screenshot showing the expanded state.

        name must be one of:
            " Contact Address "
            " Contact Email "
            " Contact Phone "
        """
        
        name = name.strip()
        panel = self._get_contact_panel(name)
        panel.wait_for(state="visible")

        caret = panel.locator("a.collections-accordion-caret")

        caret.wait_for(state="visible")  

        expanded = caret.first.get_attribute("aria-expanded")

        if expanded == "false":
            caret.first.click()

        self.screenshot(f"contact_detail_{name}_expanded")
        log.info("Contact panel '%s' expanded and screenshotted ✓", name.strip())

    def expand_all_contact_details(self) -> None:
        """
        Expand all three Contact Detail accordion panels in order:
          1. Contact Address
          2. Contact Email
          3. Contact Phone
        A screenshot is taken after each expansion.
        """
        log.info("Expanding all Contact Detail panels …")
        for name in (self.CONTACT_ADDRESS, self.CONTACT_EMAIL, self.CONTACT_PHONE):
            self.expand_contact_detail(name)
        self.screenshot("all_contact_details_expanded")
        log.info("All Contact Detail panels expanded ✓")

    def collapse_contact_detail(self, name: str) -> None:
        """Collapse the named Contact Detail accordion panel if expanded."""
        panel = self._get_contact_panel(name)
        caret = panel.locator(self.CONTACT_ACCORDION_CARET)
        if caret.get_attribute("aria-expanded") == "true":
            log.info("Collapsing contact detail panel: '%s'", name.strip())
            caret.click()

    # ──────────────────────────────────────────────────────────────
    # Tertiary nav
    # ──────────────────────────────────────────────────────────────

    def click_customer_overview_tab(self) -> None:
        log.info("Clicking Customer Overview tertiary tab from Person Profile")
        self.click(self.TAB_CUSTOMER_OVERVIEW)

    # ──────────────────────────────────────────────────────────────
    # Notes widget
    # ──────────────────────────────────────────────────────────────

    def expand_notes_panel(self) -> None:
        self.click(self.NOTES_EXPAND_BTN)
        self.wait_for_element_visible(self.NOTES_TEXTAREA)

    def type_note(self, text: str) -> None:
        self.fill_and_trigger(self.NOTES_TEXTAREA, text)

    def save_note(self) -> None:
        self.click(self.NOTES_SAVE_BTN)

    # ──────────────────────────────────────────────────────────────
    # Assertions
    # ──────────────────────────────────────────────────────────────

    def assert_on_person_profile(self) -> None:
        self.assert_visible(self.PAGE_ROOT, "Person Profile page root must be visible")

    def assert_person_profile_tab_active(self) -> None:
        self.assert_visible(
            self.TAB_PERSON_PROFILE_ACTIVE,
            "Person Profile tertiary tab must be active (aria-selected='true')",
        )

    def assert_contact_details_visible(self) -> None:
        self.assert_visible(self.CONTACT_DETAILS_SECTION, "Contact Details section must be visible")

    def assert_contact_panel_visible(self, name: str) -> None:
        from playwright.sync_api import expect
        expect(self._get_contact_panel(name)).to_be_visible(timeout=self.timeout)

    def assert_all_contact_panels_visible(self) -> None:
        for name in (self.CONTACT_ADDRESS, self.CONTACT_EMAIL, self.CONTACT_PHONE):
            self.assert_contact_panel_visible(name)

    def assert_contact_panel_expanded(self, name: str) -> None:
        assert self.is_contact_panel_expanded(name), (
            f"Contact panel '{name.strip()}' should be expanded"
        )
