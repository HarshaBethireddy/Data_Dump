"""
pages/home_page.py
──────────────────
Page Object for the Collections home/dashboard page.
Covers: header nav, notifications badge, user menu, language picker,
        logout, and the main search form.
"""
from __future__ import annotations

from playwright.sync_api import Page

from pages.base_page import BasePage
from utils.logger import get_logger

log = get_logger(__name__)


class HomePage(BasePage):
    """Models the Collections home page after successful login."""

    # ── Header nav ───────────────────────────────────────────────
    APP_NAME = "#application-name"                   # "Collections"
    NAV_SEARCH = "a[aria-label='Search']"
    NAV_LOAD_NEXT = "a[aria-label='Load Next']"
    NAV_VIEW_CASELISTS = "a[aria-label='View Caselists']"
    NAV_ADMIN = "a[aria-label='Admin']"

    # ── Notifications ────────────────────────────────────────────
    NOTIFICATION_ICON = "a[aria-label='Pending cases']"
    NOTIFICATION_COUNT = ".notification-number"
    NOTIFICATION_POPOVER = ".notifications .popover"

    # ── User menu ────────────────────────────────────────────────
    USER_MENU_TRIGGER = ".user-menu > a[role='menuitem']"
    LOGOUT_BUTTON = ".logout"
    LANG_ENGLISH = "input[name='language'][value='English']"
    LANG_FRENCH = "input[name='language'][value='Français']"

    # ── Search form (main) ────────────────────────────────────────
    # aria-label selectors match the actual rendered inputs (not the id
    # on the outer wrapper which is on a different element).
    ACCOUNT_NUMBER_INPUT = "input[aria-label='Account Number']"
    PHONE_NUMBER_INPUT   = "input[aria-label='Phone Number']"
    # The section[role='search'] prefix was too narrow after Angular
    # re-renders the dynamic form; target the button directly.
    SEARCH_BUTTON = "button[type='submit']"

    # ──────────────────────────────────────────────────────────────
    # State
    # ──────────────────────────────────────────────────────────────

    def is_loaded(self) -> bool:
        """Returns True once the home page nav is visible."""
        return self.is_visible(self.APP_NAME)

    def wait_until_loaded(self, timeout: int = 60_000) -> "HomePage":
        log.info("Waiting for Collections home page to load …")
        self.wait_for_element_visible(self.APP_NAME, timeout=timeout)
        self.screenshot("home_page_loaded")
        return self

    def get_app_name(self) -> str:
        return self.get_text(self.APP_NAME)

    def get_notification_count(self) -> str:
        return self.get_text(self.NOTIFICATION_COUNT)

    # ──────────────────────────────────────────────────────────────
    # Navigation
    # ──────────────────────────────────────────────────────────────

    def click_search_nav(self) -> None:
        log.info("Clicking Search nav item")
        self.click(self.NAV_SEARCH)

    # ── Primary header navigation ────────────────────────────────
    # All nav items share the pattern:
    #   nav[aria-label='headerData'] a.menu-item-main[aria-label='{label}']
    # Known labels from HTML: Search, Load Next, View Caselists, Admin,
    #   Pending cases, and the user-initials item (e.g. 'SJ')

    def click_nav_item(self, label: str) -> None:
        """
        Click any primary navigation item by its aria-label.
        This single method replaces all the individual nav-click methods
        — just pass the label text shown in the HTML.

        Examples:
            home_page.click_nav_item("Search")
            home_page.click_nav_item("Admin")
            home_page.click_nav_item("View Caselists")
            home_page.click_nav_item("Load Next")
        """
        selector = (
            f"nav[aria-label='headerData'] "
            f"a.menu-item-main[aria-label='{label}']"
        )
        log.info("Clicking nav item: '%s'", label)
        self.click(selector)

    # Keep specific helpers as thin aliases for backward-compat
    def click_search_nav_button(self) -> None:
        self.click_nav_item("Search")

    def click_load_next(self) -> None:
        log.info("Clicking Load Next")
        self.click(self.NAV_LOAD_NEXT)

    def click_view_caselists(self) -> None:
        log.info("Clicking View Caselists")
        self.click(self.NAV_VIEW_CASELISTS)

    def click_admin(self) -> None:
        log.info("Clicking Admin")
        self.click(self.NAV_ADMIN)

    # ──────────────────────────────────────────────────────────────
    # User menu
    # ──────────────────────────────────────────────────────────────

    def open_user_menu(self) -> "HomePage":
        log.info("Opening user menu")
        self.click(self.USER_MENU_TRIGGER)
        return self

    def logout(self) -> None:
        log.info("Logging out")
        self.open_user_menu()
        self.wait_for_element_visible(self.LOGOUT_BUTTON)
        self.screenshot("before_logout")
        self.click(self.LOGOUT_BUTTON)

    def switch_language(self, language: str) -> None:
        """Switch UI language. Accepts 'English' or 'Français'."""
        self.open_user_menu()
        selector = self.LANG_ENGLISH if language == "English" else self.LANG_FRENCH
        self.click(selector)
        log.info("Language switched to: %s", language)

    # ──────────────────────────────────────────────────────────────
    # Inline search form
    # ──────────────────────────────────────────────────────────────

    def enter_account_number(self, account: str) -> "HomePage":
        log.info("Entering account number: %s", account)
        # press_sequentially fires keydown/keypress/input/keyup per char —
        # required so Angular's form validator re-evaluates and enables Search.
        self.fill_and_trigger(self.ACCOUNT_NUMBER_INPUT, account)
        return self

    def enter_phone_number(self, phone: str) -> "HomePage":
        log.info("Entering phone number: %s", phone)
        self.fill_and_trigger(self.PHONE_NUMBER_INPUT, phone)
        return self

    def click_search(self) -> None:
        log.info("Clicking Search button")
        self.screenshot("before_search")
        self.click(self.SEARCH_BUTTON)

    def search_by_account(self, account_number: str) -> None:
        self.enter_account_number(account_number).click_search()

    def search_by_phone(self, phone_number: str) -> None:
        self.enter_phone_number(phone_number).click_search()

    def is_search_button_enabled(self) -> bool:
        return self.is_enabled(self.SEARCH_BUTTON)

    # ──────────────────────────────────────────────────────────────
    # Assertions
    # ──────────────────────────────────────────────────────────────

    def assert_home_page_loaded(self) -> None:
        self.assert_visible(self.APP_NAME, "Collections app name should be visible")

    def assert_nav_items_visible(self) -> None:
        for sel in (
            self.NAV_SEARCH,
            self.NAV_LOAD_NEXT,
            self.NAV_VIEW_CASELISTS,
        ):
            self.assert_visible(sel)
