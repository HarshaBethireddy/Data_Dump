"""
pages/login_page.py
───────────────────
Page Object for the LDAP login screen.
HTML reference (from FS.txt):
  #idToken1  — Username input
  #idToken2  — Password input
  #loginButton_0 — Submit button
"""
from __future__ import annotations

from playwright.sync_api import Page, expect

from pages.base_page import BasePage
from utils.config import Config
from utils.logger import get_logger

log = get_logger(__name__)


class LoginPage(BasePage):
    """Models the Collections LDAP login page."""

    # ── Selectors ────────────────────────────────────────────────
    USERNAME_INPUT = "#idToken1"
    PASSWORD_INPUT = "#idToken2"
    LOGIN_BUTTON = "#loginButton_0"
    FORM_SELECTOR = "form.form.login"
    ERROR_MESSAGE = ".alert, .error-message, [role='alert']"

    def __init__(self, page: Page) -> None:
        super().__init__(page)

    # ──────────────────────────────────────────────────────────────
    # Navigation
    # ──────────────────────────────────────────────────────────────

    def open(self) -> "LoginPage":
        """Open the application root URL and wait for the login form."""
        log.info("Opening Collections login page at %s", Config.BASE_URL)
        self.navigate(Config.BASE_URL)
        self.wait_for_element_visible(self.FORM_SELECTOR, timeout=60_000)
        self.screenshot("login_page_loaded")
        return self

    # ──────────────────────────────────────────────────────────────
    # Actions
    # ──────────────────────────────────────────────────────────────

    def enter_username(self, username: str, slow: bool = True) -> "LoginPage":
        log.info("Entering username: %s", username)
        if slow:
            self.slow_type(self.USERNAME_INPUT, username)
        else:
            self.fill(self.USERNAME_INPUT, username)
        return self

    def enter_password(self, password: str, slow: bool = True) -> "LoginPage":
        log.info("Entering password: [HIDDEN]")
        if slow:
            self.slow_type(self.PASSWORD_INPUT, password)
        else:
            self.fill(self.PASSWORD_INPUT, password)
        return self

    def click_login(self) -> None:
        log.info("Clicking Login button")
        self.screenshot("before_login_click")
        self.click(self.LOGIN_BUTTON)

    def login(
        self,
        username: str = "",
        password: str = "",
        slow_type: bool = True,
    ) -> None:
        """
        Complete login flow.

        Parameters
        ----------
        username : str  — defaults to Config.USERNAME
        password : str  — defaults to Config.PASSWORD
        slow_type : bool — mimic human typing (True by default)
        """
        usr = username or Config.USERNAME
        pwd = password or Config.PASSWORD
        self.enter_username(usr, slow=slow_type).enter_password(pwd, slow=slow_type)
        self.click_login()

    # ──────────────────────────────────────────────────────────────
    # State queries
    # ──────────────────────────────────────────────────────────────

    def is_login_form_displayed(self) -> bool:
        return self.is_visible(self.FORM_SELECTOR)

    def get_error_message(self) -> str:
        if self.is_visible(self.ERROR_MESSAGE):
            return self.get_text(self.ERROR_MESSAGE)
        return ""

    def is_login_button_enabled(self) -> bool:
        return self.is_enabled(self.LOGIN_BUTTON)

    # ──────────────────────────────────────────────────────────────
    # Assertions
    # ──────────────────────────────────────────────────────────────

    def assert_login_form_visible(self) -> None:
        self.assert_visible(self.FORM_SELECTOR, "Login form should be visible")

    def assert_error_visible(self) -> None:
        self.assert_visible(self.ERROR_MESSAGE, "Login error should be visible")
