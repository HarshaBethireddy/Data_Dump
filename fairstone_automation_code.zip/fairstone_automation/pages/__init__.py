"""Page Object Models for the Collections automation framework."""
from pages.activities_mixin import ActivitiesMixin
from pages.accordion_mixin import AccordionMixin
from pages.base_page import BasePage
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.search_page import SearchPage
from pages.search_modal_page import SearchModalPage
from pages.customer_overview_page import CustomerOverviewPage
from pages.account_activity_page import AccountActivityPage
from pages.person_profile_page import PersonProfilePage
from pages.admin_popover_page import AdminPopoverPage
from pages.reference_interfaces_page import ReferenceInterfacesPage

__all__ = [
    "ActivitiesMixin",
    "AccordionMixin",
    "BasePage",
    "LoginPage",
    "HomePage",
    "SearchPage",
    "SearchModalPage",
    "CustomerOverviewPage",
    "AccountActivityPage",
    "PersonProfilePage",
    "AdminPopoverPage",
    "ReferenceInterfacesPage",
]
