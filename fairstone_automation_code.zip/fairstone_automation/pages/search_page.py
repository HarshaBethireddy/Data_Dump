"""
pages/search_page.py
────────────────────
Page Object for the Collections Search Results page.
Covers:
  • "No matches found" alert
  • Results data-table (AG-Grid)
  • Pagination (pcc-eds-pager)
  • Dynamic search form (collections-dynamic-form)
"""
from __future__ import annotations

from playwright.sync_api import Page

from pages.base_page import BasePage
from utils.logger import get_logger

log = get_logger(__name__)


class SearchPage(BasePage):
    """Models the search results / master-detail screen."""

    # ── Alert ─────────────────────────────────────────────────────
    ALERT_CONTAINER = "collections-alert"
    ALERT_TITLE = "collections-heading h3"
    ALERT_BODY_TEXT = "collections-alert p"
    ALERT_CLOSE_BUTTON = "eds-icon[icon='close']"

    # ── Results grid (AG-Grid) ─────────────────────────────────────
    GRID_ROOT = "ag-grid-angular"
    GRID_ROWS = ".ag-center-cols-container [role='row']"
    GRID_HEADER_CELL = ".ag-header-cell"
    GRID_LOADING_OVERLAY = ".ag-overlay:not(.ag-hidden)"

    # ── Pagination ────────────────────────────────────────────────
    PAGER_CONTAINER = "pcc-eds-pager[class='pager']"
    PAGER_ACTIVE_PAGE = "li.active a"
    # PAGER_NEXT = "li.next a"
    # PAGER_PREV = "li.prev a"
    PAGER_FIRST = "li.prev a:has(eds-icon[icon='first_page'])"
    PAGER_PREV = "li.prev a:has(eds-icon[icon='chevron_left'])"
    PAGER_NEXT = "li.next a:has(eds-icon[icon='chevron_right'])"
    PAGER_LAST = "li.next a:has(eds-icon[icon='last_page'])"
    PAGER_STATS = ".stats[aria-label='Pagination information: ']"
    ROWS_PER_PAGE_DROPDOWN = ".rows-per-page-dd eds-dropdown[role='application']"

    # ── Dynamic search form ───────────────────────────────────────
    ACCOUNT_NUMBER_DYNAMIC = "input[placeholder='Account Number']"
    SPINNER = "collections-spinner"

    # ──────────────────────────────────────────────────────────────
    # Wait helpers
    # ──────────────────────────────────────────────────────────────

    def wait_for_results(self, timeout: int = 60_000) -> "SearchPage":
        """Wait until either results or a no-match alert is visible."""
        log.info("Waiting for search results …")
        self.page.wait_for_selector(
            f"{self.GRID_ROOT}, {self.ALERT_CONTAINER}",
            timeout=timeout,
        )
        # Wait for spinner to disappear
        self.wait_for_element_hidden(f"{self.SPINNER}:not(.sr-only)", timeout=timeout)
        self.screenshot("search_results")
        return self

    def wait_for_grid_loaded(self, timeout: int = 60_000) -> "SearchPage":
        """Wait until AG-Grid finishes loading (overlay disappears)."""
        self.wait_for_element_hidden(self.GRID_LOADING_OVERLAY, timeout=timeout)
        return self

    # ──────────────────────────────────────────────────────────────
    # Alert / no-match
    # ──────────────────────────────────────────────────────────────

    def is_no_match_alert_shown(self) -> bool:
        return self.is_visible(self.ALERT_CONTAINER)

    def get_alert_title(self) -> str:
        if self.is_visible(self.ALERT_TITLE):
            return self.get_text(self.ALERT_TITLE).strip()
        return ""

    def get_alert_body(self) -> str:
        if self.is_visible(self.ALERT_BODY_TEXT):
            return self.get_text(self.ALERT_BODY_TEXT).strip()
        return ""

    def close_alert(self) -> None:
        if self.is_visible(self.ALERT_CLOSE_BUTTON):
            self.click(self.ALERT_CLOSE_BUTTON)
            log.info("Alert dismissed")

    # ──────────────────────────────────────────────────────────────
    # Grid / results
    # ──────────────────────────────────────────────────────────────

    def get_row_count(self) -> int:
        rows = self.page.locator(self.GRID_ROWS)
        count = rows.count()
        log.debug("Grid row count: %d", count)
        return count

    def has_results(self) -> bool:
        return self.get_row_count() > 0

    def get_column_headers(self) -> list[str]:
        headers = self.page.locator(self.GRID_HEADER_CELL)
        return [headers.nth(i).inner_text().strip() for i in range(headers.count())]

    def click_row(self, index: int = 0) -> None:
        log.info("Clicking grid row %d", index)
        self.page.locator(self.GRID_ROWS).nth(index).click()

    # ──────────────────────────────────────────────────────────────
    # Pagination
    # ──────────────────────────────────────────────────────────────

    def get_pagination_stats(self) -> str:
        """Returns text like '1-10 of 6348'."""
        if self.is_visible(self.PAGER_STATS):
            return self.get_text(self.PAGER_STATS).strip()
        return ""

    def get_active_page(self) -> str:
        return self.get_text(self.PAGER_ACTIVE_PAGE).strip()

    def click_next_page(self) -> None:
        log.info("Clicking Next page")
        self.click(self.PAGER_NEXT)
        self.wait_for_grid_loaded()
        self.page.wait_for_timeout(15000)
        self.screenshot("next_page")

    def click_prev_page(self) -> None:
        log.info("Clicking Previous page")
        self.click(self.PAGER_PREV)
        self.wait_for_grid_loaded()
        self.page.wait_for_timeout(15000)
        self.screenshot("prev_page")

    def set_rows_per_page(self, value: str) -> None:
        """value: '10' | '20' | '30'"""
        log.info("Setting rows per page to: %s", value)
        trigger = self.page.locator(f"{self.ROWS_PER_PAGE_DROPDOWN} button")
        trigger.click()
        option = self.page.locator(f"li[data-value='{value}']")
        option.click()
        self.wait_for_grid_loaded()

    # ──────────────────────────────────────────────────────────────
    # Assertions
    # ──────────────────────────────────────────────────────────────

    def assert_no_match_alert(self) -> None:
        self.assert_visible(self.ALERT_CONTAINER, "No-match alert should be visible")
        self.assert_contains_text(self.ALERT_TITLE, "No matches found")

    def assert_results_present(self) -> None:
        assert self.has_results(), "Expected search results but grid is empty"

    def assert_pagination_stats_contains(self, fragment: str) -> None:
        stats = self.get_pagination_stats()
        assert fragment in stats, (
            f"Pagination stats '{stats}' does not contain '{fragment}'"
        )
