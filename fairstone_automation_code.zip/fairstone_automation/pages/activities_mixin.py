"""
pages/activities_mixin.py
─────────────────────────
Mixin that provides the Activities sidebar panel and embedded-activity
iframe interaction to any page that has it.

Both CustomerOverviewPage and AccountActivityPage have identical
Activities panels in their right sidebar.  Rather than copy-pasting
the code, both pages inherit this mixin.

Usage
-----
    class MyPage(BasePage, ActivitiesMixin):
        ...

BasePage must come first in the MRO so that self.page, self.click(),
self.wait_for_element_visible(), self.wait_for_spinner_gone(), etc.
resolve from there.
"""
from __future__ import annotations

from playwright.sync_api import FrameLocator
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError

from utils.activity_logic import (
    build_fill_plan,
    detect_variant_from_shape,
    filter_enabled_tabs,
    match_field_value,
    match_select_option,
    match_timeline_items,
    select_most_recent,
)
from utils.activity_models import (
    ActivityField,
    DetailTab,
    FieldKind,
    IframeVariant,
    SelectOption,
    TimelineItem,
)
from utils.logger import get_logger
from utils.run_step_log import compose_label
from utils.screenshot_helper import ScreenshotHelper

log = get_logger(__name__)


class ActivitiesMixin:
    """
    Shared mixin — Activities sidebar and embedded-activity iframe.

    Selectors
    ---------
    Activities tab
        pcc-eds-tabs a[data-index='1']

    Activity list items
        Parent WITH children  — role='menu',     class has-children (caret shown)
        Parent WITHOUT children — role='menuitem', no has-children   (direct click)
        Child items — inside .menu-item-children after parent expanded

    Embedded activity iframe
        collections-embedded-activity  → spinner → iframe → body.popup
    """

    # ── Sidebar tabs ──────────────────────────────────────────────
    SIDEBAR_TAB_ALERTS     = "pcc-eds-tabs a[data-index='0']"
    SIDEBAR_TAB_ACTIVITIES = "pcc-eds-tabs a[data-index='1']"

    # ── Activity list ─────────────────────────────────────────────
    ACTIVITY_LIST_CONTAINER    = "collections-activity-list"
    ACTIVITY_PARENT_EXPANDABLE = (
        "collections-activity-list "
        "collections-menu-item.has-children > a.menu-item-main[role='menu']"
    )
    ACTIVITY_PARENT_DIRECT = (
        "collections-activity-list "
        "collections-menu-item.pcc-tabs__item:not(.has-children) "
        "> a.menu-item-main[role='menuitem']"
    )
    ACTIVITY_CHILD_ITEM = (
        "collections-activity-list "
        ".menu-item-children collections-menu-item a.menu-item-main[role='menuitem']"
    )

    # ── Embedded activity / iframe ────────────────────────────────
    EMBEDDED_ACTIVITY_CONTAINER = "collections-embedded-activity"
    # Spinner specific to the embedded container (not the full-page one)
    EMBEDDED_SPINNER            = (
        "collections-spinner.collections-spinner__rendering--embedded"
    )
    # Real DOM: the embedded popup iframe lives inside the embedded-activity
    # container; no confirmed title attribute, so target it by container scope.
    ACTIVITY_IFRAME   = "collections-embedded-activity collections-embedded-view iframe"
    # Real DOM: popup document body <body class="popup"> containing .popup-window
    IFRAME_BODY       = "body.popup"
    # Real DOM: activity heading <h1> inside the popup window
    IFRAME_HEADING    = ".popup-window h1"
    # Real DOM: OK control #btnOk (name="ok", type="submit") in form#activityForm
    IFRAME_OK_BTN     = "form#activityForm #btnOk"
    # Real DOM: Cancel control #btnCancel
    IFRAME_CANCEL_BTN = "#btnCancel"
    # Real DOM: user-updates form present only in the Inputs variant
    USER_UPDATES_FORM = "form#userUpdatesMap"
    # Real DOM: the Activity_Field inputs inside USER_UPDATES_FORM, in DOM order
    # — a textarea (e.g. id=B1), a select (e.g. id=B2), or the visible date
    # picker input (input#dt_visiblereviewDateId). The hidden companion
    # input#reviewDateId is deliberately excluded so it is never counted/filled.
    ACTIVITY_FIELD_SELECTOR = (
        "form#userUpdatesMap textarea, "
        "form#userUpdatesMap select, "
        "form#userUpdatesMap input#dt_visiblereviewDateId"
    )

    # ── Activity-details modal ────────────────────────────────────
    # Real DOM: details modal .popup-window.activity-details
    DETAILS_MODAL     = ".popup-window.activity-details"
    # Real DOM: details modal tab strip
    DETAIL_TABS       = "ul.nav.nav-tabs#detailTabs"
    # Real DOM: the individual Detail_Tab <li> entries within the tab strip,
    # in left-to-right order. A tab is disabled when its <li> carries the
    # 'disabled' class.
    DETAIL_TAB_ITEM   = "ul.nav.nav-tabs#detailTabs > li"
    # Real DOM: details modal Close control
    DETAILS_CLOSE_BTN = "button[name='close']"

    # ── Timeline item title link (drill-in target) ────────────────
    # Real DOM: each Timeline_Item exposes a title link div[role='link'].title
    # whose subtitle span carries the Activity_Name.
    TIMELINE_TITLE_LINK = "collections-timeline-item div.title"
    TIMELINE_SUBTITLE = ".subtitle-text"
    TIMELINE_TITLE_TEXT = ".title-text"

    DETAILS_IFRAME = "collections-embedded-view iframe"

    # ──────────────────────────────────────────────────────────────
    # Per-step screenshot recording (Requirement 9)
    # ──────────────────────────────────────────────────────────────

    def record_screenshot(self, label: str) -> None:
        """
        Capture exactly one screenshot via Screenshot_Helper and record it into
        the injected Run_Step_Log.

        This is the single recording point wired into every mandated step of the
        activity flow (Requirements 9.1–9.8). The screenshot file path and the
        descriptive ``label`` — which identifies both the flow step and the
        Activity_Name (compose via :func:`utils.run_step_log.compose_label`) — are
        appended to the Run_Step_Log in execution order (Requirements 9.9, 9.10).

        The Run_Step_Log reference is held defensively: it is read from the
        ``run_step_log`` attribute injected by the conftest fixture. When no log
        has been injected, the screenshot is still captured but no entry is
        recorded, so the method never fails for lack of a log.

        Capture is fault-tolerant: if :meth:`ScreenshotHelper.capture` raises, a
        failure-labelled entry (``failed=True``, ``screenshot_path=None``) is
        recorded when a log is present and the flow continues without aborting
        (Requirement 9.11).

        Parameters
        ----------
        label : str
            The descriptive step label, already composed to carry both the
            flow-step token and the Activity_Name.
        """
        run_log = getattr(self, "run_step_log", None)
        try:
            path = ScreenshotHelper.capture(self.page, label)
        except Exception as exc:  # Req 9.11 — capture must never abort the run
            log.warning(
                "[ActivitiesMixin] Screenshot capture failed for step '%s': %s; "
                "recording a failure entry and continuing.",
                label, exc,
            )
            if run_log is not None:
                run_log.record(label, None, failed=True)
            return

        if run_log is not None:
            run_log.record(label, str(path), failed=False)

    # ──────────────────────────────────────────────────────────────
    # Sidebar tab actions
    # ──────────────────────────────────────────────────────────────

    def click_alerts_sidebar_tab(self) -> None:
        log.info("[ActivitiesMixin] Clicking Alerts sidebar tab")
        self.click(self.SIDEBAR_TAB_ALERTS)

    def click_activities_sidebar_tab(self) -> None:
        """
        Click the Activities tab in the right sidebar.
        Waits for the activity list container to be visible before returning
        so callers can immediately interact with activity items.
        """
        log.info("[ActivitiesMixin] Clicking Activities sidebar tab")
        self.click(self.SIDEBAR_TAB_ACTIVITIES)
        self.wait_for_element_visible(self.ACTIVITY_LIST_CONTAINER)
        self.screenshot("activities_tab_opened")

    # ──────────────────────────────────────────────────────────────
    # Activity list
    # ──────────────────────────────────────────────────────────────

    def click_activity(
        self,
        parent_label: str,
        child_label: str | None = None,
    ) -> None:
        """
        Click an activity from the Activities sidebar list.

        Case 1 — standalone parent (child_label is None)
            The item has role='menuitem' and no has-children class.
            Click it directly by aria-label.

        Case 2 — expandable parent + child (child_label is provided)
            The parent has role='menu' and class has-children (caret visible).
            Steps:
              a) Click parent to open its submenu.
              b) Wait for the child list to appear.
              c) Click the child by aria-label.

        aria-label is used for targeting — stable across sessions.
        """
        parent_sel = (
            f"collections-activity-list "
            f"a.menu-item-main[aria-label='{parent_label}']"
        )

        if child_label is None:
            log.info("[ActivitiesMixin] Clicking parent activity: '%s'", parent_label)
            self.wait_for_element_visible(parent_sel)
            self.click(parent_sel)
        else:
            log.info(
                "[ActivitiesMixin] Expanding parent '%s' → clicking child '%s'",
                parent_label, child_label,
            )
            self.wait_for_element_visible(parent_sel)
            self.click(parent_sel)                    # expand dropdown

            child_sel = (
                f"collections-activity-list "
                f".menu-item-children a.menu-item-main[aria-label='{child_label}']"
            )
            self.wait_for_element_visible(child_sel)
            self.click(child_sel)

        # Req 9.1 — capture exactly one screenshot when the activity is triggered.
        # The triggered Activity_Name is the child when expanding a parent,
        # otherwise the standalone parent. Remember it so downstream steps that
        # don't receive the name (e.g. fill_activity_inputs) can still label
        # their screenshots with it.
        triggered_name = child_label or parent_label
        self._current_activity_name = triggered_name
        self.record_screenshot(compose_label("activity_trigger", triggered_name))

    def is_parent_activity_expandable(self, parent_label: str) -> bool:
        """True if the parent has a dropdown (has-children class = caret shown)."""
        sel = (
            f"collections-activity-list "
            f"collections-menu-item.has-children "
            f"a.menu-item-main[aria-label='{parent_label}']"
        )
        return self.is_visible(sel)

    # ──────────────────────────────────────────────────────────────
    # Embedded activity iframe
    # ──────────────────────────────────────────────────────────────

    def wait_for_activity_iframe(
        self, activity_label: str, timeout: int = 180_000
    ) -> FrameLocator:
        """
        Wait for the embedded activity iframe to fully load for ``activity_label``.

        Loading sequence (real DOM):
          1. collections-embedded-activity container appears in DOM.
          2. Embedded spinner (collections-spinner …--embedded) shows a
             "Please wait…" message — can be instant or very slow.
          3. Spinner disappears, <iframe> element appears.
          4. The popup document renders: <body class="popup"> containing
             a .popup-window element.

        wait_for_spinner_gone() is used at step 2 so we never block
        when the spinner simply doesn't appear (returns immediately).

        Parameters
        ----------
        activity_label : str
            Human-readable label of the activity being opened. Included in
            the error message if the iframe never becomes ready so callers
            can tell which activity failed to open.
        timeout : int
            Per-step timeout in milliseconds (default 180 000 ms).

        Returns
        -------
        FrameLocator
            Ready for use in fill/click helpers.

        Raises
        ------
        RuntimeError
            If any step of the load sequence exceeds ``timeout``. The message
            names ``activity_label`` and the element that failed to appear.
            No FrameLocator is returned in this case.
        """
        log.info(
            "[ActivitiesMixin] Waiting for activity iframe for '%s' (timeout=%dms) …",
            activity_label, timeout,
        )

        try:
            # Step 1 — container must exist
            self.page.wait_for_selector(
                self.EMBEDDED_ACTIVITY_CONTAINER, timeout=timeout
            )

            # Step 2 — wait out the embedded spinner (safe — exits immediately if absent)
            self.wait_for_spinner_gone(self.EMBEDDED_SPINNER, timeout=timeout)

            # Step 3 — iframe element must appear
            self.page.wait_for_selector(self.ACTIVITY_IFRAME, timeout=timeout)

            # Step 4 — popup body and window must render inside the iframe
            frame_loc = self.page.frame_locator(self.ACTIVITY_IFRAME)
            frame_loc.locator(self.IFRAME_BODY).wait_for(timeout=timeout)
            frame_loc.locator(self.IFRAME_BODY).locator(".popup-window").wait_for(
                timeout=timeout
            )
        except PlaywrightTimeoutError as exc:
            raise RuntimeError(
                f"Activity iframe for '{activity_label}' did not become ready "
                f"within {timeout} ms: {exc}"
            ) from exc

        # Req 9.2 — capture exactly one screenshot when the iframe becomes ready.
        self._current_activity_name = activity_label
        self.record_screenshot(compose_label("iframe_ready", activity_label))
        log.info("[ActivitiesMixin] Activity iframe loaded for '%s' ✓", activity_label)
        return frame_loc

    def get_activity_heading(self, frame_loc: FrameLocator) -> str:
        """
        Read the activity heading text from the iframe ``<h1>`` element.

        Parameters
        ----------
        frame_loc : FrameLocator
            The FrameLocator returned by :meth:`wait_for_activity_iframe`.

        Returns
        -------
        str
            The non-null heading text from ``.popup-window h1``.

        Raises
        ------
        AssertionError
            If the heading text is null/empty.
        """
        log.info("[ActivitiesMixin] Reading activity heading from iframe <h1>")
        heading = frame_loc.locator(self.IFRAME_HEADING).inner_text()
        assert heading is not None and heading.strip(), (
            "Activity iframe heading (<h1>) must be a non-null, non-empty string"
        )
        return heading

    def get_activity_iframe(self) -> FrameLocator:
        """Return a FrameLocator for an already-visible activity iframe."""
        return self.page.frame_locator(self.ACTIVITY_IFRAME)

    def fill_iframe_input(
        self,
        frame_loc: FrameLocator,
        input_selector: str,
        value: str,
    ) -> None:
        """
        Fill an input inside the activity iframe.
        Uses press_sequentially so change/input events fire inside the frame.
        """
        log.info(
            "[ActivitiesMixin] Filling iframe input '%s' = %s",
            input_selector, value,
        )
        loc = frame_loc.locator(input_selector)
        loc.click()
        loc.clear()
        loc.press_sequentially(value, delay=40)

    def click_iframe_ok(self, frame_loc: FrameLocator) -> None:
        """Click the OK / Submit button inside the activity iframe."""
        log.info("[ActivitiesMixin] Clicking OK in activity iframe")
        self.screenshot("before_iframe_ok")
        frame_loc.locator(self.IFRAME_OK_BTN).click()

    def click_iframe_cancel(self, frame_loc: FrameLocator) -> None:
        """Click the Cancel button inside the activity iframe."""
        log.info("[ActivitiesMixin] Clicking Cancel in activity iframe")
        frame_loc.locator(self.IFRAME_CANCEL_BTN).click()

    # ──────────────────────────────────────────────────────────────
    # Assertions
    # ──────────────────────────────────────────────────────────────

    def assert_activity_list_visible(self) -> None:
        self.assert_visible(
            self.ACTIVITY_LIST_CONTAINER,
            "Activity list must be visible after clicking Activities tab",
        )

    def assert_activity_iframe_visible(self) -> None:
        self.assert_visible(
            self.ACTIVITY_IFRAME,
            "Activity iframe must be present in the DOM",
        )

    # ──────────────────────────────────────────────────────────────
    # Variant detection and input filling (Inputs_Variant)
    # ──────────────────────────────────────────────────────────────

    def _scrape_activity_fields(self, frame_loc: FrameLocator) -> list[ActivityField]:
        """
        Scrape the Activity_Fields from ``form#userUpdatesMap`` in DOM order.

        Each matched element (textarea, select, or the visible date-picker input)
        is turned into an :class:`ActivityField`:

          • ``field_id``  — the element ``id`` attribute (e.g. "B1", "B2",
            "dt_visiblereviewDateId").
          • ``label``     — the text of an associated ``<label for=field_id>``
            inside the form, trimmed; empty string when absent.
          • ``kind``      — TEXTAREA / SELECT / DATE inferred from the tag.
          • ``dom_order`` — the element's position among the matched fields.
          • ``options``   — visible-text/value pairs for SELECT fields only.

        Returns
        -------
        list[ActivityField]
            The fields in their DOM order within the user-updates form.
        """
        fields: list[ActivityField] = []
        field_locs = frame_loc.locator(self.ACTIVITY_FIELD_SELECTOR).all()

        for dom_order, loc in enumerate(field_locs):
            tag = (loc.evaluate("el => el.tagName") or "").lower()
            field_id = loc.get_attribute("id") or ""

            if tag == "textarea":
                kind = FieldKind.TEXTAREA
            elif tag == "select":
                kind = FieldKind.SELECT
            else:
                kind = FieldKind.DATE

            # Associated <label for="field_id"> text, if present.
            label = ""
            if field_id:
                label_loc = frame_loc.locator(
                    f"{self.USER_UPDATES_FORM} label[for='{field_id}']"
                )
                if label_loc.count() > 0:
                    label = (label_loc.first.inner_text() or "").strip()

            # Options (SELECT only).
            options: tuple[SelectOption, ...] = ()
            if kind is FieldKind.SELECT:
                option_locs = loc.locator("option").all()
                scraped: list[SelectOption] = []
                for opt in option_locs:
                    text = (opt.inner_text() or "").strip()
                    value = opt.get_attribute("value")
                    scraped.append(SelectOption(text=text, value=value or ""))
                options = tuple(scraped)

            fields.append(
                ActivityField(
                    field_id=field_id,
                    label=label,
                    kind=kind,
                    dom_order=dom_order,
                    options=options,
                )
            )

        return fields

    def detect_iframe_variant(self, frame_loc: FrameLocator) -> IframeVariant:
        """
        Classify the ready Activity_Iframe as Inputs_Variant or Confirmation_Variant.

        Scrapes the iframe DOM shape — whether a ``form#userUpdatesMap`` is present
        and how many Activity_Field inputs (textarea / select / visible date input)
        it contains — and delegates the decision to the pure-logic
        :func:`detect_variant_from_shape`. The iframe is the Inputs_Variant iff the
        form is present with at least one input; otherwise it is the
        Confirmation_Variant. Exactly one variant is always returned.

        The detected variant is also stored on ``self._detected_variant`` and
        returned to the caller, so it is exposed *before* any Activity_Field is
        filled and before the OK (``#btnOk``) or Cancel (``#btnCancel``) control is
        clicked (Requirement 3.4).

        Parameters
        ----------
        frame_loc : FrameLocator
            The FrameLocator returned by :meth:`wait_for_activity_iframe`.

        Returns
        -------
        IframeVariant
            ``IframeVariant.INPUTS`` or ``IframeVariant.CONFIRMATION``.
        """
        has_user_updates_form = frame_loc.locator(self.USER_UPDATES_FORM).count() > 0
        input_count = 0
        if has_user_updates_form:
            input_count = frame_loc.locator(self.ACTIVITY_FIELD_SELECTOR).count()

        variant = detect_variant_from_shape(has_user_updates_form, input_count)
        self._detected_variant = variant
        log.info(
            "[ActivitiesMixin] Detected iframe variant: %s "
            "(form present=%s, input_count=%d)",
            variant.value, has_user_updates_form, input_count,
        )
        return variant

    def fill_activity_inputs(
        self, frame_loc: FrameLocator, field_values: dict[str, str]
    ) -> None:
        """
        Fill the Inputs_Variant Activity_Fields from caller-supplied ``field_values``.

        Activity_Fields are scraped from ``form#userUpdatesMap`` in DOM order and
        the work is delegated to the pure-logic layer:

          • Every provided key must match a field (exact, case-insensitive,
            whitespace-trimmed against field id then label, via
            :func:`match_field_value`). A key that matches no Activity_Field raises
            a descriptive error identifying the unmatched key (Requirement 4.7).
          • :func:`build_fill_plan` produces fill operations only for matched
            fields, in ascending DOM order; fields with no corresponding key are
            left at their existing value (Requirements 4.1, 4.8).

        Each operation is dispatched on the field kind:

          • TEXTAREA — typed character-by-character inside the frame so the input
            value equals the provided text and the form's input/change events fire
            (Requirement 4.3).
          • SELECT — the option whose visible text or value equals the provided
            value (via :func:`match_select_option`) is selected; an unmatched value
            raises a descriptive error naming the field and value and leaves the
            select at its existing selection (Requirements 4.4, 4.5).
          • DATE — the visible date input (``input#dt_visiblereviewDateId``) is set
            to the provided value (Requirement 4.6).

        Parameters
        ----------
        frame_loc : FrameLocator
            The ready Activity_Iframe FrameLocator.
        field_values : dict[str, str]
            Caller-supplied values keyed by field id or field label.

        Raises
        ------
        ValueError
            If a provided key matches no Activity_Field, or a provided value for a
            select field matches no option.
        """
        fields = self._scrape_activity_fields(frame_loc)

        # Requirement 4.7 — every provided key must match an Activity_Field.
        for key in field_values:
            if match_field_value(key, fields) is None:
                raise ValueError(
                    f"Field_Values key '{key}' matches no Activity_Field in the "
                    f"Inputs_Variant. Available fields: "
                    f"{[(f.field_id, f.label) for f in fields]}"
                )

        plan = build_fill_plan(fields, field_values)

        for op in plan:
            field = op.field
            value = op.value
            selector = f"#{field.field_id}"

            if field.kind is FieldKind.SELECT:
                option = match_select_option(value, list(field.options))
                if option is None:
                    raise ValueError(
                        f"Value '{value}' matches no option of select "
                        f"Activity_Field (id='{field.field_id}', "
                        f"label='{field.label}'). Available options: "
                        f"{[(o.text, o.value) for o in field.options]}"
                    )
                log.info(
                    "[ActivitiesMixin] Selecting option '%s' (value='%s') for "
                    "field '%s'",
                    option.text, option.value, field.field_id,
                )
                # select_option fires input/change events automatically.
                frame_loc.locator(selector).select_option(value=option.value)
            else:
                # TEXTAREA and DATE: type inside the frame so input/change fire
                # and the field value equals the provided value.
                self.fill_iframe_input(frame_loc, selector, value)

        log.info(
            "[ActivitiesMixin] Filled %d Activity_Field(s) from %d provided value(s)",
            len(plan), len(field_values),
        )

        # Req 9.3 — capture exactly one screenshot after the Inputs_Variant
        # fields are filled. This method has no Activity_Name parameter, so use
        # the name remembered when the activity was triggered / the iframe loaded.
        self.record_screenshot(
            compose_label(
                "inputs_filled", getattr(self, "_current_activity_name", None)
            )
        )

    # ──────────────────────────────────────────────────────────────
    # Submit / Cancel flows
    # ──────────────────────────────────────────────────────────────

    def submit_activity(
        self, frame_loc: FrameLocator, activity_label: str
    ) -> None:
        """
        Submit the activity by clicking the OK control (``#btnOk``) inside the
        Activity_Iframe and waiting for the post-submission embedded spinner to
        clear.

        Sequence (real DOM):
          1. Capture a screenshot before the click (Requirement 9.4).
          2. Click ``#btnOk`` inside the iframe — this works for both variants:
             the Confirmation_Variant submits without any inputs (Requirement
             5.1) and the Inputs_Variant is submitted only after its fields have
             been filled by the caller (Requirement 5.2).
          3. Wait for the post-submission embedded loading spinner
             (``EMBEDDED_SPINNER``) to disappear using the existing
             :meth:`wait_for_spinner_gone` helper (Requirement 5.3). That helper
             is non-blocking and returns immediately when the spinner is absent,
             so a follow-up presence check enforces the timeout.
          4. Capture a screenshot after the spinner has cleared (Requirement
             9.4).

        Parameters
        ----------
        frame_loc : FrameLocator
            The ready Activity_Iframe FrameLocator.
        activity_label : str
            Human-readable label of the activity being submitted. Included in
            the error message if the post-submission spinner never clears so
            callers can tell which activity failed to submit.

        Raises
        ------
        RuntimeError
            If the post-submission embedded spinner does not disappear within
            the configured timeout after ``#btnOk`` is clicked (Requirement
            5.4).
        """
        log.info(
            "[ActivitiesMixin] Submitting activity '%s' (clicking #btnOk) …",
            activity_label,
        )
        self.record_screenshot(compose_label("before_ok", activity_label))

        frame_loc.locator(self.IFRAME_OK_BTN).click()

        # Requirement 5.3 — wait out the post-submission embedded spinner.
        # wait_for_spinner_gone is non-blocking (returns immediately if the
        # spinner never appears), so a follow-up check enforces the timeout.
        self.wait_for_spinner_gone(self.EMBEDDED_SPINNER)
        try:
            
            spinner = self.page.locator(
                    "collections-spinner.collections-spinner__rendering--embedded:not(.sr-only)"
            )

            if spinner.count() > 0:
                spinner.first.wait_for(state="hidden", timeout=self.timeout)

        except PlaywrightTimeoutError as exc:
            raise RuntimeError(
                f"Activity '{activity_label}' failed to submit: the "
                f"post-submission embedded spinner ('{self.EMBEDDED_SPINNER}') "
                f"did not disappear within {self.timeout} ms after clicking "
                f"#btnOk: {exc}"
            ) from exc

        self.record_screenshot(compose_label("after_ok", activity_label))
        log.info(
            "[ActivitiesMixin] Activity '%s' submitted ✓", activity_label
        )

    def cancel_activity(self, frame_loc: FrameLocator) -> None:
        """
        Abandon the activity by clicking the Cancel control (``#btnCancel``)
        inside the Activity_Iframe and confirming the popup body has closed.

        No Field_Values are applied and no submission occurs, so no new
        Timeline_Item is recorded for the activity (Requirements 5.5, 5.6).

        Sequence (real DOM):
          1. Click ``#btnCancel`` inside the iframe.
          2. Confirm the iframe popup body (``body.popup``) is no longer present
             by waiting for it to detach (Requirement 5.6).
          3. Capture a screenshot after the iframe has closed.

        Parameters
        ----------
        frame_loc : FrameLocator
            The Activity_Iframe FrameLocator to cancel.

        Raises
        ------
        RuntimeError
            If the iframe popup body is still present within the configured
            timeout after ``#btnCancel`` is clicked (i.e. the iframe did not
            close).
        """
        log.info("[ActivitiesMixin] Cancelling activity (clicking #btnCancel) …")

        frame_loc.locator(self.IFRAME_CANCEL_BTN).click()

        # Requirement 5.6 — the iframe popup body must no longer be present.
        try:
            frame_loc.locator(self.IFRAME_BODY).wait_for(
                state="detached", timeout=self.timeout
            )
        except PlaywrightTimeoutError as exc:
            raise RuntimeError(
                f"Activity iframe popup body ('{self.IFRAME_BODY}') was still "
                f"present {self.timeout} ms after clicking #btnCancel; the "
                f"activity iframe did not close as expected: {exc}"
            ) from exc

        self.screenshot("after_cancel")
        log.info("[ActivitiesMixin] Activity cancelled, iframe closed ✓")

    # ──────────────────────────────────────────────────────────────
    # Activity-details modal drill-in and tab iteration
    # ──────────────────────────────────────────────────────────────

    def open_details_modal(self, activity_name: str) -> None:
        """
        Open the Activity_Details_Modal for the Most_Recent_Item matching
        ``activity_name``.

        The Timeline_Item title links (``div[role='link'].title``) are scraped
        into :class:`TimelineItem` models — their subtitle span holds the
        Activity_Name and their document position is the index (0 = top-most).
        The pure-logic layer then selects the match: :func:`match_timeline_items`
        keeps the items whose trimmed subtitle equals ``activity_name`` under a
        case-insensitive comparison, and :func:`select_most_recent` picks the
        top-most (smallest index) of those (Requirement 8.1).

        That matched title link is clicked to open the modal; the page spinner is
        waited out with the existing :meth:`wait_for_spinner_gone` helper (which
        returns immediately when no spinner is present), and the
        ``.popup-window.activity-details`` modal must become present within the
        configured timeout (Requirement 8.2).

        Parameters
        ----------
        activity_name : str
            The Activity_Name whose Most_Recent_Item details modal to open.

        Raises
        ------
        RuntimeError
            If no Timeline_Item matches ``activity_name`` (no title link to
            click), or if the ``.popup-window.activity-details`` modal does not
            become present within the configured timeout after the title link is
            clicked (Requirement 8.3).
        """
        log.info(
            "[ActivitiesMixin] Opening details modal for activity '%s' …",
            activity_name,
        )
        
        self.page.wait_for_selector(
            "collections-timeline-item",
            timeout=10000
        )

        title_links = self.page.locator(self.TIMELINE_TITLE_LINK)
        count = title_links.count()

        items: list[TimelineItem] = []
        for index in range(count):
            link = title_links.nth(index)
            subtitle = ""
            title = ""

            subtitle_loc = link.locator(self.TIMELINE_SUBTITLE)
            if subtitle_loc.count() > 0:
                subtitle = subtitle_loc.first.inner_text().strip()

            title_loc = link.locator(self.TIMELINE_TITLE_TEXT)
            if title_loc.count() > 0:
                title = title_loc.first.inner_text().strip()

            final_text = subtitle if subtitle else title

            aria_label = link.get_attribute("aria-label") or ""
            items.append(
                TimelineItem(
                    subtitle=final_text,
                    index=index,
                    title_aria_label=aria_label,
                )
            )

        # Req 9.5 — capture exactly one screenshot of the Timeline once it has
        # been read after submission.
        self.record_screenshot(compose_label("timeline_read", activity_name))

        most_recent = select_most_recent(match_timeline_items(items, activity_name))
        if most_recent is None:
            raise RuntimeError(
                f"Cannot open details modal: no Timeline_Item subtitle matches "
                f"activity '{activity_name}'. Available subtitles: "
                f"{[item.subtitle for item in items]}"
            )

        # Req 9.6 — capture exactly one screenshot of the matched Timeline_Item.
        self.record_screenshot(compose_label("matched_item", activity_name))

        log.info(
            "[ActivitiesMixin] Clicking matched title link for '%s' at index %d",
            activity_name, most_recent.index,
        )
        title_links.nth(most_recent.index).click()

        # Requirement 8.2 — wait out the page spinner (non-blocking if absent),
        # then confirm the details modal is present within the timeout.
        self.wait_for_spinner_gone()
        frame_loc = self.page.frame_locator(self.DETAILS_IFRAME)
        try:
            frame_loc.locator(self.DETAILS_MODAL).wait_for(timeout=self.timeout)
        except PlaywrightTimeoutError as exc:
            raise RuntimeError(
                f"Activity details modal ('{self.DETAILS_MODAL}') for activity "
                f"'{activity_name}' did not become present within "
                f"{self.timeout} ms after clicking the timeline title link: {exc}"
            ) from exc

        self.record_screenshot(compose_label("modal_open", activity_name))
        log.info(
            "[ActivitiesMixin] Details modal open for '%s' ✓", activity_name
        )

    def iterate_enabled_tabs(self, activity_name: str) -> list[str]:
        """
        Visit every Enabled_Tab of the open Activity_Details_Modal, then close it.

        The Detail_Tabs are scraped from ``ul.nav.nav-tabs#detailTabs`` into
        :class:`DetailTab` models — each tab's ``<li>`` is disabled when it
        carries the ``disabled`` class, and its left-to-right position is the
        index. :func:`filter_enabled_tabs` keeps only the non-disabled tabs in
        their original order (Requirements 8.4, 8.7); a modal exposing zero
        enabled tabs raises a descriptive error (Requirement 8.5).

        Each Enabled_Tab is clicked exactly once in left-to-right order and the
        existing :meth:`wait_for_spinner_gone` helper is used to wait out any
        tab-load spinner between clicks (Requirement 8.6). When every Enabled_Tab
        has been visited, the Close control (``button[name='close']``) is clicked
        and the ``.popup-window.activity-details`` modal must no longer be present
        within the configured timeout (Requirement 8.8).

        Parameters
        ----------
        activity_name : str
            The Activity_Name whose details modal is open; included in error
            messages for context.

        Returns
        -------
        list[str]
            The labels of the Enabled_Tabs visited, in left-to-right order.

        Raises
        ------
        RuntimeError
            If the modal exposes zero Enabled_Tabs, or if the modal is still
            present within the configured timeout after the Close control is
            clicked.
        """
        log.info(
            "[ActivitiesMixin] Iterating enabled detail tabs for '%s' …",
            activity_name,
        )

        frame_loc = self.page.frame_locator(self.DETAILS_IFRAME)

        tab_items = frame_loc.locator(self.DETAIL_TAB_ITEM)
        count = tab_items.count()

        tabs: list[DetailTab] = []
        for index in range(count):
            li = tab_items.nth(index)
            css_classes = (li.get_attribute("class") or "").split()
            disabled = "disabled" in css_classes
            label = (li.inner_text() or "").strip()
            tabs.append(DetailTab(label=label, index=index, disabled=disabled))

        enabled = filter_enabled_tabs(tabs)
        if not enabled:
            raise RuntimeError(
                f"Activity details modal for activity '{activity_name}' exposed "
                f"no Enabled_Tabs (all {count} tab(s) are disabled): "
                f"{[t.label for t in tabs]}"
            )

        visited: list[str] = []
        for tab in enabled:
            log.info(
                "[ActivitiesMixin] Clicking detail tab '%s' (index %d)",
                tab.label, tab.index,
            )
            target = tab_items.nth(tab.index)
            anchor = target.locator("a")
            if anchor.count() > 0:
                anchor.first.click()
            else:
                target.click()

            # Requirement 8.6 — wait out any tab-load spinner before the next tab.
            self.wait_for_spinner_gone()
            # Req 9.8 — capture exactly one screenshot of each Enabled_Tab's content.
            self.record_screenshot(
                compose_label(f"tab_{tab.label}", activity_name)
            )
            visited.append(tab.label)

        # Requirement 8.8 — close the modal and confirm it is gone.
        log.info("[ActivitiesMixin] Closing details modal for '%s'", activity_name)
        frame_loc.locator(self.DETAILS_CLOSE_BTN).click()
        try:
            frame_loc.locator(self.DETAILS_MODAL).wait_for(
                state="hidden",
                timeout=self.timeout
            )
        except PlaywrightTimeoutError as exc:
            raise RuntimeError(
                f"Activity details modal ('{self.DETAILS_MODAL}') for activity "
                f"'{activity_name}' was still present {self.timeout} ms after "
                f"clicking the Close control; the modal did not close: {exc}"
            ) from exc

        self.screenshot("details_modal_closed")
        log.info(
            "[ActivitiesMixin] Visited %d enabled tab(s) for '%s' and closed "
            "the modal ✓", len(visited), activity_name,
        )
        return visited
