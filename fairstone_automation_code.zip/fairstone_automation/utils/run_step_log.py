"""
utils/run_step_log.py
─────────────────────
The ordered, in-memory record of step labels and their associated screenshot
file paths captured during a run (the Run_Step_Log).

The interaction layer (`ActivitiesMixin`) appends one entry per mandated step
of the activity flow; the `Report_Generator` consumes the ordered entries to
build the per-run Word report. Each entry's label identifies both the flow step
and the associated `Activity_Name` so the report captions are self-describing.

This module has no Playwright/browser dependency so it can be exercised by
property-based tests over generated sequences of `record(...)` calls.

Requirements covered:
- 9.9  : record the screenshot file path and a descriptive step label that
         identifies both the flow step and the associated Activity_Name.
- 9.10 : preserve screenshot entries in the order in which they were captured.
- 9.11 : record a failure-labelled entry (and continue) when capture fails.
"""
from __future__ import annotations

from typing import Callable, Optional

from utils.activity_models import RunStepEntry


def compose_label(step: str, activity_name: Optional[str]) -> str:
    """Compose a descriptive step label containing both the flow-step token and
    the ``Activity_Name`` (Requirement 9.9).

    The returned label always contains the ``step`` token. When an
    ``activity_name`` is supplied it is appended in a bracketed segment so both
    tokens are present and recoverable from the label text.
    """
    step_token = (step or "").strip()
    name_token = (activity_name or "").strip()
    if name_token:
        return f"{step_token} [{name_token}]"
    return step_token


class RunStepLog:
    """An ordered log of screenshot steps captured during a run."""

    def __init__(self) -> None:
        self._entries: list[RunStepEntry] = []

    def record(
        self,
        label: str,
        screenshot_path: Optional[str],
        failed: bool = False,
    ) -> None:
        """Append a step entry, preserving insertion order (Requirements 9.9, 9.10).

        ``label`` should already identify both the flow step and the
        ``Activity_Name`` (see :func:`compose_label`). ``screenshot_path`` is the
        path to the captured screenshot, or ``None`` when no screenshot is
        associated (e.g. a failure-labelled entry). ``failed`` marks an entry as
        a failure-labelled entry (Requirement 9.11).
        """
        self._entries.append(
            RunStepEntry(label=label, screenshot_path=screenshot_path, failed=failed)
        )

    def record_step(
        self,
        step: str,
        activity_name: Optional[str],
        screenshot_path: Optional[str],
        failed: bool = False,
    ) -> None:
        """Convenience wrapper that composes the label from ``step`` and
        ``activity_name`` before recording (Requirement 9.9)."""
        self.record(compose_label(step, activity_name), screenshot_path, failed=failed)

    def record_capture(
        self,
        label: str,
        capture: Callable[[], Optional[str]],
    ) -> None:
        """Run ``capture`` to obtain a screenshot path and record the result.

        If ``capture`` raises, a failure-labelled entry with no screenshot path
        is recorded and the exception is swallowed so the run continues without
        aborting (Requirement 9.11).
        """
        try:
            screenshot_path = capture()
        except Exception:
            self.record(label, None, failed=True)
            return
        self.record(label, screenshot_path, failed=False)

    def entries(self) -> list[RunStepEntry]:
        """Return the recorded entries in insertion order (Requirement 9.10)."""
        return list(self._entries)
