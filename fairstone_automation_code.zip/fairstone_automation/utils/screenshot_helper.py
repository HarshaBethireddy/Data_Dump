"""
utils/screenshot_helper.py
──────────────────────────
Thread-safe screenshot helper.
Usage:
    ScreenshotHelper.capture(page, "login_success")
    ScreenshotHelper.capture_full_page(page, "search_results")
"""
from __future__ import annotations

import threading
from datetime import datetime
from pathlib import Path

from playwright.sync_api import Page

from utils.config import Config
from utils.logger import get_logger

log = get_logger(__name__)
_lock = threading.Lock()


class ScreenshotHelper:
    """Captures named screenshots into the configured screenshots directory."""

    @staticmethod
    def _build_path(name: str, suffix: str = "") -> Path:
        Config.SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        safe_name = name.replace(" ", "_").replace("/", "-")
        filename = f"{timestamp}_{safe_name}{suffix}.png"
        return Config.SCREENSHOTS_DIR / filename

    @classmethod
    def capture(cls, page: Page, name: str = "screenshot") -> Path:
        """Capture a viewport screenshot. Returns the saved path."""
        path = cls._build_path(name)
        with _lock:
            page.screenshot(path=str(path))
        log.info("Screenshot saved → %s", path.name)
        return path

    @classmethod
    def capture_full_page(cls, page: Page, name: str = "full_page") -> Path:
        """Capture a full-page screenshot (scrolls automatically)."""
        path = cls._build_path(name, suffix="_FULL")
        with _lock:
            page.screenshot(path=str(path), full_page=True)
        log.info("Full-page screenshot saved → %s", path.name)
        return path

    @classmethod
    def capture_on_failure(cls, page: Page, test_name: str) -> Path | None:
        """Capture only if SCREENSHOT_ON_FAILURE is enabled."""
        if not Config.SCREENSHOT_ON_FAILURE:
            return None
        return cls.capture(page, f"FAILURE_{test_name}")

    @classmethod
    def capture_on_pass(cls, page: Page, test_name: str) -> Path | None:
        """Capture only if SCREENSHOT_ON_PASS is enabled."""
        if not Config.SCREENSHOT_ON_PASS:
            return None
        return cls.capture(page, f"PASS_{test_name}")
