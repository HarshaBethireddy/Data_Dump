"""
utils/config.py
───────────────
Single source of truth for all configuration values.
Reads from environment variables (or a .env file if present).
"""
from __future__ import annotations

import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env from the project root (two levels up from this file)
_ROOT = Path(__file__).resolve().parents[1]
load_dotenv(_ROOT / ".env", override=True)


def _bool(key: str, default: bool = False) -> bool:
    return os.getenv(key, str(default)).lower() in ("1", "true", "yes")


def _int(key: str, default: int = 0) -> int:
    try:
        return int(os.getenv(key, str(default)))
    except ValueError:
        return default


class Config:
    """Centralised, immutable configuration object."""

    # ── Application ──────────────────────────────────────────────
    BASE_URL: str = os.getenv("BASE_URL", "http://usaqaplfair30.us.experian.eeca:9080/")
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "dev")

    # ── Credentials ───────────────────────────────────────────────
    USERNAME: str = os.getenv("USERNAME", "")
    PASSWORD: str = os.getenv("PASSWORD", "")

    # ── Browser ───────────────────────────────────────────────────
    BROWSER: str = os.getenv("BROWSER", "chromium").lower()
    HEADLESS: bool = _bool("HEADLESS", default=False)
    SLOW_MO: int = _int("SLOW_MO", default=150)
    TIMEOUT: int = _int("TIMEOUT", default=180_000)   # ms

    # ── Screenshots ───────────────────────────────────────────────
    SCREENSHOT_ON_FAILURE: bool = _bool("SCREENSHOT_ON_FAILURE", default=True)
    SCREENSHOT_ON_PASS: bool = _bool("SCREENSHOT_ON_PASS", default=False)
    SCREENSHOTS_DIR: Path = _ROOT / os.getenv("SCREENSHOTS_DIR", "screenshots")

    # ── Reporting ─────────────────────────────────────────────────
    REPORTS_DIR: Path = _ROOT / os.getenv("REPORTS_DIR", "reports")

    @classmethod
    def validate(cls) -> None:
        """Raise at startup if critical values are missing."""
        missing = [k for k in ("BASE_URL",) if not getattr(cls, k)]
        if missing:
            raise EnvironmentError(f"Missing required config keys: {missing}")

    @classmethod
    def summary(cls) -> str:
        return (
            f"[Config] env={cls.ENVIRONMENT} | url={cls.BASE_URL} | "
            f"browser={cls.BROWSER} | headless={cls.HEADLESS} | slow_mo={cls.SLOW_MO}ms"
        )
