"""
utils/screenshot_naming.py
──────────────────────────
Pure, browser-free helpers for naming Reference Interfaces step screenshots.

These functions hold the deterministic naming rules for the SPA Reference
Interfaces feature so they can be exercised by property-based tests without a
browser:

- ``derive_screenshot_prefix`` — turn a reference-type option name into a
  filename-safe Screenshot_Prefix (spaces → single underscores).
- ``screenshot_name``          — compose the canonical ``{prefix}_{suffix}``
  step screenshot name.
"""
from __future__ import annotations


def derive_screenshot_prefix(option_name: str) -> str:
    """Derive a Screenshot_Prefix from a reference-type option name.

    Every space character in ``option_name`` is replaced with a single
    underscore; all other characters are preserved exactly, in order. The
    result therefore has the same length as the input, contains no spaces, and
    carries an underscore at exactly the positions where the input had a space.

    Args:
        option_name: The selected reference-type dropdown option name.

    Returns:
        The option name with every space replaced by one underscore.

    Validates Requirements 2.4.
    """
    return option_name.replace(" ", "_")


def screenshot_name(prefix: str, suffix: str) -> str:
    """Compose the canonical step screenshot name.

    The composed name is the Screenshot_Prefix and the step suffix joined by a
    single underscore, i.e. it starts with ``prefix``, ends with ``suffix``,
    and joins them with exactly one underscore.

    Args:
        prefix: The Screenshot_Prefix (see :func:`derive_screenshot_prefix`).
        suffix: The fixed step suffix that uniquely identifies the step
            (e.g. ``"selected"``, ``"add_filled"``, ``"delete_verified"``).

    Returns:
        ``f"{prefix}_{suffix}"``.

    Validates Requirements 9.2.
    """
    return f"{prefix}_{suffix}"
