"""Utility helpers for the Collections automation framework."""
