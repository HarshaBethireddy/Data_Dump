"""
utils/report_generator.py
─────────────────────────
Reporting layer for the activity-execution-and-reporting feature.

This module turns an ordered Run_Step_Log into a per-run Word (`.docx`) report
embedding each captured screenshot in execution order with a descriptive
caption.

Two pieces of pure, browser-free logic live here so they can be exercised by
property-based tests (see Property 8 in the design):

* ``build_report_plan(log)`` — converts the recorded step entries into an
  order-preserving, one-to-one plan describing what the report should contain.
* ``generate_report_filename(...)`` — produces the timestamped, collision-free
  ``activity_report_<YYYYmmdd_HHMMSS>.docx`` file name.

The browser/python-docx-driven ``ReportGenerator.generate`` method (which
consumes :func:`build_report_plan` and :func:`generate_report_filename` to emit
the actual ``.docx``) is implemented in a later task; this module is structured
so that method can be layered on top without changing the pure functions below.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Iterable, Protocol, Sequence

from utils.activity_models import RunStepEntry

# Caption text used when a recorded screenshot file is absent at report time
# (Requirement 10.7) and when no steps were captured at all (Requirement 10.8).
MISSING_SCREENSHOT_CAPTION = "Screenshot missing"
NO_STEPS_CAPTION = "No steps were captured"

# Filename pattern for a Run_Report (Requirement 10.5). One-second resolution
# guarantees uniqueness across runs that start at distinct seconds.
_FILENAME_PREFIX = "activity_report_"
_FILENAME_SUFFIX = ".docx"
_TIMESTAMP_FORMAT = "%Y%m%d_%H%M%S"

# Sub-directory of the reports directory that holds the generated Word reports
# (Requirement 10.4). Created on demand when a report is generated.
_DOCS_SUBDIR = "docs"

# Width applied to each embedded screenshot so wide captures stay within the
# page margins; chosen to fit a default Letter/A4 page body.
_PICTURE_WIDTH_INCHES = 6.0


class ReportElementKind(Enum):
    """The kind of a single element in a report plan."""

    SCREENSHOT = "screenshot"               # embed image + caption
    MISSING_SCREENSHOT = "missing_screenshot"  # caption only, file absent
    EMPTY_LOG = "empty_log"                 # textual "no steps were captured"


@dataclass(frozen=True)
class ReportElement:
    """One ordered element of a Run_Report plan.

    * ``SCREENSHOT`` — ``screenshot_path`` points at an existing file and
      ``caption`` is the step label recorded in the log.
    * ``MISSING_SCREENSHOT`` — the recorded file is absent; ``screenshot_path``
      is ``None`` and ``caption`` indicates the screenshot is missing for that
      step (Requirement 10.7).
    * ``EMPTY_LOG`` — emitted as the single element when the log has no entries
      (Requirement 10.8); ``screenshot_path`` is ``None``.
    """

    kind: ReportElementKind
    caption: str
    screenshot_path: str | None = None


class _SupportsEntries(Protocol):
    """Structural type for any Run_Step_Log exposing ordered entries."""

    def entries(self) -> Sequence[RunStepEntry]:
        ...


def _screenshot_exists(path: str | None) -> bool:
    """Return True only when ``path`` is set and refers to an existing file."""
    return bool(path) and os.path.isfile(path)  # type: ignore[arg-type]


def build_report_plan(log: _SupportsEntries) -> list[ReportElement]:
    """Build an order-preserving, one-to-one report plan from a Run_Step_Log.

    For each entry in ``log.entries()`` (in recorded order) exactly one
    :class:`ReportElement` is produced:

    * when the entry's screenshot file exists → a ``SCREENSHOT`` element whose
      caption is the entry's exact recorded ``label`` (Requirements 10.2, 10.3);
    * when the file is absent (missing, ``None``, or a failed capture) → a
      ``MISSING_SCREENSHOT`` element in that same position whose caption notes
      the screenshot is missing for that step (Requirement 10.7).

    When the log has no entries a single ``EMPTY_LOG`` element is returned
    (Requirement 10.8).

    The result is always non-empty and never reorders or omits entries.
    """
    entries = list(log.entries())

    if not entries:
        return [ReportElement(kind=ReportElementKind.EMPTY_LOG, caption=NO_STEPS_CAPTION)]

    plan: list[ReportElement] = []
    for entry in entries:
        if _screenshot_exists(entry.screenshot_path):
            plan.append(
                ReportElement(
                    kind=ReportElementKind.SCREENSHOT,
                    caption=entry.label,
                    screenshot_path=entry.screenshot_path,
                )
            )
        else:
            plan.append(
                ReportElement(
                    kind=ReportElementKind.MISSING_SCREENSHOT,
                    caption=f"{entry.label} — {MISSING_SCREENSHOT_CAPTION}",
                    screenshot_path=None,
                )
            )
    return plan


def generate_report_filename(timestamp: datetime | None = None) -> str:
    """Return a timestamped, collision-free Run_Report file name.

    The name matches ``activity_report_<YYYYmmdd_HHMMSS>.docx`` (Requirement
    10.5). Distinct timestamps at one-second (or coarser) resolution always
    yield distinct file names, so no prior run's report is overwritten.

    Args:
        timestamp: the moment to stamp into the name; defaults to ``now()``.
    """
    ts = timestamp if timestamp is not None else datetime.now()
    return f"{_FILENAME_PREFIX}{ts.strftime(_TIMESTAMP_FORMAT)}{_FILENAME_SUFFIX}"


class ReportGenerator:
    """Emit one per-run Word (`.docx`) report from a Run_Step_Log.

    The generator consumes the pure :func:`build_report_plan` and
    :func:`generate_report_filename` helpers above and renders the plan into an
    actual ``.docx`` using ``python-docx``. ``python-docx`` is imported lazily
    inside :meth:`generate` so this module (and the pure functions / property
    tests that import it) keep working even before the pinned ``python-docx``
    dependency is installed.
    """

    @staticmethod
    def generate(
        log: _SupportsEntries,
        reports_dir: Path | str | None = None,
    ) -> Path:
        """Build and save exactly one Run_Report, returning its path.

        Steps:

        1. Ensure ``<reports_dir>/docs/`` exists, creating it if absent
           (Requirement 10.4).
        2. Build the ordered, one-to-one plan from ``log`` via
           :func:`build_report_plan` and render it into a ``Document``: each
           ``SCREENSHOT`` element embeds its image via ``add_picture`` followed
           by its caption; ``MISSING_SCREENSHOT`` and ``EMPTY_LOG`` elements add
           their caption text only (Requirements 10.2, 10.3, 10.7, 10.8).
        3. Save the document under a unique, timestamped file name
           (``activity_report_<YYYYmmdd_HHMMSS>.docx``) so no prior run's report
           is overwritten (Requirement 10.5).

        On any write failure (directory creation or document save) a descriptive
        ``OSError`` is raised; because the target file name is unique to this
        run, existing reports are left untouched, and any partially-written file
        for this run is removed before re-raising (Requirement 10.9).

        Args:
            log: the Run_Step_Log whose ordered entries drive the report.
            reports_dir: the base reports directory; the report is written to its
                ``docs/`` sub-directory. Defaults to ``Config.REPORTS_DIR`` when
                not supplied.

        Returns:
            The path to the written ``.docx`` report.
        """
        # Lazy import so the module imports without python-docx present.
        try:
            from docx import Document
            from docx.shared import Inches
        except ImportError as exc:  # pragma: no cover - depends on environment
            raise OSError(
                "Cannot generate the activity report: the 'python-docx' library "
                "is not installed. Install the pinned dependency from "
                "requirements.txt (python-docx==1.1.2) and retry."
            ) from exc

        # Resolve the default reports directory lazily so importing this module
        # does not require the application Config (and its dependencies).
        if reports_dir is None:
            from utils.config import Config

            reports_dir = Config.REPORTS_DIR

        docs_dir = Path(reports_dir) / _DOCS_SUBDIR

        # 1. Ensure the output directory exists (Requirement 10.4).
        try:
            docs_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise OSError(
                f"Failed to create the reports directory '{docs_dir}' for the "
                f"activity report: {exc}"
            ) from exc

        # 2. Build the plan and render it into a document.
        plan = build_report_plan(log)
        document = Document()
        document.add_heading("Activity Execution Report", level=0)

        for element in plan:
            if element.kind is ReportElementKind.SCREENSHOT and element.screenshot_path:
                try:
                    document.add_picture(
                        element.screenshot_path, width=Inches(_PICTURE_WIDTH_INCHES)
                    )
                except OSError:
                    # The file vanished/became unreadable between planning and
                    # rendering: fall back to a missing-screenshot caption in
                    # this same position rather than aborting (Requirement 10.7).
                    document.add_paragraph(
                        f"{element.caption} \u2014 {MISSING_SCREENSHOT_CAPTION}"
                    )
                    continue
                document.add_paragraph(element.caption)
            else:
                # MISSING_SCREENSHOT and EMPTY_LOG: caption text only.
                document.add_paragraph(element.caption)

        # 3. Save under a unique, timestamped name (Requirement 10.5).
        target = docs_dir / generate_report_filename()
        try:
            document.save(os.fspath(target))
        except OSError as exc:
            # Leave existing reports untouched; remove any partial file written
            # for this run before surfacing the failure (Requirement 10.9).
            try:
                if target.exists():
                    target.unlink()
            except OSError:
                pass
            raise OSError(
                f"Failed to write the activity report to '{target}': {exc}"
            ) from exc

        return target
