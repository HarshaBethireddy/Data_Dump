"""
utils/activity_models.py
────────────────────────
Shared data models for the activity-execution-and-reporting feature.

These plain-data structures are produced by the interaction layer (scraping the
live DOM) and consumed by the pure-logic layer (`utils/activity_logic.py`), the
run-step log (`utils/run_step_log.py`), and the report generator
(`utils/report_generator.py`). Keeping them free of any Playwright/browser
dependency lets the decision logic be exercised by property-based tests.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class IframeVariant(Enum):
    """The two embedded-activity popup shapes."""

    CONFIRMATION = "confirmation"   # only message + OK, no input form
    INPUTS = "inputs"               # form#userUpdatesMap with >=1 input


class FieldKind(Enum):
    """The supported Activity_Field input kinds."""

    TEXTAREA = "textarea"
    SELECT = "select"
    DATE = "date"


@dataclass(frozen=True)
class SelectOption:
    """A single option within a select Activity_Field."""

    text: str        # visible option text
    value: str       # option value attribute


@dataclass(frozen=True)
class ActivityField:
    """An input within the Inputs_Variant `form#userUpdatesMap`."""

    field_id: str               # e.g. "B1", "B2", "dt_visiblereviewDateId"
    label: str                  # e.g. "Bankruptcy Notes", "Code"
    kind: FieldKind
    dom_order: int              # position within form#userUpdatesMap
    options: tuple[SelectOption, ...] = ()   # populated for SELECT only


@dataclass(frozen=True)
class TimelineItem:
    """A single `collections-timeline-item` scraped from a Timeline."""

    subtitle: str               # the Activity_Name shown in the item
    index: int                  # 0 = top-most (Most_Recent_Item)
    title_aria_label: str = ""
    acting_user: str = ""


@dataclass(frozen=True)
class DetailTab:
    """A tab in the Activity_Details_Modal tab strip."""

    label: str                  # e.g. "General Details"
    index: int                  # left-to-right position
    disabled: bool              # <li> carries 'disabled' class


@dataclass
class RunStepEntry:
    """One ordered entry in the Run_Step_Log."""

    label: str
    screenshot_path: str | None
    failed: bool = False
