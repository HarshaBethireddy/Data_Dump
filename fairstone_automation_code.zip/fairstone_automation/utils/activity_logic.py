"""
utils/activity_logic.py
───────────────────────
Pure-logic layer for the activity-execution-and-reporting feature.

The matching / selection / filtering decisions that the interaction layer
(`ActivitiesMixin`) makes are extracted into small pure functions here. They
take plain data (scraped from the live DOM by the mixin) and return plain data,
so they are deterministic and exercisable by property-based tests without a
browser.

This module is built up incrementally across tasks. Functions added so far:

- ``normalize``                  — strip + casefold for comparisons
- ``detect_variant_from_shape``  — classify the embedded-iframe popup variant
- ``match_field_value``          — match a Field_Values key to an Activity_Field
- ``match_select_option``        — match a value to a select option
- ``build_fill_plan``            — build the ordered fill operations for the
                                   Inputs_Variant

Later tasks extend this module with timeline matching, most-recent selection,
and enabled-tab filtering.
"""
from __future__ import annotations

from dataclasses import dataclass

from utils.activity_models import (
    ActivityField,
    DetailTab,
    IframeVariant,
    SelectOption,
    TimelineItem,
)


def normalize(value: str) -> str:
    """Return a comparison-normalized form of ``value``.

    Comparisons throughout the feature are exact, case-insensitive, and
    whitespace-trimmed. ``normalize`` performs the shared transformation used by
    every such comparison: strip leading/trailing whitespace, then ``casefold``
    for case-insensitive equality.

    Args:
        value: The raw string to normalize.

    Returns:
        The trimmed, case-folded string.
    """
    return value.strip().casefold()


def detect_variant_from_shape(
    has_user_updates_form: bool,
    input_count: int,
) -> IframeVariant:
    """Classify an embedded-activity popup from its DOM-shape descriptor.

    The iframe is the Inputs_Variant if and only if a ``form#userUpdatesMap`` is
    present *and* it contains at least one Activity_Field input. In every other
    case — no form present, or a form present with zero inputs — the iframe is
    the Confirmation_Variant. Exactly one variant is always returned.

    Args:
        has_user_updates_form: Whether a ``form#userUpdatesMap`` is present.
        input_count: The number of Activity_Field inputs (textarea, select, or
            date-picker input) found within that form. Expected to be ``>= 0``.

    Returns:
        ``IframeVariant.INPUTS`` when ``has_user_updates_form`` is ``True`` and
        ``input_count >= 1``; otherwise ``IframeVariant.CONFIRMATION``.

    Validates Requirements 3.1, 3.2, 3.3.
    """
    if has_user_updates_form and input_count >= 1:
        return IframeVariant.INPUTS
    return IframeVariant.CONFIRMATION


def match_field_value(key: str, fields: list[ActivityField]) -> ActivityField | None:
    """Match a ``Field_Values`` key to an Activity_Field.

    The comparison is exact, case-insensitive, and whitespace-trimmed (via
    :func:`normalize`) against each field's ``field_id`` first, then its
    ``label``. When a key matches one field's id and a *different* field's
    label, the field-id match is preferred.

    Args:
        key: The caller-supplied ``Field_Values`` key, possibly with case or
            surrounding-whitespace differences.
        fields: The Activity_Fields scraped from ``form#userUpdatesMap``.

    Returns:
        The Activity_Field whose normalized ``field_id`` equals the normalized
        key when such a field exists (preferred); otherwise the first field
        whose normalized ``label`` equals the normalized key; otherwise
        ``None`` when the normalized key matches neither any field id nor any
        field label.

    Validates Requirements 4.2, 4.7.
    """
    normalized_key = normalize(key)

    for field in fields:
        if normalize(field.field_id) == normalized_key:
            return field

    for field in fields:
        if normalize(field.label) == normalized_key:
            return field

    return None


def match_select_option(value: str, options: list[SelectOption]) -> SelectOption | None:
    """Match a provided value to a select Activity_Field option.

    The comparison is exact, case-insensitive, and whitespace-trimmed (via
    :func:`normalize`) against each option's visible ``text`` or its ``value``
    attribute. Options are considered in their given order, and the first
    option whose normalized text or value equals the normalized input is
    returned.

    Args:
        value: The caller-supplied value to apply to the select field, possibly
            with case or surrounding-whitespace differences.
        options: The options of the select Activity_Field.

    Returns:
        The first :class:`SelectOption` whose normalized ``text`` or ``value``
        equals the normalized input; ``None`` when no option matches.

    Validates Requirements 4.4, 4.5.
    """
    normalized_value = normalize(value)

    for option in options:
        if normalize(option.text) == normalized_value or normalize(option.value) == normalized_value:
            return option

    return None


@dataclass(frozen=True)
class FillOperation:
    """A single planned fill of an Activity_Field with a provided value.

    Produced by :func:`build_fill_plan`. The interaction layer applies these
    operations in order, dispatching on ``field.kind`` (textarea / select /
    date) to the appropriate ``BasePage`` helper.
    """

    field: ActivityField   # the matched Activity_Field to fill
    value: str             # the caller-supplied value to apply


def build_fill_plan(
    fields: list[ActivityField],
    field_values: dict[str, str],
) -> list[FillOperation]:
    """Build the ordered fill plan for the Inputs_Variant.

    Each key in ``field_values`` is matched to an Activity_Field via
    :func:`match_field_value` (exact, case-insensitive, whitespace-trimmed
    against ``field_id`` then ``label``, preferring the field-id match). A
    :class:`FillOperation` is produced only for the fields that a key matched —
    fields with no corresponding key are never included, so the interaction
    layer leaves them at their existing value. The resulting operations are
    returned in ascending ``dom_order`` so the fields are processed in their DOM
    order within ``form#userUpdatesMap``.

    Keys that match no Activity_Field are ignored here (the interaction layer is
    responsible for raising the unmatched-key error per Requirement 4.7); this
    keeps the plan builder total. When more than one key resolves to the same
    Activity_Field, a single operation is produced for that field, with the
    value of the last such key in iteration order.

    Args:
        fields: The Activity_Fields scraped from ``form#userUpdatesMap``.
        field_values: The caller-supplied mapping of values, keyed by field id
            or field label.

    Returns:
        A list of :class:`FillOperation` for the matched fields only, ordered by
        ascending ``field.dom_order``.

    Validates Requirements 4.1, 4.8.
    """
    matched: dict[ActivityField, str] = {}
    for key, value in field_values.items():
        field = match_field_value(key, fields)
        if field is not None:
            matched[field] = value

    ordered_fields = sorted(matched, key=lambda f: f.dom_order)
    return [FillOperation(field=field, value=matched[field]) for field in ordered_fields]


def match_timeline_items(
    items: list[TimelineItem],
    activity_name: str,
) -> list[TimelineItem]:
    """Select the Timeline_Items matching a requested Activity_Name.

    A Timeline_Item matches when its ``subtitle``, after trimming leading and
    trailing whitespace, equals the requested ``activity_name`` under a
    case-insensitive comparison (via :func:`normalize`). The matching items are
    returned in their original document order (top-to-bottom), so the first
    element of the result is the top-most matching item.

    Args:
        items: The Timeline_Items scraped from the Timeline, in document order.
        activity_name: The requested Activity_Name, possibly with case or
            surrounding-whitespace differences.

    Returns:
        The matching Timeline_Items in document order; an empty list when none
        match.

    Validates Requirements 6.2, 6.3.
    """
    normalized_name = normalize(activity_name)
    return [item for item in items if normalize(item.subtitle) == normalized_name]


def select_most_recent(matches: list[TimelineItem]) -> TimelineItem | None:
    """Select the Most_Recent_Item from a list of matching Timeline_Items.

    The Most_Recent_Item is the top-most matching item, i.e. the one with the
    smallest ``index``. This is robust to the input ordering: rather than
    assuming ``matches`` is already sorted, the minimum-index item is selected
    explicitly.

    Args:
        matches: The matching Timeline_Items (e.g. from
            :func:`match_timeline_items`).

    Returns:
        The Timeline_Item with the smallest ``index`` when ``matches`` is
        non-empty; ``None`` when ``matches`` is empty.

    Validates Requirements 6.3.
    """
    if not matches:
        return None
    return min(matches, key=lambda item: item.index)


def filter_enabled_tabs(tabs: list[DetailTab]) -> list[DetailTab]:
    """Filter the Enabled_Tabs from an Activity_Details_Modal tab strip.

    A Detail_Tab is enabled when its ``disabled`` flag is ``False`` (its
    ``<li>`` does not carry the ``disabled`` class). The enabled tabs are
    returned in their original left-to-right tab-strip order; disabled tabs are
    excluded. The result is empty when every tab is disabled.

    Args:
        tabs: The Detail_Tabs scraped from ``ul.nav.nav-tabs#detailTabs``, in
            left-to-right order.

    Returns:
        The enabled Detail_Tabs in left-to-right order.

    Validates Requirements 8.4, 8.7.
    """
    return [tab for tab in tabs if not tab.disabled]
