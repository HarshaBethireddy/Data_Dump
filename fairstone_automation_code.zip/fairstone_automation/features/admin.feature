# features/admin.feature
# ─────────────────────────────────────────────────────────────────────
# Admin navigation, Admin popover, and Reference Interfaces CRUD.
#
# Screenshot trail per option (prefix = option name with spaces → _):
#   {prefix}_selected            dropdown option selected
#   {prefix}_add_modal_open      Add modal just opened
#   {prefix}_add_filled          Add modal fields filled
#   {prefix}_add_saved           after Save clicked in Add modal
#   {prefix}_add_verified        new row confirmed in grid
#   {prefix}_edit_modal_open     Edit modal just opened
#   {prefix}_edit_filled         Edit modal fields updated
#   {prefix}_edit_saved          after Save clicked in Edit modal
#   {prefix}_edit_verified       updated row confirmed in grid
#   {prefix}_delete_modal_open   modal opened for delete
#   {prefix}_delete_confirmed    after Delete clicked
#   {prefix}_delete_verified     row confirmed gone from grid
# ─────────────────────────────────────────────────────────────────────

@admin
Feature: Admin Navigation and Reference Interfaces CRUD

  As a Collections administrator
  I want to access Reference Interfaces via the Admin nav
  So that I can manage reference data records

  Background:
    Given I am logged in to the Collections application

  # ──────────────────────────────────────────────────────────────
  # Navigation — generic nav click by label
  # ──────────────────────────────────────────────────────────────

  # @smoke
  # Scenario: All primary nav items can be clicked by label
  #   When I click the "Admin" nav item
  #   Then the Admin popover should be open

  @smoke
  Scenario: Admin popover shows Reference Interfaces and Teams
    When I click the "Admin" nav item
    Then the Admin popover should be open

  # ──────────────────────────────────────────────────────────────
  # Reference Interfaces — full CRUD for Bankruptcy Types
  # ──────────────────────────────────────────────────────────────

  @smoke
  Scenario: Navigate to Reference Interfaces page via Admin popover
    When I click the "Admin" nav item
    And I click "Reference Interfaces" in the Admin popover
    Then I should be on the Reference Interfaces page

  @smoke
  Scenario: Select Bankruptcy Types and perform full Add, Edit, Delete cycle
    When I click the "Admin" nav item
    And I click "Reference Interfaces" in the Admin popover
    Then I should be on the Reference Interfaces page

    # ── SELECT TYPE ──────────────────────────────────────────────
    When I select reference type "Bankruptcy Types"
    # screenshot: BankruptcyTypes_selected

    # ── ADD ──────────────────────────────────────────────────────
    When I click the Add button on the Reference Interfaces page
    # screenshot: Bankruptcy_Types_add_modal_open
    And I fill the Add modal field "Code" with "SET"
    And I fill the Add modal field "Description" with "Test Bankruptcy Type"
    And I save the Add modal
    # screenshot: Bankruptcy_Types_add_saved
    Then the record with code "SET" should be present in the grid
    # screenshot: Bankruptcy_Types_add_verified

    # ── EDIT ─────────────────────────────────────────────────────
    When I open the Edit modal for code "SET"
    # screenshot: Bankruptcy_Types_edit_modal_open
    And I fill the Edit modal field "Description" with "Updated Bankruptcy Type"
    And I save the Edit modal
    # screenshot: Bankruptcy_Types_edit_saved
    Then the record with code "SET" should show description "Updated Bankruptcy Type"

    # ── DELETE ───────────────────────────────────────────────────
    When I open the Delete modal for code "SET"
    # screenshot: Bankruptcy_Types_delete_modal_open
    And I click Delete in the modal
    # screenshot: Bankruptcy_Types_delete_confirmed
    Then the record with code "SET" should not be present in the grid
    # screenshot: Bankruptcy_Types_delete_verified

  # @regression
  # Scenario Outline: Add, Edit, Delete cycle for different reference types
  #   When I click the "Admin" nav item
  #   And I click "Reference Interfaces" in the Admin popover
  #   Then I should be on the Reference Interfaces page

  #   When I select reference type "<option>"
  #   When I click the Add button on the Reference Interfaces page
  #   And I fill the Add modal field "Code" with "<code>"
  #   And I fill the Add modal field "Description" with "<description>"
  #   And I save the Add modal
  #   Then the record with code "<code>" should be present in the grid

  #   When I open the Edit modal for code "<code>"
  #   And I fill the Edit modal field "Description" with "<updated_desc>"
  #   And I save the Edit modal
  #   Then the record with code "<code>" should show description "<updated_desc>"

  #   When I open the Delete modal for code "<code>"
  #   And I click Delete in the modal
  #   Then the record with code "<code>" should not be present in the grid

  #   Examples:
  #     | option          | code | description       | updated_desc          |
  #     | Bankruptcy Types | BNK1 | Test BNK          | Updated BNK           |
  #     | Product          | PRD1 | Test Product      | Updated Product       |

  # @regression
  # Scenario: Cancel Add modal discards changes
  #   When I click the "Admin" nav item
  #   And I click "Reference Interfaces" in the Admin popover
  #   Then I should be on the Reference Interfaces page
  #   When I select reference type "Bankruptcy Types"
  #   And I click the Add button on the Reference Interfaces page
  #   And I fill the Add modal field "Code" with "CANCEL_TEST"
  #   And I cancel the modal
  #   Then the record with code "CANCEL_TEST" should not be present in the grid
