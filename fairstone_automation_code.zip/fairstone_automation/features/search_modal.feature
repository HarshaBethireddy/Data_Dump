# features/search_modal.feature
# ─────────────────────────────────────────────────────────────────────
# Search Modal — 5 tabs, each with screenshot before fill, after fill,
# and after clicking Search.  Partial inputs are supported.
#
# Screenshot contract per scenario:
#   1. Clicking a tab             → auto-screenshot (before fill)
#   2. "I take a screenshot of …" → screenshot       (after fill)
#   3. "I submit the search modal"→ auto-screenshot (after Search click)
#
# Destination pages:
#   Account Search             → Customer Overview page
#   Advanced Account Search    → Customer Overview page
#   Customer Search            → Customer Overview page
#   Contact Search             → Person Profile page
#   Contact Search FS          → Person Profile page
# ─────────────────────────────────────────────────────────────────────

@search_modal
Feature: Search Modal — All Tabs

  As a Collections agent
  I want to use the Search modal to find accounts and customers
  So that I can navigate to the correct Customer Overview or Person Profile

  Background:
    Given I am logged in to the Collections application
    And I click the Search nav button
    Then the search modal should be open

  # ──────────────────────────────────────────────────────────────
  # TAB 0 — Account Search
  # ──────────────────────────────────────────────────────────────

  @smoke
  Scenario: Account Search — search by exact account number
    When I click the "Account Search" tab in the search modal
    When I fill field "Account Number" with "6030491001289802" in the modal
    And I submit the search modal
    Then I should be on the Customer Overview page

  @smoke
  Scenario: Account Search — search by phone number only (partial input)
    When I click the "Account Search" tab in the search modal
    When I fill field "Phone Number" with "2047220222" in the modal
    And I submit the search modal
    Then I should be on the Customer Overview page

  @regression
  Scenario: Account Search — search with both account number and phone number
    When I click the "Account Search" tab in the search modal
    When I fill field "Account Number" with "6030491001289802" in the modal
    And I fill field "Phone Number" with "2047220222" in the modal
    And I submit the search modal
    Then I should be on the Customer Overview page

  # ──────────────────────────────────────────────────────────────
  # TAB 1 — Advanced Account Search
  # ──────────────────────────────────────────────────────────────

  @smoke
  Scenario: Advanced Account Search — search by account number
    When I click the "Advanced Account Search" tab in the search modal
    When I fill field "Account Number" with "6030491001289802" in the modal
    When I fill field "SIN" with "130463693" in the modal
    When I fill field "First Name" with "YMLNDRY" in the modal
    When I fill field "Last Name" with "LND" in the modal
    When I fill field "Phone Number" with "2047220222" in the modal
    When I fill field "City" with "WINNIPEG" in the modal
    When I fill field "Province" with "MB" in the modal
    When I fill field "Postal Code" with "R2M0S7" in the modal
    When I fill field "Address Line 1" with "888 WKNGSTNR KNG" in the modal
    And I submit the search modal
    Then I should be on the Customer Overview page
 
  # ──────────────────────────────────────────────────────────────
  # TAB 2 — Customer Search
  # ──────────────────────────────────────────────────────────────
 
  @regression
  Scenario: Customer Search — search by customer number
    When I click the "Customer Search" tab in the search modal 
    When I fill field "Customer Number" with "eLLgZZZJxVbh" in the modal
    And I submit the search modal
    Then I should be on the Customer Overview page
