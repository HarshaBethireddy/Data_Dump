# features/navigation.feature
# ──────────────────────────────────────────────────────────────
# Header navigation & caselist scenarios.
# ──────────────────────────────────────────────────────────────

@caselist
Feature: Collections Navigation

  As a Collections agent
  I want to navigate between key sections of the application
  So that I can efficiently manage my cases

  Background:
    Given I am logged in to the Collections application

  @smoke
  Scenario: Header navigation items are visible on home page
    Then the "Search" nav item should be visible
    And the "Load Next" nav item should be visible
    And the "View Caselists" nav item should be visible

  @smoke
  Scenario: Notification bell shows pending cases count
    Then the notification bell should be visible
    And the notification count should be displayed

  @regression
  Scenario: User can switch language to French
    When I open the user menu
    And I select the language "Français"
    Then the language should be set to "Français"
