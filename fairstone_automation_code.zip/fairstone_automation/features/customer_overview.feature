# features/customer_overview.feature

@customer_overview
Feature: Customer Overview Page

  As a Collections agent
  I want the Customer Overview page to load when I search an exact account number
  So that I can review the customer and navigate to their specific account

  Background:
    Given I am logged in to the Collections application

  # @smoke
  # Scenario: Exact account number navigates to Customer Overview
  #   When I search for exact account number "6030491001289802"
  #   Then I should be on the Customer Overview page

  # @smoke
  # Scenario: Customer name heading and account list are visible
  #   When I search for exact account number "6030491001289802"
  #   Then I should be on the Customer Overview page
  #   And the customer name heading should be visible
  #   And the account list should be visible

  # @smoke
  # Scenario: Tertiary navigation tabs are present
  #   When I search for exact account number "6030491001289802"
  #   Then I should be on the Customer Overview page
  #   And the tertiary navigation tabs should be present

  # @smoke
  # Scenario: Clicking the matching account opens Account Activity page
  #   When I search for exact account number "6030491001289802"
  #   Then I should be on the Customer Overview page
  #   And the account list should contain account "6030491001289802"
  #   When I click the matching account in the account list
  #   Then I should be on the Account Activity page

  # @regression
  # Scenario: Activities tab shows the activity list in the sidebar
  #   When I search for exact account number "6030491001289802"
  #   Then I should be on the Customer Overview page
  #   When I click the Activities tab in the sidebar
  #   Then the activity list should be visible in the sidebar

  # @regression
  # Scenario: Direct parent activity opens the activity iframe
  #   When I search for exact account number "6030491001289802"
  #   Then I should be on the Customer Overview page
  #   When I click the Activities tab in the sidebar
  #   And I click the parent activity "Do Not Call"
  #   And I wait for the activity iframe to load
  #   Then the activity iframe should be loaded

  # @regression
  # Scenario: Child activity opens the activity iframe after expanding parent
  #   When I search for exact account number "6030491001289802"
  #   Then I should be on the Customer Overview page
  #   When I click the Activities tab in the sidebar
  #   And I expand parent activity "Inbound Phone Call Finished" and click child "Contact with Customer"
  #   And I wait for the activity iframe to load
  #   Then the activity iframe should be loaded

  # @regression
  # Scenario: Agent can switch the right-panel view
  #   When I search for exact account number "6030491001289802"
  #   Then I should be on the Customer Overview page
  #   When I switch the Customer Overview view to "Customer Decisioning"
  #   Then I should still be on the Customer Overview page

  # @regression
  # Scenario: Full activity flow from Customer Overview - trigger, submit, verify and drill into details
  #   When I search for exact account number "6030491001289802"
  #   Then I should be on the Customer Overview page
  #   When I click the Activities tab in the sidebar
  #   And I trigger the activity "Do Not Call"
  #   Then the activity iframe variant should be "confirmation"
  #   When I submit the activity
  #   Then the activity "Do Not Call" should appear in the timeline
  #   When I open the activity details modal for "Do Not Call"
  #   And I iterate every enabled tab in the activity details for "Do Not Call"

  # @regression
  # Scenario: Full activity flow from Customer Overview - trigger, submit, verify and drill into details
  #   When I search for exact account number "6030491230004550"
  #   Then I should be on the Customer Overview page
  #   When I click the Activities tab in the sidebar
  #   And I trigger the activity "Manage Customer Exceptions" with child "Report Complaint"
  #   Then the activity iframe variant should be "inputs"
  #   When I fill the activity input "B1" with "Test Report Complaint"
  #   And I submit the activity
  #   Then the activity "Report Complaint" should appear in the timeline
  #   When I open the activity details modal for "Report Complaint"
  #   And I iterate every enabled tab in the activity details for "Report Complaint"
  #   And I trigger the activity "Manage Customer Exceptions" with child "Resolve Complaint"
  #   When I fill the activity input "B1" with "Test Resolve Complaint"
  #   And I submit the activity
  #   Then the activity "Resolve Complaint" should appear in the timeline
  #   When I open the activity details modal for "Resolve Complaint"
  #   And I iterate every enabled tab in the activity details for "Resolve Complaint"

  
  # @regression
  # Scenario Outline: Full activity flow from Customer Overview - trigger, submit, verify and drill into details

  #   When I search for exact account number "<account>"
  #   Then I should be on the Customer Overview page

  #   When I click the Activities tab in the sidebar
  #   And I trigger the activity "<parent_activity>" with child "<child_activity>"
  #   Then the activity iframe variant should be "<variation>"
  #   When I fill the activity input "<label_id>" with "<input>"
  #   And I submit the activity

  #   Then the activity "<child_activity>" should appear in the timeline

  #   When I open the activity details modal for "<child_activity>"
  #   And I iterate every enabled tab in the activity details for "<child_activity>"

  # Examples:
  #   | account          | parent_activity                   | child_activity               | variation  | label_id | input                     |
  #   | 6030491230001457 | Manage Customer Exceptions        | Report Complaint             | inputs     | B1       | Test Report Complaint     |
  #   | 6030491230001457 | Manage Customer Exceptions        | Resolve Complaint            | inputs     | B1       | Test Resolve Complaint    |
  #   | 6030491230001457 | Manage Customer Exceptions        | Report Bankrupt              | inputs     | B1       | Test Report Bankrupt      |


  @regression
  Scenario Outline: Full activity flow from Customer Overview - 

    When I search for exact account number "<account>"
    Then I should be on the Customer Overview page

    When I click the Activities tab in the sidebar
    And I trigger the activity "<parent_activity>" with child "<child_activity>"
    Then the activity iframe variant should be "<variation>"
    When I fill the activity input "<label_id>" with "<input>"
    And I submit the activity

    Then the activity "<child_activity>" should appear in the timeline

    When I open the activity details modal for "<child_activity>"
    And I iterate every enabled tab in the activity details for "<child_activity>"

  Examples:
    | account          | parent_activity                   | child_activity               | variation  | label_id | input                     |
    | 6030491230001457 | Manage Customer Exceptions        | Report Complaint             | inputs     | B1       | Test Report Complaint     |
    | 6030491230001457 | Manage Customer Exceptions        | Resolve Complaint            | inputs     | B1       | Test Resolve Complaint    |
    | 6030491230001457 | Manage Customer Exceptions        | Report Bankrupt              | inputs     | B1       | Test Report Bankrupt      |
    | 6030491230001457 | Manage Customer Exceptions        | Remove Bankrupt              | inputs     | B1       | Test Remove Bankrupt      |
    | 6030491230001457 | Manage Customer Exceptions        | Report Deregistered          | inputs     | B1       | Test Report Deregistered  |
    | 6030491230001457 | Manage Customer Exceptions        | Remove Deregistered          | inputs     | B1       | Test Remove Deregistered  |
    # Different Acc -> Confirm Deregistered, Remove Deregistered
    | 6030491230001457 | Manage Customer Exceptions        | Report Deregistered          | inputs     | B1       | Test Report Deregistered  |
    | 6030491230001457 | Manage Customer Exceptions        | Confirm Deregistered         | inputs     | B1       | Test Confirm Deregistered |
    | 6030491230001457 | Manage Customer Exceptions        | Report Fraud                 | inputs     | B1       | Test Report Fraud         |
    | 6030491230001457 | Manage Customer Exceptions        | Remove Fraud                 | inputs     | B1       | Test Remove Fraud         |
    | 6030491230001457 | Manage Customer Exceptions        | Report Fraud                 | inputs     | B1       | Test Report Fraud         |
    | 6030491230001457 | Manage Customer Exceptions        | Confirm Fraud                | inputs     | B1       | Test Confirm Fraud        |
    | 6030491230001457 | Manage Customer Exceptions        | Report Insolvent             | inputs     | B1       | Test Report Insolvent     |
    | 6030491230001457 | Manage Customer Exceptions        | Remove Insolvent             | inputs     | B1       | Test Remove Insolvent     |
    | 6030491230001457 | Manage Customer Exceptions        | Report Insolvent             | inputs     | B1       | Test Report Insolvent     |
    | 6030491230001457 | Manage Customer Exceptions        | Confirm Insolvent            | inputs     | B1       | Test Confirm Insolvent    |
    | 6030491230001457 | Manage Customer Exceptions        | Report Ombudsman             | inputs     | B1       | Test Report Ombudsman     |
    | 6030491230001457 | Manage Customer Exceptions        | Resolve Ombudsman            | inputs     | B1       | Test Resolve Ombudsman    |
    | 6030491230001457 | Manage Customer Exceptions        | Report Other Exception       | inputs     | B1       | Test Report Other Exception|
    | 6030491230001457 | Manage Customer Exceptions        | Remove Other Exception       | inputs     | B1       | Test Remove Other Exception|
    | 6030491230001457 | Manage Customer Exceptions        | Report Skip Trace            | inputs     | B1       | Test Report Skip Trace    |
    | 6030491230001457 | Manage Customer Exceptions        | Remove Skip Trace            | inputs     | B1       | Test Remove Skip Trace    |







  @regression
  Scenario: Full activity flow from Customer Overview - trigger, submit, verify and drill into details
    When I search for exact account number "6030491230004550"
    Then I should be on the Customer Overview page
    When I click the Activities tab in the sidebar
    And I trigger the activity "Manage Customer Exceptions" with child "Report Fraud"
    Then the activity iframe variant should be "inputs"
    When I fill the activity input "B1" with "Test Report Fraud"
    And I submit the activity
    Then the activity "Report ComplFraudaint" should appear in the timeline
    When I open the activity details modal for "Report Fraud"
    And I iterate every enabled tab in the activity details for "Report Fraud"
    And I trigger the activity "Manage Customer Exceptions" with child "Remove Fraud"
    And I submit the activity
    Then the activity "Remove Fraud" should appear in the timeline
    When I open the activity details modal for "Remove Fraud"
    And I iterate every enabled tab in the activity details for "Remove Fraud"