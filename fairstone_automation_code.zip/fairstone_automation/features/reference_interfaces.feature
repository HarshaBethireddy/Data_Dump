# features/reference_interfaces.feature
# ─────────────────────────────────────────────────────────────────────
# Reference Interfaces — full Add → Search/Verify → Edit → Delete (CRUD)
# lifecycle, one self-contained scenario per in-scope Reference_Type, plus
# a Cancel-path scenario.
#
# Each CRUD scenario is independent (Req 8.7): it logs in (Background),
# navigates Admin → Reference Interfaces popover, selects its own type, then
# runs the fixed-order cycle Add → Verify → Edit → Delete (Req 8.2). Every
# cycle deletes the exact record it created, cleaning up its own data
# (Req 6, 8.5).
#
# Screenshot trail per option (prefix = option name with spaces → _):
#   {prefix}_selected            dropdown option selected
#   {prefix}_add_modal_open      Add modal just opened
#   {prefix}_add_filled          Add modal fields filled
#   {prefix}_add_saved           after Save clicked in Add modal
#   {prefix}_add_verified        new row confirmed in grid
#   {prefix}_edit_modal_open     Edit modal just opened
#   {prefix}_edit_filled         Edit modal fields updated
#   {prefix}_edit_saved          after Save clicked in Edit modal
#   {prefix}_edit_verified       updated row confirmed in grid
#   {prefix}_delete_modal_open   modal opened for delete
#   {prefix}_delete_confirmed    after Delete clicked
#   {prefix}_delete_verified     row confirmed gone from grid
#   {prefix}_cancel              cancelled Add modal state
# ─────────────────────────────────────────────────────────────────────

@admin
Feature: Reference Interfaces full CRUD per reference type

  As a Collections administrator
  I want a complete Add, Verify, Edit, Delete cycle for each reference type
  So that the suite mirrors and improves on the Java reference behaviour

  Background:
    Given I am logged in to the Collections application

  # ──────────────────────────────────────────────────────────────
  # Product Types (dropdown option "Product")
  # ──────────────────────────────────────────────────────────────

  @admin @regression
  Scenario: Product Types full CRUD cycle
    When I click the "Admin" nav item
    And I click "Reference Interfaces" in the Admin popover
    Then I should be on the Reference Interfaces page
    When I select reference type "Product"
    # ── ADD ──────────────────────────────────────────────────────
    When I click the Add button on the Reference Interfaces page
    And I fill the Add modal field "Code" with "TST"
    And I fill the Add modal field "Description" with "Test Product Type"
    And I save the Add modal
    # ── SEARCH / VERIFY (the Java-reference improvement) ──────────
    Then the added record should be present with its entered description
    # ── EDIT ─────────────────────────────────────────────────────
    When I open the Edit modal for code "TST"
    And I fill the Edit modal field "Description" with "Updated Product Type"
    And I save the Edit modal
    Then the edited record should show the updated description
    # ── DELETE (self-cleanup of the same code) ───────────────────
    When I delete the record that was added
    Then the deleted record should be absent from the grid

  # # ──────────────────────────────────────────────────────────────
  # # Branch Update
  # # ──────────────────────────────────────────────────────────────

  # @admin @regression
  # Scenario: Branch Update full CRUD cycle
  #   When I click the "Admin" nav item
  #   And I click "Reference Interfaces" in the Admin popover
  #   Then I should be on the Reference Interfaces page
  #   When I select reference type "Branch Update"
  #   # ── ADD ──────────────────────────────────────────────────────
  #   When I click the Add button on the Reference Interfaces page
  #   And I fill the Add modal field "Code" with "BRU1"
  #   And I fill the Add modal field "Description" with "Test Branch Update"
  #   And I save the Add modal
  #   # ── SEARCH / VERIFY ──────────────────────────────────────────
  #   Then the added record should be present with its entered description
  #   # ── EDIT ─────────────────────────────────────────────────────
  #   When I open the Edit modal for code "BRU1"
  #   And I fill the Edit modal field "Description" with "Updated Branch Update"
  #   And I save the Edit modal
  #   Then the edited record should show the updated description
  #   # ── DELETE ───────────────────────────────────────────────────
  #   When I delete the record that was added
  #   Then the deleted record should be absent from the grid

  # # ──────────────────────────────────────────────────────────────
  # # Bankruptcy Types
  # # ──────────────────────────────────────────────────────────────

  # @admin @regression
  # Scenario: Bankruptcy Types full CRUD cycle
  #   When I click the "Admin" nav item
  #   And I click "Reference Interfaces" in the Admin popover
  #   Then I should be on the Reference Interfaces page
  #   When I select reference type "Bankruptcy Types"
  #   # ── ADD ──────────────────────────────────────────────────────
  #   When I click the Add button on the Reference Interfaces page
  #   And I fill the Add modal field "Code" with "BNK1"
  #   And I fill the Add modal field "Description" with "Test Bankruptcy Type"
  #   And I save the Add modal
  #   # ── SEARCH / VERIFY ──────────────────────────────────────────
  #   Then the added record should be present with its entered description
  #   # ── EDIT ─────────────────────────────────────────────────────
  #   When I open the Edit modal for code "BNK1"
  #   And I fill the Edit modal field "Description" with "Updated Bankruptcy Type"
  #   And I save the Edit modal
  #   Then the edited record should show the updated description
  #   # ── DELETE ───────────────────────────────────────────────────
  #   When I delete the record that was added
  #   Then the deleted record should be absent from the grid

  # # ──────────────────────────────────────────────────────────────
  # # Update Disaster Codes (dropdown option "UpdateDisasterCodes")
  # # ──────────────────────────────────────────────────────────────

  # @admin @regression
  # Scenario: Update Disaster Codes full CRUD cycle
  #   When I click the "Admin" nav item
  #   And I click "Reference Interfaces" in the Admin popover
  #   Then I should be on the Reference Interfaces page
  #   When I select reference type "UpdateDisasterCodes"
  #   # ── ADD ──────────────────────────────────────────────────────
  #   When I click the Add button on the Reference Interfaces page
  #   And I fill the Add modal field "Code" with "DIS1"
  #   And I fill the Add modal field "Description" with "Test Disaster Code"
  #   And I save the Add modal
  #   # ── SEARCH / VERIFY ──────────────────────────────────────────
  #   Then the added record should be present with its entered description
  #   # ── EDIT ─────────────────────────────────────────────────────
  #   When I open the Edit modal for code "DIS1"
  #   And I fill the Edit modal field "Description" with "Updated Disaster Code"
  #   And I save the Edit modal
  #   Then the edited record should show the updated description
  #   # ── DELETE ───────────────────────────────────────────────────
  #   When I delete the record that was added
  #   Then the deleted record should be absent from the grid

  # # ──────────────────────────────────────────────────────────────
  # # Solution Parameters
  # # ──────────────────────────────────────────────────────────────

  # @admin @regression
  # Scenario: Solution Parameters full CRUD cycle
  #   When I click the "Admin" nav item
  #   And I click "Reference Interfaces" in the Admin popover
  #   Then I should be on the Reference Interfaces page
  #   When I select reference type "Solution Parameters"
  #   # ── ADD ──────────────────────────────────────────────────────
  #   When I click the Add button on the Reference Interfaces page
  #   And I fill the Add modal field "Code" with "SOL1"
  #   And I fill the Add modal field "Description" with "Test Solution Parameter"
  #   And I save the Add modal
  #   # ── SEARCH / VERIFY ──────────────────────────────────────────
  #   Then the added record should be present with its entered description
  #   # ── EDIT ─────────────────────────────────────────────────────
  #   When I open the Edit modal for code "SOL1"
  #   And I fill the Edit modal field "Description" with "Updated Solution Parameter"
  #   And I save the Edit modal
  #   Then the edited record should show the updated description
  #   # ── DELETE ───────────────────────────────────────────────────
  #   When I delete the record that was added
  #   Then the deleted record should be absent from the grid

  # # ──────────────────────────────────────────────────────────────
  # # Cancel path — Add modal cancelled, no record persisted (Req 7)
  # # ──────────────────────────────────────────────────────────────

  # @admin @regression
  # Scenario: Cancel Add modal discards changes
  #   When I click the "Admin" nav item
  #   And I click "Reference Interfaces" in the Admin popover
  #   Then I should be on the Reference Interfaces page
  #   When I select reference type "Bankruptcy Types"
  #   And I click the Add button on the Reference Interfaces page
  #   And I cancel the Add modal entering code "CANCEL1"
  #   Then the record with code "CANCEL1" should not be present in the grid
