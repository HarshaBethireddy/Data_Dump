# features/screens.feature
# ──────────────────────────────────────────────────────────────
# All screen scenarios for the Collections application.
# Compatible with Python + Playwright + BDD without Rule blocks.
# ──────────────────────────────────────────────────────────────

@screens
Feature: Collections Screens

  Background:
    Given I am logged in to the Collections application

  # ──────────────────────────────────────────────────────────────
  # Home Page Screen
  # ──────────────────────────────────────────────────────────────

  @regression @home
  Scenario: Search returns results for a valid account number
    When I search for exact account number "6030491001289802"
    Then I should be on the Customer Overview page

  @regression @home
  Scenario: Search shows no-match alert for an unknown account number
    When I search for account number "123"
    Then a "No matches found" alert should be displayed
    And the alert body should say "Please amend your search."

  @regression @home
  Scenario: Search button is disabled with no input
    Then the Search button should be disabled

  @regression @home
  Scenario: Pagination is visible for large result sets
    When I search for account number "60%"
    Then the search results grid should be displayed
    And pagination stats should be visible
    And I should be able to navigate to the next page

  @regression @home
  Scenario Outline: Search with different account numbers
    When I search for account number "<account>"
    Then the search outcome should be "<outcome>"

    Examples:
      | account | outcome  |
      | 60%     | results  |
      | 0%      | results  |
      | 234     | no_match |

  @regression @home
  Scenario: User can change rows-per-page in results
    When I search for account number "60%"
    Then the search results grid should be displayed
    When I set rows per page to "20"
    Then the grid should display up to 20 rows


  # ──────────────────────────────────────────────────────────────
  # Person Profile Page
  # ──────────────────────────────────────────────────────────────

  @regression @person_profile
  Scenario: Navigate to Person Profile page from Customer Overview
    When I search for exact account number "6030491001289802"
    Then I should be on the Customer Overview page
    When I open the Person Profile page from Customer Overview
    Then I should be on the Person Profile page
    And the Person Profile tab should be active
    And the Contact Details section should be visible
    When I expand all Person Profile contact panels
    Then all contact detail panels should be visible

  @regression @person_profile
  Scenario: Expand Contact Address panel
    When I search for exact account number "6030491001289802"
    Then I should be on the Customer Overview page
    When I open the Person Profile page from Customer Overview
    Then I should be on the Person Profile page
    When I expand the "Contact Address" panel in Person Profile
    Then the "Contact Address" panel should be expanded

  @regression @person_profile
  Scenario: Expand Contact Email panel
    When I search for exact account number "6030491001289802"
    Then I should be on the Customer Overview page
    When I open the Person Profile page from Customer Overview
    Then I should be on the Person Profile page
    When I expand the "Contact Email" panel in Person Profile
    Then the "Contact Email" panel should be expanded

  @regression @person_profile
  Scenario: Expand Contact Phone panel
    When I search for exact account number "6030491001289802"
    Then I should be on the Customer Overview page
    When I open the Person Profile page from Customer Overview
    Then I should be on the Person Profile page
    When I expand the "Contact Phone" panel in Person Profile
    Then the "Contact Phone" panel should be expanded


  # ──────────────────────────────────────────────────────────────
  # Account Details Screen
  # ──────────────────────────────────────────────────────────────

  @regression @account_details
  Scenario: Account activity page loads with relevant accordions
    When I search for exact account number "6030491230001689"
    Then I should be on the Customer Overview page
    And the account list should contain account "6030491230001689"
    When I click the matching account in the account list
    Then I should be on the Account Activity page
    And the active tab should correspond to the clicked account
    And the Account and Activity History action buttons should be visible
    And the calendar widget should be visible
    And these accordions should be visible: "Customer Overview, Payments, Re-Age, Exceptions, Treatment"