# features/person_profile.feature

@person_profile
Feature: Person Profile Page

  As a Collections agent
  I want to open the Person Profile page from Customer Overview
  So that I can review and verify the customer contact details

  Background:
    Given I am logged in to the Collections application
    And I search for exact account number "6030491001289802"
    And I should be on the Customer Overview page

  @regression
  Scenario: Navigate to Person Profile page from Customer Overview
    When I open the Person Profile page from Customer Overview
    Then I should be on the Person Profile page
    And the Person Profile tab should be active
    And the Contact Details section should be visible
    When I expand all Person Profile contact panels
    And all contact detail panels should be visible

    
  @regression
  Scenario: Expand Contact Address panel
    When I open the Person Profile page from Customer Overview
    Then I should be on the Person Profile page
    When I expand the "Contact Address" panel in Person Profile
    Then the "Contact Address" panel should be expanded

  @regression
  Scenario: Expand Contact Email panel
    When I open the Person Profile page from Customer Overview
    Then I should be on the Person Profile page
    When I expand the "Contact Email" panel in Person Profile
    Then the "Contact Email" panel should be expanded

  @regression
  Scenario: Expand Contact Phone panel
    When I open the Person Profile page from Customer Overview
    Then I should be on the Person Profile page
    When I expand the "Contact Phone" panel in Person Profile
    Then the "Contact Phone" panel should be expanded