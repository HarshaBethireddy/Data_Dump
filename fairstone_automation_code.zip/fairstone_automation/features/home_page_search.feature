# features/search.feature
# ──────────────────────────────────────────────────────────────
# All account-search scenarios for the Collections application.
# ──────────────────────────────────────────────────────────────

@home
Feature: Collections Account Search

  As a Collections agent
  I want to search for accounts by account number or phone number
  So that I can view and action the correct customer's case

  Background:
    Given I am logged in to the Collections application

  @regression
  Scenario: Search returns results for a valid account number
    When I search for exact account number "6030491001289802"
    Then I should be on the Customer Overview page

  @regression
  Scenario: Search shows no-match alert for an unknown account number
    When I search for account number "123"
    Then a "No matches found" alert should be displayed
    And the alert body should say "Please amend your search."

  # @regression
  # Scenario: Search button is disabled with no input
  #   Then the Search button should be disabled

  @regression
  Scenario: Pagination is visible for large result sets
    When I search for account number "60%"
    Then the search results grid should be displayed
    And pagination stats should be visible
    And I should be able to navigate to the next page

  @regression
  Scenario Outline: Search with different account numbers
    When I search for account number "<account>"
    Then the search outcome should be "<outcome>"

    Examples:
      | account     | outcome      |
      | 60%         | results      |
      | 0%          | results      |
      | 234         | no_match     |

  @regression
  Scenario: User can change rows-per-page in results
    When I search for account number "60%"
    Then the search results grid should be displayed
    When I set rows per page to "20"
    Then the grid should display up to 20 rows
