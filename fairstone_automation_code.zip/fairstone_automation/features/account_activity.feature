# features/account_activity.feature
# Shared steps (Activities + Accordion) use the SAME text as customer_overview.feature
# — no "on the account page" suffixes needed.

@account_activity
Feature: Account Activity Page

  As a Collections agent
  I want to open a specific account from the Customer Overview page
  So that I can review and action the account-level details

  Background:
    Given I am logged in to the Collections application
    And I search for exact account number "6030491230001689"
    And I should be on the Customer Overview page
    And the account list should contain account "6030491230001689"
    And I click the matching account in the account list
    And I should be on the Account Activity page
  
  # @regression
  # Scenario: Account activity page loads with relevant accordions
  #   Then the active tab should correspond to the clicked account
  #   Then the Account and Activity History action buttons should be visible
  #   Then the calendar widget should be visible
  #   Then these accordions should be visible: "Customer Overview, Payments, Delinquency Information, Arrangement Details, Recent Communication, Re-Age, Exceptions, Treatment"

  # @regression
  # Scenario: Full activity flow from Account Activity - trigger child, submit, verify and drill into details
  #   When I click the Activities tab in the sidebar
  #   And I trigger the activity "Outbound Phone Call Finished" with child "RP - Promise To Pay"
  #   When I submit the activity
  #   Then the activity "RP - Promise To Pay" should appear in the timeline
  #   When I open the activity details modal for "RP - Promise To Pay"
  #   And I iterate every enabled tab in the activity details for "RP - Promise To Pay"

  # @smoke
  # Scenario: Account Activity page loads with the correct account in the tab
  #   Then the active tab should correspond to the clicked account

  # @smoke
  # Scenario: Action buttons are visible
  #   Then the Account and Activity History action buttons should be visible

  # @smoke
  # Scenario: Calendar widget is visible by default
  #   Then the calendar widget should be visible

  # @smoke
  # Scenario: All expected accordion sections are present
  #   Then these accordions should be visible: "Customer Overview, Payments, Delinquency Information, Treatment"

  # @regression
  # Scenario: Agent can scroll to each accordion and see a screenshot
  #   When I scroll to the "Customer Overview" accordion
  #   Then the "Customer Overview" accordion should be visible
  #   When I scroll to the "Payments" accordion
  #   Then the "Payments" accordion should be visible
  #   When I scroll to the "Delinquency Information" accordion
  #   Then the "Delinquency Information" accordion should be visible
  #   When I scroll to the "Recent Communication" accordion
  #   Then the "Recent Communication" accordion should be visible
  #   When I scroll to the "Exceptions" accordion
  #   Then the "Exceptions" accordion should be visible
  #   When I scroll to the "Treatment" accordion
  #   Then the "Treatment" accordion should be visible

  # @regression
  # Scenario: Field values can be read from a specific accordion
  #   When I scroll to the "Delinquency Information" accordion
  #   Then the field "Days Past Due" in the "Delinquency Information" accordion should be visible

  # @regression
  # Scenario: Agent can switch to Activity History view
  #   When I click the Activity History button
  #   Then I should be on the Account Activity page

  # @regression
  # Scenario Outline: Agent can switch between account views
  #   When I switch the account view to "<view>"
  #   Then I should be on the Account Activity page

  #   Examples:
  #     | view                       |
  #     | Account Customers          |
  #     | Account Details            |
  #     | Delinquency Bucket Details |
  #     | Arrangements               |
  #     | Memo History               |

  # @regression
  # Scenario: Activities tab shows the activity list in the sidebar
  #   When I click the Activities tab in the sidebar
  #   Then the activity list should be visible in the sidebar

  # @regression
  # Scenario: Direct parent activity opens the activity iframe
  #   When I click the Activities tab in the sidebar
  #   Then the activity list should be visible in the sidebar
  #   And I click the parent activity "Do Not Call"
  #   And I wait for the activity iframe to load
  #   Then the activity iframe should be loaded

  # @regression
  # Scenario: Child activity opens the activity iframe after expanding parent
  #   When I click the Activities tab in the sidebar
  #   And I expand parent activity "Outbound Phone Call Finished" and click child "RP - Promise To Pay"
  #   And I wait for the activity iframe to load
  #   Then the activity iframe should be loaded

  # @regression
  # Scenario: Agent can navigate back to Customer Overview
  #   When I click the Customer Overview tab from the account page
  #   Then I should be on the Customer Overview page

  # @regression
  # Scenario: Agent can close the account tab to return to Customer Overview
  #   When I close the account tab
  #   Then I should be on the Customer Overview page

  @regression
  Scenario: Full activity flow from Account Overview - trigger, submit, verify and drill into details
    When I click the Activities tab in the sidebar
    And I trigger the activity "Do Not Call"
    Then the activity iframe variant should be "confirmation"
    When I submit the activity
    Then the activity "Do Not Call" should appear in the timeline
    When I open the activity details modal for "Do Not Call"
    And I iterate every enabled tab in the activity details for "Do Not Call"