# features/login.feature
# ──────────────────────────────────────────────────────────────
# All login-related scenarios for the Collections application.
# ──────────────────────────────────────────────────────────────

@login
Feature: Collections Login

  As a Collections agent
  I want to log in to the Collections application
  So that I can access my workload

  Background:
    Given I open the Collections login page

  @smoke
  Scenario: Successful login with valid credentials
    When I enter valid username and password
    And I click the Login button
    Then I should be redirected to the Collections home page
    And the application name "Collections" should be visible

  @negative
  Scenario: Login fails with invalid credentials
    When I enter username "invalid_user" and password "wrong_pass"
    And I click the Login button
    Then I should see a login error message
    And I should remain on the login page

  @negative
  Scenario: Login button is disabled when fields are empty
    Then the Login button should be visible on the page

  @smoke
  Scenario: Successful logout after login
    When I enter valid username and password
    And I click the Login button
    Then I should be redirected to the Collections home page
    When I open the user menu and click logout
    Then I should be redirected to the login page
