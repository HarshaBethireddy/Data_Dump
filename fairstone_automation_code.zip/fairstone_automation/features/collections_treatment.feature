@collections_treatment
Feature: Account Activity Page

  Background:
    Given I am logged in to the Collections application
    And I search for exact account number "6030491230001689"
    And I should be on the Customer Overview page
    And the account list should contain account "6030491230001689"
    And I click the matching account in the account list
    And I should be on the Account Activity page

  Scenario: Child activity opens the activity iframe after expanding parent
    When I click the Activities tab in the sidebar
    And I trigger the activity "Auto Email Activities" with child "Email - Soft Arrears"
    Then the activity iframe variant should be "confirmation"
    When I submit the activity
    Then the activity "Email - Soft Arrears" should appear in the timeline
    When I open the activity details modal for "Email - Soft Arrears"
    And I iterate every enabled tab in the activity details for "Email - Soft Arrears"