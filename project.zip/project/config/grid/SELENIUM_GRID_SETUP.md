# Selenium Grid 4 Standalone Setup Guide

## Quick Start (Standalone Mode)

### 1. Download Selenium Grid JAR

Download the latest Selenium Server (Grid) JAR file:
```bash
# Visit: https://github.com/SeleniumHQ/selenium/releases
# Download: selenium-server-4.17.0.jar (or latest version)

# Or use wget/curl:
wget https://github.com/SeleniumHQ/selenium/releases/download/selenium-4.17.0/selenium-server-4.17.0.jar
```

### 2. Start Grid in Standalone Mode

**Option A: Simple Standalone (Recommended for Development)**
```bash
java -jar selenium-server-4.17.0.jar standalone --port 4444 --max-sessions 50
```

**Option B: Standalone with Configuration**
```bash
java -jar selenium-server-4.17.0.jar standalone --config config/grid/grid-config.toml
```

### 3. Verify Grid is Running

Open browser and navigate to:
```
http://localhost:4444/ui
```

You should see the Grid console with available sessions.

---

## Advanced: Hub + Nodes Setup (For Production)

### 1. Start Hub
```bash
java -jar selenium-server-4.17.0.jar hub --port 4444
```

### 2. Start Chrome Nodes (Repeat for Multiple Nodes)

**Node 1:**
```bash
java -jar selenium-server-4.17.0.jar node --hub http://localhost:4444 --port 5555 --max-sessions 5
```

**Node 2:**
```bash
java -jar selenium-server-4.17.0.jar node --hub http://localhost:4444 --port 5556 --max-sessions 5
```

**Node 3-10:** (Repeat with different ports: 5557, 5558, etc.)

### 3. Verify Nodes Connected

Check Grid console:
```
http://localhost:4444/ui
```

You should see all connected nodes with their capacities.

---

## Configuration File (grid-config.toml)

Create `config/grid/grid-config.toml`:

```toml
[server]
port = 4444

[node]
detect-drivers = true
max-sessions = 10
session-timeout = 300

[distributor]
slot-matcher = "org.openqa.grid.internal.utils.DefaultCapabilityMatcher"

[sessionqueue]
session-request-timeout = 300
session-retry-interval = 5

[relay]
host = "localhost"
port = 4444

[logging]
enable = true
level = "INFO"
```

---

## Windows Batch Scripts

### `start-grid-standalone.bat`
```batch
@echo off
echo Starting Selenium Grid Standalone...
java -jar selenium-server-4.17.0.jar standalone --port 4444 --max-sessions 50
pause
```

### `start-grid-hub.bat`
```batch
@echo off
echo Starting Selenium Grid Hub...
java -jar selenium-server-4.17.0.jar hub --port 4444
pause
```

### `start-grid-node.bat`
```batch
@echo off
echo Starting Selenium Grid Node...
java -jar selenium-server-4.17.0.jar node --hub http://localhost:4444 --port 5555 --max-sessions 5
pause
```

---

## Linux Shell Scripts

### `start-grid-standalone.sh`
```bash
#!/bin/bash
echo "Starting Selenium Grid Standalone..."
java -jar selenium-server-4.17.0.jar standalone --port 4444 --max-sessions 50
```

### `start-grid-hub.sh`
```bash
#!/bin/bash
echo "Starting Selenium Grid Hub..."
java -jar selenium-server-4.17.0.jar hub --port 4444
```

### `start-grid-node.sh`
```bash
#!/bin/bash
echo "Starting Selenium Grid Node on port $1..."
java -jar selenium-server-4.17.0.jar node --hub http://localhost:4444 --port $1 --max-sessions 5
```

**Usage:**
```bash
chmod +x *.sh
./start-grid-hub.sh &
./start-grid-node.sh 5555 &
./start-grid-node.sh 5556 &
```

---

## Recommended Setup for 4000 Files

**Configuration:**
- **Standalone Grid** with **50 max sessions**
- **Browser Pool Size:** 20 (configured in application.yml)
- **Parallel Processing:** 20 concurrent files

**Command:**
```bash
java -Xmx2G -jar selenium-server-4.17.0.jar standalone --port 4444 --max-sessions 50 --session-timeout 300
```

**Why Standalone?**
- Simpler setup (no hub/node coordination)
- Lower overhead
- Sufficient for single-machine deployment
- Easier debugging

---

## Troubleshooting

### Grid Not Starting
```bash
# Check if port 4444 is already in use
netstat -ano | findstr :4444  # Windows
lsof -i :4444                 # Linux/Mac

# Kill process using port
taskkill /PID <PID> /F        # Windows
kill -9 <PID>                 # Linux/Mac
```

### ChromeDriver Not Found
Grid will auto-detect ChromeDriver if Chrome is installed. If not:

```bash
# Download ChromeDriver manually
# Place in PATH or specify location
java -jar selenium-server-4.17.0.jar standalone --driver-path /path/to/chromedriver
```

### Session Timeout Issues
Increase session timeout in application.yml:
```yaml
selenium:
  grid:
    session-timeout: 600  # 10 minutes
```

---

## Performance Tips

1. **Increase Max Sessions:** Adjust based on your machine's capacity
   ```bash
   --max-sessions 100
   ```

2. **Allocate More Memory to Grid:**
   ```bash
   java -Xmx4G -jar selenium-server-4.17.0.jar standalone
   ```

3. **Use Headless Browsers:** Configured in application.yml
   ```yaml
   browser:
     headless: true
   ```

4. **Disable Unnecessary Features:**
   ```
   --disable-ui  # Disable Grid UI for performance
   ```

---

## Grid Health Check API

Check Grid status programmatically:
```bash
curl http://localhost:4444/status
```

Response:
```json
{
  "ready": true,
  "message": "Selenium Grid ready.",
  "nodes": [...]
}
```

---

## Integration with Application

The application automatically connects to Grid using configuration from `application.yml`:

```yaml
selenium:
  grid:
    enabled: true
    url: http://localhost:4444
```

No additional setup needed in code!
