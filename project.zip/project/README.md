# Bureau Comparison System v2.0

High-performance, enterprise-grade bureau data comparison system with Selenium Grid integration, reactive processing, and comprehensive reporting.

## 🚀 Features

- ✅ **Selenium Grid 4** - Distributed browser automation
- ✅ **Browser Pooling** - Apache Commons Pool2 for resource optimization
- ✅ **Project Reactor** - Reactive streams for non-blocking I/O
- ✅ **Dynamic Waits** - Smart waiting strategies (no Thread.sleep())
- ✅ **Parallel Processing** - Process 4000+ files concurrently
- ✅ **Java 21** - Virtual threads, Records, Pattern matching
- ✅ **Spring Boot 3.2** - Modern Spring framework
- ✅ **Page Object Model** - Clean Selenium automation
- ✅ **BDD/Cucumber** - Behavior-driven testing
- ✅ **HTML Reporting** - Interactive, responsive reports
- ✅ **Structured Logging** - JSON logging with MDC context

## 📋 Prerequisites

- **Java 21** (JDK 21+)
- **Maven 3.8+**
- **Chrome Browser** (latest version)
- **Selenium Grid 4** (standalone or hub/node setup)

## 🛠️ Quick Start

### 1. Setup Selenium Grid

```bash
# Download Selenium Server JAR
wget https://github.com/SeleniumHQ/selenium/releases/download/selenium-4.17.0/selenium-server-4.17.0.jar

# Start Grid in Standalone Mode
java -jar selenium-server-4.17.0.jar standalone --port 4444 --max-sessions 50
```

**Verify Grid**: Open http://localhost:4444/ui

### 2. Configure Application

Edit `config/application.yml`:

```yaml
bureau:
  comparison:
    base-url: http://your-bureau-url:8080/WebEngine/
    credentials:
      username: your-username
      password: your-password
    folders:
      base-pre: C:/path/to/pre/folder
      base-post: C:/path/to/post/folder
      output: C:/path/to/output
    selenium:
      grid:
        enabled: true
        url: http://localhost:4444
```

### 3. Build Project

```bash
mvn clean install
```

### 4. Run Application

```bash
java -jar target/bureau-comparison-system-2.0.0.jar
```

Or use Maven:

```bash
mvn spring-boot:run
```

## 📦 Project Structure

```
bureau-comparison-system/
├── src/main/java/com/bureau/comparison/
│   ├── domain/              # Domain models (Records)
│   ├── service/             # Business logic
│   ├── selenium/            # Selenium components
│   │   ├── config/          # Selenium configuration
│   │   ├── factory/         # WebDriver factory
│   │   ├── pool/            # Browser pooling
│   │   └── page/            # Page Object Model
│   ├── reporting/           # HTML report generation
│   ├── config/              # Spring configuration
│   ├── util/                # Utilities
│   └── exception/           # Exception hierarchy
├── src/main/resources/
│   ├── templates/           # Thymeleaf templates
│   └── static/              # CSS, JS assets
├── src/test/                # BDD/Cucumber tests
└── config/                  # External configuration

```

## ⚙️ Configuration

### Environment Variables

```bash
export BUREAU_BASE_URL="http://..."
export BUREAU_USERNAME="your-username"
export BUREAU_PASSWORD="your-password"
export PRE_FOLDER="C:/path/to/pre"
export POST_FOLDER="C:/path/to/post"
export OUTPUT_FOLDER="C:/path/to/output"
export SELENIUM_GRID_URL="http://localhost:4444"
```

### Performance Tuning

```yaml
performance:
  parallelism:
    file-level: 20        # Concurrent files
  timeouts:
    extraction: 45        # Selenium timeout (seconds)
    page-load: 30         # Page load timeout
  pool:
    max-total: 20         # Max browser instances
```

## 📊 Generated Reports

Reports are generated in: `{output-folder}/comparison_{timestamp}/`

**Report Structure:**
- `MASTER_comparison_report.txt` - Overall summary
- `{category}/comparison_report.txt` - Per-category reports
- `{category}/{file}_PRE_{appId}.txt` - Extracted PRE data
- `{category}/{file}_POST_{appId}.txt` - Extracted POST data

## 🧪 Running Tests

```bash
# Run all tests
mvn test

# Run specific test suite
mvn test -Dtest=CucumberTestRunner
```

## 📈 Performance Targets

| Metric | Target | Strategy |
|--------|--------|----------|
| **Processing Time** | 15-20 min for 4000 files | Grid + Reactor + Pool |
| **Throughput** | 3-4 files/second | 20 parallel browsers |
| **Memory** | < 8GB heap | Streaming, Virtual Threads |
| **Success Rate** | > 95% | Retry + Circuit Breaker |

## 🔧 Troubleshooting

### Grid Connection Failed
```bash
# Check Grid status
curl http://localhost:4444/status

# Restart Grid
java -jar selenium-server-4.17.0.jar standalone
```

### Browser Pool Exhausted
Increase pool size in `application.yml`:
```yaml
selenium:
  pool:
    max-total: 30  # Increase from 20
```

### OutOfMemoryError
Increase heap size:
```bash
java -Xmx12G -jar target/bureau-comparison-system-2.0.0.jar
```

## 📝 Development Status

### ✅ Completed Components (32/50 files)
- Project configuration
- Domain models
- Exception handling
- Utilities
- Configuration classes
- Selenium infrastructure (Grid, Pool, Factory)
- Page Object Model foundation
- Main application

### 🔄 Remaining Components
- Complete Page Objects (Search, BureauData pages)
- Service layer (Orchestrator, Extraction, Comparison)
- Reporting module (HTML generation, templates)
- BDD tests (Feature files, Step definitions)
- CLI interface

See `GENERATION_PROGRESS.md` for detailed status.

## 🤝 Contributing

1. Follow SOLID principles
2. Use Lombok to reduce boilerplate
3. Write comprehensive tests
4. Document public APIs with Javadoc
5. Use SLF4J for logging

## 📄 License

Proprietary - Internal use only

## 👥 Team

Bureau Comparison Team @ Experian

---

**Version**: 2.0.0
**Last Updated**: 2025-10-30
