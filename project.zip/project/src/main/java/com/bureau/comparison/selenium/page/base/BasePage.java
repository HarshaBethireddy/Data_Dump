package com.bureau.comparison.selenium.page.base;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.time.Duration;
import java.util.Set;

/**
 * Base page class for all Page Objects.
 * Provides common functionality and dynamic wait strategies.
 */
@Slf4j
@Getter
public abstract class BasePage {

    protected final WebDriver driver;
    protected final DynamicWaitStrategy wait;
    protected final JavascriptExecutor js;
    protected final Actions actions;

    protected BasePage(WebDriver driver, int timeoutSeconds) {
        this.driver = driver;
        this.wait = new DynamicWaitStrategy(driver, timeoutSeconds);
        this.js = (JavascriptExecutor) driver;
        this.actions = new Actions(driver);
    }

    /**
     * Navigate to URL
     */
    public void navigateTo(String url) {
        log.info("Navigating to: {}", url);
        driver.get(url);
        waitForPageLoad();
    }

    /**
     * Get current URL
     */
    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    /**
     * Get page title
     */
    public String getPageTitle() {
        return driver.getTitle();
    }

    /**
     * Wait for page to load completely
     */
    public void waitForPageLoad() {
        wait.waitForPageReady();
        wait.waitForJQueryReady();
    }

    /**
     * Find element with wait
     */
    protected WebElement findElement(By locator) {
        return wait.waitForVisible(locator);
    }

    /**
     * Click element with wait
     */
    protected void click(By locator) {
        wait.waitAndClick(locator);
    }

    /**
     * Click element using JavaScript
     */
    protected void clickWithJavaScript(WebElement element) {
        js.executeScript("arguments[0].click();", element);
        log.debug("Clicked element using JavaScript");
    }

    /**
     * Type text with wait and clear
     */
    protected void type(By locator, String text) {
        wait.waitAndSendKeys(locator, text);
    }

    /**
     * Type text slowly (character by character)
     */
    protected void typeSlowly(By locator, String text, int delayMillis) {
        WebElement element = wait.waitForVisible(locator);
        element.clear();
        for (char c : text.toCharArray()) {
            element.sendKeys(String.valueOf(c));
            try {
                Thread.sleep(delayMillis);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        log.debug("Typed slowly to element: {}", locator);
    }

    /**
     * Get text from element
     */
    protected String getText(By locator) {
        return wait.waitAndGetText(locator);
    }

    /**
     * Check if element is displayed
     */
    protected boolean isDisplayed(By locator) {
        try {
            return driver.findElement(locator).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Scroll to element
     */
    protected void scrollToElement(WebElement element) {
        js.executeScript("arguments[0].scrollIntoView({block: 'center'});", element);
        log.debug("Scrolled to element");
    }

    /**
     * Scroll to element by locator
     */
    protected void scrollToElement(By locator) {
        WebElement element = wait.waitForPresent(locator);
        scrollToElement(element);
    }

    /**
     * Hover over element
     */
    protected void hoverOver(WebElement element) {
        actions.moveToElement(element).perform();
        log.debug("Hovered over element");
    }

    /**
     * Switch to window by index
     */
    protected void switchToWindow(int windowIndex) {
        Set<String> windows = driver.getWindowHandles();
        String[] windowArray = windows.toArray(new String[0]);
        if (windowIndex < windowArray.length) {
            driver.switchTo().window(windowArray[windowIndex]);
            log.debug("Switched to window index: {}", windowIndex);
        }
    }

    /**
     * Switch to new window (last opened)
     */
    protected void switchToNewWindow() {
        Set<String> windows = driver.getWindowHandles();
        String[] windowArray = windows.toArray(new String[0]);
        driver.switchTo().window(windowArray[windowArray.length - 1]);
        log.debug("Switched to new window");
    }

    /**
     * Close current window and switch back
     */
    protected void closeCurrentWindow() {
        driver.close();
        switchToWindow(0);
        log.debug("Closed current window");
    }

    /**
     * Get number of open windows
     */
    protected int getWindowCount() {
        return driver.getWindowHandles().size();
    }

    /**
     * Execute JavaScript
     */
    protected Object executeScript(String script, Object... args) {
        return js.executeScript(script, args);
    }

    /**
     * Take screenshot (returns base64 string)
     */
    protected String takeScreenshot() {
        return ((org.openqa.selenium.TakesScreenshot) driver)
                .getScreenshotAs(org.openqa.selenium.OutputType.BASE64);
    }

    /**
     * Refresh page
     */
    protected void refresh() {
        driver.navigate().refresh();
        waitForPageLoad();
        log.debug("Page refreshed");
    }

    /**
     * Navigate back
     */
    protected void navigateBack() {
        driver.navigate().back();
        waitForPageLoad();
        log.debug("Navigated back");
    }

    /**
     * Pause execution (use sparingly, prefer dynamic waits)
     */
    protected void pause(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
