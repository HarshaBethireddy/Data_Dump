package com.bureau.comparison.domain;

import lombok.Builder;

/**
 * Represents a section of bureau data in extracted files.
 * Each section corresponds to a specific bureau (Equifax, TransUnion, Experian)
 * and type (Request/Response).
 */
@Builder
public record BureauSection(
        String bureauName,
        String type,  // "Request" or "Response"
        int startLine,
        int endLine,
        String content
) {
    /**
     * Get the number of lines in this section
     */
    public int getLineCount() {
        return endLine - startLine + 1;
    }

    /**
     * Check if a line number falls within this section
     */
    public boolean containsLine(int lineNumber) {
        return lineNumber >= startLine && lineNumber <= endLine;
    }

    /**
     * Get a display label for this section
     */
    public String getLabel() {
        return String.format("%s - %s", bureauName, type);
    }
}
