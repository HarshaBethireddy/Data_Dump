package com.bureau.comparison.config;

import com.bureau.comparison.util.ValidationUtils;
import jakarta.annotation.PostConstruct;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.List;
import java.util.Map;

/**
 * Configuration properties for bureau comparison system.
 * Binds to bureau.comparison.* properties from application.yml
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "bureau.comparison")
public class BureauProperties {

    private String baseUrl;
    private Credentials credentials = new Credentials();
    private Folders folders = new Folders();
    private Selenium selenium = new Selenium();
    private Performance performance = new Performance();
    private Map<String, CategoryConfig> categories;
    private Reporting reporting = new Reporting();

    @PostConstruct
    public void validate() {
        ValidationUtils.validateUrl(baseUrl, "bureau.comparison.base-url");
        ValidationUtils.validateCredentials(credentials.username, credentials.password);
        ValidationUtils.validateDirectoryExists(folders.basePre, "bureau.comparison.folders.base-pre");
        ValidationUtils.validateDirectoryExists(folders.basePost, "bureau.comparison.folders.base-post");
        ValidationUtils.validateUrl(selenium.grid.url, "bureau.comparison.selenium.grid.url");
        ValidationUtils.validatePositiveInteger(selenium.pool.maxTotal, "bureau.comparison.selenium.pool.max-total");
        ValidationUtils.validatePositiveInteger(performance.parallelism.fileLevel, "bureau.comparison.performance.parallelism.file-level");
    }

    @Data
    public static class Credentials {
        private String username;
        private String password;
    }

    @Data
    public static class Folders {
        private String basePre;
        private String basePost;
        private String output;
    }

    @Data
    public static class Selenium {
        private Grid grid = new Grid();
        private Browser browser = new Browser();
        private Pool pool = new Pool();

        @Data
        public static class Grid {
            private boolean enabled = true;
            private String url;
            private int maxSessions = 50;
            private int sessionTimeout = 300;
        }

        @Data
        public static class Browser {
            private String type = "chrome";
            private boolean headless = true;
            private List<String> options;
            private String pageLoadStrategy = "EAGER";
        }

        @Data
        public static class Pool {
            private int maxTotal = 20;
            private int maxIdle = 10;
            private int minIdle = 5;
            private long maxWaitMillis = 30000;
            private boolean testOnBorrow = true;
            private boolean testOnReturn = false;
            private long timeBetweenEvictionRunsMillis = 60000;
        }
    }

    @Data
    public static class Performance {
        private Parallelism parallelism = new Parallelism();
        private Timeouts timeouts = new Timeouts();
        private Retry retry = new Retry();
        private Cache cache = new Cache();

        @Data
        public static class Parallelism {
            private int fileLevel = 20;
            private int ioOperations = 10;
            private int comparison = 8;
        }

        @Data
        public static class Timeouts {
            private int extraction = 45;
            private int navigation = 10;
            private int pageLoad = 30;
            private int elementWait = 15;
        }

        @Data
        public static class Retry {
            private int maxAttempts = 3;
            private int backoffMultiplier = 2;
            private int initialInterval = 2;
        }

        @Data
        public static class Cache {
            private boolean enabled = true;
            private int ttl = 3600;
            private int maxSize = 1000;
        }
    }

    @Data
    public static class CategoryConfig {
        private List<String> menuPath;
    }

    @Data
    public static class Reporting {
        private String format = "html";
        private boolean compression = true;
        private boolean includeScreenshots = false;
        private Pagination pagination = new Pagination();
        private Charts charts = new Charts();

        @Data
        public static class Pagination {
            private boolean enabled = true;
            private int pageSize = 500;
        }

        @Data
        public static class Charts {
            private boolean enabled = true;
        }
    }
}
