package com.bureau.comparison.selenium.page.base;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.function.Function;

/**
 * Dynamic wait strategies for Selenium operations.
 * Provides smart waiting mechanisms without hardcoded Thread.sleep().
 */
@Slf4j
public class DynamicWaitStrategy {

    private final WebDriver driver;
    private final Duration defaultTimeout;
    private final Duration defaultPollingInterval;

    public DynamicWaitStrategy(WebDriver driver, int timeoutSeconds) {
        this.driver = driver;
        this.defaultTimeout = Duration.ofSeconds(timeoutSeconds);
        this.defaultPollingInterval = Duration.ofMillis(500);
    }

    /**
     * Wait for element to be visible
     */
    public WebElement waitForVisible(By locator) {
        log.debug("Waiting for element to be visible: {}", locator);
        return createFluentWait()
                .until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    /**
     * Wait for element to be clickable
     */
    public WebElement waitForClickable(By locator) {
        log.debug("Waiting for element to be clickable: {}", locator);
        return createFluentWait()
                .until(ExpectedConditions.elementToBeClickable(locator));
    }

    /**
     * Wait for element to be present in DOM
     */
    public WebElement waitForPresent(By locator) {
        log.debug("Waiting for element to be present: {}", locator);
        return createFluentWait()
                .until(ExpectedConditions.presenceOfElementLocated(locator));
    }

    /**
     * Wait for element to be invisible
     */
    public boolean waitForInvisible(By locator) {
        log.debug("Waiting for element to be invisible: {}", locator);
        return createFluentWait()
                .until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }

    /**
     * Wait for text to be present in element
     */
    public boolean waitForTextPresent(By locator, String text) {
        log.debug("Waiting for text '{}' in element: {}", text, locator);
        return createFluentWait()
                .until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
    }

    /**
     * Wait for attribute value
     */
    public boolean waitForAttributeValue(By locator, String attribute, String value) {
        log.debug("Waiting for attribute '{}' = '{}' in element: {}", attribute, value, locator);
        return createFluentWait()
                .until(ExpectedConditions.attributeToBe(locator, attribute, value));
    }

    /**
     * Wait for number of windows
     */
    public boolean waitForNumberOfWindows(int numberOfWindows) {
        log.debug("Waiting for number of windows: {}", numberOfWindows);
        return createFluentWait()
                .until(ExpectedConditions.numberOfWindowsToBe(numberOfWindows));
    }

    /**
     * Wait for custom condition
     */
    public <T> T waitFor(Function<WebDriver, T> condition) {
        return createFluentWait().until(condition);
    }

    /**
     * Wait for custom condition with specific timeout
     */
    public <T> T waitFor(Function<WebDriver, T> condition, Duration timeout) {
        return createFluentWait(timeout).until(condition);
    }

    /**
     * Wait for page to be ready (JavaScript document.readyState)
     */
    public boolean waitForPageReady() {
        log.debug("Waiting for page to be ready");
        return createFluentWait().until((ExpectedCondition<Boolean>) driver -> {
            if (driver == null) return false;
            String readyState = ((JavascriptExecutor) driver)
                    .executeScript("return document.readyState")
                    .toString();
            return "complete".equals(readyState);
        });
    }

    /**
     * Wait for jQuery to be loaded (if present)
     */
    public boolean waitForJQueryReady() {
        log.debug("Waiting for jQuery to be ready");
        try {
            return createFluentWait().until((ExpectedCondition<Boolean>) driver -> {
                if (driver == null) return true;
                try {
                    Long jQueryActive = (Long) ((JavascriptExecutor) driver)
                            .executeScript("return jQuery.active");
                    return jQueryActive == 0;
                } catch (Exception e) {
                    // jQuery not present, that's okay
                    return true;
                }
            });
        } catch (Exception e) {
            return true; // jQuery not present
        }
    }

    /**
     * Wait for element and get text
     */
    public String waitAndGetText(By locator) {
        WebElement element = waitForVisible(locator);
        return element.getText();
    }

    /**
     * Wait for element and click
     */
    public void waitAndClick(By locator) {
        WebElement element = waitForClickable(locator);
        element.click();
        log.debug("Clicked element: {}", locator);
    }

    /**
     * Wait for element and send keys
     */
    public void waitAndSendKeys(By locator, String text) {
        WebElement element = waitForVisible(locator);
        element.clear();
        element.sendKeys(text);
        log.debug("Sent keys to element: {}", locator);
    }

    /**
     * Create fluent wait with default settings
     */
    private FluentWait<WebDriver> createFluentWait() {
        return createFluentWait(defaultTimeout);
    }

    /**
     * Create fluent wait with custom timeout
     */
    private FluentWait<WebDriver> createFluentWait(Duration timeout) {
        return new WebDriverWait(driver, timeout)
                .pollingEvery(defaultPollingInterval)
                .ignoring(NoSuchElementException.class)
                .ignoring(StaleElementReferenceException.class)
                .ignoring(ElementNotInteractableException.class);
    }

    /**
     * Retry action with exponential backoff
     */
    public <T> T retryWithBackoff(Function<WebDriver, T> action, int maxAttempts) {
        int attempt = 0;
        while (attempt < maxAttempts) {
            try {
                return action.apply(driver);
            } catch (Exception e) {
                attempt++;
                if (attempt >= maxAttempts) {
                    throw e;
                }
                long waitTime = (long) (Math.pow(2, attempt) * 1000); // Exponential backoff
                log.debug("Attempt {} failed, retrying after {}ms", attempt, waitTime);
                try {
                    Thread.sleep(waitTime);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new RuntimeException("Interrupted during retry", ie);
                }
            }
        }
        throw new RuntimeException("Max retry attempts exceeded");
    }
}
