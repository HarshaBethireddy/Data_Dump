package com.bureau.comparison.selenium.pool;

import com.bureau.comparison.config.BureauProperties;
import com.bureau.comparison.selenium.factory.WebDriverFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.openqa.selenium.WebDriver;
import org.springframework.stereotype.Component;

import jakarta.annotation.PreDestroy;

/**
 * WebDriver pool implementation using Apache Commons Pool2.
 * Manages a pool of WebDriver instances for concurrent processing.
 */
@Slf4j
public class WebDriverPool {

    private final GenericObjectPool<WebDriver> pool;
    private final WebDriverFactory webDriverFactory;

    public WebDriverPool(WebDriverFactory webDriverFactory, BureauProperties properties) {
        this.webDriverFactory = webDriverFactory;

        // Configure pool
        GenericObjectPoolConfig<WebDriver> config = new GenericObjectPoolConfig<>();
        config.setMaxTotal(properties.getSelenium().getPool().getMaxTotal());
        config.setMaxIdle(properties.getSelenium().getPool().getMaxIdle());
        config.setMinIdle(properties.getSelenium().getPool().getMinIdle());
        config.setMaxWait(java.time.Duration.ofMillis(properties.getSelenium().getPool().getMaxWaitMillis()));
        config.setTestOnBorrow(properties.getSelenium().getPool().isTestOnBorrow());
        config.setTestOnReturn(properties.getSelenium().getPool().isTestOnReturn());
        config.setTimeBetweenEvictionRuns(
                java.time.Duration.ofMillis(properties.getSelenium().getPool().getTimeBetweenEvictionRunsMillis())
        );

        // Create pool
        this.pool = new GenericObjectPool<>(new WebDriverPoolFactory(), config);

        log.info("WebDriver pool initialized - maxTotal: {}, maxIdle: {}, minIdle: {}",
                config.getMaxTotal(), config.getMaxIdle(), config.getMinIdle());
    }

    /**
     * Borrow a WebDriver from the pool
     */
    public WebDriver borrowObject() throws Exception {
        log.debug("Borrowing WebDriver from pool. Active: {}, Idle: {}",
                pool.getNumActive(), pool.getNumIdle());
        WebDriver driver = pool.borrowObject();
        log.debug("WebDriver borrowed successfully");
        return driver;
    }

    /**
     * Return a WebDriver to the pool
     */
    public void returnObject(WebDriver driver) {
        if (driver != null) {
            try {
                pool.returnObject(driver);
                log.debug("WebDriver returned to pool. Active: {}, Idle: {}",
                        pool.getNumActive(), pool.getNumIdle());
            } catch (Exception e) {
                log.error("Failed to return WebDriver to pool", e);
                // Invalidate the driver
                try {
                    invalidateObject(driver);
                } catch (Exception ex) {
                    log.error("Failed to invalidate WebDriver", ex);
                }
            }
        }
    }

    /**
     * Invalidate a WebDriver (remove from pool and destroy)
     */
    public void invalidateObject(WebDriver driver) throws Exception {
        pool.invalidateObject(driver);
        log.debug("WebDriver invalidated");
    }

    /**
     * Get number of active drivers
     */
    public int getNumActive() {
        return pool.getNumActive();
    }

    /**
     * Get number of idle drivers
     */
    public int getNumIdle() {
        return pool.getNumIdle();
    }

    /**
     * Close the pool and all drivers
     */
    @PreDestroy
    public void close() {
        log.info("Closing WebDriver pool...");
        pool.close();
        log.info("WebDriver pool closed");
    }

    /**
     * Pooled object factory for WebDriver
     */
    private class WebDriverPoolFactory extends BasePooledObjectFactory<WebDriver> {

        @Override
        public WebDriver create() throws Exception {
            log.debug("Creating new WebDriver instance for pool");
            WebDriver driver = webDriverFactory.createWebDriver();
            log.debug("WebDriver instance created");
            return driver;
        }

        @Override
        public PooledObject<WebDriver> wrap(WebDriver driver) {
            return new DefaultPooledObject<>(driver);
        }

        @Override
        public void destroyObject(PooledObject<WebDriver> p) throws Exception {
            WebDriver driver = p.getObject();
            if (driver != null) {
                try {
                    log.debug("Destroying WebDriver instance");
                    driver.quit();
                    log.debug("WebDriver instance destroyed");
                } catch (Exception e) {
                    log.error("Error destroying WebDriver", e);
                }
            }
        }

        @Override
        public boolean validateObject(PooledObject<WebDriver> p) {
            WebDriver driver = p.getObject();
            boolean isValid = webDriverFactory.validateDriver(driver);
            log.debug("WebDriver validation: {}", isValid);
            return isValid;
        }

        @Override
        public void activateObject(PooledObject<WebDriver> p) throws Exception {
            // Reset driver state before returning to borrower
            WebDriver driver = p.getObject();
            webDriverFactory.resetDriverState(driver);
            log.debug("WebDriver activated and reset");
        }

        @Override
        public void passivateObject(PooledObject<WebDriver> p) throws Exception {
            // Clean up driver state before returning to pool
            WebDriver driver = p.getObject();
            webDriverFactory.resetDriverState(driver);
            log.debug("WebDriver passivated and reset");
        }
    }
}
