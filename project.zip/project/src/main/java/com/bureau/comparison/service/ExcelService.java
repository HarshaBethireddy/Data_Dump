package com.bureau.comparison.service;

import com.bureau.comparison.domain.ApplicationData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Service for reading and writing Excel files.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ExcelService {

    /**
     * Write AppID comparison to Excel
     */
    public Path writeAppIdComparisonExcel(Map<String, ApplicationData> applications, Path outputPath) throws IOException {
        log.info("Writing AppID comparison Excel: {}", outputPath);

        try (Workbook workbook = new XSSFWorkbook();
             FileOutputStream fos = new FileOutputStream(outputPath.toFile())) {

            Sheet sheet = workbook.createSheet("AppID Comparison");

            // Create header row
            Row headerRow = sheet.createRow(0);
            headerRow.createCell(0).setCellValue("File Name");
            headerRow.createCell(1).setCellValue("Pre-AppID");
            headerRow.createCell(2).setCellValue("Post-AppID");
            headerRow.createCell(3).setCellValue("Category");

            // Write data rows
            int rowIndex = 1;
            for (ApplicationData appData : applications.values()) {
                Row row = sheet.createRow(rowIndex++);
                row.createCell(0).setCellValue(appData.fileName());
                row.createCell(1).setCellValue(appData.preAppId());
                row.createCell(2).setCellValue(appData.postAppId());
                row.createCell(3).setCellValue(appData.category().getCode());
            }

            // Auto-size columns
            for (int i = 0; i < 4; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(fos);
            log.info("Excel file written successfully: {} rows", applications.size());
        }

        return outputPath;
    }

    /**
     * Read ApplicationData from Excel file
     */
    public List<ApplicationData> readApplicationsFromExcel(Path excelPath) throws IOException {
        log.info("Reading applications from Excel: {}", excelPath);

        List<ApplicationData> applications = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(excelPath.toFile());
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);

            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                String fileName = getCellValueAsString(row.getCell(0));
                String preAppId = getCellValueAsString(row.getCell(1));
                String postAppId = getCellValueAsString(row.getCell(2));

                ApplicationData appData = ApplicationData.create(fileName, preAppId, postAppId);
                if (appData.isValid()) {
                    applications.add(appData);
                }
            }
        }

        log.info("Read {} applications from Excel", applications.size());
        return applications;
    }

    /**
     * Get cell value as string
     */
    private String getCellValueAsString(Cell cell) {
        if (cell == null) return null;

        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue().trim();
            case NUMERIC -> {
                double numValue = cell.getNumericCellValue();
                if (numValue == Math.floor(numValue)) {
                    yield String.valueOf((long) numValue);
                }
                yield String.valueOf(numValue);
            }
            case BLANK -> null;
            default -> cell.toString().trim();
        };
    }
}
