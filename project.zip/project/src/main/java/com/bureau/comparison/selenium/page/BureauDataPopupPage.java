package com.bureau.comparison.selenium.page;

import com.bureau.comparison.domain.BureauSection;
import com.bureau.comparison.exception.ExtractionException;
import com.bureau.comparison.selenium.page.base.BasePage;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Page Object for Bureau Data Popup Window.
 * Handles extraction of bureau request/response data.
 */
@Slf4j
public class BureauDataPopupPage extends BasePage {

    // Locators
    private final By jsTreeContainer = By.cssSelector(".jstree");
    private final By requestResponseLinks = By.xpath("//a[@raw and (@type='request' or @type='response')]");

    public BureauDataPopupPage(WebDriver driver, int timeoutSeconds) {
        super(driver, timeoutSeconds);
    }

    /**
     * Switch to popup window
     */
    public void switchToPopup(String mainWindowHandle) {
        try {
            log.info("Switching to bureau data popup");

            pause(4000); // Allow popup to open

            Set<String> allWindows = driver.getWindowHandles();
            for (String windowHandle : allWindows) {
                if (!windowHandle.equals(mainWindowHandle)) {
                    driver.switchTo().window(windowHandle);
                    log.info("Switched to popup window");
                    return;
                }
            }

            throw new ExtractionException("Popup window not found");
        } catch (Exception e) {
            log.error("Failed to switch to popup", e);
            throw new ExtractionException("Failed to switch to popup window", e);
        }
    }

    /**
     * Extract all bureau data from popup
     */
    public String extractAllBureauData(String applicationId, String type) {
        try {
            log.info("Extracting bureau data for app {} - {}", applicationId, type);

            pause(3000);

            StringBuilder allData = new StringBuilder();
            allData.append("===== BUREAU DATA EXTRACTION =====\n");
            allData.append("Type: ").append(type).append("\n");
            allData.append("Application ID: ").append(applicationId).append("\n");
            allData.append("Extraction Time: ").append(java.time.LocalDateTime.now()).append("\n");
            allData.append("==================================\n\n");

            // Expand jsTree
            expandAllJsTreeNodes();

            // Find all request/response links
            List<WebElement> links = findRequestResponseLinks();
            log.info("Found {} request/response links", links.size());

            // Extract data from each link
            String mainWindow = driver.getWindowHandle();
            for (int i = 0; i < links.size(); i++) {
                // Re-find links (to avoid stale element)
                links = findRequestResponseLinks();

                if (i < links.size()) {
                    WebElement link = links.get(i);
                    String linkText = link.getText();
                    String bureauKey = link.getAttribute("bureaukey");
                    String linkType = link.getAttribute("type");

                    log.info("Processing: {} - {}", bureauKey, linkType);

                    allData.append("\n").append("=".repeat(50)).append("\n");
                    allData.append("Bureau: ").append(bureauKey != null ? bureauKey : "Unknown").append("\n");
                    allData.append("Type: ").append(linkType != null ? linkType : linkText).append("\n");
                    allData.append("=".repeat(50)).append("\n");

                    // Click link using JavaScript
                    clickWithJavaScript(link);
                    pause(2000);

                    // Switch to data window
                    Set<String> currentWindows = driver.getWindowHandles();
                    String dataWindow = null;
                    for (String windowHandle : currentWindows) {
                        if (!windowHandle.equals(mainWindow)) {
                            dataWindow = windowHandle;
                            break;
                        }
                    }

                    if (dataWindow != null) {
                        driver.switchTo().window(dataWindow);

                        try {
                            // Try to find <pre> element
                            WebElement preElement = wait.waitForPresent(By.tagName("pre"));
                            String preContent = preElement.getText();
                            allData.append(preContent).append("\n");
                            log.info("Extracted {} characters", preContent.length());
                        } catch (Exception e) {
                            // Fallback to body text
                            String bodyText = driver.findElement(By.tagName("body")).getText();
                            allData.append(bodyText).append("\n");
                            log.info("Extracted body text: {} characters", bodyText.length());
                        }

                        // Close data window
                        driver.close();
                        driver.switchTo().window(mainWindow);
                    }

                    pause(1000);
                }
            }

            log.info("Bureau data extraction completed");
            return allData.toString();

        } catch (Exception e) {
            log.error("Failed to extract bureau data", e);
            throw new ExtractionException.DataExtractionException("Failed to extract bureau data", e, applicationId);
        }
    }

    /**
     * Expand all jsTree nodes
     */
    private void expandAllJsTreeNodes() {
        try {
            wait.waitForPresent(jsTreeContainer);

            // Try using jsTree API first
            Object usedApi = js.executeScript(
                    "try {" +
                            "  if (window.$ && $('.jstree').length && $('.jstree').jstree) {" +
                            "    var inst = $('.jstree').jstree(true) || $('.jstree').jstree(); " +
                            "    if (inst && inst.open_all) { inst.open_all(); return true; }" +
                            "  }" +
                            "} catch(e) {}" +
                            "return false;"
            );

            if (Boolean.TRUE.equals(usedApi)) {
                try {
                    wait.waitFor(d -> driver.findElements(By.cssSelector(".jstree .jstree-loading")).isEmpty(),
                            java.time.Duration.ofSeconds(5));
                } catch (TimeoutException ignored) {
                }
                return;
            }

            // Manual expansion by clicking togglers
            int safety = 0;
            final int maxPasses = 50;

            while (safety++ < maxPasses) {
                List<WebElement> closedTogglers = driver.findElements(
                        By.cssSelector(".jstree li.jstree-closed > i.jstree-ocl, " +
                                ".jstree li.jstree-closed > i.jstree-icon.jstree-ocl")
                );

                if (closedTogglers.isEmpty()) break;

                int before = closedTogglers.size();
                for (WebElement toggler : closedTogglers) {
                    try {
                        scrollToElement(toggler);
                        wait.waitForClickable(By.cssSelector(".jstree li.jstree-closed > i")).click();
                    } catch (Exception e) {
                        clickWithJavaScript(toggler);
                    }
                    pause(150);
                }

                try {
                    wait.waitFor(d -> {
                        int after = driver.findElements(
                                By.cssSelector(".jstree li.jstree-closed > i.jstree-ocl, " +
                                        ".jstree li.jstree-closed > i.jstree-icon.jstree-ocl")
                        ).size();
                        return after < before;
                    }, java.time.Duration.ofSeconds(2));
                } catch (TimeoutException ignored) {
                }
            }

            log.info("jsTree nodes expanded");
        } catch (Exception e) {
            log.warn("Failed to expand jsTree nodes: {}", e.getMessage());
        }
    }

    /**
     * Find all request/response links
     */
    private List<WebElement> findRequestResponseLinks() {
        List<WebElement> links = new ArrayList<>();
        try {
            wait.waitForPresent(jsTreeContainer);

            List<WebElement> rawLinks = driver.findElements(By.xpath("//a[@raw]"));
            for (WebElement link : rawLinks) {
                String type = link.getAttribute("type");
                if ("request".equals(type) || "response".equals(type)) {
                    links.add(link);
                }
            }
        } catch (Exception e) {
            log.error("Error finding request/response links", e);
        }
        return links;
    }

    /**
     * Close popup and switch back to main window
     */
    public void closePopup(String mainWindowHandle) {
        try {
            driver.close();
            driver.switchTo().window(mainWindowHandle);
            log.info("Popup closed, switched back to main window");
        } catch (Exception e) {
            log.warn("Failed to close popup cleanly", e);
        }
    }
}
