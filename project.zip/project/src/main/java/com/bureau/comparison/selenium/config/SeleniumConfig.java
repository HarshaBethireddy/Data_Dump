package com.bureau.comparison.selenium.config;

import com.bureau.comparison.config.BureauProperties;
import com.bureau.comparison.selenium.factory.WebDriverFactory;
import com.bureau.comparison.selenium.pool.WebDriverPool;
import io.github.bonigarcia.wdm.WebDriverManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

/**
 * Selenium configuration for WebDriver management.
 * Sets up WebDriverManager and initializes browser pool.
 */
@Slf4j
@Configuration
@RequiredArgsConstructor
public class SeleniumConfig {

    private final BureauProperties properties;

    @PostConstruct
    public void setupWebDriverManager() {
        try {
            // Automatically manage ChromeDriver
            WebDriverManager.chromedriver().setup();
            log.info("WebDriverManager initialized for Chrome");
        } catch (Exception e) {
            log.error("Failed to setup WebDriverManager", e);
        }
    }

    @Bean
    public WebDriverPool webDriverPool(WebDriverFactory webDriverFactory) {
        WebDriverPool pool = new WebDriverPool(webDriverFactory, properties);
        log.info("WebDriver pool created with max total: {}", properties.getSelenium().getPool().getMaxTotal());
        return pool;
    }

    @PreDestroy
    public void cleanup() {
        log.info("Selenium configuration cleanup initiated");
    }
}
