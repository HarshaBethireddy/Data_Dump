package com.bureau.comparison.exception;

/**
 * Base exception for all bureau comparison system errors.
 * Provides additional context for debugging and error tracking.
 */
public class BureauComparisonException extends RuntimeException {

    private final String errorCode;
    private final transient Object context;

    public BureauComparisonException(String message) {
        super(message);
        this.errorCode = "BUREAU_ERROR";
        this.context = null;
    }

    public BureauComparisonException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = "BUREAU_ERROR";
        this.context = null;
    }

    public BureauComparisonException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
        this.context = null;
    }

    public BureauComparisonException(String errorCode, String message, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.context = null;
    }

    public BureauComparisonException(String errorCode, String message, Object context) {
        super(message);
        this.errorCode = errorCode;
        this.context = context;
    }

    public BureauComparisonException(String errorCode, String message, Throwable cause, Object context) {
        super(message, cause);
        this.errorCode = errorCode;
        this.context = context;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public Object getContext() {
        return context;
    }

    @Override
    public String toString() {
        String baseMessage = super.toString();
        if (context != null) {
            return String.format("%s [Code: %s, Context: %s]", baseMessage, errorCode, context);
        }
        return String.format("%s [Code: %s]", baseMessage, errorCode);
    }
}
