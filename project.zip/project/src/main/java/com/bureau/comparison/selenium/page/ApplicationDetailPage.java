package com.bureau.comparison.selenium.page;

import com.bureau.comparison.exception.ExtractionException;
import com.bureau.comparison.selenium.page.base.BasePage;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Page Object for Application Detail Page.
 */
@Slf4j
public class ApplicationDetailPage extends BasePage {

    // Locators
    private final By viewBureauButton = By.xpath("//button[.='View Bureau']");

    public ApplicationDetailPage(WebDriver driver, int timeoutSeconds) {
        super(driver, timeoutSeconds);
    }

    /**
     * Click View Bureau button to open popup
     */
    public void clickViewBureauButton() {
        try {
            log.info("Clicking View Bureau button");

            WebElement button = wait.waitForClickable(viewBureauButton);
            button.click();

            pause(2000);

            // Wait for new window to open
            wait.waitForNumberOfWindows(2);

            log.info("View Bureau button clicked, popup opened");
        } catch (Exception e) {
            log.error("Failed to click View Bureau button", e);
            throw new ExtractionException("Failed to click View Bureau button", e);
        }
    }

    /**
     * Check if View Bureau button is displayed
     */
    public boolean isViewBureauButtonDisplayed() {
        return isDisplayed(viewBureauButton);
    }
}
