package com.bureau.comparison.domain;

/**
 * Enum representing the processing status of an application.
 */
public enum ProcessingStatus {
    PENDING("Pending", "Application is queued for processing"),
    IN_PROGRESS("In Progress", "Application is currently being processed"),
    COMPLETED("Completed", "Application processing completed successfully"),
    FAILED("Failed", "Application processing failed"),
    EXTRACTION_FAILED("Extraction Failed", "Bureau data extraction failed"),
    COMPARISON_FAILED("Comparison Failed", "File comparison failed"),
    MATCHED("Matched", "PRE and POST files match"),
    DIFFERENT("Different", "PRE and POST files have differences");

    private final String displayName;
    private final String description;

    ProcessingStatus(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    public boolean isTerminal() {
        return this == COMPLETED || this == FAILED ||
               this == MATCHED || this == DIFFERENT;
    }

    public boolean isSuccess() {
        return this == COMPLETED || this == MATCHED || this == DIFFERENT;
    }

    public boolean isFailure() {
        return this == FAILED || this == EXTRACTION_FAILED ||
               this == COMPARISON_FAILED;
    }
}
