package com.bureau.comparison.service;

import com.bureau.comparison.config.BureauProperties;
import com.bureau.comparison.domain.ApplicationData;
import com.bureau.comparison.domain.CategoryType;
import com.bureau.comparison.domain.ExtractionResult;
import com.bureau.comparison.exception.ExtractionException;
import com.bureau.comparison.selenium.page.*;
import com.bureau.comparison.selenium.pool.WebDriverPool;
import com.bureau.comparison.util.FileUtils;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;

/**
 * Service for extracting bureau data using Selenium.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BureauExtractionService {

    private final WebDriverPool driverPool;
    private final BureauProperties properties;

    /**
     * Extract bureau data for an application
     */
    @Retry(name = "bureauExtraction")
    public ExtractionResult extractBureauData(
            ApplicationData appData,
            String appId,
            String type,
            Path outputDirectory
    ) {
        WebDriver driver = null;
        long startTime = System.currentTimeMillis();

        try {
            // Set MDC context for logging
            MDC.put("appId", appId);
            MDC.put("category", appData.category().toString());

            log.info("Starting bureau data extraction - Type: {}, AppID: {}", type, appId);

            // Borrow driver from pool
            driver = driverPool.borrowObject();

            // Perform extraction
            String bureauData = performExtraction(driver, appData.category(), appId, type);

            // Save to file
            String outputPath = FileUtils.generateOutputFilePath(outputDirectory, appData.fileName(), type, appId);
            FileUtils.writeToFile(Paths.get(outputPath), bureauData);

            long duration = (System.currentTimeMillis() - startTime) / 1000;
            log.info("Bureau data extraction successful - Duration: {}s", duration);

            return ExtractionResult.success(appId, type, outputPath, null, duration);

        } catch (Exception e) {
            long duration = (System.currentTimeMillis() - startTime) / 1000;
            log.error("Bureau data extraction failed - Type: {}, AppID: {}", type, appId, e);

            return ExtractionResult.failure(appId, type, e.getMessage(), duration);

        } finally {
            // Return driver to pool
            if (driver != null) {
                driverPool.returnObject(driver);
            }
            MDC.clear();
        }
    }

    /**
     * Perform extraction using Page Objects
     */
    private String performExtraction(WebDriver driver, CategoryType category, String appId, String type) {
        int timeout = properties.getPerformance().getTimeouts().getExtraction();

        // Initialize page objects
        LoginPage loginPage = new LoginPage(driver, timeout);
        GroupSelectionPage groupPage = new GroupSelectionPage(driver, timeout);
        SearchPage searchPage = new SearchPage(driver, timeout);
        ApplicationDetailPage detailPage = new ApplicationDetailPage(driver, timeout);
        BureauDataPopupPage popupPage = new BureauDataPopupPage(driver, timeout);

        try {
            // Step 1: Login (if not already logged in)
            if (!isLoggedIn(driver)) {
                driver.get(properties.getBaseUrl());
                loginPage.login(
                        properties.getCredentials().getUsername(),
                        properties.getCredentials().getPassword()
                );

                // Step 2: Select group
                groupPage.selectGroup("Administrators");
            }

            // Step 3: Navigate to search
            searchPage.navigateToSearch(category);

            // Step 4: Search for application
            searchPage.searchByAppId(appId);

            // Step 5: Open application
            searchPage.openApplication();

            // Step 6: Click View Bureau button
            detailPage.clickViewBureauButton();

            // Step 7: Extract data from popup
            String mainWindow = driver.getWindowHandle();
            popupPage.switchToPopup(mainWindow);

            String bureauData = popupPage.extractAllBureauData(appId, type);

            popupPage.closePopup(mainWindow);

            return bureauData;

        } catch (Exception e) {
            log.error("Extraction failed", e);
            throw new ExtractionException("Extraction failed for AppID: " + appId, e);
        }
    }

    /**
     * Check if already logged in
     */
    private boolean isLoggedIn(WebDriver driver) {
        try {
            String currentUrl = driver.getCurrentUrl();
            return currentUrl != null &&
                    currentUrl.contains(properties.getBaseUrl()) &&
                    !currentUrl.contains("login");
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Extract bureau data for multiple applications in sequence
     */
    public ExtractionResult extractBureauDataWithNavigationBack(
            WebDriver driver,
            ApplicationData appData,
            String appId,
            String type,
            Path outputDirectory,
            boolean isLast
    ) {
        long startTime = System.currentTimeMillis();
        int timeout = properties.getPerformance().getTimeouts().getExtraction();

        try {
            MDC.put("appId", appId);
            MDC.put("category", appData.category().toString());

            log.info("Extracting bureau data - Type: {}, AppID: {}", type, appId);

            SearchPage searchPage = new SearchPage(driver, timeout);
            ApplicationDetailPage detailPage = new ApplicationDetailPage(driver, timeout);
            BureauDataPopupPage popupPage = new BureauDataPopupPage(driver, timeout);

            // Search for application
            searchPage.searchByAppId(appId);

            // Open application
            searchPage.openApplication();

            // Click View Bureau button
            detailPage.clickViewBureauButton();

            // Extract data from popup
            String mainWindow = driver.getWindowHandle();
            popupPage.switchToPopup(mainWindow);

            String bureauData = popupPage.extractAllBureauData(appId, type);

            popupPage.closePopup(mainWindow);

            // Navigate back to search (unless it's the last one)
            if (!isLast) {
                searchPage.navigateBackToSearch();
            }

            // Save to file
            String outputPath = FileUtils.generateOutputFilePath(outputDirectory, appData.fileName(), type, appId);
            FileUtils.writeToFile(Paths.get(outputPath), bureauData);

            long duration = (System.currentTimeMillis() - startTime) / 1000;
            log.info("Bureau data extraction successful - Duration: {}s", duration);

            return ExtractionResult.success(appId, type, outputPath, null, duration);

        } catch (Exception e) {
            long duration = (System.currentTimeMillis() - startTime) / 1000;
            log.error("Bureau data extraction failed", e);

            return ExtractionResult.failure(appId, type, e.getMessage(), duration);

        } finally {
            MDC.clear();
        }
    }
}
