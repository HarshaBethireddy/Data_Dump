package com.bureau.comparison.cli;

import com.bureau.comparison.config.BureauProperties;
import com.bureau.comparison.domain.ApplicationData;
import com.bureau.comparison.domain.ComparisonResult;
import com.bureau.comparison.domain.ProcessingStatistics;
import com.bureau.comparison.service.AppIdExtractionService;
import com.bureau.comparison.service.ApplicationOrchestrator;
import com.bureau.comparison.service.ExcelService;
import com.bureau.comparison.util.FileUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Command Line Interface for Bureau Comparison System.
 * Provides interactive CLI for processing bureau data.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CommandLineRunner implements CommandLineRunner {

    private final BureauProperties properties;
    private final AppIdExtractionService appIdService;
    private final ExcelService excelService;
    private final ApplicationOrchestrator orchestrator;
    private final ProcessingStatistics statistics;

    @Override
    public void run(String... args) throws Exception {
        Scanner scanner = new Scanner(System.in);

        try {
            displayBanner();

            System.out.println("\n=== Step 1: Application ID Extraction ===\n");

            // Get folder names from user
            System.out.print("Enter PRE folder name (in Downloads): ");
            String preFolderName = scanner.nextLine().trim();

            System.out.print("Enter POST folder name (in Downloads): ");
            String postFolderName = scanner.nextLine().trim();

            // Create output directory
            Path outputDirectory = FileUtils.createTimestampedOutputDirectory(
                    properties.getFolders().getOutput()
            );

            log.info("Output directory created: {}", outputDirectory);

            // Extract AppIDs
            System.out.println("\n\uD83D\uDD0D Extracting Application IDs from JSON files...");
            Map<String, ApplicationData> applications = appIdService.extractAppIds(
                    preFolderName,
                    postFolderName
            );

            if (applications.isEmpty()) {
                System.out.println("\n❌ No applications found. Exiting.");
                return;
            }

            System.out.printf("✅ Found %d applications\n", applications.size());

            // Write comparison Excel
            Path excelPath = outputDirectory.resolve("APPIDComparison_ALL.xlsx");
            excelService.writeAppIdComparisonExcel(applications, excelPath);
            System.out.printf("✅ Excel comparison written: %s\n", excelPath);

            System.out.println("\n=== Step 2: Bureau Data Extraction & Comparison ===\n");
            System.out.printf("Processing %d applications with parallel execution...\n", applications.size());
            System.out.println("Using Selenium Grid: " + properties.getSelenium().getGrid().getUrl());
            System.out.println("Browser pool size: " + properties.getSelenium().getPool().getMaxTotal());
            System.out.println();

            // Process all applications
            long startTime = System.currentTimeMillis();

            Map<String, List<ComparisonResult>> results =
                    orchestrator.processAllApplicationsByCategory(applications, outputDirectory);

            long endTime = System.currentTimeMillis();
            long durationSeconds = (endTime - startTime) / 1000;

            // Generate and save reports
            System.out.println("\n=== Step 3: Generating Reports ===\n");
            generateReports(results, outputDirectory);

            // Display summary
            displaySummary(durationSeconds);

            System.out.println("\n=== Processing Complete ===");
            System.out.printf("Output location: %s\n", outputDirectory);
            System.out.println();

        } catch (Exception e) {
            log.error("Error in CLI execution", e);
            System.err.println("\n❌ Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }

    /**
     * Display banner
     */
    private void displayBanner() {
        System.out.println();
        System.out.println("=".repeat(70));
        System.out.println("  BUREAU COMPARISON SYSTEM v2.0");
        System.out.println("  High-Performance Reactive Processing with Selenium Grid");
        System.out.println("=".repeat(70));
        System.out.println();
        System.out.println("Features:");
        System.out.println("  ✓ Selenium Grid 4 - Distributed browser automation");
        System.out.println("  ✓ Browser Pooling - Optimized resource management");
        System.out.println("  ✓ Project Reactor - Non-blocking parallel processing");
        System.out.println("  ✓ Java 21 - Virtual threads & modern features");
        System.out.println("=".repeat(70));
    }

    /**
     * Generate text reports
     */
    private void generateReports(Map<String, List<ComparisonResult>> results, Path outputDirectory) throws Exception {
        StringBuilder masterReport = new StringBuilder();
        masterReport.append("===== MASTER BUREAU DATA COMPARISON REPORT =====\n");
        masterReport.append("Generated: ").append(java.time.LocalDateTime.now()).append("\n");
        masterReport.append("Total Applications: ").append(statistics.getTotalFiles().get()).append("\n");
        masterReport.append("==============================================\n\n");

        masterReport.append(statistics.getSummary()).append("\n\n");

        // Generate per-category reports
        for (Map.Entry<String, List<ComparisonResult>> entry : results.entrySet()) {
            String category = entry.getKey();
            List<ComparisonResult> categoryResults = entry.getValue();

            System.out.printf("  Generating report for category: %s (%d files)\n", category, categoryResults.size());

            // Category report
            StringBuilder categoryReport = new StringBuilder();
            categoryReport.append("===== CATEGORY: ").append(category).append(" =====\n");
            categoryReport.append("Applications: ").append(categoryResults.size()).append("\n");
            categoryReport.append("==========================================\n\n");

            for (ComparisonResult result : categoryResults) {
                categoryReport.append(formatComparisonResult(result)).append("\n\n");
            }

            // Save category report
            Path categoryDir = outputDirectory.resolve(category);
            Path categoryReportPath = categoryDir.resolve("comparison_report.txt");
            FileUtils.writeToFile(categoryReportPath, categoryReport.toString());

            // Add to master report
            masterReport.append(categoryReport);
        }

        // Save master report
        Path masterReportPath = outputDirectory.resolve("MASTER_comparison_report.txt");
        FileUtils.writeToFile(masterReportPath, masterReport.toString());

        System.out.println("✅ All reports generated successfully");
    }

    /**
     * Format comparison result for report
     */
    private String formatComparisonResult(ComparisonResult result) {
        StringBuilder sb = new StringBuilder();

        sb.append("File: ").append(result.applicationData().fileName()).append("\n");
        sb.append("Status: ").append(result.status().getDisplayName()).append("\n");

        if (result.matched()) {
            sb.append("Result: MATCHED - No differences found\n");
            sb.append("PRE Lines: ").append(result.preFileLines()).append("\n");
            sb.append("POST Lines: ").append(result.postFileLines()).append("\n");
        } else if (result.status().isFailure()) {
            sb.append("Result: FAILED\n");
            sb.append("Error: ").append(result.summaryMessage()).append("\n");
        } else {
            sb.append("Result: DIFFERENCES FOUND\n");
            sb.append("Total Differences: ").append(result.totalDifferences()).append("\n");
            sb.append("PRE Lines: ").append(result.preFileLines()).append("\n");
            sb.append("POST Lines: ").append(result.postFileLines()).append("\n");

            if (result.differences() != null && !result.differences().isEmpty()) {
                sb.append("\nDifference Details (showing first 20):\n");
                int count = 0;
                for (ComparisonResult.LineDifference diff : result.differences()) {
                    if (count++ >= 20) {
                        sb.append("... and ").append(result.differences().size() - 20).append(" more differences\n");
                        break;
                    }
                    sb.append("\nLine ").append(diff.lineNumber());
                    sb.append(" (Bureau: ").append(diff.bureauName());
                    sb.append(", Type: ").append(diff.bureauType()).append(")\n");
                    sb.append("  PRE:  ").append(diff.preLine()).append("\n");
                    sb.append("  POST: ").append(diff.postLine()).append("\n");
                }
            }
        }

        sb.append("Duration: ").append(result.comparisonDurationSeconds()).append(" seconds\n");

        return sb.toString();
    }

    /**
     * Display processing summary
     */
    private void displaySummary(long durationSeconds) {
        System.out.println("\n" + "=".repeat(70));
        System.out.println("  PROCESSING SUMMARY");
        System.out.println("=".repeat(70));

        System.out.printf("Total Files:         %d\n", statistics.getTotalFiles().get());
        System.out.printf("Processed:           %d\n", statistics.getProcessedFiles().get());
        System.out.printf("Matched:             %d\n", statistics.getMatchedFiles().get());
        System.out.printf("Different:           %d\n", statistics.getDifferentFiles().get());
        System.out.printf("Failed:              %d\n",
                statistics.getFailedExtractions().get() + statistics.getFailedComparisons().get());
        System.out.printf("Total Differences:   %d\n", statistics.getTotalDifferencesFound().get());
        System.out.println();
        System.out.printf("Processing Time:     %d seconds (%.2f minutes)\n",
                durationSeconds, durationSeconds / 60.0);
        System.out.printf("Throughput:          %.2f files/second\n",
                (double) statistics.getProcessedFiles().get() / durationSeconds);
        System.out.printf("Success Rate:        %.1f%%\n", statistics.getSuccessRate());

        System.out.println("=".repeat(70));
    }
}
