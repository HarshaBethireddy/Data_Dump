package com.bureau.comparison.domain;

import lombok.Builder;

import java.util.List;

/**
 * Represents the result of comparing PRE and POST bureau data files.
 */
@Builder
public record ComparisonResult(
        ApplicationData applicationData,
        ProcessingStatus status,
        boolean matched,
        int totalDifferences,
        int preFileLines,
        int postFileLines,
        List<LineDifference> differences,
        String summaryMessage,
        long comparisonDurationSeconds
) {
    /**
     * Create a matched comparison result
     */
    public static ComparisonResult matched(
            ApplicationData applicationData,
            int preFileLines,
            int postFileLines,
            long durationSeconds
    ) {
        return ComparisonResult.builder()
                .applicationData(applicationData)
                .status(ProcessingStatus.MATCHED)
                .matched(true)
                .totalDifferences(0)
                .preFileLines(preFileLines)
                .postFileLines(postFileLines)
                .summaryMessage("No differences found")
                .comparisonDurationSeconds(durationSeconds)
                .build();
    }

    /**
     * Create a different comparison result
     */
    public static ComparisonResult different(
            ApplicationData applicationData,
            List<LineDifference> differences,
            int preFileLines,
            int postFileLines,
            long durationSeconds
    ) {
        return ComparisonResult.builder()
                .applicationData(applicationData)
                .status(ProcessingStatus.DIFFERENT)
                .matched(false)
                .totalDifferences(differences.size())
                .differences(differences)
                .preFileLines(preFileLines)
                .postFileLines(postFileLines)
                .summaryMessage(String.format("%d differences found", differences.size()))
                .comparisonDurationSeconds(durationSeconds)
                .build();
    }

    /**
     * Create a failed comparison result
     */
    public static ComparisonResult failed(ApplicationData applicationData, String errorMessage) {
        return ComparisonResult.builder()
                .applicationData(applicationData)
                .status(ProcessingStatus.COMPARISON_FAILED)
                .matched(false)
                .totalDifferences(0)
                .summaryMessage("Comparison failed: " + errorMessage)
                .build();
    }

    /**
     * Nested record for line-level differences
     */
    @Builder
    public record LineDifference(
            int lineNumber,
            String preLine,
            String postLine,
            String bureauName,
            String bureauType,
            DifferenceType type
    ) {
        public enum DifferenceType {
            MODIFIED,
            ADDED,
            REMOVED
        }
    }
}
