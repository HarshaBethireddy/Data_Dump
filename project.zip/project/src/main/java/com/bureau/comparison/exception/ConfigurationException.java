package com.bureau.comparison.exception;

/**
 * Exception thrown when configuration is invalid or missing.
 */
public class ConfigurationException extends BureauComparisonException {

    public ConfigurationException(String message) {
        super("CONFIG_ERROR", message);
    }

    public ConfigurationException(String message, Throwable cause) {
        super("CONFIG_ERROR", message, cause);
    }

    /**
     * Missing required configuration
     */
    public static class MissingConfigurationException extends ConfigurationException {
        public MissingConfigurationException(String configKey) {
            super("Missing required configuration: " + configKey);
        }
    }

    /**
     * Invalid configuration value
     */
    public static class InvalidConfigurationException extends ConfigurationException {
        public InvalidConfigurationException(String configKey, String value, String reason) {
            super(String.format("Invalid configuration for '%s': value='%s', reason: %s",
                    configKey, value, reason));
        }
    }

    /**
     * Selenium Grid connection error
     */
    public static class GridConnectionException extends ConfigurationException {
        public GridConnectionException(String gridUrl) {
            super("Cannot connect to Selenium Grid at: " + gridUrl);
        }

        public GridConnectionException(String gridUrl, Throwable cause) {
            super("Cannot connect to Selenium Grid at: " + gridUrl, cause);
        }
    }
}
