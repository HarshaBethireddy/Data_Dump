package com.bureau.comparison.service;

import com.bureau.comparison.config.BureauProperties;
import com.bureau.comparison.domain.ApplicationData;
import com.bureau.comparison.util.FileUtils;
import com.bureau.comparison.util.JsonUtils;
import com.bureau.comparison.util.StringUtils;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

/**
 * Service for extracting application IDs from JSON files.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AppIdExtractionService {

    private final BureauProperties properties;

    /**
     * Extract AppIDs from PRE and POST folders and create ApplicationData list
     */
    public Map<String, ApplicationData> extractAppIds(String preFolderName, String postFolderName) throws Exception {
        log.info("Extracting AppIDs from folders - PRE: {}, POST: {}", preFolderName, postFolderName);

        String preFolderPath = properties.getFolders().getBasePre() + preFolderName;
        String postFolderPath = properties.getFolders().getBasePost() + postFolderName;

        Map<String, String> preAppIds = extractAppIdsFromFolder(preFolderPath);
        Map<String, String> postAppIds = extractAppIdsFromFolder(postFolderPath);

        // Combine into ApplicationData
        Set<String> allFileNames = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        allFileNames.addAll(preAppIds.keySet());
        allFileNames.addAll(postAppIds.keySet());

        Map<String, ApplicationData> applications = new LinkedHashMap<>();
        for (String fileName : allFileNames) {
            String preAppId = preAppIds.getOrDefault(fileName, "");
            String postAppId = postAppIds.getOrDefault(fileName, "");

            ApplicationData appData = ApplicationData.create(fileName, preAppId, postAppId);
            if (appData.isValid()) {
                applications.put(fileName, appData);
            }
        }

        log.info("Extracted {} valid applications", applications.size());
        return applications;
    }

    /**
     * Extract AppIDs from all files in a folder
     */
    private Map<String, String> extractAppIdsFromFolder(String folderPath) throws Exception {
        Map<String, String> appIds = new HashMap<>();

        Path folder = Paths.get(folderPath);
        if (!java.nio.file.Files.exists(folder)) {
            log.warn("Folder not found: {}", folderPath);
            return appIds;
        }

        // Get all JSON and TXT files
        List<File> jsonFiles = FileUtils.listFilesWithExtension(folder, ".json");
        List<File> txtFiles = FileUtils.listFilesWithExtension(folder, ".txt");

        // Process JSON files
        for (File file : jsonFiles) {
            try {
                String appId = extractAppIdFromJsonFile(file);
                appIds.put(file.getName(), appId);
            } catch (Exception e) {
                log.warn("Failed to extract AppID from {}: {}", file.getName(), e.getMessage());
                appIds.put(file.getName(), "");
            }
        }

        // Process TXT files
        for (File file : txtFiles) {
            try {
                String appId = extractAppIdFromTxtFile(file);
                appIds.put(file.getName(), appId);
            } catch (Exception e) {
                log.warn("Failed to extract AppID from {}: {}", file.getName(), e.getMessage());
                appIds.put(file.getName(), "");
            }
        }

        log.info("Extracted AppIDs from {} files in folder: {}", appIds.size(), folderPath);
        return appIds;
    }

    /**
     * Extract AppID from JSON file
     */
    private String extractAppIdFromJsonFile(File file) throws Exception {
        String content = FileUtils.readFileWithEncoding(file.toPath());
        JsonNode root = JsonUtils.parseJson(content);
        return JsonUtils.extractAppId(root);
    }

    /**
     * Extract AppID from TXT file (from filename or content)
     */
    private String extractAppIdFromTxtFile(File file) throws Exception {
        // Try from filename first
        String appId = StringUtils.extractAppIdFromFileName(file.getName());
        if (StringUtils.isNotBlank(appId)) {
            return appId;
        }

        // Try from content
        String content = FileUtils.readFileWithEncoding(file.toPath());
        appId = StringUtils.extractAppIdFromContent(content);

        return StringUtils.defaultIfBlank(appId, "");
    }
}
