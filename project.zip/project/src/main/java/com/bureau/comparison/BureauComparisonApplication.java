package com.bureau.comparison;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

/**
 * Main Spring Boot Application for Bureau Comparison System.
 *
 * High-performance, distributed bureau data comparison system featuring:
 * - Selenium Grid integration for parallel processing
 * - Project Reactor for reactive processing
 * - Browser pooling for resource optimization
 * - Dynamic waits for efficient Selenium operations
 * - Comprehensive HTML reporting
 * - BDD/Cucumber test support
 *
 * @author Bureau Comparison Team
 * @version 2.0.0
 */
@SpringBootApplication
@EnableConfigurationProperties
public class BureauComparisonApplication {

    public static void main(String[] args) {
        // Set system properties for better performance
        System.setProperty("java.awt.headless", "true");
        System.setProperty("webdriver.http.factory", "jdk-http-client");

        // Start Spring Boot application
        SpringApplication.run(BureauComparisonApplication.class, args);
    }
}
