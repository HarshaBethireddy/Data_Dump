package com.bureau.comparison.exception;

/**
 * Exception thrown when bureau data extraction fails.
 */
public class ExtractionException extends BureauComparisonException {

    public ExtractionException(String message) {
        super("EXTRACTION_ERROR", message);
    }

    public ExtractionException(String message, Throwable cause) {
        super("EXTRACTION_ERROR", message, cause);
    }

    public ExtractionException(String message, String applicationId) {
        super("EXTRACTION_ERROR", message, applicationId);
    }

    public ExtractionException(String message, Throwable cause, String applicationId) {
        super("EXTRACTION_ERROR", message, cause, applicationId);
    }

    /**
     * Specific extraction failure types
     */
    public static class LoginFailedException extends ExtractionException {
        public LoginFailedException(String message) {
            super("Login failed: " + message);
        }

        public LoginFailedException(String message, Throwable cause) {
            super("Login failed: " + message, cause);
        }
    }

    public static class NavigationException extends ExtractionException {
        public NavigationException(String message) {
            super("Navigation failed: " + message);
        }

        public NavigationException(String message, Throwable cause) {
            super("Navigation failed: " + message, cause);
        }
    }

    public static class DataExtractionException extends ExtractionException {
        public DataExtractionException(String message, String applicationId) {
            super("Data extraction failed: " + message, applicationId);
        }

        public DataExtractionException(String message, Throwable cause, String applicationId) {
            super("Data extraction failed: " + message, cause, applicationId);
        }
    }

    public static class TimeoutException extends ExtractionException {
        public TimeoutException(String message) {
            super("Timeout occurred: " + message);
        }

        public TimeoutException(String message, Throwable cause) {
            super("Timeout occurred: " + message, cause);
        }
    }
}
