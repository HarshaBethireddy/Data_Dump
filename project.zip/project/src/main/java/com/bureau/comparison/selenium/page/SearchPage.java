package com.bureau.comparison.selenium.page;

import com.bureau.comparison.domain.CategoryType;
import com.bureau.comparison.exception.ExtractionException;
import com.bureau.comparison.selenium.page.base.BasePage;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.*;

import java.util.List;

/**
 * Page Object for Application Search Page.
 */
@Slf4j
public class SearchPage extends BasePage {

    // Locators
    private final By appIdField = By.id("txt-appid");
    private final By searchButton = By.id("btn-search");
    private final By dataGrid = By.id("datagrid");
    private final By applicationLink = By.xpath("//table[@id='datagrid']//td//div//center//a");

    public SearchPage(WebDriver driver, int timeoutSeconds) {
        super(driver, timeoutSeconds);
    }

    /**
     * Navigate to search screen via menu
     */
    public void navigateToSearch(CategoryType category) {
        try {
            log.info("Navigating to search for category: {}", category);

            String[] menuPath = category.getMenuPath();
            openMenuAndClick(menuPath);

            // Wait for search screen
            wait.waitForVisible(appIdField);
            pause(2000);

            log.info("Successfully navigated to search screen");
        } catch (Exception e) {
            log.error("Failed to navigate to search", e);
            throw new ExtractionException.NavigationException("Failed to navigate to search screen", e);
        }
    }

    /**
     * Search for application by ID
     */
    public void searchByAppId(String appId) {
        try {
            log.info("Searching for application ID: {}", appId);

            // Wait for field to be visible
            wait.waitForVisible(appIdField);
            pause(2000);

            // Get field and clear it
            WebElement appIdInput = wait.waitForClickable(appIdField);

            // Scroll into view
            scrollToElement(appIdInput);
            appIdInput.click();

            // Clear field
            appIdInput.sendKeys(Keys.CONTROL + "a");
            appIdInput.sendKeys(Keys.DELETE);
            pause(1000);

            // Type application ID slowly
            for (char c : appId.toCharArray()) {
                appIdInput.sendKeys(String.valueOf(c));
                pause(50);
            }

            // Wait for value to be set
            wait.waitForAttributeValue(appIdField, "value", appId);
            pause(2000);

            // Click search button
            WebElement searchBtn = wait.waitForClickable(searchButton);
            searchBtn.click();

            log.info("Search button clicked");
            pause(3000);

        } catch (Exception e) {
            log.error("Failed to search for application: {}", appId, e);
            throw new ExtractionException("Failed to search for application: " + appId, e);
        }
    }

    /**
     * Open application from search results
     */
    public void openApplication() {
        try {
            log.info("Opening application from search results");

            WebElement link = wait.waitForClickable(applicationLink);
            link.click();

            pause(3000);

            log.info("Application opened");
        } catch (Exception e) {
            log.error("Failed to open application", e);
            throw new ExtractionException("Failed to open application", e);
        }
    }

    /**
     * Navigate back to search screen
     */
    public void navigateBackToSearch() {
        try {
            log.info("Navigating back to search screen");

            // Click Close button
            By closeButton = By.xpath("//button[.='Close']");
            WebElement closeBtn = wait.waitForClickable(closeButton);
            closeBtn.click();

            pause(2000);

            // Handle confirmation modal
            handleConfirmationModal();

            // Wait for search screen
            wait.waitForVisible(appIdField);
            pause(2000);

            log.info("Successfully navigated back to search screen");
        } catch (Exception e) {
            log.error("Failed to navigate back to search", e);
            throw new ExtractionException.NavigationException("Failed to navigate back to search", e);
        }
    }

    /**
     * Handle confirmation modal (OK button)
     */
    private void handleConfirmationModal() {
        try {
            By modal = By.cssSelector(".wicket-modal");
            WebElement modalElement = wait.waitForVisible(modal);

            By okButton = By.xpath("//*[@name='ok']");
            WebElement okBtn = wait.waitForClickable(okButton);
            okBtn.click();

            wait.waitForInvisible(modal);
            log.info("Confirmation modal handled");

        } catch (Exception e) {
            try {
                // Alternative OK button locator
                By okButton = By.xpath("//input[@type='button' and @value='OK']");
                WebElement okBtn = wait.waitForClickable(okButton);
                okBtn.click();
                pause(2000);
            } catch (Exception altError) {
                log.warn("Modal handling failed: {}", altError.getMessage());
            }
        }
    }

    /**
     * Open menu and click through menu path
     */
    private void openMenuAndClick(String... labels) {
        if (labels == null || labels.length == 0) {
            throw new IllegalArgumentException("At least one label is required");
        }

        try {
            By menuLocator = By.cssSelector("ul#menu");
            WebElement scope = wait.waitForPresent(menuLocator);

            for (int i = 0; i < labels.length; i++) {
                String label = labels[i].trim().replaceAll("\\s+", " ");

                String anchorsXpath = scope.getTagName().equalsIgnoreCase("ul") ? "./li/a" : "./ul/li/a";
                List<WebElement> anchors = scope.findElements(By.xpath(anchorsXpath));

                WebElement link = anchors.stream()
                        .filter(a -> {
                            String directText = (String) js.executeScript(
                                    "const a=arguments[0]; return [...a.childNodes].filter(n=>n.nodeType===3)" +
                                            ".map(n=>n.textContent).join('').replace(/\\s+/g,' ').trim();", a);
                            return label.equals(directText);
                        })
                        .findFirst()
                        .orElseThrow(() -> new NoSuchElementException("Not found: " + label));

                scrollToElement(link);
                wait.waitForVisible(By.xpath(".//a[text()='" + label + "']"));

                boolean isLeaf = (i == labels.length - 1);
                if (isLeaf) {
                    // Click final item
                    wait.waitForClickable(By.xpath(".//a[contains(text(),'" + label + "')]"));
                    clickWithJavaScript(link);
                    return;
                } else {
                    // Hover to open submenu
                    WebElement li = link.findElement(By.xpath("./ancestor::li[1]"));
                    boolean opened = false;

                    try {
                        hoverOver(link);
                        pause(150);
                        opened = waitForChildVisible(li, 2);
                    } catch (Exception ignored) {
                    }

                    if (!opened) {
                        clickWithJavaScript(link);
                        opened = waitForChildVisible(li, 4);
                    }

                    if (!opened) {
                        throw new ExtractionException.NavigationException("Submenu did not open for: " + label);
                    }
                    scope = li;
                }
            }
        } catch (Exception e) {
            log.error("Failed to navigate menu", e);
            throw new ExtractionException.NavigationException("Failed to navigate menu", e);
        }
    }

    /**
     * Wait for child submenu to become visible
     */
    private boolean waitForChildVisible(WebElement li, int timeoutSeconds) {
        try {
            return wait.waitFor(driver -> {
                try {
                    WebElement ul = li.findElement(By.xpath("./ul"));
                    Object visible = js.executeScript(
                            "const u=arguments[0]; if(!u) return false;" +
                                    "const s=getComputedStyle(u);" +
                                    "if(s.display==='none' || s.visibility==='hidden' || +s.opacity===0) return false;" +
                                    "const r=u.getBoundingClientRect(); return r.width>0 && r.height>0;", ul);
                    return Boolean.TRUE.equals(visible);
                } catch (NoSuchElementException | StaleElementReferenceException e) {
                    return false;
                }
            }, java.time.Duration.ofSeconds(timeoutSeconds));
        } catch (TimeoutException e) {
            return false;
        }
    }
}
