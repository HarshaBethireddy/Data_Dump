package com.bureau.comparison.service;

import com.bureau.comparison.config.BureauProperties;
import com.bureau.comparison.domain.*;
import com.bureau.comparison.selenium.pool.WebDriverPool;
import com.bureau.comparison.util.FileUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Main orchestrator service for bureau comparison processing.
 * Uses Project Reactor for reactive, parallel processing.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ApplicationOrchestrator {

    private final BureauProperties properties;
    private final WebDriverPool driverPool;
    private final BureauExtractionService extractionService;
    private final FileComparisonService comparisonService;
    private final ProcessingStatistics statistics;
    private final Scheduler seleniumScheduler;

    /**
     * Process all applications with maximum parallelism (category-based grouping)
     */
    public Map<String, List<ComparisonResult>> processAllApplicationsByCategory(
            Map<String, ApplicationData> applications,
            Path outputDirectory
    ) throws Exception {

        statistics.getTotalFiles().set(applications.size());
        statistics.markCompleted(); // Will be updated at the end

        log.info("Starting processing of {} applications", applications.size());

        // Group by category
        Map<CategoryType, List<ApplicationData>> categoryGroups = applications.values().stream()
                .collect(Collectors.groupingBy(ApplicationData::category));

        log.info("Processing {} categories: {}", categoryGroups.size(), categoryGroups.keySet());

        // Process each category in parallel
        Map<String, List<ComparisonResult>> results = Flux.fromIterable(categoryGroups.entrySet())
                .flatMap(entry -> processCategoryReactively(
                        entry.getKey(),
                        entry.getValue(),
                        outputDirectory
                ).map(categoryResults -> Map.entry(entry.getKey().getCode(), categoryResults)))
                .collectMap(Map.Entry::getKey, Map.Entry::getValue)
                .block();

        statistics.markCompleted();
        log.info("Processing completed. {}", statistics.getSummary());

        return results;
    }

    /**
     * Process a single category reactively with browser session reuse
     */
    private Mono<List<ComparisonResult>> processCategoryReactively(
            CategoryType category,
            List<ApplicationData> applications,
            Path outputDirectory
    ) {
        return Mono.fromCallable(() -> {
            log.info("[{}] Starting processing of {} applications", category, applications.size());

            WebDriver driver = null;
            try {
                // Borrow a driver for this entire category
                driver = driverPool.borrowObject();
                log.info("[{}] Borrowed WebDriver from pool", category);

                // Initialize browser (login once per category)
                initializeBrowserSession(driver, category);

                // Create category output directory
                Path categoryDir = FileUtils.createCategoryDirectory(outputDirectory, category.getCode());

                List<ComparisonResult> categoryResults = new ArrayList<>();

                // Process all applications in this category sequentially (within same browser session)
                for (int i = 0; i < applications.size(); i++) {
                    ApplicationData app = applications.get(i);
                    boolean isLast = (i == applications.size() - 1);

                    try {
                        ComparisonResult result = processApplicationInCategory(
                                driver, app, categoryDir, isLast
                        );
                        categoryResults.add(result);

                        // Update statistics
                        updateStatistics(result);

                    } catch (Exception e) {
                        log.error("[{}] Failed to process application: {}", category, app.fileName(), e);
                        ComparisonResult failedResult = ComparisonResult.failed(app, e.getMessage());
                        categoryResults.add(failedResult);
                        statistics.recordExtractionFailure(category);
                    }
                }

                log.info("[{}] Completed processing {} applications", category, categoryResults.size());
                return categoryResults;

            } finally {
                if (driver != null) {
                    driverPool.returnObject(driver);
                    log.info("[{}] Returned WebDriver to pool", category);
                }
            }
        }).subscribeOn(seleniumScheduler);
    }

    /**
     * Initialize browser session (login + group selection + navigation)
     */
    private void initializeBrowserSession(WebDriver driver, CategoryType category) {
        try {
            log.info("Initializing browser session for category: {}", category);

            var loginPage = new com.bureau.comparison.selenium.page.LoginPage(driver, 60);
            var groupPage = new com.bureau.comparison.selenium.page.GroupSelectionPage(driver, 60);
            var searchPage = new com.bureau.comparison.selenium.page.SearchPage(driver, 60);

            // Login
            driver.get(properties.getBaseUrl());
            loginPage.login(
                    properties.getCredentials().getUsername(),
                    properties.getCredentials().getPassword()
            );

            // Select Administrator group
            groupPage.selectGroup("Administrators");

            // Navigate to search screen for this category
            searchPage.navigateToSearch(category);

            log.info("Browser session initialized successfully");

        } catch (Exception e) {
            log.error("Failed to initialize browser session", e);
            throw new RuntimeException("Browser initialization failed", e);
        }
    }

    /**
     * Process single application within a category (with existing browser session)
     */
    private ComparisonResult processApplicationInCategory(
            WebDriver driver,
            ApplicationData app,
            Path categoryDir,
            boolean isLast
    ) {
        log.info("Processing application: {}", app.fileName());

        try {
            // Extract PRE data
            ExtractionResult preResult = extractionService.extractBureauDataWithNavigationBack(
                    driver, app, app.preAppId(), "PRE", categoryDir, false
            );

            if (!preResult.isSuccess()) {
                return ComparisonResult.failed(app, "PRE extraction failed: " + preResult.errorMessage());
            }

            // Extract POST data
            ExtractionResult postResult = extractionService.extractBureauDataWithNavigationBack(
                    driver, app, app.postAppId(), "POST", categoryDir, isLast
            );

            if (!postResult.isSuccess()) {
                return ComparisonResult.failed(app, "POST extraction failed: " + postResult.errorMessage());
            }

            // Update application data with file paths
            ApplicationData updatedApp = app.withFilePaths(preResult.outputFilePath(), postResult.outputFilePath());

            // Compare files
            ComparisonResult result = comparisonService.compareFiles(updatedApp, preResult, postResult);

            log.info("Application processed successfully: {} - Status: {}", app.fileName(), result.status());
            return result;

        } catch (Exception e) {
            log.error("Failed to process application: {}", app.fileName(), e);
            return ComparisonResult.failed(app, e.getMessage());
        }
    }

    /**
     * Update statistics based on comparison result
     */
    private void updateStatistics(ComparisonResult result) {
        if (result.status() == ProcessingStatus.MATCHED) {
            statistics.recordMatched(result.applicationData().category());
        } else if (result.status() == ProcessingStatus.DIFFERENT) {
            statistics.recordDifferent(
                    result.applicationData().category(),
                    result.totalDifferences()
            );
        } else {
            statistics.recordExtractionFailure(result.applicationData().category());
        }

        if (result.comparisonDurationSeconds() > 0) {
            statistics.recordProcessingTime(result.comparisonDurationSeconds());
        }
    }
}
