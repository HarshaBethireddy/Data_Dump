package com.bureau.comparison.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;

/**
 * Project Reactor configuration for reactive processing.
 * Configures custom schedulers for different types of operations.
 */
@Slf4j
@Configuration
@RequiredArgsConstructor
public class ReactorConfig {

    private final BureauProperties properties;

    /**
     * Scheduler for file I/O operations
     * Uses bounded elastic scheduler suitable for blocking I/O
     */
    @Bean(name = "ioScheduler")
    public Scheduler ioScheduler() {
        int ioParallelism = properties.getPerformance().getParallelism().getIoOperations();
        log.info("Creating I/O scheduler with parallelism: {}", ioParallelism);

        return Schedulers.newBoundedElastic(
                ioParallelism,
                Integer.MAX_VALUE,
                "io-scheduler",
                60, // TTL in seconds
                true // daemon threads
        );
    }

    /**
     * Scheduler for CPU-intensive operations (file comparison)
     * Uses parallel scheduler with configurable parallelism
     */
    @Bean(name = "cpuScheduler")
    public Scheduler cpuScheduler() {
        int cpuParallelism = properties.getPerformance().getParallelism().getComparison();
        log.info("Creating CPU scheduler with parallelism: {}", cpuParallelism);

        return Schedulers.newParallel(
                "cpu-scheduler",
                cpuParallelism,
                true // daemon threads
        );
    }

    /**
     * Scheduler for Selenium operations
     * Uses bounded elastic for blocking Selenium calls
     */
    @Bean(name = "seleniumScheduler")
    public Scheduler seleniumScheduler() {
        int fileParallelism = properties.getPerformance().getParallelism().getFileLevel();
        log.info("Creating Selenium scheduler with parallelism: {}", fileParallelism);

        return Schedulers.newBoundedElastic(
                fileParallelism,
                Integer.MAX_VALUE,
                "selenium-scheduler",
                300, // TTL in seconds (longer for selenium operations)
                true // daemon threads
        );
    }
}
