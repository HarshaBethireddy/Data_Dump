package com.bureau.comparison.selenium.page;

import com.bureau.comparison.exception.ExtractionException;
import com.bureau.comparison.selenium.page.base.BasePage;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Page Object for Login Page.
 */
@Slf4j
public class LoginPage extends BasePage {

    // Locators
    private final By usernameField = By.id("idToken1");
    private final By passwordField = By.id("idToken2");
    private final By loginButton = By.id("loginButton_0");
    private final By groupsDropdown = By.id("groups");

    public LoginPage(WebDriver driver, int timeoutSeconds) {
        super(driver, timeoutSeconds);
    }

    /**
     * Perform login with credentials
     */
    public void login(String username, String password) {
        try {
            log.info("Performing login for user: {}", username);

            wait.waitForVisible(usernameField);
            type(usernameField, username);

            wait.waitForVisible(passwordField);
            type(passwordField, password);

            wait.waitForClickable(loginButton);
            click(loginButton);

            // Wait for login to complete (group selection page appears)
            wait.waitForVisible(groupsDropdown);

            log.info("Login successful");
        } catch (Exception e) {
            log.error("Login failed", e);
            throw new ExtractionException.LoginFailedException("Failed to login", e);
        }
    }

    /**
     * Check if login page is displayed
     */
    public boolean isLoginPageDisplayed() {
        return isDisplayed(usernameField) && isDisplayed(passwordField) && isDisplayed(loginButton);
    }
}
