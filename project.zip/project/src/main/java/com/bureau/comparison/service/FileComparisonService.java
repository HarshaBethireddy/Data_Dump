package com.bureau.comparison.service;

import com.bureau.comparison.domain.*;
import com.bureau.comparison.exception.ComparisonException;
import com.bureau.comparison.util.FileUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * Service for comparing PRE and POST bureau data files.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class FileComparisonService {

    /**
     * Compare PRE and POST files
     */
    public ComparisonResult compareFiles(ApplicationData appData, ExtractionResult preResult, ExtractionResult postResult) {
        long startTime = System.currentTimeMillis();

        try {
            // Check if both extractions were successful
            if (!preResult.isSuccess() || !postResult.isSuccess()) {
                return ComparisonResult.failed(appData, "Extraction failed");
            }

            log.info("Comparing files for: {}", appData.fileName());

            // Read file contents
            List<String> preLines = Files.readAllLines(Paths.get(preResult.outputFilePath()));
            List<String> postLines = Files.readAllLines(Paths.get(postResult.outputFilePath()));

            // Parse bureau sections
            List<BureauSection> preSections = parseBureauSections(preLines);
            List<BureauSection> postSections = parseBureauSections(postLines);

            // Normalize content for comparison
            List<String> preNormalized = normalizeContent(preLines);
            List<String> postNormalized = normalizeContent(postLines);

            // Remove metadata
            preNormalized = removeMetadata(preNormalized);
            postNormalized = removeMetadata(postNormalized);

            long duration = (System.currentTimeMillis() - startTime) / 1000;

            // Compare
            if (preNormalized.equals(postNormalized)) {
                log.info("Files matched: {}", appData.fileName());
                return ComparisonResult.matched(appData, preLines.size(), postLines.size(), duration);
            } else {
                // Find differences
                List<ComparisonResult.LineDifference> differences =
                        findDifferences(preLines, postLines, preSections, postSections);

                log.info("Files different: {} - {} differences found", appData.fileName(), differences.size());
                return ComparisonResult.different(appData, differences, preLines.size(), postLines.size(), duration);
            }

        } catch (Exception e) {
            log.error("Comparison failed for: {}", appData.fileName(), e);
            return ComparisonResult.failed(appData, e.getMessage());
        }
    }

    /**
     * Parse bureau sections from lines
     */
    private List<BureauSection> parseBureauSections(List<String> lines) {
        List<BureauSection> sections = new ArrayList<>();
        String currentBureau = "Unknown";
        String currentType = "Unknown";
        int sectionStart = -1;

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);

            if (line.startsWith("==================================================")) {
                if (i + 1 < lines.size() && lines.get(i + 1).startsWith("Bureau: ")) {
                    if (sectionStart >= 0) {
                        sections.add(BureauSection.builder()
                                .bureauName(currentBureau)
                                .type(currentType)
                                .startLine(sectionStart)
                                .endLine(i - 1)
                                .build());
                    }

                    currentBureau = lines.get(i + 1).substring("Bureau: ".length()).trim();
                    if (i + 2 < lines.size() && lines.get(i + 2).startsWith("Type: ")) {
                        currentType = lines.get(i + 2).substring("Type: ".length()).trim();
                    }
                    sectionStart = i;
                }
            }
        }

        if (sectionStart >= 0) {
            sections.add(BureauSection.builder()
                    .bureauName(currentBureau)
                    .type(currentType)
                    .startLine(sectionStart)
                    .endLine(lines.size() - 1)
                    .build());
        }

        return sections;
    }

    /**
     * Find bureau section for a line number
     */
    private BureauSection findBureauSection(int lineNum, List<BureauSection> sections) {
        for (BureauSection section : sections) {
            if (section.containsLine(lineNum)) {
                return section;
            }
        }
        return null;
    }

    /**
     * Find differences between files
     */
    private List<ComparisonResult.LineDifference> findDifferences(
            List<String> preLines,
            List<String> postLines,
            List<BureauSection> preSections,
            List<BureauSection> postSections
    ) {
        List<ComparisonResult.LineDifference> differences = new ArrayList<>();
        int maxLines = Math.max(preLines.size(), postLines.size());
        final int MAX_DIFFERENCES = 100; // Limit to prevent huge reports

        for (int i = 0; i < maxLines && differences.size() < MAX_DIFFERENCES; i++) {
            String preLine = i < preLines.size() ? preLines.get(i).trim() : "[MISSING]";
            String postLine = i < postLines.size() ? postLines.get(i).trim() : "[MISSING]";

            // Skip empty lines
            if (preLine.isEmpty() && postLine.isEmpty()) continue;

            // Skip metadata lines
            if (isMetadataLine(preLine) || isMetadataLine(postLine)) continue;

            if (!preLine.equals(postLine)) {
                BureauSection preSection = findBureauSection(i, preSections);
                BureauSection postSection = findBureauSection(i, postSections);

                String bureauName = "Unknown";
                String bureauType = "Unknown";

                if (preSection != null) {
                    bureauName = preSection.bureauName();
                    bureauType = preSection.type();
                } else if (postSection != null) {
                    bureauName = postSection.bureauName();
                    bureauType = postSection.type();
                }

                // Determine difference type
                ComparisonResult.LineDifference.DifferenceType diffType;
                if (preLine.equals("[MISSING]")) {
                    diffType = ComparisonResult.LineDifference.DifferenceType.ADDED;
                } else if (postLine.equals("[MISSING]")) {
                    diffType = ComparisonResult.LineDifference.DifferenceType.REMOVED;
                } else {
                    diffType = ComparisonResult.LineDifference.DifferenceType.MODIFIED;
                }

                differences.add(ComparisonResult.LineDifference.builder()
                        .lineNumber(i + 1)
                        .preLine(truncate(preLine, 200))
                        .postLine(truncate(postLine, 200))
                        .bureauName(bureauName)
                        .bureauType(bureauType)
                        .type(diffType)
                        .build());
            }
        }

        return differences;
    }

    /**
     * Normalize content for comparison
     */
    private List<String> normalizeContent(List<String> lines) {
        return lines.stream()
                .map(String::trim)
                .filter(line -> !line.isEmpty())
                .toList();
    }

    /**
     * Remove metadata lines
     */
    private List<String> removeMetadata(List<String> lines) {
        List<String> filtered = new ArrayList<>();
        boolean skipMetadata = true;

        for (String line : lines) {
            if (skipMetadata && line.contains("==================================")) {
                skipMetadata = false;
                continue;
            }

            if (!isMetadataLine(line) && !skipMetadata) {
                filtered.add(line);
            }
        }

        return filtered;
    }

    /**
     * Check if line is metadata
     */
    private boolean isMetadataLine(String line) {
        return line.contains("Extraction Time:") ||
                line.contains("Application ID:") ||
                line.startsWith("Type:") && !line.contains("Bureau");
    }

    /**
     * Truncate string to max length
     */
    private String truncate(String str, int maxLength) {
        if (str.length() <= maxLength) {
            return str;
        }
        return str.substring(0, maxLength) + "...";
    }
}
