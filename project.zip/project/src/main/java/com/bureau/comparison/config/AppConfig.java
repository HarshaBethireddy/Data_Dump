package com.bureau.comparison.config;

import com.bureau.comparison.domain.ProcessingStatistics;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.github.benmanes.caffeine.cache.Caffeine;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.spring6.templateresolver.SpringResourceTemplateResolver;
import org.thymeleaf.templatemode.TemplateMode;

import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;

/**
 * Main application configuration.
 */
@Slf4j
@Configuration
@EnableCaching
@EnableAsync
@EnableConfigurationProperties(BureauProperties.class)
@RequiredArgsConstructor
public class AppConfig {

    private final BureauProperties properties;

    /**
     * Configure ObjectMapper for JSON operations
     */
    @Bean
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        return mapper;
    }

    /**
     * Configure Caffeine cache manager
     */
    @Bean
    public CacheManager cacheManager() {
        CaffeineCacheManager cacheManager = new CaffeineCacheManager("bureauData", "applicationData", "fileContent");

        if (properties.getPerformance().getCache().isEnabled()) {
            cacheManager.setCaffeine(Caffeine.newBuilder()
                    .expireAfterWrite(properties.getPerformance().getCache().getTtl(), TimeUnit.SECONDS)
                    .maximumSize(properties.getPerformance().getCache().getMaxSize())
                    .recordStats());

            log.info("Caffeine cache configured with TTL: {}s, Max Size: {}",
                    properties.getPerformance().getCache().getTtl(),
                    properties.getPerformance().getCache().getMaxSize());
        }

        return cacheManager;
    }

    /**
     * Processing statistics singleton
     */
    @Bean
    public ProcessingStatistics processingStatistics() {
        return ProcessingStatistics.builder()
                .startTime(LocalDateTime.now())
                .build();
    }

    /**
     * Thymeleaf template resolver for HTML reports
     */
    @Bean
    public SpringResourceTemplateResolver templateResolver() {
        SpringResourceTemplateResolver resolver = new SpringResourceTemplateResolver();
        resolver.setPrefix("classpath:/templates/");
        resolver.setSuffix(".html");
        resolver.setTemplateMode(TemplateMode.HTML);
        resolver.setCharacterEncoding("UTF-8");
        resolver.setCacheable(false); // Disable for development
        resolver.setOrder(1);
        return resolver;
    }

    /**
     * Thymeleaf template engine
     */
    @Bean
    public SpringTemplateEngine templateEngine(SpringResourceTemplateResolver templateResolver) {
        SpringTemplateEngine engine = new SpringTemplateEngine();
        engine.setTemplateResolver(templateResolver);
        engine.setEnableSpringELCompiler(true);
        return engine;
    }
}
