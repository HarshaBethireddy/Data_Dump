package com.bureau.comparison.domain;

import lombok.Builder;

import java.time.LocalDateTime;

/**
 * Domain model representing application data to be processed.
 * Using Java 21 record for immutability and conciseness.
 */
@Builder
public record ApplicationData(
        String fileName,
        String preAppId,
        String postAppId,
        CategoryType category,
        String preFilePath,
        String postFilePath,
        ProcessingStatus status,
        String errorMessage,
        LocalDateTime processingStartTime,
        LocalDateTime processingEndTime
) {
    /**
     * Factory method to create ApplicationData from file parsing
     */
    public static ApplicationData create(String fileName, String preAppId, String postAppId) {
        return ApplicationData.builder()
                .fileName(fileName)
                .preAppId(preAppId)
                .postAppId(postAppId)
                .category(CategoryType.fromFileName(fileName))
                .status(ProcessingStatus.PENDING)
                .build();
    }

    /**
     * Check if application data is valid for processing
     */
    public boolean isValid() {
        return fileName != null && !fileName.isBlank() &&
               preAppId != null && !preAppId.isBlank() &&
               postAppId != null && !postAppId.isBlank() &&
               category != CategoryType.UNKNOWN;
    }

    /**
     * Create a copy with updated status
     */
    public ApplicationData withStatus(ProcessingStatus newStatus) {
        return ApplicationData.builder()
                .fileName(this.fileName)
                .preAppId(this.preAppId)
                .postAppId(this.postAppId)
                .category(this.category)
                .preFilePath(this.preFilePath)
                .postFilePath(this.postFilePath)
                .status(newStatus)
                .errorMessage(this.errorMessage)
                .processingStartTime(this.processingStartTime)
                .processingEndTime(this.processingEndTime)
                .build();
    }

    /**
     * Create a copy with error message
     */
    public ApplicationData withError(String error) {
        return ApplicationData.builder()
                .fileName(this.fileName)
                .preAppId(this.preAppId)
                .postAppId(this.postAppId)
                .category(this.category)
                .preFilePath(this.preFilePath)
                .postFilePath(this.postFilePath)
                .status(ProcessingStatus.FAILED)
                .errorMessage(error)
                .processingStartTime(this.processingStartTime)
                .processingEndTime(LocalDateTime.now())
                .build();
    }

    /**
     * Create a copy with file paths
     */
    public ApplicationData withFilePaths(String preFilePath, String postFilePath) {
        return ApplicationData.builder()
                .fileName(this.fileName)
                .preAppId(this.preAppId)
                .postAppId(this.postAppId)
                .category(this.category)
                .preFilePath(preFilePath)
                .postFilePath(postFilePath)
                .status(this.status)
                .errorMessage(this.errorMessage)
                .processingStartTime(this.processingStartTime)
                .processingEndTime(this.processingEndTime)
                .build();
    }

    /**
     * Mark processing as started
     */
    public ApplicationData markStarted() {
        return ApplicationData.builder()
                .fileName(this.fileName)
                .preAppId(this.preAppId)
                .postAppId(this.postAppId)
                .category(this.category)
                .preFilePath(this.preFilePath)
                .postFilePath(this.postFilePath)
                .status(ProcessingStatus.IN_PROGRESS)
                .errorMessage(this.errorMessage)
                .processingStartTime(LocalDateTime.now())
                .processingEndTime(this.processingEndTime)
                .build();
    }

    /**
     * Mark processing as completed
     */
    public ApplicationData markCompleted() {
        return ApplicationData.builder()
                .fileName(this.fileName)
                .preAppId(this.preAppId)
                .postAppId(this.postAppId)
                .category(this.category)
                .preFilePath(this.preFilePath)
                .postFilePath(this.postFilePath)
                .status(ProcessingStatus.COMPLETED)
                .errorMessage(this.errorMessage)
                .processingStartTime(this.processingStartTime)
                .processingEndTime(LocalDateTime.now())
                .build();
    }

    /**
     * Get processing duration in seconds
     */
    public long getProcessingDurationSeconds() {
        if (processingStartTime == null || processingEndTime == null) {
            return 0;
        }
        return java.time.Duration.between(processingStartTime, processingEndTime).getSeconds();
    }
}
