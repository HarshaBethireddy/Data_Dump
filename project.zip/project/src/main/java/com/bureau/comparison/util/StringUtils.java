package com.bureau.comparison.util;

import lombok.experimental.UtilityClass;

import java.util.Collection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Utility class for string operations.
 */
@UtilityClass
public class StringUtils {

    private static final Pattern APP_ID_PATTERN = Pattern.compile("_(PRE|POST)_(\\d+)\\.txt$");
    private static final Pattern APP_ID_CONTENT_PATTERN = Pattern.compile("Application ID:\\s*(\\d+)");

    /**
     * Check if string is null or blank
     */
    public static boolean isBlank(String str) {
        return str == null || str.isBlank();
    }

    /**
     * Check if string is not blank
     */
    public static boolean isNotBlank(String str) {
        return !isBlank(str);
    }

    /**
     * Get string or default value if blank
     */
    public static String defaultIfBlank(String str, String defaultValue) {
        return isBlank(str) ? defaultValue : str;
    }

    /**
     * Trim string safely (null-safe)
     */
    public static String safeTrim(String str) {
        return str == null ? null : str.trim();
    }

    /**
     * Extract AppID from text file name (e.g., "file_PRE_123456.txt")
     */
    public static String extractAppIdFromFileName(String fileName) {
        if (isBlank(fileName)) {
            return "";
        }

        Matcher matcher = APP_ID_PATTERN.matcher(fileName);
        if (matcher.find()) {
            return matcher.group(2);
        }
        return "";
    }

    /**
     * Extract AppID from text content (e.g., "Application ID: 123456")
     */
    public static String extractAppIdFromContent(String content) {
        if (isBlank(content)) {
            return "";
        }

        Matcher matcher = APP_ID_CONTENT_PATTERN.matcher(content);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return "";
    }

    /**
     * Normalize string for comparison (trim, remove extra spaces)
     */
    public static String normalizeForComparison(String str) {
        if (isBlank(str)) {
            return "";
        }
        return str.trim().replaceAll("\\s+", " ");
    }

    /**
     * Check if string contains any of the given substrings (case-insensitive)
     */
    public static boolean containsAnyIgnoreCase(String str, String... substrings) {
        if (isBlank(str) || substrings == null || substrings.length == 0) {
            return false;
        }

        String lowerStr = str.toLowerCase();
        for (String substring : substrings) {
            if (substring != null && lowerStr.contains(substring.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Join collection with delimiter
     */
    public static String join(Collection<?> collection, String delimiter) {
        if (collection == null || collection.isEmpty()) {
            return "";
        }
        return String.join(delimiter, collection.stream()
                .map(Object::toString)
                .toList());
    }

    /**
     * Truncate string to max length with ellipsis
     */
    public static String truncate(String str, int maxLength) {
        if (isBlank(str) || str.length() <= maxLength) {
            return str;
        }
        return str.substring(0, maxLength - 3) + "...";
    }

    /**
     * Escape HTML special characters
     */
    public static String escapeHtml(String str) {
        if (isBlank(str)) {
            return str;
        }
        return str.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#039;");
    }

    /**
     * Remove file extension
     */
    public static String removeExtension(String fileName) {
        if (isBlank(fileName)) {
            return fileName;
        }
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex == -1) {
            return fileName;
        }
        return fileName.substring(0, lastDotIndex);
    }

    /**
     * Get file extension
     */
    public static String getExtension(String fileName) {
        if (isBlank(fileName)) {
            return "";
        }
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex == -1 || lastDotIndex == fileName.length() - 1) {
            return "";
        }
        return fileName.substring(lastDotIndex + 1);
    }

    /**
     * Convert camelCase to kebab-case
     */
    public static String camelToKebab(String camelCase) {
        if (isBlank(camelCase)) {
            return camelCase;
        }
        return camelCase.replaceAll("([a-z])([A-Z])", "$1-$2").toLowerCase();
    }

    /**
     * Capitalize first letter
     */
    public static String capitalize(String str) {
        if (isBlank(str)) {
            return str;
        }
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }

    /**
     * Check if string is numeric
     */
    public static boolean isNumeric(String str) {
        if (isBlank(str)) {
            return false;
        }
        try {
            Long.parseLong(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Pad string to specified length
     */
    public static String padRight(String str, int length, char padChar) {
        if (str == null) {
            str = "";
        }
        if (str.length() >= length) {
            return str;
        }
        return str + String.valueOf(padChar).repeat(length - str.length());
    }

    /**
     * Repeat string n times
     */
    public static String repeat(String str, int times) {
        if (isBlank(str) || times <= 0) {
            return "";
        }
        return str.repeat(times);
    }
}
