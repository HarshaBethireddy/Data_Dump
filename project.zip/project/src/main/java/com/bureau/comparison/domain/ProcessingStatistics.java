package com.bureau.comparison.domain;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Tracks processing statistics across all applications.
 * Thread-safe for concurrent updates.
 */
@Data
@Builder
public class ProcessingStatistics {
    private final LocalDateTime startTime;
    private LocalDateTime endTime;

    @Builder.Default
    private final AtomicInteger totalFiles = new AtomicInteger(0);

    @Builder.Default
    private final AtomicInteger processedFiles = new AtomicInteger(0);

    @Builder.Default
    private final AtomicInteger matchedFiles = new AtomicInteger(0);

    @Builder.Default
    private final AtomicInteger differentFiles = new AtomicInteger(0);

    @Builder.Default
    private final AtomicInteger failedExtractions = new AtomicInteger(0);

    @Builder.Default
    private final AtomicInteger failedComparisons = new AtomicInteger(0);

    @Builder.Default
    private final AtomicLong totalDifferencesFound = new AtomicLong(0);

    @Builder.Default
    private final AtomicLong totalProcessingTime = new AtomicLong(0);

    @Builder.Default
    private final Map<CategoryType, CategoryStats> categoryStatistics = new ConcurrentHashMap<>();

    /**
     * Record a matched file
     */
    public void recordMatched(CategoryType category) {
        processedFiles.incrementAndGet();
        matchedFiles.incrementAndGet();
        getCategoryStats(category).matched.incrementAndGet();
    }

    /**
     * Record a file with differences
     */
    public void recordDifferent(CategoryType category, int differenceCount) {
        processedFiles.incrementAndGet();
        differentFiles.incrementAndGet();
        totalDifferencesFound.addAndGet(differenceCount);
        CategoryStats stats = getCategoryStats(category);
        stats.different.incrementAndGet();
        stats.totalDifferences.addAndGet(differenceCount);
    }

    /**
     * Record a failed extraction
     */
    public void recordExtractionFailure(CategoryType category) {
        processedFiles.incrementAndGet();
        failedExtractions.incrementAndGet();
        getCategoryStats(category).failed.incrementAndGet();
    }

    /**
     * Record a failed comparison
     */
    public void recordComparisonFailure(CategoryType category) {
        processedFiles.incrementAndGet();
        failedComparisons.incrementAndGet();
        getCategoryStats(category).failed.incrementAndGet();
    }

    /**
     * Record processing time for a file
     */
    public void recordProcessingTime(long seconds) {
        totalProcessingTime.addAndGet(seconds);
    }

    /**
     * Get or create category statistics
     */
    private CategoryStats getCategoryStats(CategoryType category) {
        return categoryStatistics.computeIfAbsent(category, k -> new CategoryStats());
    }

    /**
     * Calculate total processing duration
     */
    public long getTotalDurationSeconds() {
        if (startTime == null) return 0;
        LocalDateTime end = endTime != null ? endTime : LocalDateTime.now();
        return java.time.Duration.between(startTime, end).getSeconds();
    }

    /**
     * Calculate average processing time per file
     */
    public double getAverageProcessingTimeSeconds() {
        int processed = processedFiles.get();
        if (processed == 0) return 0.0;
        return (double) totalProcessingTime.get() / processed;
    }

    /**
     * Calculate processing throughput (files per second)
     */
    public double getThroughput() {
        long duration = getTotalDurationSeconds();
        if (duration == 0) return 0.0;
        return (double) processedFiles.get() / duration;
    }

    /**
     * Calculate success rate percentage
     */
    public double getSuccessRate() {
        int total = processedFiles.get();
        if (total == 0) return 0.0;
        int successful = matchedFiles.get() + differentFiles.get();
        return (double) successful / total * 100.0;
    }

    /**
     * Calculate progress percentage
     */
    public double getProgressPercentage() {
        int total = totalFiles.get();
        if (total == 0) return 0.0;
        return (double) processedFiles.get() / total * 100.0;
    }

    /**
     * Mark processing as completed
     */
    public void markCompleted() {
        this.endTime = LocalDateTime.now();
    }

    /**
     * Generate summary report
     */
    public String getSummary() {
        return String.format(
                "Processing Summary:%n" +
                "==================%n" +
                "Total Files: %d%n" +
                "Processed: %d (%.1f%%)%n" +
                "Matched: %d%n" +
                "Different: %d%n" +
                "Failed: %d (Extraction: %d, Comparison: %d)%n" +
                "Total Differences: %d%n" +
                "Duration: %d seconds%n" +
                "Average Time/File: %.2f seconds%n" +
                "Throughput: %.2f files/second%n" +
                "Success Rate: %.1f%%",
                totalFiles.get(),
                processedFiles.get(),
                getProgressPercentage(),
                matchedFiles.get(),
                differentFiles.get(),
                failedExtractions.get() + failedComparisons.get(),
                failedExtractions.get(),
                failedComparisons.get(),
                totalDifferencesFound.get(),
                getTotalDurationSeconds(),
                getAverageProcessingTimeSeconds(),
                getThroughput(),
                getSuccessRate()
        );
    }

    /**
     * Inner class for per-category statistics
     */
    @Data
    public static class CategoryStats {
        private final AtomicInteger matched = new AtomicInteger(0);
        private final AtomicInteger different = new AtomicInteger(0);
        private final AtomicInteger failed = new AtomicInteger(0);
        private final AtomicLong totalDifferences = new AtomicLong(0);

        public int getTotal() {
            return matched.get() + different.get() + failed.get();
        }
    }
}
