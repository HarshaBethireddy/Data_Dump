package com.bureau.comparison.domain;

import lombok.Getter;

import java.util.Arrays;

/**
 * Enum representing different bureau application categories.
 * Each category has specific menu navigation paths.
 */
@Getter
public enum CategoryType {
    ACQ("ACQ", new String[]{"View Only", "Credit Full", "All"}),
    CLI("CLI", new String[]{"View Only", "CLI Credit Full", "All"}),
    PRQ("PRQ", new String[]{"View Only", "PreQual Credit Full", "All"}),
    UNKNOWN("UNKNOWN", new String[]{});

    private final String code;
    private final String[] menuPath;

    CategoryType(String code, String[] menuPath) {
        this.code = code;
        this.menuPath = menuPath;
    }

    /**
     * Determine category from filename
     */
    public static CategoryType fromFileName(String fileName) {
        if (fileName == null || fileName.isBlank()) {
            return UNKNOWN;
        }

        String upperFileName = fileName.toUpperCase();

        if (upperFileName.contains("CLI")) {
            return CLI;
        }
        if (upperFileName.contains("PRQ") || upperFileName.contains("PREQUAL")) {
            return PRQ;
        }
        if (upperFileName.contains("ACQ")) {
            return ACQ;
        }

        // Default to ACQ if no match
        return ACQ;
    }

    /**
     * Find category by code
     */
    public static CategoryType fromCode(String code) {
        return Arrays.stream(values())
                .filter(cat -> cat.code.equalsIgnoreCase(code))
                .findFirst()
                .orElse(UNKNOWN);
    }

    @Override
    public String toString() {
        return code;
    }
}
