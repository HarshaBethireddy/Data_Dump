package com.bureau.comparison.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Utility class for JSON operations.
 * Provides methods for parsing JSON and extracting application IDs.
 */
@Slf4j
@UtilityClass
public class JsonUtils {

    private static final ObjectMapper OBJECT_MAPPER = createObjectMapper();

    private static final List<String> APPID_KEYS = Arrays.asList(
            "APPID", "AppID", "AppId", "appId", "appid",
            "APP_ID", "app_id", "APP-ID", "app-id"
    );

    private static final List<String> ID_KEYS = Arrays.asList(
            "id", "ID", "Id", "value", "appId", "APPID"
    );

    /**
     * Create and configure ObjectMapper
     */
    private static ObjectMapper createObjectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        return mapper;
    }

    /**
     * Get ObjectMapper instance
     */
    public static ObjectMapper getObjectMapper() {
        return OBJECT_MAPPER;
    }

    /**
     * Parse JSON string to JsonNode
     */
    public static JsonNode parseJson(String jsonContent) throws IOException {
        return OBJECT_MAPPER.readTree(jsonContent);
    }

    /**
     * Parse JSON file to JsonNode
     */
    public static JsonNode parseJsonFile(File file) throws IOException {
        return OBJECT_MAPPER.readTree(file);
    }

    /**
     * Extract application ID from JSON node
     */
    public static String extractAppId(JsonNode rootNode) {
        if (rootNode == null || rootNode.isMissingNode() || rootNode.isNull()) {
            return "";
        }

        // First, try direct APPID keys
        for (String key : APPID_KEYS) {
            JsonNode candidate = rootNode.get(key);
            String value = nodeToIdString(candidate);
            if (!value.isEmpty()) {
                log.debug("Found AppID using key: {}", key);
                return value;
            }
        }

        // Recursively search through the JSON tree
        String foundId = searchForAppId(rootNode);
        if (!foundId.isEmpty()) {
            return foundId;
        }

        log.warn("Could not find AppID in JSON");
        return "";
    }

    /**
     * Recursively search for AppID in JSON tree
     */
    private static String searchForAppId(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) {
            return "";
        }

        if (node.isObject()) {
            // Check if any field name contains "appid"
            Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> entry = fields.next();
                String fieldName = entry.getKey();
                JsonNode value = entry.getValue();

                if (fieldName != null && fieldName.toLowerCase(Locale.ROOT).contains("appid")) {
                    String id = nodeToIdString(value);
                    if (!id.isEmpty()) {
                        return id;
                    }
                }

                // Recurse into nested objects
                String deeperId = searchForAppId(value);
                if (!deeperId.isEmpty()) {
                    return deeperId;
                }
            }
        }

        if (node.isArray()) {
            for (JsonNode item : node) {
                String foundId = searchForAppId(item);
                if (!foundId.isEmpty()) {
                    return foundId;
                }
            }
        }

        return "";
    }

    /**
     * Convert JsonNode to ID string
     */
    private static String nodeToIdString(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) {
            return "";
        }

        // Direct value (text, number, boolean)
        if (node.isTextual() || node.isNumber() || node.isBoolean()) {
            return node.asText();
        }

        // Object with ID keys
        if (node.isObject()) {
            for (String idKey : ID_KEYS) {
                JsonNode inner = node.get(idKey);
                if (inner != null && !inner.isNull()) {
                    String value = nodeToIdString(inner);
                    if (!value.isEmpty()) {
                        return value;
                    }
                }
            }

            // Try all fields
            Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> entry = fields.next();
                String value = nodeToIdString(entry.getValue());
                if (!value.isEmpty()) {
                    return value;
                }
            }
        }

        // Array - take first non-empty value
        if (node.isArray()) {
            for (JsonNode item : node) {
                String value = nodeToIdString(item);
                if (!value.isEmpty()) {
                    return value;
                }
            }
        }

        return "";
    }

    /**
     * Extract AppID from JSON file
     */
    public static String extractAppIdFromFile(File jsonFile) {
        try {
            JsonNode rootNode = parseJsonFile(jsonFile);
            return extractAppId(rootNode);
        } catch (Exception e) {
            log.warn("Failed to extract AppID from file: {}", jsonFile.getName(), e);
            return "";
        }
    }

    /**
     * Extract AppID from JSON string
     */
    public static String extractAppIdFromString(String jsonContent) {
        try {
            JsonNode rootNode = parseJson(jsonContent);
            return extractAppId(rootNode);
        } catch (Exception e) {
            log.warn("Failed to extract AppID from JSON string", e);
            return "";
        }
    }

    /**
     * Validate JSON string
     */
    public static boolean isValidJson(String jsonContent) {
        try {
            OBJECT_MAPPER.readTree(jsonContent);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Pretty print JSON
     */
    public static String prettyPrint(JsonNode node) {
        try {
            return OBJECT_MAPPER.writerWithDefaultPrettyPrinter()
                    .writeValueAsString(node);
        } catch (Exception e) {
            log.error("Failed to pretty print JSON", e);
            return node.toString();
        }
    }

    /**
     * Convert object to JSON string
     */
    public static String toJsonString(Object obj) throws IOException {
        return OBJECT_MAPPER.writeValueAsString(obj);
    }

    /**
     * Convert JSON string to object
     */
    public static <T> T fromJsonString(String json, Class<T> clazz) throws IOException {
        return OBJECT_MAPPER.readValue(json, clazz);
    }
}
