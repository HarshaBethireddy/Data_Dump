package com.bureau.comparison.domain;

import lombok.Builder;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Represents the result of bureau data extraction for a single application.
 */
@Builder
public record ExtractionResult(
        String applicationId,
        String type,  // "PRE" or "POST"
        String outputFilePath,
        boolean success,
        String errorMessage,
        List<BureauSection> sections,
        int totalSections,
        LocalDateTime extractionTime,
        long durationSeconds
) {
    /**
     * Create a successful extraction result
     */
    public static ExtractionResult success(
            String applicationId,
            String type,
            String outputFilePath,
            List<BureauSection> sections,
            long durationSeconds
    ) {
        return ExtractionResult.builder()
                .applicationId(applicationId)
                .type(type)
                .outputFilePath(outputFilePath)
                .success(true)
                .sections(sections)
                .totalSections(sections.size())
                .extractionTime(LocalDateTime.now())
                .durationSeconds(durationSeconds)
                .build();
    }

    /**
     * Create a failed extraction result
     */
    public static ExtractionResult failure(
            String applicationId,
            String type,
            String errorMessage,
            long durationSeconds
    ) {
        return ExtractionResult.builder()
                .applicationId(applicationId)
                .type(type)
                .success(false)
                .errorMessage(errorMessage)
                .totalSections(0)
                .extractionTime(LocalDateTime.now())
                .durationSeconds(durationSeconds)
                .build();
    }

    /**
     * Check if extraction was successful
     */
    public boolean isSuccess() {
        return success;
    }

    /**
     * Get the number of extracted sections
     */
    public int getSectionCount() {
        return sections != null ? sections.size() : 0;
    }
}
