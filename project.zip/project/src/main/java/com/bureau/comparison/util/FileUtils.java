package com.bureau.comparison.util;

import com.bureau.comparison.exception.ComparisonException;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Stream;

/**
 * Utility class for file operations.
 * Provides methods for reading, writing, and managing files with proper encoding detection.
 */
@Slf4j
@UtilityClass
public class FileUtils {

    private static final DateTimeFormatter TIMESTAMP_FORMATTER =
            DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");

    /**
     * Read file content with automatic encoding detection
     */
    public static String readFileWithEncoding(Path filePath) throws IOException {
        // Try UTF-8 first
        try {
            String content = Files.readString(filePath, StandardCharsets.UTF_8);
            if (!content.contains("\uFFFD")) { // No replacement characters
                return content;
            }
        } catch (Exception e) {
            log.debug("UTF-8 encoding failed for {}, trying alternative encodings", filePath);
        }

        // Try Windows-1252
        try {
            String content = Files.readString(filePath, Charset.forName("Windows-1252"));
            return content;
        } catch (Exception e) {
            log.debug("Windows-1252 encoding failed for {}", filePath);
        }

        // Try ISO-8859-1
        try {
            String content = Files.readString(filePath, Charset.forName("ISO-8859-1"));
            return content;
        } catch (Exception e) {
            log.debug("ISO-8859-1 encoding failed for {}", filePath);
        }

        // Fallback to default charset
        return Files.readString(filePath, Charset.defaultCharset());
    }

    /**
     * Read file as lines with encoding detection
     */
    public static List<String> readLinesWithEncoding(Path filePath) throws IOException {
        String content = readFileWithEncoding(filePath);
        return content.lines().toList();
    }

    /**
     * Write content to file
     */
    public static void writeToFile(Path filePath, String content) throws IOException {
        ensureParentDirectoryExists(filePath);
        Files.writeString(filePath, content, StandardCharsets.UTF_8);
    }

    /**
     * Write lines to file
     */
    public static void writeLinesToFile(Path filePath, List<String> lines) throws IOException {
        ensureParentDirectoryExists(filePath);
        Files.write(filePath, lines, StandardCharsets.UTF_8);
    }

    /**
     * Append content to file
     */
    public static void appendToFile(Path filePath, String content) throws IOException {
        ensureParentDirectoryExists(filePath);
        try (BufferedWriter writer = Files.newBufferedWriter(filePath,
                StandardCharsets.UTF_8,
                java.nio.file.StandardOpenOption.CREATE,
                java.nio.file.StandardOpenOption.APPEND)) {
            writer.write(content);
        }
    }

    /**
     * Create directory if it doesn't exist
     */
    public static void ensureDirectoryExists(Path directory) throws IOException {
        if (!Files.exists(directory)) {
            Files.createDirectories(directory);
            log.debug("Created directory: {}", directory);
        }
    }

    /**
     * Ensure parent directory exists for a file
     */
    public static void ensureParentDirectoryExists(Path filePath) throws IOException {
        Path parent = filePath.getParent();
        if (parent != null) {
            ensureDirectoryExists(parent);
        }
    }

    /**
     * Generate timestamped output directory
     */
    public static Path createTimestampedOutputDirectory(String baseOutputPath) throws IOException {
        String timestamp = LocalDateTime.now().format(TIMESTAMP_FORMATTER);
        Path outputPath = Paths.get(baseOutputPath, "comparison_" + timestamp);
        ensureDirectoryExists(outputPath);
        return outputPath;
    }

    /**
     * Create category subdirectory
     */
    public static Path createCategoryDirectory(Path baseOutputPath, String category) throws IOException {
        Path categoryPath = baseOutputPath.resolve(category);
        ensureDirectoryExists(categoryPath);
        return categoryPath;
    }

    /**
     * List all files in directory with specific extension
     */
    public static List<File> listFilesWithExtension(Path directory, String extension) throws IOException {
        if (!Files.exists(directory) || !Files.isDirectory(directory)) {
            throw new ComparisonException.FileNotFoundException(directory.toString());
        }

        try (Stream<Path> paths = Files.list(directory)) {
            return paths
                    .filter(Files::isRegularFile)
                    .filter(path -> path.toString().toLowerCase().endsWith(extension.toLowerCase()))
                    .map(Path::toFile)
                    .toList();
        }
    }

    /**
     * Check if file exists and is readable
     */
    public static boolean isFileAccessible(Path filePath) {
        return Files.exists(filePath) && Files.isReadable(filePath);
    }

    /**
     * Get file size in bytes
     */
    public static long getFileSize(Path filePath) throws IOException {
        return Files.size(filePath);
    }

    /**
     * Get file extension
     */
    public static String getFileExtension(String fileName) {
        if (fileName == null || fileName.isEmpty()) {
            return "";
        }
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex == -1 || lastDotIndex == fileName.length() - 1) {
            return "";
        }
        return fileName.substring(lastDotIndex + 1);
    }

    /**
     * Remove file extension
     */
    public static String removeFileExtension(String fileName) {
        if (fileName == null || fileName.isEmpty()) {
            return fileName;
        }
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex == -1) {
            return fileName;
        }
        return fileName.substring(0, lastDotIndex);
    }

    /**
     * Generate output file path
     */
    public static String generateOutputFilePath(Path categoryDirectory,
                                                String fileName,
                                                String type,
                                                String appId) {
        String baseFileName = removeFileExtension(fileName);
        String outputFileName = String.format("%s_%s_%s.txt", baseFileName, type, appId);
        return categoryDirectory.resolve(outputFileName).toString();
    }

    /**
     * Delete file if exists
     */
    public static void deleteIfExists(Path filePath) {
        try {
            Files.deleteIfExists(filePath);
            log.debug("Deleted file: {}", filePath);
        } catch (IOException e) {
            log.warn("Failed to delete file: {}", filePath, e);
        }
    }

    /**
     * Copy file
     */
    public static void copyFile(Path source, Path destination) throws IOException {
        ensureParentDirectoryExists(destination);
        Files.copy(source, destination, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
    }

    /**
     * Validate file path
     */
    public static void validateFilePath(String filePath) {
        if (filePath == null || filePath.isBlank()) {
            throw new ComparisonException("File path cannot be null or empty");
        }

        Path path = Paths.get(filePath);
        if (!Files.exists(path)) {
            throw new ComparisonException.FileNotFoundException(filePath);
        }

        if (!Files.isReadable(path)) {
            throw new ComparisonException("File is not readable: " + filePath);
        }
    }
}
