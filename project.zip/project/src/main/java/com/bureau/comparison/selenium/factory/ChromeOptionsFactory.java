package com.bureau.comparison.selenium.factory;

import com.bureau.comparison.config.BureauProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.chrome.ChromeOptions;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Factory for creating optimized ChromeOptions.
 * Configures browser options for maximum performance.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ChromeOptionsFactory {

    private final BureauProperties properties;

    /**
     * Create ChromeOptions with configuration from properties
     */
    public ChromeOptions createChromeOptions() {
        ChromeOptions options = new ChromeOptions();

        // Add configured options
        if (properties.getSelenium().getBrowser().getOptions() != null) {
            properties.getSelenium().getBrowser().getOptions()
                    .forEach(options::addArguments);
        }

        // Headless mode
        if (properties.getSelenium().getBrowser().isHeadless()) {
            options.addArguments("--headless=new");
            log.debug("Chrome configured in headless mode");
        }

        // Page load strategy
        String pageLoadStrategy = properties.getSelenium().getBrowser().getPageLoadStrategy();
        options.setPageLoadStrategy(PageLoadStrategy.valueOf(pageLoadStrategy.toUpperCase()));
        log.debug("Page load strategy: {}", pageLoadStrategy);

        // Disable automation detection
        options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
        options.setExperimentalOption("useAutomationExtension", false);

        // Performance preferences
        Map<String, Object> prefs = new HashMap<>();
        prefs.put("profile.default_content_setting_values.notifications", 2);
        prefs.put("profile.default_content_settings.popups", 0);
        prefs.put("disk-cache-size", 0);
        prefs.put("media-cache-size", 0);
        options.setExperimentalOption("prefs", prefs);

        // Set capability
        options.setCapability("acceptInsecureCerts", true);

        log.debug("ChromeOptions created with {} arguments", options.asMap().get("args"));
        return options;
    }

    /**
     * Create ChromeOptions for debugging (non-headless, with DevTools)
     */
    public ChromeOptions createDebugChromeOptions() {
        ChromeOptions options = createChromeOptions();
        options.addArguments("--auto-open-devtools-for-tabs");
        options.addArguments("--start-maximized");
        // Remove headless if present
        options.getArgs().removeIf(arg -> arg.contains("headless"));
        log.debug("Debug ChromeOptions created");
        return options;
    }
}
