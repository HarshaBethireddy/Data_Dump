package com.bureau.comparison.exception;

/**
 * Exception thrown when file comparison operations fail.
 */
public class ComparisonException extends BureauComparisonException {

    public ComparisonException(String message) {
        super("COMPARISON_ERROR", message);
    }

    public ComparisonException(String message, Throwable cause) {
        super("COMPARISON_ERROR", message, cause);
    }

    public ComparisonException(String message, String fileName) {
        super("COMPARISON_ERROR", message, fileName);
    }

    public ComparisonException(String message, Throwable cause, String fileName) {
        super("COMPARISON_ERROR", message, cause, fileName);
    }

    /**
     * File not found during comparison
     */
    public static class FileNotFoundException extends ComparisonException {
        public FileNotFoundException(String filePath) {
            super("File not found: " + filePath);
        }
    }

    /**
     * File read error
     */
    public static class FileReadException extends ComparisonException {
        public FileReadException(String message, Throwable cause) {
            super("Failed to read file: " + message, cause);
        }
    }

    /**
     * Invalid file format
     */
    public static class InvalidFileFormatException extends ComparisonException {
        public InvalidFileFormatException(String message) {
            super("Invalid file format: " + message);
        }
    }
}
