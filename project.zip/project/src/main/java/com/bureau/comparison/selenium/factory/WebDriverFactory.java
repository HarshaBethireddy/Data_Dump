package com.bureau.comparison.selenium.factory;

import com.bureau.comparison.config.BureauProperties;
import com.bureau.comparison.exception.ConfigurationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.springframework.stereotype.Component;

import java.net.URL;
import java.time.Duration;

/**
 * Factory for creating WebDriver instances.
 * Supports both local ChromeDriver and Selenium Grid RemoteWebDriver.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class WebDriverFactory {

    private final BureauProperties properties;
    private final ChromeOptionsFactory chromeOptionsFactory;

    /**
     * Create WebDriver instance (Grid or Local)
     */
    public WebDriver createWebDriver() {
        ChromeOptions options = chromeOptionsFactory.createChromeOptions();

        if (properties.getSelenium().getGrid().isEnabled()) {
            return createRemoteWebDriver(options);
        } else {
            return createLocalWebDriver(options);
        }
    }

    /**
     * Create RemoteWebDriver for Selenium Grid
     */
    private WebDriver createRemoteWebDriver(ChromeOptions options) {
        try {
            String gridUrl = properties.getSelenium().getGrid().getUrl();
            log.debug("Creating RemoteWebDriver for Grid: {}", gridUrl);

            URL url = new URL(gridUrl);
            RemoteWebDriver driver = new RemoteWebDriver(url, options);

            configureDriver(driver);
            log.debug("RemoteWebDriver created successfully");

            return driver;
        } catch (Exception e) {
            log.error("Failed to create RemoteWebDriver", e);
            throw new ConfigurationException.GridConnectionException(
                    properties.getSelenium().getGrid().getUrl(), e);
        }
    }

    /**
     * Create local ChromeDriver
     */
    private WebDriver createLocalWebDriver(ChromeOptions options) {
        try {
            log.debug("Creating local ChromeDriver");
            ChromeDriver driver = new ChromeDriver(options);

            configureDriver(driver);
            log.debug("Local ChromeDriver created successfully");

            return driver;
        } catch (Exception e) {
            log.error("Failed to create local ChromeDriver", e);
            throw new ConfigurationException("Failed to create ChromeDriver: " + e.getMessage(), e);
        }
    }

    /**
     * Configure driver timeouts and settings
     */
    private void configureDriver(WebDriver driver) {
        int pageLoadTimeout = properties.getPerformance().getTimeouts().getPageLoad();
        int elementWaitTimeout = properties.getPerformance().getTimeouts().getElementWait();

        driver.manage().timeouts()
                .pageLoadTimeout(Duration.ofSeconds(pageLoadTimeout))
                .implicitlyWait(Duration.ofSeconds(elementWaitTimeout));

        log.debug("WebDriver configured with timeouts - pageLoad: {}s, elementWait: {}s",
                pageLoadTimeout, elementWaitTimeout);
    }

    /**
     * Validate driver is responsive
     */
    public boolean validateDriver(WebDriver driver) {
        try {
            driver.getCurrentUrl();
            return true;
        } catch (Exception e) {
            log.warn("Driver validation failed", e);
            return false;
        }
    }

    /**
     * Reset driver state (clear cookies, navigate to blank)
     */
    public void resetDriverState(WebDriver driver) {
        try {
            driver.manage().deleteAllCookies();
            driver.get("about:blank");
            log.debug("Driver state reset");
        } catch (Exception e) {
            log.warn("Failed to reset driver state", e);
        }
    }
}
