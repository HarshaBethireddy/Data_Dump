package com.bureau.comparison.selenium.page;

import com.bureau.comparison.exception.ExtractionException;
import com.bureau.comparison.selenium.page.base.BasePage;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

/**
 * Page Object for Group Selection Page.
 */
@Slf4j
public class GroupSelectionPage extends BasePage {

    // Locators
    private final By groupsDropdown = By.id("groups");
    private final By submitButton = By.id("id2");
    private final By menuWrapper = By.id("menu-wrapper");
    private final By menu = By.id("menu");

    public GroupSelectionPage(WebDriver driver, int timeoutSeconds) {
        super(driver, timeoutSeconds);
    }

    /**
     * Select group and submit
     */
    public void selectGroup(String groupName) {
        try {
            log.info("Selecting group: {}", groupName);

            // Wait for groups dropdown
            WebElement dropdownElement = wait.waitForVisible(groupsDropdown);

            // Select group
            Select select = new Select(dropdownElement);
            select.selectByVisibleText(groupName);

            // Click submit button
            WebElement submitBtn = wait.waitForClickable(submitButton);
            submitBtn.click();

            // Wait for menu to appear (navigation successful)
            wait.waitForVisible(menuWrapper);
            wait.waitForVisible(menu);

            pause(3000); // Allow menu to fully load

            log.info("Group selected successfully: {}", groupName);
        } catch (Exception e) {
            log.error("Failed to select group: {}", groupName, e);
            throw new ExtractionException.NavigationException("Failed to select group: " + groupName, e);
        }
    }

    /**
     * Check if group selection page is displayed
     */
    public boolean isGroupSelectionPageDisplayed() {
        return isDisplayed(groupsDropdown) && isDisplayed(submitButton);
    }
}
