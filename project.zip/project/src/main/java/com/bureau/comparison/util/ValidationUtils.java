package com.bureau.comparison.util;

import com.bureau.comparison.domain.ApplicationData;
import com.bureau.comparison.exception.ConfigurationException;
import lombok.experimental.UtilityClass;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Utility class for validation operations.
 */
@UtilityClass
public class ValidationUtils {

    /**
     * Validate application data
     */
    public static void validateApplicationData(ApplicationData appData) {
        if (appData == null) {
            throw new IllegalArgumentException("Application data cannot be null");
        }

        if (StringUtils.isBlank(appData.fileName())) {
            throw new IllegalArgumentException("File name cannot be blank");
        }

        if (StringUtils.isBlank(appData.preAppId())) {
            throw new IllegalArgumentException("PRE AppID cannot be blank for file: " + appData.fileName());
        }

        if (StringUtils.isBlank(appData.postAppId())) {
            throw new IllegalArgumentException("POST AppID cannot be blank for file: " + appData.fileName());
        }

        if (appData.category() == null) {
            throw new IllegalArgumentException("Category cannot be null for file: " + appData.fileName());
        }
    }

    /**
     * Validate directory path exists
     */
    public static void validateDirectoryExists(String directoryPath, String parameterName) {
        if (StringUtils.isBlank(directoryPath)) {
            throw new ConfigurationException.MissingConfigurationException(parameterName);
        }

        Path path = Paths.get(directoryPath);
        if (!Files.exists(path)) {
            throw new ConfigurationException(
                    String.format("Directory does not exist: %s (parameter: %s)", directoryPath, parameterName)
            );
        }

        if (!Files.isDirectory(path)) {
            throw new ConfigurationException(
                    String.format("Path is not a directory: %s (parameter: %s)", directoryPath, parameterName)
            );
        }

        if (!Files.isReadable(path)) {
            throw new ConfigurationException(
                    String.format("Directory is not readable: %s (parameter: %s)", directoryPath, parameterName)
            );
        }
    }

    /**
     * Validate URL format
     */
    public static void validateUrl(String url, String parameterName) {
        if (StringUtils.isBlank(url)) {
            throw new ConfigurationException.MissingConfigurationException(parameterName);
        }

        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            throw new ConfigurationException.InvalidConfigurationException(
                    parameterName, url, "URL must start with http:// or https://"
            );
        }
    }

    /**
     * Validate port number
     */
    public static void validatePort(int port, String parameterName) {
        if (port < 1 || port > 65535) {
            throw new ConfigurationException.InvalidConfigurationException(
                    parameterName, String.valueOf(port), "Port must be between 1 and 65535"
            );
        }
    }

    /**
     * Validate positive integer
     */
    public static void validatePositiveInteger(int value, String parameterName) {
        if (value <= 0) {
            throw new ConfigurationException.InvalidConfigurationException(
                    parameterName, String.valueOf(value), "Value must be positive"
            );
        }
    }

    /**
     * Validate positive or zero integer
     */
    public static void validateNonNegativeInteger(int value, String parameterName) {
        if (value < 0) {
            throw new ConfigurationException.InvalidConfigurationException(
                    parameterName, String.valueOf(value), "Value must be non-negative"
            );
        }
    }

    /**
     * Validate integer range
     */
    public static void validateRange(int value, int min, int max, String parameterName) {
        if (value < min || value > max) {
            throw new ConfigurationException.InvalidConfigurationException(
                    parameterName, String.valueOf(value),
                    String.format("Value must be between %d and %d", min, max)
            );
        }
    }

    /**
     * Validate timeout value (seconds)
     */
    public static void validateTimeout(int timeoutSeconds, String parameterName) {
        if (timeoutSeconds <= 0 || timeoutSeconds > 3600) {
            throw new ConfigurationException.InvalidConfigurationException(
                    parameterName, String.valueOf(timeoutSeconds),
                    "Timeout must be between 1 and 3600 seconds"
            );
        }
    }

    /**
     * Validate required string parameter
     */
    public static void validateRequiredString(String value, String parameterName) {
        if (StringUtils.isBlank(value)) {
            throw new ConfigurationException.MissingConfigurationException(parameterName);
        }
    }

    /**
     * Validate credentials
     */
    public static void validateCredentials(String username, String password) {
        validateRequiredString(username, "credentials.username");
        validateRequiredString(password, "credentials.password");
    }

    /**
     * Validate application ID format
     */
    public static boolean isValidApplicationId(String appId) {
        return StringUtils.isNotBlank(appId) && StringUtils.isNumeric(appId);
    }

    /**
     * Require valid application ID
     */
    public static void requireValidApplicationId(String appId, String context) {
        if (!isValidApplicationId(appId)) {
            throw new IllegalArgumentException(
                    String.format("Invalid application ID '%s' for %s (must be numeric)", appId, context)
            );
        }
    }
}
