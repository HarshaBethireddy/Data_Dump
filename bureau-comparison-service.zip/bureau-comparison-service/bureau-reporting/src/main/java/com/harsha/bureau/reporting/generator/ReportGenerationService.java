package com.harsha.bureau.reporting.generator;

import com.harsha.bureau.core.domain.model.ComparisonResult;
import com.harsha.bureau.core.ports.input.GenerateReportUseCase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service that implements GenerateReportUseCase port.
 * Coordinates HTML and Text report generation.
 */
@Service
public class ReportGenerationService implements GenerateReportUseCase {

    private static final Logger log = LoggerFactory.getLogger(ReportGenerationService.class);

    private final HtmlReportGenerator htmlGenerator;
    private final TextReportGenerator textGenerator;

    public ReportGenerationService(HtmlReportGenerator htmlGenerator,
                                   TextReportGenerator textGenerator) {
        this.htmlGenerator = htmlGenerator;
        this.textGenerator = textGenerator;
    }

    @Override
    public void generateReports(List<ComparisonResult> results, String outputDirectory) {
        log.info("Generating both HTML and Text reports in: {}", outputDirectory);

        generateHtmlReport(results, outputDirectory);
        generateTextReport(results, outputDirectory);

        log.info("✅ Reports generated successfully");
    }

    @Override
    public String generateHtmlReport(List<ComparisonResult> results, String outputDirectory) {
        String htmlPath = outputDirectory + "/index.html";
        return htmlGenerator.generateHtmlReport(results, htmlPath);
    }

    @Override
    public String generateTextReport(List<ComparisonResult> results, String outputDirectory) {
        String textPath = outputDirectory + "/MASTER_comparison_report.txt";
        return textGenerator.generateTextReport(results, textPath);
    }
}
