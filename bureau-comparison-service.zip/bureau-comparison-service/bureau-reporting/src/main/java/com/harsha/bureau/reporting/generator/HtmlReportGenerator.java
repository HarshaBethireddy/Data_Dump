package com.harsha.bureau.reporting.generator;

import com.harsha.bureau.core.domain.model.ComparisonResult;
import com.harsha.bureau.core.domain.model.Difference;
import com.harsha.bureau.core.ports.output.ReportGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Generates interactive HTML reports with collapsible tree, filters, and charts.
 */
@Component
public class HtmlReportGenerator implements ReportGenerator {

    private static final Logger log = LoggerFactory.getLogger(HtmlReportGenerator.class);
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    public String generateHtmlReport(List<ComparisonResult> results, String outputPath) {
        log.info("Generating HTML report: {}", outputPath);

        String html = buildHtmlReport(results);

        // Write to file
        try (FileWriter writer = new FileWriter(outputPath)) {
            writer.write(html);
            log.info("HTML report generated successfully: {}", outputPath);
        } catch (IOException e) {
            log.error("Failed to write HTML report: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to write HTML report", e);
        }

        return outputPath;
    }

    @Override
    public String generateTextReport(List<ComparisonResult> results, String outputPath) {
        throw new UnsupportedOperationException("Use TextReportGenerator for text reports");
    }

    @Override
    public void generateBothReports(List<ComparisonResult> results, String outputDirectory) {
        String htmlPath = outputDirectory + "/index.html";
        generateHtmlReport(results, htmlPath);
    }

    /**
     * Builds complete HTML report.
     *
     * @param results the comparison results
     * @return HTML string
     */
    private String buildHtmlReport(List<ComparisonResult> results) {
        long matched = results.stream().filter(ComparisonResult::isMatched).count();
        long different = results.stream().filter(ComparisonResult::hasDifferences).count();
        long failed = results.stream().filter(ComparisonResult::isFailed).count();
        double matchRate = results.isEmpty() ? 0 : (double) matched / results.size() * 100;

        StringBuilder html = new StringBuilder();

        // HTML Header
        html.append("<!DOCTYPE html>\n");
        html.append("<html lang=\"en\">\n");
        html.append("<head>\n");
        html.append("    <meta charset=\"UTF-8\">\n");
        html.append("    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n");
        html.append("    <title>Bureau Comparison Report</title>\n");
        html.append(generateStyles());
        html.append("</head>\n");
        html.append("<body>\n");

        // Header
        html.append("    <header>\n");
        html.append("        <div class=\"container\">\n");
        html.append("            <h1>Bureau Data Comparison Report</h1>\n");
        html.append("            <div class=\"metadata\">\n");
        html.append("                <span>Generated: ").append(LocalDateTime.now().format(FORMATTER)).append("</span>\n");
        html.append("                <span>Total Files: ").append(results.size()).append("</span>\n");
        html.append("                <span>Version: 2.0.0</span>\n");
        html.append("            </div>\n");
        html.append("        </div>\n");
        html.append("    </header>\n\n");

        // Summary Cards
        html.append("    <div class=\"container\">\n");
        html.append("        <div class=\"summary-cards\">\n");
        html.append(generateSummaryCard("Total Files", String.valueOf(results.size()), "#3b82f6"));
        html.append(generateSummaryCard("Matched", String.valueOf(matched), "#10b981"));
        html.append(generateSummaryCard("Different", String.valueOf(different), "#f59e0b"));
        html.append(generateSummaryCard("Failed", String.valueOf(failed), "#ef4444"));
        html.append("        </div>\n\n");

        // Filters
        html.append(generateFilters(results));

        // File List
        html.append("        <div class=\"file-list\" id=\"file-list\">\n");
        for (ComparisonResult result : results) {
            html.append(generateFileItem(result));
        }
        html.append("        </div>\n");
        html.append("    </div>\n\n");

        // JavaScript
        html.append(generateJavaScript());

        html.append("</body>\n");
        html.append("</html>");

        return html.toString();
    }

    /**
     * Generates CSS styles.
     */
    private String generateStyles() {
        return """
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }

                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
                    background: #f3f4f6;
                    color: #1f2937;
                    line-height: 1.6;
                }

                .container {
                    max-width: 1400px;
                    margin: 0 auto;
                    padding: 2rem;
                }

                header {
                    background: linear-gradient(135deg, #3b82f6, #6366f1);
                    color: white;
                    padding: 2rem;
                    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                }

                header h1 {
                    font-size: 2.5rem;
                    margin-bottom: 0.5rem;
                }

                .metadata {
                    display: flex;
                    gap: 2rem;
                    font-size: 0.9rem;
                    opacity: 0.9;
                }

                .summary-cards {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 1.5rem;
                    margin: 2rem 0;
                }

                .card {
                    background: white;
                    border-radius: 12px;
                    padding: 1.5rem;
                    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                    transition: all 0.2s ease;
                    border-left: 4px solid;
                }

                .card:hover {
                    transform: translateY(-4px);
                    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
                }

                .card-title {
                    font-size: 0.875rem;
                    color: #6b7280;
                    text-transform: uppercase;
                    letter-spacing: 0.05em;
                    margin-bottom: 0.5rem;
                }

                .card-value {
                    font-size: 2.5rem;
                    font-weight: bold;
                }

                .filters-section {
                    background: white;
                    border-radius: 12px;
                    padding: 1.5rem;
                    margin: 2rem 0;
                    box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
                }

                .filter-group {
                    display: flex;
                    gap: 1rem;
                    flex-wrap: wrap;
                    align-items: center;
                }

                .filter-group select, .filter-group input {
                    padding: 0.5rem 1rem;
                    border: 1px solid #e5e7eb;
                    border-radius: 6px;
                    background: white;
                    font-size: 0.875rem;
                }

                #search-box {
                    flex: 1;
                    min-width: 300px;
                    padding: 0.75rem 1rem;
                    border: 2px solid #e5e7eb;
                    border-radius: 8px;
                    font-size: 1rem;
                }

                #search-box:focus {
                    outline: none;
                    border-color: #3b82f6;
                }

                .file-item {
                    background: white;
                    border: 1px solid #e5e7eb;
                    border-radius: 8px;
                    margin-bottom: 1rem;
                    overflow: hidden;
                    transition: all 0.2s ease;
                }

                .file-item:hover {
                    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                }

                .file-header {
                    padding: 1rem;
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                    cursor: pointer;
                    user-select: none;
                }

                .expand-icon {
                    transition: transform 0.2s;
                    font-size: 0.875rem;
                }

                .expand-icon.expanded {
                    transform: rotate(90deg);
                }

                .file-name {
                    flex: 1;
                    font-weight: 500;
                }

                .status-badge {
                    padding: 0.25rem 0.75rem;
                    border-radius: 9999px;
                    font-size: 0.75rem;
                    font-weight: 600;
                    color: white;
                }

                .status-matched { background: #10b981; }
                .status-different { background: #f59e0b; }
                .status-failed { background: #ef4444; }

                .category-tag {
                    padding: 0.25rem 0.75rem;
                    border-radius: 4px;
                    font-size: 0.75rem;
                    font-weight: 600;
                    background: #e5e7eb;
                    color: #374151;
                }

                .diff-count {
                    font-size: 0.875rem;
                    color: #6b7280;
                }

                .file-details {
                    padding: 0 1rem 1rem 1rem;
                    display: none;
                    border-top: 1px solid #e5e7eb;
                    background: #f9fafb;
                }

                .file-details.show {
                    display: block;
                }

                .details-container {
                    padding: 1rem 0;
                }

                .file-links h4 {
                    margin-bottom: 0.5rem;
                    color: #374151;
                }

                .link-row {
                    display: flex;
                    gap: 1rem;
                    align-items: center;
                    margin-bottom: 0.5rem;
                }

                .file-link-btn, .download-btn {
                    padding: 0.5rem 1rem;
                    border: 1px solid #3b82f6;
                    background: white;
                    color: #3b82f6;
                    border-radius: 6px;
                    cursor: pointer;
                    font-size: 0.875rem;
                    transition: all 0.2s ease;
                }

                .file-link-btn:hover, .download-btn:hover {
                    background: #3b82f6;
                    color: white;
                }

                .comparison-summary {
                    margin: 1rem 0;
                    padding: 1rem;
                    background: white;
                    border-radius: 6px;
                }

                .summary-stats {
                    display: flex;
                    gap: 2rem;
                    flex-wrap: wrap;
                }

                .summary-stats span {
                    font-size: 0.875rem;
                    color: #6b7280;
                }

                .summary-stats strong {
                    color: #1f2937;
                }

                .differences-list {
                    margin: 1rem 0;
                }

                .difference-item {
                    background: white;
                    border-left: 3px solid #f59e0b;
                    padding: 1rem;
                    margin-bottom: 0.5rem;
                    border-radius: 4px;
                }

                .diff-header {
                    display: flex;
                    gap: 1rem;
                    margin-bottom: 0.5rem;
                    flex-wrap: wrap;
                }

                .line-number {
                    font-weight: 600;
                    color: #374151;
                }

                .bureau-tag, .type-tag {
                    padding: 0.125rem 0.5rem;
                    border-radius: 4px;
                    font-size: 0.75rem;
                    background: #e5e7eb;
                    color: #374151;
                }

                .diff-content {
                    font-family: 'Courier New', monospace;
                    font-size: 0.875rem;
                }

                .pre-line, .post-line {
                    padding: 0.5rem;
                    margin: 0.25rem 0;
                    border-radius: 4px;
                }

                .pre-line {
                    background: #fee2e2;
                    border-left: 3px solid #ef4444;
                }

                .post-line {
                    background: #d1fae5;
                    border-left: 3px solid #10b981;
                }

                .label {
                    font-weight: 600;
                    margin-right: 0.5rem;
                }

                @media (max-width: 768px) {
                    .container { padding: 1rem; }
                    header h1 { font-size: 1.5rem; }
                    .metadata { flex-direction: column; gap: 0.5rem; }
                    .summary-cards { grid-template-columns: 1fr 1fr; }
                }
            </style>
        """;
    }

    /**
     * Generates summary card HTML.
     */
    private String generateSummaryCard(String title, String value, String color) {
        return String.format(
            "            <div class=\"card\" style=\"border-left-color: %s;\">\n" +
            "                <div class=\"card-title\">%s</div>\n" +
            "                <div class=\"card-value\" style=\"color: %s;\">%s</div>\n" +
            "            </div>\n",
            color, title, color, value
        );
    }

    /**
     * Generates filters section.
     */
    private String generateFilters(List<ComparisonResult> results) {
        // Get unique categories
        String categories = results.stream()
            .map(r -> r.getApplicationData().getCategory())
            .distinct()
            .sorted()
            .collect(Collectors.joining());

        return """
                <div class="filters-section">
                    <div class="filter-group">
                        <select id="filter-status">
                            <option value="all">All Status</option>
                            <option value="MATCHED">Matched</option>
                            <option value="DIFFERENT">Different</option>
                            <option value="FAILED">Failed</option>
                        </select>

                        <select id="filter-category">
                            <option value="all">All Categories</option>
                            <option value="ACQ">ACQ</option>
                            <option value="CLI">CLI</option>
                            <option value="PRQ">PRQ</option>
                        </select>

                        <input type="text" id="search-box" placeholder="Search files...">
                    </div>
                </div>

        """;
    }

    /**
     * Generates HTML for a single file item.
     */
    private String generateFileItem(ComparisonResult result) {
        String status = result.isMatched() ? "MATCHED" :
                       result.hasDifferences() ? "DIFFERENT" : "FAILED";
        String statusClass = "status-" + status.toLowerCase();

        StringBuilder html = new StringBuilder();
        html.append("            <div class=\"file-item\" data-status=\"").append(status).append("\" ")
            .append("data-category=\"").append(result.getApplicationData().getCategory()).append("\">\n");

        // File header
        html.append("                <div class=\"file-header\" onclick=\"toggleDetails(this)\">\n");
        html.append("                    <span class=\"expand-icon\">▶</span>\n");
        html.append("                    <span class=\"file-name\">").append(result.getApplicationData().getFileName()).append("</span>\n");
        html.append("                    <span class=\"status-badge ").append(statusClass).append("\">").append(status).append("</span>\n");
        html.append("                    <span class=\"category-tag\">").append(result.getApplicationData().getCategory()).append("</span>\n");

        if (result.hasDifferences()) {
            html.append("                    <span class=\"diff-count\">").append(result.getTotalDifferences()).append(" differences</span>\n");
        }

        html.append("                </div>\n");

        // File details (collapsed)
        html.append("                <div class=\"file-details\">\n");
        html.append("                    <div class=\"details-container\">\n");

        if (!result.isFailed()) {
            html.append(generateFileLinks(result));
        }

        if (result.hasDifferences()) {
            html.append(generateComparisonDetails(result));
        } else if (result.isFailed()) {
            html.append("                        <div class=\"error-message\">\n");
            html.append("                            <strong>Error:</strong> ").append(result.getErrorMessage()).append("\n");
            html.append("                        </div>\n");
        }

        html.append("                    </div>\n");
        html.append("                </div>\n");
        html.append("            </div>\n");

        return html.toString();
    }

    /**
     * Generates file links section.
     */
    private String generateFileLinks(ComparisonResult result) {
        return String.format("""
                        <div class="file-links">
                            <h4>Extracted Files:</h4>
                            <div class="link-row">
                                <button class="file-link-btn" onclick="openFile('%s')">📄 PRE (%s)</button>
                            </div>
                            <div class="link-row">
                                <button class="file-link-btn" onclick="openFile('%s')">📄 POST (%s)</button>
                            </div>
                        </div>

        """,
            result.getApplicationData().getPreFilePath(),
            result.getApplicationData().getPreAppId(),
            result.getApplicationData().getPostFilePath(),
            result.getApplicationData().getPostAppId()
        );
    }

    /**
     * Generates comparison details section.
     */
    private String generateComparisonDetails(ComparisonResult result) {
        StringBuilder html = new StringBuilder();

        html.append("                        <div class=\"comparison-summary\">\n");
        html.append("                            <h4>Comparison Summary:</h4>\n");
        html.append("                            <div class=\"summary-stats\">\n");
        html.append("                                <span>Total Differences: <strong>").append(result.getTotalDifferences()).append("</strong></span>\n");
        html.append("                                <span>PRE Lines: <strong>").append(result.getPreLineCount()).append("</strong></span>\n");
        html.append("                                <span>POST Lines: <strong>").append(result.getPostLineCount()).append("</strong></span>\n");
        html.append("                            </div>\n");
        html.append("                        </div>\n\n");

        html.append("                        <div class=\"differences-list\">\n");
        html.append("                            <h4>Differences:</h4>\n");

        // Show first 5 differences
        int displayCount = Math.min(result.getDifferences().size(), 5);
        for (int i = 0; i < displayCount; i++) {
            Difference diff = result.getDifferences().get(i);
            html.append(generateDifferenceItem(diff));
        }

        if (result.getDifferences().size() > 5) {
            html.append("                            <p style=\"margin-top: 1rem; color: #6b7280;\">... and ")
                .append(result.getDifferences().size() - 5).append(" more differences</p>\n");
        }

        html.append("                        </div>\n");

        return html.toString();
    }

    /**
     * Generates single difference item.
     */
    private String generateDifferenceItem(Difference diff) {
        return String.format("""
                            <div class="difference-item">
                                <div class="diff-header">
                                    <span class="line-number">Line %d</span>
                                    <span class="bureau-tag">%s</span>
                                    <span class="type-tag">%s</span>
                                </div>
                                <div class="diff-content">
                                    <div class="pre-line">
                                        <span class="label">PRE:</span>%s
                                    </div>
                                    <div class="post-line">
                                        <span class="label">POST:</span>%s
                                    </div>
                                </div>
                            </div>

        """,
            diff.getLineNumber(),
            diff.getBureauName(),
            diff.getType(),
            escapeHtml(diff.getPreLine()),
            escapeHtml(diff.getPostLine())
        );
    }

    /**
     * Generates JavaScript code.
     */
    private String generateJavaScript() {
        return """
            <script>
                function toggleDetails(header) {
                    const details = header.nextElementSibling;
                    const icon = header.querySelector('.expand-icon');

                    if (details.classList.contains('show')) {
                        details.classList.remove('show');
                        icon.classList.remove('expanded');
                    } else {
                        details.classList.add('show');
                        icon.classList.add('expanded');
                    }
                }

                function openFile(filePath) {
                    window.location.href = 'file:///' + filePath.replace(/\\\\/g, '/');
                }

                // Filter functionality
                document.getElementById('filter-status').addEventListener('change', applyFilters);
                document.getElementById('filter-category').addEventListener('change', applyFilters);
                document.getElementById('search-box').addEventListener('input', applyFilters);

                function applyFilters() {
                    const statusFilter = document.getElementById('filter-status').value;
                    const categoryFilter = document.getElementById('filter-category').value;
                    const searchText = document.getElementById('search-box').value.toLowerCase();

                    const items = document.querySelectorAll('.file-item');

                    items.forEach(item => {
                        const status = item.getAttribute('data-status');
                        const category = item.getAttribute('data-category');
                        const fileName = item.querySelector('.file-name').textContent.toLowerCase();

                        let show = true;

                        if (statusFilter !== 'all' && status !== statusFilter) {
                            show = false;
                        }

                        if (categoryFilter !== 'all' && category !== categoryFilter) {
                            show = false;
                        }

                        if (searchText && !fileName.includes(searchText)) {
                            show = false;
                        }

                        item.style.display = show ? 'block' : 'none';
                    });
                }
            </script>
        """;
    }

    /**
     * Escapes HTML special characters.
     */
    private String escapeHtml(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;")
                  .replace("<", "&lt;")
                  .replace(">", "&gt;")
                  .replace("\"", "&quot;")
                  .replace("'", "&#039;");
    }
}
