package com.harsha.bureau.reporting.generator;

import com.harsha.bureau.common.constant.BureauConstants;
import com.harsha.bureau.core.domain.model.ComparisonResult;
import com.harsha.bureau.core.domain.model.Difference;
import com.harsha.bureau.core.ports.output.ReportGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Generates text-based comparison reports (legacy format).
 */
@Component
public class TextReportGenerator implements ReportGenerator {

    private static final Logger log = LoggerFactory.getLogger(TextReportGenerator.class);

    @Override
    public String generateTextReport(List<ComparisonResult> results, String outputPath) {
        log.info("Generating text report: {}", outputPath);

        StringBuilder report = new StringBuilder();
        report.append("===== BUREAU DATA COMPARISON REPORT =====\n");
        report.append("Generated: ").append(LocalDateTime.now()).append("\n");
        report.append("Total Applications: ").append(results.size()).append("\n");

        // Summary statistics
        long matched = results.stream().filter(ComparisonResult::isMatched).count();
        long different = results.stream().filter(ComparisonResult::hasDifferences).count();
        long failed = results.stream().filter(ComparisonResult::isFailed).count();

        report.append("\nSUMMARY:\n");
        report.append("  Matched      : ").append(matched).append("\n");
        report.append("  Different    : ").append(different).append("\n");
        report.append("  Failed       : ").append(failed).append("\n");
        report.append("  Match Rate   : ").append(String.format("%.1f%%",
            results.isEmpty() ? 0 : (double) matched / results.size() * 100)).append("\n");
        report.append("==========================================\n\n");

        // Detailed results
        for (ComparisonResult result : results) {
            report.append(generateFileSection(result));
            report.append("\n\n");
        }

        // Write to file
        try (FileWriter writer = new FileWriter(outputPath)) {
            writer.write(report.toString());
            log.info("Text report generated successfully: {}", outputPath);
        } catch (IOException e) {
            log.error("Failed to write text report: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to write text report", e);
        }

        return outputPath;
    }

    @Override
    public String generateHtmlReport(List<ComparisonResult> results, String outputPath) {
        throw new UnsupportedOperationException("Use HtmlReportGenerator for HTML reports");
    }

    @Override
    public void generateBothReports(List<ComparisonResult> results, String outputDirectory) {
        String textPath = outputDirectory + "/MASTER_comparison_report.txt";
        generateTextReport(results, textPath);
    }

    /**
     * Generates section for a single file comparison.
     *
     * @param result the comparison result
     * @return the section text
     */
    private String generateFileSection(ComparisonResult result) {
        StringBuilder section = new StringBuilder();

        section.append("File: ").append(result.getApplicationData().getFileName()).append("\n");

        if (result.isMatched()) {
            section.append("Status: MATCHED - No differences found");
        } else if (result.hasDifferences()) {
            section.append("Status: DIFFERENCES FOUND\n");
            section.append("Total Differences: ").append(result.getTotalDifferences()).append("\n");
            section.append("Pre Lines: ").append(result.getPreLineCount()).append("\n");
            section.append("Post Lines: ").append(result.getPostLineCount()).append("\n\n");
            section.append("Differences Details:\n");
            section.append(generateDifferencesText(result.getDifferences()));
        } else if (result.isFailed()) {
            section.append("Status: ERROR - Could not compare files\n");
            section.append("Error: ").append(result.getErrorMessage());
        }

        return section.toString();
    }

    /**
     * Generates text for differences list.
     *
     * @param differences the list of differences
     * @return the differences text
     */
    private String generateDifferencesText(List<Difference> differences) {
        StringBuilder text = new StringBuilder();

        int displayCount = Math.min(differences.size(), BureauConstants.DEFAULT_COMPARISON_DISPLAY_LIMIT);

        for (int i = 0; i < displayCount; i++) {
            Difference diff = differences.get(i);
            text.append("\n").append(diff.toDisplayString()).append("\n");
        }

        if (differences.size() > BureauConstants.DEFAULT_COMPARISON_DISPLAY_LIMIT) {
            text.append("\n... and ").append(differences.size() - BureauConstants.DEFAULT_COMPARISON_DISPLAY_LIMIT)
                .append(" more differences\n");
        }

        text.append("\nTotal differences found: ").append(differences.size());

        return text.toString();
    }
}
