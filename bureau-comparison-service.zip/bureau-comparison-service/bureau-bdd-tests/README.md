# Bureau BDD Tests

Behavior-Driven Development (BDD) tests for the Bureau Comparison System using Cucumber and TestNG.

## Overview

This module contains comprehensive BDD tests covering:
- User authentication and login
- Bureau data extraction
- File comparison
- Report generation

## Technologies

- **Cucumber**: BDD framework for writing tests in natural language
- **TestNG**: Test execution framework
- **Spring Boot Test**: Integration with Spring context
- **AssertJ**: Fluent assertions

## Project Structure

```
bureau-bdd-tests/
├── src/
│   └── test/
│       ├── java/com/harsha/bureau/bdd/
│       │   ├── CucumberTestRunner.java          # Main test runner
│       │   ├── config/
│       │   │   ├── SpringTestConfig.java        # Spring test configuration
│       │   │   ├── TestApplication.java         # Test application context
│       │   │   └── TestHooks.java               # Before/After hooks
│       │   └── steps/
│       │       ├── LoginSteps.java              # Login step definitions
│       │       ├── ExtractionSteps.java         # Extraction step definitions
│       │       ├── ComparisonSteps.java         # Comparison step definitions
│       │       └── ReportGenerationSteps.java   # Reporting step definitions
│       └── resources/
│           ├── features/                        # Cucumber feature files
│           │   ├── login.feature
│           │   ├── bureau-extraction.feature
│           │   ├── file-comparison.feature
│           │   └── report-generation.feature
│           ├── testng.xml                       # TestNG configuration
│           ├── cucumber.properties              # Cucumber properties
│           └── application-test.yml             # Test Spring configuration
```

## Running Tests

### Run All Tests

```bash
mvn clean test
```

### Run Specific Test Suite

```bash
# Smoke tests only
mvn test -Dcucumber.filter.tags="@Smoke"

# Login tests
mvn test -Dcucumber.filter.tags="@Login"

# Extraction tests
mvn test -Dcucumber.filter.tags="@Extraction"

# Comparison tests
mvn test -Dcucumber.filter.tags="@Comparison"

# Reporting tests
mvn test -Dcucumber.filter.tags="@Reporting"

# Performance tests
mvn test -Dcucumber.filter.tags="@Performance"

# Exclude negative tests
mvn test -Dcucumber.filter.tags="not @Negative"
```

### Run with TestNG XML

```bash
mvn test -DsuiteXmlFile=src/test/resources/testng.xml
```

### Parallel Execution

Tests are configured for parallel execution:
- 4 parallel threads by default
- Configured in `cucumber.properties` and `testng.xml`

To adjust parallelism:
```bash
mvn test -Dcucumber.execution.parallel.config.fixed.parallelism=8
```

## Feature Tags

### By Functionality
- `@Login` - User authentication tests
- `@Extraction` - Bureau data extraction tests
- `@Comparison` - File comparison tests
- `@Reporting` - Report generation tests

### By Type
- `@Smoke` - Critical smoke tests
- `@Regression` - Full regression suite
- `@Performance` - Performance validation tests
- `@Negative` - Negative scenario tests
- `@Detailed` - Detailed verification tests

### Special Tags
- `@Ignore` - Skip this test
- `@WIP` - Work in progress (optional)

## Test Reports

After running tests, reports are generated in:

### Cucumber Reports
- **HTML Report**: `target/cucumber-reports/cucumber.html`
- **JSON Report**: `target/cucumber-reports/cucumber.json`
- **JUnit XML**: `target/cucumber-reports/cucumber.xml`

### TestNG Reports
- **HTML Report**: `target/surefire-reports/index.html`
- **XML Report**: `target/surefire-reports/TEST-*.xml`

### Extent Reports
- **Report**: `target/cucumber-reports/ExtentReport.html`

## Writing New Tests

### 1. Create Feature File

Create a new `.feature` file in `src/test/resources/features/`:

```gherkin
Feature: My New Feature
  As a user
  I want to do something
  So that I can achieve a goal

  Scenario: My test scenario
    Given some precondition
    When I perform an action
    Then I should see expected result
```

### 2. Implement Step Definitions

Create or update step definition class in `src/test/java/com/harsha/bureau/bdd/steps/`:

```java
@Given("some precondition")
public void somePrecondition() {
    // Implementation
}

@When("I perform an action")
public void iPerformAnAction() {
    // Implementation
}

@Then("I should see expected result")
public void iShouldSeeExpectedResult() {
    // Assertions
}
```

### 3. Run Your Test

```bash
mvn test -Dcucumber.filter.tags="@YourTag"
```

## Test Configuration

### Spring Test Profile

Tests use the `test` Spring profile configured in `application-test.yml`:
- Headless browser mode for CI/CD
- Reduced parallelism
- Test-specific timeouts
- Mock credentials

### Environment Variables

Override test configuration using environment variables:
```bash
export BUREAU_USERNAME=test_user
export BUREAU_PASSWORD=test_pass
mvn test
```

## Best Practices

1. **Tag Your Scenarios**: Always use appropriate tags
2. **Keep Scenarios Focused**: One scenario per behavior
3. **Use Background**: Share common preconditions
4. **Meaningful Names**: Use descriptive scenario names
5. **Avoid UI Details**: Focus on behavior, not implementation
6. **Independent Tests**: Tests should not depend on each other
7. **Clean Test Data**: Use fresh test data for each run

## Troubleshooting

### WebDriver Issues

If WebDriver fails to start:
```bash
# Clear WebDriver cache
rm -rf ~/.wdm/cache
```

### Port Already in Use

If Selenium Grid port is in use:
```bash
# Find and kill process on port 4444
netstat -ano | findstr :4444
taskkill /PID <pid> /F
```

### Test Failures

Check logs:
```bash
tail -f target/logs/bureau-test.log
```

## CI/CD Integration

### GitHub Actions Example

```yaml
name: BDD Tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with:
          java-version: '17'
      - name: Run BDD Tests
        run: mvn clean test
      - name: Publish Test Report
        uses: actions/upload-artifact@v3
        with:
          name: cucumber-reports
          path: target/cucumber-reports/
```

## Support

For issues or questions:
1. Check the main project README
2. Review Cucumber documentation: https://cucumber.io/docs/
3. Review TestNG documentation: https://testng.org/doc/
