package com.harsha.bureau.bdd.steps;

import com.harsha.bureau.core.domain.model.ComparisonResult;
import com.harsha.bureau.core.ports.input.GenerateReportUseCase;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Step Definitions for Report Generation.
 */
public class ReportGenerationSteps {

    private static final Logger log = LoggerFactory.getLogger(ReportGenerationSteps.class);

    @Autowired
    private GenerateReportUseCase generateReportUseCase;

    private List<ComparisonResult> comparisonResults = new ArrayList<>();
    private String outputDirectory;
    private String htmlReportPath;
    private String textReportPath;

    @Given("there are {int} comparison results")
    public void thereAreComparisonResults(int count) {
        // Mock comparison results for testing
        comparisonResults = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            // Create mock results (in real tests, these would be actual results)
            comparisonResults.add(createMockResult(i));
        }

        log.info("Created {} comparison results for testing", count);
    }

    @Given("the output directory is {string}")
    public void theOutputDirectoryIs(String directory) {
        this.outputDirectory = directory;

        // Create directory if it doesn't exist
        File dir = new File(directory);
        if (!dir.exists()) {
            dir.mkdirs();
            log.info("Created output directory: {}", directory);
        }
    }

    @When("the HTML report is generated")
    public void theHtmlReportIsGenerated() {
        log.info("Generating HTML report...");

        htmlReportPath = generateReportUseCase.generateHtmlReport(
            comparisonResults,
            outputDirectory
        );

        log.info("HTML report generated: {}", htmlReportPath);
    }

    @When("the text report is generated")
    public void theTextReportIsGenerated() {
        log.info("Generating text report...");

        textReportPath = generateReportUseCase.generateTextReport(
            comparisonResults,
            outputDirectory
        );

        log.info("Text report generated: {}", textReportPath);
    }

    @When("both reports are generated")
    public void bothReportsAreGenerated() {
        log.info("Generating both HTML and text reports...");

        generateReportUseCase.generateReports(comparisonResults, outputDirectory);

        htmlReportPath = outputDirectory + "/index.html";
        textReportPath = outputDirectory + "/MASTER_comparison_report.txt";

        log.info("Both reports generated successfully");
    }

    @Then("the HTML report should be created")
    public void theHtmlReportShouldBeCreated() {
        assertThat(htmlReportPath)
            .as("HTML report path should not be null")
            .isNotNull();

        File htmlFile = new File(htmlReportPath);
        assertThat(htmlFile.exists())
            .as("HTML report file should exist")
            .isTrue();

        assertThat(htmlFile.length())
            .as("HTML report should not be empty")
            .isGreaterThan(0);

        log.info("Verified HTML report created: {}", htmlReportPath);
    }

    @Then("the text report should be created")
    public void theTextReportShouldBeCreated() {
        assertThat(textReportPath)
            .as("Text report path should not be null")
            .isNotNull();

        File textFile = new File(textReportPath);
        assertThat(textFile.exists())
            .as("Text report file should exist")
            .isTrue();

        assertThat(textFile.length())
            .as("Text report should not be empty")
            .isGreaterThan(0);

        log.info("Verified text report created: {}", textReportPath);
    }

    @Then("the HTML report should contain the summary section")
    public void theHtmlReportShouldContainTheSummarySection() throws Exception {
        String content = Files.readString(Paths.get(htmlReportPath));

        assertThat(content)
            .as("HTML should contain summary section")
            .contains("summary", "Summary");

        log.info("Verified HTML report contains summary section");
    }

    @Then("the HTML report should contain comparison results")
    public void theHtmlReportShouldContainComparisonResults() throws Exception {
        String content = Files.readString(Paths.get(htmlReportPath));

        assertThat(content)
            .as("HTML should contain comparison results")
            .contains("comparison", "result");

        log.info("Verified HTML report contains comparison results");
    }

    @Then("the text report should contain the summary section")
    public void theTextReportShouldContainTheSummarySection() throws Exception {
        String content = Files.readString(Paths.get(textReportPath));

        assertThat(content)
            .as("Text report should contain summary")
            .contains("SUMMARY", "Total Applications");

        log.info("Verified text report contains summary section");
    }

    @Then("the text report should contain all {int} results")
    public void theTextReportShouldContainAllResults(int expectedCount) throws Exception {
        String content = Files.readString(Paths.get(textReportPath));

        // Count occurrences of application entries
        long actualCount = content.lines()
            .filter(line -> line.contains("Application ID:"))
            .count();

        assertThat(actualCount)
            .as("Text report should contain all results")
            .isGreaterThanOrEqualTo(expectedCount);

        log.info("Verified text report contains {} results", actualCount);
    }

    @Then("the HTML report should have interactive features")
    public void theHtmlReportShouldHaveInteractiveFeatures() throws Exception {
        String content = Files.readString(Paths.get(htmlReportPath));

        assertThat(content)
            .as("HTML should contain JavaScript")
            .contains("<script>", "function");

        assertThat(content)
            .as("HTML should have filter functionality")
            .contains("filter", "Filter");

        log.info("Verified HTML report has interactive features");
    }

    @Then("the HTML report should include CSS styles")
    public void theHtmlReportShouldIncludeCssStyles() throws Exception {
        String content = Files.readString(Paths.get(htmlReportPath));

        assertThat(content)
            .as("HTML should contain CSS")
            .contains("<style>", "css");

        log.info("Verified HTML report includes CSS styles");
    }

    // Helper method to create mock results
    private ComparisonResult createMockResult(int index) {
        // In real tests, use actual comparison results
        // This is a simplified mock for demonstration
        return null; // Replace with actual mock creation logic
    }
}
