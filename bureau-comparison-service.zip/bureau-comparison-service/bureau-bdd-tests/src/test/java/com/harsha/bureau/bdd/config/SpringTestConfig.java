package com.harsha.bureau.bdd.config;

import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

/**
 * Spring Boot Test Configuration for Cucumber.
 * Enables Spring context for BDD tests.
 */
@CucumberContextConfiguration
@SpringBootTest(classes = TestApplication.class)
@ActiveProfiles("test")
public class SpringTestConfig {
    // Spring context will be automatically loaded for all step definitions
}
