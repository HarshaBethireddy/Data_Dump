package com.harsha.bureau.bdd.steps;

import com.harsha.bureau.core.domain.model.ExtractionResult;
import com.harsha.bureau.core.ports.output.BureauExtractor;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Step Definitions for Bureau Data Extraction.
 */
public class ExtractionSteps {

    private static final Logger log = LoggerFactory.getLogger(ExtractionSteps.class);

    @Autowired
    private BureauExtractor bureauExtractor;

    private String applicationId;
    private String bureauType;
    private String category;
    private String outputPath;
    private ExtractionResult extractionResult;

    @Given("the user is logged in to the system")
    public void theUserIsLoggedInToTheSystem() {
        log.info("Verifying user is logged in...");

        boolean isReady = bureauExtractor.isReady();
        if (!isReady) {
            log.info("Not logged in, attempting login...");
            boolean loginSuccess = bureauExtractor.login();
            assertThat(loginSuccess)
                .as("Login should succeed")
                .isTrue();
        }

        log.info("User is logged in and ready");
    }

    @Given("the application ID is {string}")
    public void theApplicationIDIs(String appId) {
        this.applicationId = appId;
        log.info("Set application ID: {}", appId);
    }

    @Given("the bureau type is {string}")
    public void theBureauTypeIs(String type) {
        this.bureauType = type;
        log.info("Set bureau type: {}", type);
    }

    @Given("the category is {string}")
    public void theCategoryIs(String category) {
        this.category = category;
        log.info("Set category: {}", category);
    }

    @Given("the output path is {string}")
    public void theOutputPathIs(String outputPath) {
        this.outputPath = outputPath;
        log.info("Set output path: {}", outputPath);
    }

    @When("the user extracts bureau data")
    public void theUserExtractsBureauData() {
        log.info("Starting extraction for AppID: {}, Type: {}, Category: {}",
            applicationId, bureauType, category);

        extractionResult = bureauExtractor.extract(
            applicationId,
            bureauType,
            category,
            outputPath
        );

        log.info("Extraction completed with status: {}", extractionResult.getStatus());
    }

    @Then("the extraction should be successful")
    public void theExtractionShouldBeSuccessful() {
        assertThat(extractionResult)
            .as("Extraction result should not be null")
            .isNotNull();

        assertThat(extractionResult.isSuccess())
            .as("Extraction should be successful")
            .isTrue();

        log.info("Extraction verified as successful");
    }

    @Then("the data should be saved to the output file")
    public void theDataShouldBeSavedToTheOutputFile() {
        assertThat(extractionResult.getFilePath())
            .as("Output file path should not be empty")
            .isNotEmpty();

        File outputFile = new File(extractionResult.getFilePath());
        assertThat(outputFile.exists())
            .as("Output file should exist")
            .isTrue();

        assertThat(outputFile.length())
            .as("Output file should not be empty")
            .isGreaterThan(0);

        log.info("Verified data saved to: {}", extractionResult.getFilePath());
    }

    @Then("the extraction should fail")
    public void theExtractionShouldFail() {
        assertThat(extractionResult)
            .as("Extraction result should not be null")
            .isNotNull();

        assertThat(extractionResult.isSuccess())
            .as("Extraction should have failed")
            .isFalse();

        log.info("Extraction failed as expected");
    }

    @Then("the error message should contain {string}")
    public void theErrorMessageShouldContain(String expectedMessage) {
        assertThat(extractionResult.getErrorMessage())
            .as("Error message should contain expected text")
            .containsIgnoringCase(expectedMessage);

        log.info("Error message verified: {}", extractionResult.getErrorMessage());
    }

    @Then("the extracted file should contain bureau sections")
    public void theExtractedFileShouldContainBureauSections() throws Exception {
        String content = Files.readString(Paths.get(extractionResult.getFilePath()));

        assertThat(content)
            .as("File content should not be empty")
            .isNotEmpty();

        assertThat(content)
            .as("File should contain section separator")
            .contains("==================================================");

        assertThat(content)
            .as("File should contain application ID")
            .contains(applicationId);

        log.info("Verified bureau sections in extracted file");
    }
}
