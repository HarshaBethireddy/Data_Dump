package com.harsha.bureau.bdd;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;

/**
 * Cucumber TestNG Runner.
 * Executes all feature files and generates reports.
 */
@CucumberOptions(
    features = "src/test/resources/features",           // Path to feature files
    glue = {
        "com.harsha.bureau.bdd.steps",                 // Step definitions package
        "com.harsha.bureau.bdd.config"                 // Configuration/hooks package
    },
    plugin = {
        "pretty",                                       // Console output
        "html:target/cucumber-reports/cucumber.html",   // HTML report
        "json:target/cucumber-reports/cucumber.json",   // JSON report for tools
        "junit:target/cucumber-reports/cucumber.xml",   // JUnit XML report
        "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:" // Extent Reports
    },
    monochrome = true,                                  // Readable console output
    dryRun = false,                                     // Set to true to check step definitions without execution
    tags = "not @Ignore",                               // Run all tests except those tagged with @Ignore
    publish = false                                     // Don't publish to Cucumber Cloud
)
public class CucumberTestRunner extends AbstractTestNGCucumberTests {

    /**
     * Enables parallel execution of scenarios.
     * Override this method to run scenarios in parallel.
     */
    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}
