package com.harsha.bureau.bdd.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Test Application for BDD tests.
 * Provides Spring Boot context for Cucumber tests.
 */
@SpringBootApplication
@ComponentScan(basePackages = "com.harsha.bureau")
public class TestApplication {

    public static void main(String[] args) {
        SpringApplication.run(TestApplication.class, args);
    }
}
