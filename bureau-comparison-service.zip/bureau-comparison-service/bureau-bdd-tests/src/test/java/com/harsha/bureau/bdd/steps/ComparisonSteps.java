package com.harsha.bureau.bdd.steps;

import com.harsha.bureau.core.domain.model.ApplicationData;
import com.harsha.bureau.core.domain.model.ComparisonResult;
import com.harsha.bureau.core.domain.model.ProcessingStatus;
import com.harsha.bureau.core.ports.input.CompareFilesUseCase;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.nio.file.Files;
import java.nio.file.Paths;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Step Definitions for File Comparison.
 */
public class ComparisonSteps {

    private static final Logger log = LoggerFactory.getLogger(ComparisonSteps.class);

    @Autowired
    private CompareFilesUseCase compareFilesUseCase;

    private ApplicationData applicationData;
    private String preFilePath;
    private String postFilePath;
    private ComparisonResult comparisonResult;

    @Given("a PRE file exists at {string}")
    public void aPreFileExistsAt(String filePath) {
        this.preFilePath = filePath;

        assertThat(Files.exists(Paths.get(filePath)))
            .as("PRE file should exist at: " + filePath)
            .isTrue();

        log.info("PRE file verified: {}", filePath);
    }

    @Given("a POST file exists at {string}")
    public void aPostFileExistsAt(String filePath) {
        this.postFilePath = filePath;

        assertThat(Files.exists(Paths.get(filePath)))
            .as("POST file should exist at: " + filePath)
            .isTrue();

        log.info("POST file verified: {}", filePath);
    }

    @Given("the application data has:")
    public void theApplicationDataHas(io.cucumber.datatable.DataTable dataTable) {
        var data = dataTable.asMap(String.class, String.class);

        applicationData = ApplicationData.builder()
            .fileName(data.get("fileName"))
            .preAppId(data.get("preAppId"))
            .postAppId(data.get("postAppId"))
            .category(data.get("category"))
            .status(ProcessingStatus.PENDING)
            .build();

        log.info("Application data created: {}", applicationData);
    }

    @When("the files are compared")
    public void theFilesAreCompared() {
        log.info("Comparing files - PRE: {}, POST: {}", preFilePath, postFilePath);

        comparisonResult = compareFilesUseCase.compareFiles(
            applicationData,
            preFilePath,
            postFilePath
        );

        log.info("Comparison completed with status: {}", comparisonResult.getStatus());
    }

    @Then("the comparison result should be {string}")
    public void theComparisonResultShouldBe(String expectedStatus) {
        ProcessingStatus expected = ProcessingStatus.valueOf(expectedStatus.toUpperCase());

        assertThat(comparisonResult.getStatus())
            .as("Comparison status should match expected")
            .isEqualTo(expected);

        log.info("Comparison result verified: {}", expectedStatus);
    }

    @Then("the comparison should show {int} differences")
    public void theComparisonShouldShowDifferences(int expectedDifferences) {
        assertThat(comparisonResult.getTotalDifferences())
            .as("Total differences should match expected")
            .isEqualTo(expectedDifferences);

        log.info("Verified {} differences", expectedDifferences);
    }

    @Then("no differences should be found")
    public void noDifferencesShouldBeFound() {
        assertThat(comparisonResult.getTotalDifferences())
            .as("Should have zero differences")
            .isZero();

        assertThat(comparisonResult.getDifferences())
            .as("Differences list should be empty")
            .isEmpty();

        log.info("Verified no differences found");
    }

    @Then("differences should be found")
    public void differencesShouldBeFound() {
        assertThat(comparisonResult.getTotalDifferences())
            .as("Should have at least one difference")
            .isGreaterThan(0);

        assertThat(comparisonResult.getDifferences())
            .as("Differences list should not be empty")
            .isNotEmpty();

        log.info("Verified differences found: {}", comparisonResult.getTotalDifferences());
    }

    @Then("the differences should include:")
    public void theDifferencesShouldInclude(io.cucumber.datatable.DataTable dataTable) {
        var expectedDiffs = dataTable.asMaps(String.class, String.class);

        for (var expectedDiff : expectedDiffs) {
            String section = expectedDiff.get("section");
            String field = expectedDiff.get("field");

            boolean found = comparisonResult.getDifferences().stream()
                .anyMatch(diff ->
                    diff.getSection().equals(section) &&
                    diff.getFieldName().equals(field)
                );

            assertThat(found)
                .as("Should find difference in section '%s', field '%s'", section, field)
                .isTrue();
        }

        log.info("Verified expected differences present");
    }

    @Then("the comparison duration should be less than {int} milliseconds")
    public void theComparisonDurationShouldBeLessThanMilliseconds(long maxDuration) {
        assertThat(comparisonResult.getDurationMs())
            .as("Comparison should complete within time limit")
            .isLessThan(maxDuration);

        log.info("Comparison duration: {} ms (limit: {} ms)",
            comparisonResult.getDurationMs(), maxDuration);
    }

    @Then("the PRE file should have {int} lines")
    public void thePreFileShouldHaveLines(int expectedLines) {
        assertThat(comparisonResult.getPreLineCount())
            .as("PRE file line count should match")
            .isEqualTo(expectedLines);

        log.info("Verified PRE file has {} lines", expectedLines);
    }

    @Then("the POST file should have {int} lines")
    public void thePostFileShouldHaveLines(int expectedLines) {
        assertThat(comparisonResult.getPostLineCount())
            .as("POST file line count should match")
            .isEqualTo(expectedLines);

        log.info("Verified POST file has {} lines", expectedLines);
    }
}
