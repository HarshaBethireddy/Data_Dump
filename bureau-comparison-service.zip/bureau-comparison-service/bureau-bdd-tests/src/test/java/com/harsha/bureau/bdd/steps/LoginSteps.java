package com.harsha.bureau.bdd.steps;

import com.harsha.bureau.bdd.config.TestHooks;
import com.harsha.bureau.core.ports.output.WebDriverProvider;
import com.harsha.bureau.infrastructure.selenium.pages.GroupSelectionPage;
import com.harsha.bureau.infrastructure.selenium.pages.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Step Definitions for Login functionality.
 */
public class LoginSteps {

    private static final Logger log = LoggerFactory.getLogger(LoginSteps.class);

    @Autowired
    private WebDriverProvider driverProvider;

    @Autowired
    private TestHooks testHooks;

    @Value("${bureau.comparison.base-url}")
    private String baseUrl;

    @Value("${bureau.comparison.credentials.username}")
    private String username;

    @Value("${bureau.comparison.credentials.password}")
    private String password;

    private WebDriver driver;
    private LoginPage loginPage;
    private GroupSelectionPage groupSelectionPage;
    private Exception loginException;

    @Given("the user is on the login page")
    public void theUserIsOnTheLoginPage() throws Exception {
        log.info("Opening login page: {}", baseUrl);

        // Acquire WebDriver from pool
        driver = driverProvider.acquire();
        testHooks.setCurrentDriver(driver);

        // Navigate to login page
        driver.get(baseUrl);
        loginPage = new LoginPage(driver);

        // Verify page loaded
        assertThat(loginPage.isLoginPageDisplayed())
            .as("Login page should be displayed")
            .isTrue();

        log.info("Login page loaded successfully");
    }

    @When("the user enters valid credentials")
    public void theUserEntersValidCredentials() {
        log.info("Entering credentials for user: {}", username);
        // Credentials are entered during login action
    }

    @When("the user clicks the login button")
    public void theUserClicksTheLoginButton() {
        log.info("Attempting login...");

        try {
            groupSelectionPage = loginPage.login(username, password);
            log.info("Login action completed");
        } catch (Exception e) {
            log.error("Login failed: {}", e.getMessage());
            loginException = e;
        }
    }

    @Then("the user should be redirected to the group selection page")
    public void theUserShouldBeRedirectedToTheGroupSelectionPage() {
        assertThat(loginException)
            .as("Login should not throw exception")
            .isNull();

        assertThat(groupSelectionPage)
            .as("Group selection page should be loaded")
            .isNotNull();

        assertThat(groupSelectionPage.isGroupSelectionPageDisplayed())
            .as("Group selection page should be displayed")
            .isTrue();

        log.info("User successfully redirected to group selection page");
    }

    @Then("the user should see an error message")
    public void theUserShouldSeeAnErrorMessage() {
        assertThat(loginException)
            .as("Login should have thrown exception for invalid credentials")
            .isNotNull();

        log.info("Error message displayed as expected");
    }

    @When("the user enters username {string} and password {string}")
    public void theUserEntersUsernameAndPassword(String username, String password) {
        log.info("Entering custom credentials - Username: {}", username);

        try {
            groupSelectionPage = loginPage.login(username, password);
        } catch (Exception e) {
            log.error("Login failed: {}", e.getMessage());
            loginException = e;
        }
    }
}
