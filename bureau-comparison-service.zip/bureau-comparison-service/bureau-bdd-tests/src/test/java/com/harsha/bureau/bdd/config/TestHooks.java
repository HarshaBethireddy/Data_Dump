package com.harsha.bureau.bdd.config;

import com.harsha.bureau.core.ports.output.WebDriverProvider;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Cucumber Test Hooks.
 * Executes setup and teardown logic before/after each scenario.
 */
public class TestHooks {

    private static final Logger log = LoggerFactory.getLogger(TestHooks.class);

    @Autowired(required = false)
    private WebDriverProvider driverProvider;

    private WebDriver currentDriver;

    /**
     * Executes before each scenario.
     */
    @Before
    public void beforeScenario(Scenario scenario) {
        log.info("========================================");
        log.info("Starting Scenario: {}", scenario.getName());
        log.info("Tags: {}", scenario.getSourceTagNames());
        log.info("========================================");
    }

    /**
     * Executes after each scenario.
     * Takes screenshot if scenario failed.
     */
    @After
    public void afterScenario(Scenario scenario) {
        try {
            if (scenario.isFailed()) {
                log.error("Scenario FAILED: {}", scenario.getName());

                // Take screenshot if driver is available
                if (currentDriver != null && currentDriver instanceof TakesScreenshot) {
                    byte[] screenshot = ((TakesScreenshot) currentDriver).getScreenshotAs(OutputType.BYTES);
                    scenario.attach(screenshot, "image/png", "failure-screenshot");
                    log.info("Screenshot captured for failed scenario");
                }
            } else {
                log.info("Scenario PASSED: {}", scenario.getName());
            }
        } catch (Exception e) {
            log.warn("Could not capture screenshot: {}", e.getMessage());
        } finally {
            // Cleanup WebDriver if used
            if (currentDriver != null && driverProvider != null) {
                try {
                    driverProvider.release(currentDriver);
                    currentDriver = null;
                } catch (Exception e) {
                    log.warn("Error releasing WebDriver: {}", e.getMessage());
                }
            }
        }

        log.info("========================================");
        log.info("Completed Scenario: {}", scenario.getName());
        log.info("Status: {}", scenario.getStatus());
        log.info("========================================\n");
    }

    /**
     * Executes once before all scenarios.
     */
    @Before(order = 0)
    public void globalSetup() {
        log.info("=== GLOBAL TEST SETUP ===");
        // Global setup logic here
    }

    /**
     * Executes once after all scenarios.
     */
    @After(order = Integer.MAX_VALUE)
    public void globalTeardown() {
        log.info("=== GLOBAL TEST TEARDOWN ===");

        // Shutdown WebDriver pool
        if (driverProvider != null) {
            try {
                driverProvider.shutdown();
                log.info("WebDriver pool shut down successfully");
            } catch (Exception e) {
                log.error("Error shutting down WebDriver pool: {}", e.getMessage());
            }
        }
    }

    // Helper methods for step definitions

    public void setCurrentDriver(WebDriver driver) {
        this.currentDriver = driver;
    }

    public WebDriver getCurrentDriver() {
        return currentDriver;
    }
}
