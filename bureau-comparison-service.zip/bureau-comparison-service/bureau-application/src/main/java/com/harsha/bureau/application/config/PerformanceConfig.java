package com.harsha.bureau.application.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Performance and parallelism configuration.
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "bureau.comparison.performance")
public class PerformanceConfig {

    private Parallelism parallelism = new Parallelism();
    private Timeouts timeouts = new Timeouts();
    private Retry retry = new Retry();
    private Cache cache = new Cache();

    @Data
    public static class Parallelism {
        private int fileLevel = 12;          // Parallel files (matches browser pool)
        private int ioOperations = 10;       // Parallel I/O operations
        private int comparison = 8;          // Parallel comparisons
    }

    @Data
    public static class Timeouts {
        private int extraction = 45;         // Seconds
        private int navigation = 10;         // Seconds
        private int pageLoad = 30;           // Seconds
    }

    @Data
    public static class Retry {
        private int maxAttempts = 3;
        private int backoffMultiplier = 2;
        private int initialInterval = 2;     // Seconds
    }

    @Data
    public static class Cache {
        private boolean enabled = true;
        private int ttl = 3600;              // Seconds
        private int maxSize = 1000;
    }
}
