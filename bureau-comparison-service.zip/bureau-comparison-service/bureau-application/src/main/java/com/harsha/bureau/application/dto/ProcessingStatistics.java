package com.harsha.bureau.application.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Statistics for processing run.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProcessingStatistics {

    private int totalFiles;
    private int processedFiles;
    private int matchedFiles;
    private int differentFiles;
    private int failedFiles;

    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private long totalDurationMs;

    private double averageProcessingTimeMs;
    private double matchRate;

    /**
     * Calculates statistics from counts.
     */
    public void calculateStatistics() {
        if (totalFiles > 0) {
            this.matchRate = (double) matchedFiles / totalFiles * 100;
        }

        if (processedFiles > 0 && totalDurationMs > 0) {
            this.averageProcessingTimeMs = (double) totalDurationMs / processedFiles;
        }
    }

    /**
     * Gets formatted duration string.
     *
     * @return duration string (e.g., "15m 30s")
     */
    public String getFormattedDuration() {
        long seconds = totalDurationMs / 1000;
        long minutes = seconds / 60;
        long remainingSeconds = seconds % 60;

        if (minutes > 0) {
            return String.format("%dm %ds", minutes, remainingSeconds);
        } else {
            return String.format("%ds", seconds);
        }
    }

    /**
     * Gets summary string.
     *
     * @return summary
     */
    public String getSummary() {
        return String.format(
            "Total: %d | Matched: %d | Different: %d | Failed: %d | Duration: %s | Match Rate: %.1f%%",
            totalFiles, matchedFiles, differentFiles, failedFiles, getFormattedDuration(), matchRate
        );
    }
}
