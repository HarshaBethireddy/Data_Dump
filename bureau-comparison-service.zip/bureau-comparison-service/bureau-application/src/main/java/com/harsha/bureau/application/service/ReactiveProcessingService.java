package com.harsha.bureau.application.service;

import com.harsha.bureau.application.config.PerformanceConfig;
import com.harsha.bureau.application.dto.ProcessingStatistics;
import com.harsha.bureau.core.domain.model.ApplicationData;
import com.harsha.bureau.core.domain.model.ComparisonResult;
import com.harsha.bureau.core.domain.model.ProcessingStatus;
import com.harsha.bureau.core.ports.input.ProcessApplicationsUseCase;
import com.harsha.bureau.core.service.ApplicationProcessingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Reactive processing service using Project Reactor.
 * Handles parallel processing of applications with non-blocking I/O.
 */
@Service
public class ReactiveProcessingService implements ProcessApplicationsUseCase {

    private static final Logger log = LoggerFactory.getLogger(ReactiveProcessingService.class);

    private final ApplicationProcessingService processingService;
    private final PerformanceConfig performanceConfig;

    public ReactiveProcessingService(ApplicationProcessingService processingService,
                                    PerformanceConfig performanceConfig) {
        this.processingService = processingService;
        this.performanceConfig = performanceConfig;
    }

    @Override
    public List<ComparisonResult> processApplications(List<ApplicationData> applications) {
        log.info("Starting reactive processing for {} applications", applications.size());

        LocalDateTime startTime = LocalDateTime.now();
        AtomicInteger processed = new AtomicInteger(0);
        AtomicInteger matched = new AtomicInteger(0);
        AtomicInteger different = new AtomicInteger(0);
        AtomicInteger failed = new AtomicInteger(0);

        int parallelism = performanceConfig.getParallelism().getFileLevel();
        log.info("Using parallelism level: {}", parallelism);

        List<ComparisonResult> results = Flux.fromIterable(applications)
            // Parallel processing with bounded concurrency
            .parallel(parallelism)
            .runOn(Schedulers.boundedElastic())

            // Process each application
            .flatMap(app -> processApplicationReactive(app)
                .doOnNext(result -> {
                    int count = processed.incrementAndGet();

                    if (result.isMatched()) matched.incrementAndGet();
                    else if (result.hasDifferences()) different.incrementAndGet();
                    else if (result.isFailed()) failed.incrementAndGet();

                    if (count % 10 == 0 || count == applications.size()) {
                        log.info("Progress: {}/{} - Matched: {}, Different: {}, Failed: {}",
                            count, applications.size(), matched.get(), different.get(), failed.get());
                    }
                })
                .doOnError(error -> {
                    log.error("Error processing application: {}", error.getMessage());
                    failed.incrementAndGet();
                })
                .onErrorResume(error -> {
                    // Continue processing even if one fails
                    return Mono.just(ComparisonResult.failed(app, error.getMessage()));
                })
            )

            // Collect back to sequential
            .sequential()
            .collectList()
            .block(); // Block to wait for completion

        LocalDateTime endTime = LocalDateTime.now();
        long durationMs = Duration.between(startTime, endTime).toMillis();

        // Log statistics
        ProcessingStatistics stats = ProcessingStatistics.builder()
            .totalFiles(applications.size())
            .processedFiles(processed.get())
            .matchedFiles(matched.get())
            .differentFiles(different.get())
            .failedFiles(failed.get())
            .startTime(startTime)
            .endTime(endTime)
            .totalDurationMs(durationMs)
            .build();

        stats.calculateStatistics();

        log.info("=".repeat(80));
        log.info("PROCESSING COMPLETE: {}", stats.getSummary());
        log.info("=".repeat(80));

        return results;
    }

    @Override
    public ComparisonResult processSingleApplication(ApplicationData application) {
        return processApplicationReactive(application).block();
    }

    /**
     * Processes a single application reactively.
     *
     * @param application the application data
     * @return Mono of comparison result
     */
    private Mono<ComparisonResult> processApplicationReactive(ApplicationData application) {
        return Mono.fromCallable(() -> {
                application.setStatus(ProcessingStatus.IN_PROGRESS);
                return processingService.processSingleApplication(application);
            })
            .timeout(Duration.ofSeconds(performanceConfig.getTimeouts().getExtraction() * 2))
            .retry(performanceConfig.getRetry().getMaxAttempts())
            .subscribeOn(Schedulers.boundedElastic());
    }
}
