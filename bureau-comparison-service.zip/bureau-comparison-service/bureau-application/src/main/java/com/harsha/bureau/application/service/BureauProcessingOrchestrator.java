package com.harsha.bureau.application.service;

import com.harsha.bureau.application.dto.ProcessingStatistics;
import com.harsha.bureau.core.domain.model.ApplicationData;
import com.harsha.bureau.core.domain.model.ComparisonResult;
import com.harsha.bureau.core.ports.input.GenerateReportUseCase;
import com.harsha.bureau.core.ports.input.ProcessApplicationsUseCase;
import com.harsha.bureau.core.ports.output.ApplicationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;

/**
 * Main orchestrator for the entire bureau comparison workflow.
 * Coordinates: AppID extraction → Excel generation → Processing → Reporting
 */
@Service
public class BureauProcessingOrchestrator {

    private static final Logger log = LoggerFactory.getLogger(BureauProcessingOrchestrator.class);

    private final ApplicationRepository applicationRepository;
    private final ProcessApplicationsUseCase processingService;
    private final GenerateReportUseCase reportService;

    @Value("${bureau.comparison.folders.base-pre}")
    private String basePreFolder;

    @Value("${bureau.comparison.folders.base-post}")
    private String basePostFolder;

    @Value("${bureau.comparison.folders.output}")
    private String baseOutputFolder;

    public BureauProcessingOrchestrator(ApplicationRepository applicationRepository,
                                       ProcessApplicationsUseCase processingService,
                                       GenerateReportUseCase reportService) {
        this.applicationRepository = applicationRepository;
        this.processingService = processingService;
        this.reportService = reportService;
    }

    /**
     * Executes the complete workflow interactively.
     */
    public void executeInteractive() {
        Scanner scanner = new Scanner(System.in);

        try {
            log.info("=".repeat(80));
            log.info("Bureau Data Comparison Tool - Enterprise Edition v2.0");
            log.info("=".repeat(80));

            // Step 1: Get folder inputs
            System.out.print("\nEnter PRE folder name (in Downloads): ");
            String preFolderName = scanner.nextLine().trim();
            String preFolderPath = basePreFolder + preFolderName;

            System.out.print("Enter POST folder name (in Downloads): ");
            String postFolderName = scanner.nextLine().trim();
            String postFolderPath = basePostFolder + postFolderName;

            // Step 2: Compare AppIDs and generate Excel
            log.info("\n=== Step 1: Comparing APP IDs ===");
            String outputFolder = baseOutputFolder + File.separator + "comparison_" +
                LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));

            String excelPath = applicationRepository.compareAndGenerateExcel(
                preFolderPath, postFolderPath, outputFolder
            );

            if (excelPath == null) {
                log.error("Failed to generate Excel file. Exiting.");
                return;
            }

            log.info("✅ Excel file generated: {}", excelPath);

            // Step 3: Read applications from Excel
            log.info("\n=== Step 2: Reading Applications from Excel ===");
            List<ApplicationData> applications = applicationRepository.readApplicationsFromExcel(excelPath);

            if (applications.isEmpty()) {
                log.warn("No applications found in Excel. Exiting.");
                return;
            }

            log.info("✅ Found {} applications to process", applications.size());

            // Display category summary
            java.util.Map<String, Long> categoryCount = applications.stream()
                .collect(java.util.stream.Collectors.groupingBy(
                    ApplicationData::getCategory,
                    java.util.stream.Collectors.counting()
                ));

            log.info("Categories breakdown:");
            categoryCount.forEach((category, count) ->
                log.info("  {} : {} applications", category, count));

            // Step 4: Confirm processing
            System.out.print("\nProceed with bureau data extraction? (yes/no): ");
            String confirm = scanner.nextLine().trim().toLowerCase();

            if (!confirm.equals("yes") && !confirm.equals("y")) {
                log.info("Processing cancelled by user.");
                return;
            }

            // Step 5: Process applications (parallel + reactive)
            log.info("\n=== Step 3: Extracting Bureau Data (Parallel Processing) ===");
            LocalDateTime processStartTime = LocalDateTime.now();

            List<ComparisonResult> results = processingService.processApplications(applications);

            LocalDateTime processEndTime = LocalDateTime.now();
            long processingDurationMs = Duration.between(processStartTime, processEndTime).toMillis();

            // Step 6: Generate reports
            log.info("\n=== Step 4: Generating Reports ===");
            reportService.generateReports(results, outputFolder);

            // Step 7: Display final summary
            displayFinalSummary(results, processingDurationMs, outputFolder);

        } catch (Exception e) {
            log.error("Error during processing: {}", e.getMessage(), e);
        } finally {
            scanner.close();
        }
    }

    /**
     * Executes workflow programmatically (for testing/automation).
     *
     * @param preFolder PRE folder path
     * @param postFolder POST folder path
     * @param outputFolder output folder path
     * @return processing statistics
     */
    public ProcessingStatistics executeAutomated(String preFolder, String postFolder, String outputFolder) {
        LocalDateTime startTime = LocalDateTime.now();

        try {
            // Step 1: Compare AppIDs
            String excelPath = applicationRepository.compareAndGenerateExcel(
                preFolder, postFolder, outputFolder
            );

            // Step 2: Read applications
            List<ApplicationData> applications = applicationRepository.readApplicationsFromExcel(excelPath);

            // Step 3: Process applications
            List<ComparisonResult> results = processingService.processApplications(applications);

            // Step 4: Generate reports
            reportService.generateReports(results, outputFolder);

            // Step 5: Calculate statistics
            LocalDateTime endTime = LocalDateTime.now();
            long durationMs = Duration.between(startTime, endTime).toMillis();

            long matched = results.stream().filter(ComparisonResult::isMatched).count();
            long different = results.stream().filter(ComparisonResult::hasDifferences).count();
            long failed = results.stream().filter(ComparisonResult::isFailed).count();

            ProcessingStatistics stats = ProcessingStatistics.builder()
                .totalFiles(applications.size())
                .processedFiles(results.size())
                .matchedFiles((int) matched)
                .differentFiles((int) different)
                .failedFiles((int) failed)
                .startTime(startTime)
                .endTime(endTime)
                .totalDurationMs(durationMs)
                .build();

            stats.calculateStatistics();

            return stats;

        } catch (Exception e) {
            log.error("Automated processing failed: {}", e.getMessage(), e);
            throw new RuntimeException("Processing failed", e);
        }
    }

    /**
     * Displays final summary.
     *
     * @param results the comparison results
     * @param durationMs processing duration in milliseconds
     * @param outputFolder the output folder
     */
    private void displayFinalSummary(List<ComparisonResult> results, long durationMs, String outputFolder) {
        long matched = results.stream().filter(ComparisonResult::isMatched).count();
        long different = results.stream().filter(ComparisonResult::hasDifferences).count();
        long failed = results.stream().filter(ComparisonResult::isFailed).count();

        double matchRate = results.isEmpty() ? 0 : (double) matched / results.size() * 100;

        log.info("\n" + "=".repeat(80));
        log.info("FINAL SUMMARY");
        log.info("=".repeat(80));
        log.info("Total Files          : {}", results.size());
        log.info("Matched              : {} ({:.1f}%)", matched, matchRate);
        log.info("Different            : {}", different);
        log.info("Failed               : {}", failed);
        log.info("Total Duration       : {}", formatDuration(durationMs));
        log.info("Average Time/File    : {:.2f} seconds", (double) durationMs / results.size() / 1000);
        log.info("Output Location      : {}", outputFolder);
        log.info("=".repeat(80));
    }

    /**
     * Formats duration to human-readable string.
     *
     * @param durationMs duration in milliseconds
     * @return formatted string
     */
    private String formatDuration(long durationMs) {
        long seconds = durationMs / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long remainingMinutes = minutes % 60;
        long remainingSeconds = seconds % 60;

        if (hours > 0) {
            return String.format("%dh %dm %ds", hours, remainingMinutes, remainingSeconds);
        } else if (minutes > 0) {
            return String.format("%dm %ds", minutes, remainingSeconds);
        } else {
            return String.format("%ds", seconds);
        }
    }
}
