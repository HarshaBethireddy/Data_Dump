package com.harsha.bureau.core.ports.output;

import com.harsha.bureau.core.domain.model.ExtractionResult;

/**
 * Output port for bureau data extraction.
 * This is a driven port in Hexagonal Architecture.
 * Infrastructure layer will implement this interface.
 */
public interface BureauExtractor {

    /**
     * Extracts bureau data for an application.
     *
     * @param applicationId the application ID
     * @param type the type (PRE/POST)
     * @param category the category
     * @param outputPath the output file path
     * @return extraction result
     */
    ExtractionResult extract(String applicationId, String type, String category, String outputPath);

    /**
     * Checks if extractor is ready.
     *
     * @return true if ready
     */
    boolean isReady();

    /**
     * Performs login (if needed).
     *
     * @return true if login successful
     */
    boolean login();

    /**
     * Navigates to search screen for category.
     *
     * @param category the category
     * @return true if navigation successful
     */
    boolean navigateToSearch(String category);
}
