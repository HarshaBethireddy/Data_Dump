package com.harsha.bureau.core.domain.valueobject;

import com.harsha.bureau.common.util.ValidationUtils;
import lombok.EqualsAndHashCode;
import lombok.Getter;

/**
 * Value object representing an Application ID.
 * Ensures immutability and validation.
 */
@Getter
@EqualsAndHashCode
public class ApplicationId {

    private final String value;

    private ApplicationId(String value) {
        ValidationUtils.requireNonEmpty(value, "ApplicationId");
        ValidationUtils.require(ValidationUtils.isValidAppId(value),
            "ApplicationId must be numeric: " + value);
        this.value = value;
    }

    /**
     * Creates an ApplicationId from string.
     *
     * @param value the application ID value
     * @return ApplicationId instance
     */
    public static ApplicationId of(String value) {
        return new ApplicationId(value);
    }

    @Override
    public String toString() {
        return value;
    }
}
