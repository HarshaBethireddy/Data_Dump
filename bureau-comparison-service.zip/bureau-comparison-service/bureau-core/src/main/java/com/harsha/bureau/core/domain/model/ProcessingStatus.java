package com.harsha.bureau.core.domain.model;

/**
 * Processing status for applications.
 */
public enum ProcessingStatus {
    /**
     * Application is pending processing.
     */
    PENDING,

    /**
     * Application is currently being processed.
     */
    IN_PROGRESS,

    /**
     * Application processing completed successfully.
     */
    COMPLETED,

    /**
     * Application processing failed.
     */
    FAILED,

    /**
     * Application is queued for retry.
     */
    RETRY_PENDING
}
