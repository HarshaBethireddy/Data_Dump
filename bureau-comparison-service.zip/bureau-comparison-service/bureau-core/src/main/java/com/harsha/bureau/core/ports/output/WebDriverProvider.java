package com.harsha.bureau.core.ports.output;

import org.openqa.selenium.WebDriver;

/**
 * Output port for WebDriver provisioning.
 * This is a driven port in Hexagonal Architecture.
 * Infrastructure layer will implement this interface (pooling).
 */
public interface WebDriverProvider {

    /**
     * Acquires a WebDriver instance from pool.
     *
     * @return WebDriver instance
     * @throws Exception if acquisition fails
     */
    WebDriver acquire() throws Exception;

    /**
     * Releases a WebDriver instance back to pool.
     *
     * @param driver the WebDriver instance
     */
    void release(WebDriver driver);

    /**
     * Gets total pool size.
     *
     * @return total pool size
     */
    int getPoolSize();

    /**
     * Gets active (borrowed) instances count.
     *
     * @return active count
     */
    int getActiveCount();

    /**
     * Gets idle (available) instances count.
     *
     * @return idle count
     */
    int getIdleCount();

    /**
     * Shuts down the pool.
     */
    void shutdown();
}
