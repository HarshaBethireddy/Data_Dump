package com.harsha.bureau.core.domain.model;

import lombok.*;

/**
 * Domain model representing a single difference between PRE and POST files.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Difference {

    /**
     * Line number where difference occurs.
     */
    private int lineNumber;

    /**
     * Bureau name (Equifax, TransUnion, Experian).
     */
    private String bureauName;

    /**
     * Type (request, response).
     */
    private String type;

    /**
     * PRE file line content.
     */
    private String preLine;

    /**
     * POST file line content.
     */
    private String postLine;

    /**
     * Gets display string for this difference.
     *
     * @return formatted difference string
     */
    public String toDisplayString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Line ").append(lineNumber);

        if (bureauName != null && !bureauName.isEmpty()) {
            sb.append(" (Bureau: ").append(bureauName);
            if (type != null && !type.isEmpty()) {
                sb.append(", Type: ").append(type);
            }
            sb.append(")");
        }

        sb.append(":\n");
        sb.append("  PRE:  ").append(truncate(preLine, 100)).append("\n");
        sb.append("  POST: ").append(truncate(postLine, 100));

        return sb.toString();
    }

    /**
     * Truncates a string to max length.
     *
     * @param str the string
     * @param maxLength the max length
     * @return truncated string
     */
    private String truncate(String str, int maxLength) {
        if (str == null) return "[MISSING]";
        if (str.length() <= maxLength) return str;
        return str.substring(0, maxLength - 3) + "...";
    }
}
