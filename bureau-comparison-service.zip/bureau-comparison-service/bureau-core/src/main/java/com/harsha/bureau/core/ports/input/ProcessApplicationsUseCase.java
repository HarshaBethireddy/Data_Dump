package com.harsha.bureau.core.ports.input;

import com.harsha.bureau.core.domain.model.ApplicationData;
import com.harsha.bureau.core.domain.model.ComparisonResult;

import java.util.List;

/**
 * Use case port for processing applications.
 * This is a driving port (input) in Hexagonal Architecture.
 */
public interface ProcessApplicationsUseCase {

    /**
     * Processes a list of applications in parallel.
     *
     * @param applications the applications to process
     * @return list of comparison results
     */
    List<ComparisonResult> processApplications(List<ApplicationData> applications);

    /**
     * Processes a single application.
     *
     * @param application the application to process
     * @return comparison result
     */
    ComparisonResult processSingleApplication(ApplicationData application);
}
