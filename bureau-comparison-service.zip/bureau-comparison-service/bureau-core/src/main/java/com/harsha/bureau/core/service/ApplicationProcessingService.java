package com.harsha.bureau.core.service;

import com.harsha.bureau.core.domain.model.ApplicationData;
import com.harsha.bureau.core.domain.model.ComparisonResult;
import com.harsha.bureau.core.domain.model.ExtractionResult;
import com.harsha.bureau.core.ports.input.CompareFilesUseCase;
import com.harsha.bureau.core.ports.input.ExtractBureauDataUseCase;
import com.harsha.bureau.core.ports.input.ProcessApplicationsUseCase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Core orchestration service for processing applications.
 * Coordinates extraction and comparison.
 */
public class ApplicationProcessingService implements ProcessApplicationsUseCase {

    private static final Logger log = LoggerFactory.getLogger(ApplicationProcessingService.class);

    private final ExtractBureauDataUseCase extractionService;
    private final CompareFilesUseCase comparisonService;

    public ApplicationProcessingService(ExtractBureauDataUseCase extractionService,
                                       CompareFilesUseCase comparisonService) {
        this.extractionService = extractionService;
        this.comparisonService = comparisonService;
    }

    @Override
    public List<ComparisonResult> processApplications(List<ApplicationData> applications) {
        // This will be implemented in application layer with parallel processing
        // Core layer defines the contract, application layer implements parallelization
        throw new UnsupportedOperationException(
            "Batch processing is implemented in application layer");
    }

    @Override
    public ComparisonResult processSingleApplication(ApplicationData application) {
        log.info("Processing application: {}", application.getFileName());

        try {
            application.markAsInProgress();

            // Extract PRE data
            ExtractionResult preResult = extractionService.extractBureauData(
                application.getPreAppId(),
                "PRE",
                application.getCategory(),
                application.getPreFilePath()
            );

            if (!preResult.isSuccess()) {
                String error = "PRE extraction failed: " + preResult.getErrorMessage();
                application.markAsFailed(error);
                return ComparisonResult.failed(application, error);
            }

            application.setPreFilePath(preResult.getOutputFilePath());

            // Extract POST data
            ExtractionResult postResult = extractionService.extractBureauData(
                application.getPostAppId(),
                "POST",
                application.getCategory(),
                application.getPostFilePath()
            );

            if (!postResult.isSuccess()) {
                String error = "POST extraction failed: " + postResult.getErrorMessage();
                application.markAsFailed(error);
                return ComparisonResult.failed(application, error);
            }

            application.setPostFilePath(postResult.getOutputFilePath());

            // Compare files
            ComparisonResult result = comparisonService.compareFiles(
                application,
                preResult.getOutputFilePath(),
                postResult.getOutputFilePath()
            );

            if (!result.isFailed()) {
                application.markAsCompleted();
            } else {
                application.markAsFailed(result.getErrorMessage());
            }

            return result;

        } catch (Exception e) {
            log.error("Processing failed for {}: {}", application.getFileName(),
                e.getMessage(), e);
            application.markAsFailed(e.getMessage());
            return ComparisonResult.failed(application, e.getMessage());
        }
    }
}
