package com.harsha.bureau.core.ports.output;

import com.harsha.bureau.core.domain.model.ApplicationData;

import java.util.List;
import java.util.Map;

/**
 * Output port for application data repository.
 * This is a driven port in Hexagonal Architecture.
 * Infrastructure layer will implement this interface.
 */
public interface ApplicationRepository {

    /**
     * Extracts application IDs from folder.
     *
     * @param folderPath the folder path
     * @return map of filename to application ID
     */
    Map<String, String> extractAppIds(String folderPath);

    /**
     * Reads applications from Excel file.
     *
     * @param excelPath the Excel file path
     * @return list of application data
     */
    List<ApplicationData> readApplicationsFromExcel(String excelPath);

    /**
     * Writes applications to Excel file.
     *
     * @param applications the applications
     * @param excelPath the Excel file path
     */
    void writeApplicationsToExcel(List<ApplicationData> applications, String excelPath);

    /**
     * Compares PRE and POST folders and generates Excel.
     *
     * @param preFolder the PRE folder path
     * @param postFolder the POST folder path
     * @param outputFolder the output folder path
     * @return path to generated Excel file
     */
    String compareAndGenerateExcel(String preFolder, String postFolder, String outputFolder);
}
