package com.harsha.bureau.core.domain.model;

import lombok.*;

/**
 * Domain model representing application data to be processed.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationData {

    /**
     * Original file name from Excel.
     */
    private String fileName;

    /**
     * PRE application ID.
     */
    private String preAppId;

    /**
     * POST application ID.
     */
    private String postAppId;

    /**
     * Category (ACQ, CLI, PRQ).
     */
    private String category;

    /**
     * Current processing status.
     */
    private ProcessingStatus status;

    /**
     * Failure reason (if failed).
     */
    private String failureReason;

    /**
     * Failure count (for retry tracking).
     */
    private int failureCount;

    /**
     * PRE file path (after extraction).
     */
    private String preFilePath;

    /**
     * POST file path (after extraction).
     */
    private String postFilePath;

    /**
     * Checks if the application data is valid for processing.
     *
     * @return true if valid
     */
    public boolean isValid() {
        return fileName != null && !fileName.trim().isEmpty() &&
               preAppId != null && !preAppId.trim().isEmpty() &&
               postAppId != null && !postAppId.trim().isEmpty() &&
               category != null && !category.trim().isEmpty();
    }

    /**
     * Marks as failed with reason.
     *
     * @param reason the failure reason
     */
    public void markAsFailed(String reason) {
        this.status = ProcessingStatus.FAILED;
        this.failureReason = reason;
        this.failureCount++;
    }

    /**
     * Marks as completed.
     */
    public void markAsCompleted() {
        this.status = ProcessingStatus.COMPLETED;
    }

    /**
     * Marks as in progress.
     */
    public void markAsInProgress() {
        this.status = ProcessingStatus.IN_PROGRESS;
    }

    /**
     * Checks if should retry based on failure count.
     *
     * @param maxRetries the maximum retries allowed
     * @return true if should retry
     */
    public boolean shouldRetry(int maxRetries) {
        return this.failureCount < maxRetries;
    }
}
