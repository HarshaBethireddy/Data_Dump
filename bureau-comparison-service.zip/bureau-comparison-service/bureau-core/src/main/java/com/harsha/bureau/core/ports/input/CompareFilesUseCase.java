package com.harsha.bureau.core.ports.input;

import com.harsha.bureau.core.domain.model.ApplicationData;
import com.harsha.bureau.core.domain.model.ComparisonResult;

/**
 * Use case port for comparing files.
 * This is a driving port (input) in Hexagonal Architecture.
 */
public interface CompareFilesUseCase {

    /**
     * Compares PRE and POST files for an application.
     *
     * @param applicationData the application data
     * @param preFilePath the PRE file path
     * @param postFilePath the POST file path
     * @return comparison result
     */
    ComparisonResult compareFiles(ApplicationData applicationData,
                                 String preFilePath, String postFilePath);
}
