package com.harsha.bureau.core.domain.model;

import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Domain model representing file comparison result.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ComparisonResult {

    /**
     * Application data reference.
     */
    private ApplicationData applicationData;

    /**
     * Comparison status (MATCHED, DIFFERENT, FAILED).
     */
    private String status;

    /**
     * List of differences found.
     */
    @Builder.Default
    private List<Difference> differences = new ArrayList<>();

    /**
     * Total difference count.
     */
    private int totalDifferences;

    /**
     * PRE file line count.
     */
    private int preLineCount;

    /**
     * POST file line count.
     */
    private int postLineCount;

    /**
     * Comparison timestamp.
     */
    private LocalDateTime comparedAt;

    /**
     * Processing duration in milliseconds.
     */
    private long durationMs;

    /**
     * Error message (if failed).
     */
    private String errorMessage;

    /**
     * Checks if files matched.
     *
     * @return true if matched
     */
    public boolean isMatched() {
        return "MATCHED".equals(status);
    }

    /**
     * Checks if differences found.
     *
     * @return true if different
     */
    public boolean hasDifferences() {
        return "DIFFERENT".equals(status);
    }

    /**
     * Checks if comparison failed.
     *
     * @return true if failed
     */
    public boolean isFailed() {
        return "FAILED".equals(status);
    }

    /**
     * Creates a matched comparison result.
     *
     * @param applicationData the application data
     * @param preLineCount PRE line count
     * @param postLineCount POST line count
     * @param durationMs duration
     * @return comparison result
     */
    public static ComparisonResult matched(ApplicationData applicationData,
                                          int preLineCount, int postLineCount, long durationMs) {
        return ComparisonResult.builder()
            .applicationData(applicationData)
            .status("MATCHED")
            .differences(new ArrayList<>())
            .totalDifferences(0)
            .preLineCount(preLineCount)
            .postLineCount(postLineCount)
            .comparedAt(LocalDateTime.now())
            .durationMs(durationMs)
            .build();
    }

    /**
     * Creates a different comparison result.
     *
     * @param applicationData the application data
     * @param differences the differences
     * @param preLineCount PRE line count
     * @param postLineCount POST line count
     * @param durationMs duration
     * @return comparison result
     */
    public static ComparisonResult different(ApplicationData applicationData,
                                            List<Difference> differences,
                                            int preLineCount, int postLineCount, long durationMs) {
        return ComparisonResult.builder()
            .applicationData(applicationData)
            .status("DIFFERENT")
            .differences(differences)
            .totalDifferences(differences.size())
            .preLineCount(preLineCount)
            .postLineCount(postLineCount)
            .comparedAt(LocalDateTime.now())
            .durationMs(durationMs)
            .build();
    }

    /**
     * Creates a failed comparison result.
     *
     * @param applicationData the application data
     * @param errorMessage the error message
     * @return comparison result
     */
    public static ComparisonResult failed(ApplicationData applicationData, String errorMessage) {
        return ComparisonResult.builder()
            .applicationData(applicationData)
            .status("FAILED")
            .errorMessage(errorMessage)
            .comparedAt(LocalDateTime.now())
            .build();
    }
}
