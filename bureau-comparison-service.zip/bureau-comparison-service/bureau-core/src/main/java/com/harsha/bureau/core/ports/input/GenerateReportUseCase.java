package com.harsha.bureau.core.ports.input;

import com.harsha.bureau.core.domain.model.ComparisonResult;

import java.util.List;

/**
 * Use case port for generating reports.
 * This is a driving port (input) in Hexagonal Architecture.
 */
public interface GenerateReportUseCase {

    /**
     * Generates HTML and Text reports from comparison results.
     *
     * @param results the comparison results
     * @param outputDirectory the output directory
     */
    void generateReports(List<ComparisonResult> results, String outputDirectory);

    /**
     * Generates HTML report only.
     *
     * @param results the comparison results
     * @param outputDirectory the output directory
     * @return path to generated HTML report
     */
    String generateHtmlReport(List<ComparisonResult> results, String outputDirectory);

    /**
     * Generates text report only.
     *
     * @param results the comparison results
     * @param outputDirectory the output directory
     * @return path to generated text report
     */
    String generateTextReport(List<ComparisonResult> results, String outputDirectory);
}
