package com.harsha.bureau.core.domain.model;

import lombok.*;

import java.time.LocalDateTime;

/**
 * Domain model representing bureau data extraction result.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExtractionResult {

    /**
     * Application ID.
     */
    private String applicationId;

    /**
     * Type (PRE or POST).
     */
    private String type;

    /**
     * Output file path.
     */
    private String outputFilePath;

    /**
     * Extraction success status.
     */
    private boolean success;

    /**
     * Error message (if failed).
     */
    private String errorMessage;

    /**
     * Extraction timestamp.
     */
    private LocalDateTime extractedAt;

    /**
     * Processing duration in milliseconds.
     */
    private long durationMs;

    /**
     * Bureau data content (optional, for caching).
     */
    private String content;

    /**
     * Creates a successful extraction result.
     *
     * @param applicationId the application ID
     * @param type the type (PRE/POST)
     * @param outputFilePath the output file path
     * @param durationMs the duration
     * @return extraction result
     */
    public static ExtractionResult success(String applicationId, String type,
                                          String outputFilePath, long durationMs) {
        return ExtractionResult.builder()
            .applicationId(applicationId)
            .type(type)
            .outputFilePath(outputFilePath)
            .success(true)
            .extractedAt(LocalDateTime.now())
            .durationMs(durationMs)
            .build();
    }

    /**
     * Creates a failed extraction result.
     *
     * @param applicationId the application ID
     * @param type the type (PRE/POST)
     * @param errorMessage the error message
     * @return extraction result
     */
    public static ExtractionResult failure(String applicationId, String type, String errorMessage) {
        return ExtractionResult.builder()
            .applicationId(applicationId)
            .type(type)
            .success(false)
            .errorMessage(errorMessage)
            .extractedAt(LocalDateTime.now())
            .build();
    }
}
