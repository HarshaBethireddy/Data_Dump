package com.harsha.bureau.core.service;

import com.harsha.bureau.common.constant.BureauConstants;
import com.harsha.bureau.core.domain.model.*;
import com.harsha.bureau.core.ports.input.CompareFilesUseCase;
import com.harsha.bureau.core.ports.output.FileRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Core business logic for file comparison.
 * Implements the CompareFilesUseCase port.
 */
public class FileComparisonService implements CompareFilesUseCase {

    private static final Logger log = LoggerFactory.getLogger(FileComparisonService.class);

    private final FileRepository fileRepository;

    public FileComparisonService(FileRepository fileRepository) {
        this.fileRepository = fileRepository;
    }

    @Override
    public ComparisonResult compareFiles(ApplicationData applicationData,
                                        String preFilePath, String postFilePath) {
        long startTime = System.currentTimeMillis();

        try {
            log.info("Comparing files for {}: PRE={}, POST={}",
                applicationData.getFileName(), preFilePath, postFilePath);

            // Read files
            List<String> preLines = fileRepository.readLines(preFilePath);
            List<String> postLines = fileRepository.readLines(postFilePath);

            // Parse bureau sections
            List<BureauSection> preSections = parseBureauSections(preLines);
            List<BureauSection> postSections = parseBureauSections(postLines);

            // Normalize content (remove metadata, trim)
            List<String> preNormalized = normalizeContent(preLines);
            List<String> postNormalized = normalizeContent(postLines);

            // Quick hash check first (optimization)
            if (preNormalized.equals(postNormalized)) {
                long duration = System.currentTimeMillis() - startTime;
                log.info("Files matched for {}: {}", applicationData.getFileName(), duration);
                return ComparisonResult.matched(applicationData, preLines.size(),
                    postLines.size(), duration);
            }

            // Find detailed differences
            List<Difference> differences = findDifferences(preLines, postLines,
                preSections, postSections);

            long duration = System.currentTimeMillis() - startTime;

            if (differences.isEmpty()) {
                log.info("Files matched (after normalization) for {}", applicationData.getFileName());
                return ComparisonResult.matched(applicationData, preLines.size(),
                    postLines.size(), duration);
            } else {
                log.info("Found {} differences for {}", differences.size(),
                    applicationData.getFileName());
                return ComparisonResult.different(applicationData, differences,
                    preLines.size(), postLines.size(), duration);
            }

        } catch (Exception e) {
            log.error("Comparison failed for {}: {}", applicationData.getFileName(),
                e.getMessage(), e);
            return ComparisonResult.failed(applicationData, e.getMessage());
        }
    }

    private List<BureauSection> parseBureauSections(List<String> lines) {
        List<BureauSection> sections = new ArrayList<>();
        String currentBureau = "Unknown";
        String currentType = "Unknown";
        int sectionStart = -1;

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);

            if (line.startsWith(BureauConstants.SECTION_SEPARATOR)) {
                // End previous section
                if (sectionStart >= 0) {
                    sections.add(BureauSection.builder()
                        .bureauName(currentBureau)
                        .type(currentType)
                        .startLine(sectionStart)
                        .endLine(i - 1)
                        .build());
                }

                // Start new section
                if (i + 1 < lines.size() &&
                    lines.get(i + 1).startsWith(BureauConstants.SECTION_BUREAU_PREFIX)) {
                    currentBureau = lines.get(i + 1)
                        .substring(BureauConstants.SECTION_BUREAU_PREFIX.length()).trim();

                    if (i + 2 < lines.size() &&
                        lines.get(i + 2).startsWith(BureauConstants.SECTION_TYPE_PREFIX)) {
                        currentType = lines.get(i + 2)
                            .substring(BureauConstants.SECTION_TYPE_PREFIX.length()).trim();
                    }
                    sectionStart = i;
                }
            }
        }

        // Add last section
        if (sectionStart >= 0) {
            sections.add(BureauSection.builder()
                .bureauName(currentBureau)
                .type(currentType)
                .startLine(sectionStart)
                .endLine(lines.size() - 1)
                .build());
        }

        return sections;
    }

    private List<String> normalizeContent(List<String> lines) {
        return lines.stream()
            .filter(line -> !line.trim().isEmpty())
            .filter(line -> !line.contains(BureauConstants.METADATA_EXTRACTION_TIME))
            .filter(line -> !line.contains(BureauConstants.METADATA_APPLICATION_ID))
            .filter(line -> !line.startsWith(BureauConstants.METADATA_TYPE))
            .map(String::trim)
            .collect(Collectors.toList());
    }

    private List<Difference> findDifferences(List<String> preLines, List<String> postLines,
                                            List<BureauSection> preSections,
                                            List<BureauSection> postSections) {
        List<Difference> differences = new ArrayList<>();
        int maxLines = Math.max(preLines.size(), postLines.size());

        for (int i = 0; i < maxLines; i++) {
            String preLine = i < preLines.size() ? preLines.get(i).trim() : "[MISSING]";
            String postLine = i < postLines.size() ? postLines.get(i).trim() : "[MISSING]";

            // Skip empty lines and metadata
            if (preLine.isEmpty() && postLine.isEmpty()) continue;
            if (isMetadataLine(preLine) || isMetadataLine(postLine)) continue;

            if (!preLine.equals(postLine)) {
                // Find bureau context
                BureauSection section = findSectionForLine(i, preSections);
                if (section == null) {
                    section = findSectionForLine(i, postSections);
                }

                Difference diff = Difference.builder()
                    .lineNumber(i + 1)
                    .bureauName(section != null ? section.getBureauName() : "Unknown")
                    .type(section != null ? section.getType() : "Unknown")
                    .preLine(preLine)
                    .postLine(postLine)
                    .build();

                differences.add(diff);

                // Limit to avoid huge diffs
                if (differences.size() >= BureauConstants.DEFAULT_COMPARISON_DISPLAY_LIMIT * 10) {
                    break;
                }
            }
        }

        return differences;
    }

    private boolean isMetadataLine(String line) {
        return line.contains(BureauConstants.METADATA_EXTRACTION_TIME) ||
               line.contains(BureauConstants.METADATA_APPLICATION_ID) ||
               line.startsWith(BureauConstants.METADATA_TYPE);
    }

    private BureauSection findSectionForLine(int lineNum, List<BureauSection> sections) {
        for (BureauSection section : sections) {
            if (section.containsLine(lineNum)) {
                return section;
            }
        }
        return null;
    }
}
