package com.harsha.bureau.core.ports.output;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

/**
 * Output port for file operations.
 * This is a driven port in Hexagonal Architecture.
 * Infrastructure layer will implement this interface.
 */
public interface FileRepository {

    /**
     * Reads file content.
     *
     * @param filePath the file path
     * @return file content
     * @throws IOException if read fails
     */
    String readFile(String filePath) throws IOException;

    /**
     * Reads file lines.
     *
     * @param filePath the file path
     * @return list of lines
     * @throws IOException if read fails
     */
    List<String> readLines(String filePath) throws IOException;

    /**
     * Writes content to file.
     *
     * @param filePath the file path
     * @param content the content
     * @throws IOException if write fails
     */
    void writeFile(String filePath, String content) throws IOException;

    /**
     * Writes lines to file.
     *
     * @param filePath the file path
     * @param lines the lines
     * @throws IOException if write fails
     */
    void writeLines(String filePath, List<String> lines) throws IOException;

    /**
     * Checks if file exists.
     *
     * @param filePath the file path
     * @return true if exists
     */
    boolean fileExists(String filePath);

    /**
     * Creates directory.
     *
     * @param directoryPath the directory path
     * @return the created path
     * @throws IOException if creation fails
     */
    Path createDirectory(String directoryPath) throws IOException;

    /**
     * Lists files in directory with extensions.
     *
     * @param directoryPath the directory path
     * @param extensions the file extensions
     * @return list of file paths
     */
    List<String> listFiles(String directoryPath, String... extensions);

    /**
     * Calculates file hash.
     *
     * @param filePath the file path
     * @return the hash
     * @throws IOException if calculation fails
     */
    String calculateFileHash(String filePath) throws IOException;
}
