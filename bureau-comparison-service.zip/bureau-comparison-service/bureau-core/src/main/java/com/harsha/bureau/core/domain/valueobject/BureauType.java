package com.harsha.bureau.core.domain.valueobject;

/**
 * Value object representing bureau type.
 */
public enum BureauType {
    EQUIFAX("Equifax"),
    TRANSUNION("TransUnion"),
    EXPERIAN("Experian");

    private final String displayName;

    BureauType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    /**
     * Gets BureauType from display name.
     *
     * @param displayName the display name
     * @return BureauType or null
     */
    public static BureauType fromDisplayName(String displayName) {
        for (BureauType type : values()) {
            if (type.displayName.equalsIgnoreCase(displayName)) {
                return type;
            }
        }
        return null;
    }
}
