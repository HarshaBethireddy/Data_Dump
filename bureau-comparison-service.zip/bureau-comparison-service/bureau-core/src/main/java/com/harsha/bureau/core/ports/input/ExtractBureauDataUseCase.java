package com.harsha.bureau.core.ports.input;

import com.harsha.bureau.core.domain.model.ExtractionResult;

/**
 * Use case port for extracting bureau data.
 * This is a driving port (input) in Hexagonal Architecture.
 */
public interface ExtractBureauDataUseCase {

    /**
     * Extracts bureau data for an application ID.
     *
     * @param applicationId the application ID
     * @param type the type (PRE or POST)
     * @param category the category
     * @param outputPath the output file path
     * @return extraction result
     */
    ExtractionResult extractBureauData(String applicationId, String type,
                                      String category, String outputPath);
}
