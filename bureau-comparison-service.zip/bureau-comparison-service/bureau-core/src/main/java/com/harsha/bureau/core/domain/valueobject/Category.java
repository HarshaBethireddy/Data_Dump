package com.harsha.bureau.core.domain.valueobject;

import com.harsha.bureau.common.constant.CategoryConstants;

import java.util.List;

/**
 * Value object representing application category.
 */
public enum Category {
    ACQ("ACQ", CategoryConstants.ACQ_MENU_PATH),
    CLI("CLI", CategoryConstants.CLI_MENU_PATH),
    PRQ("PRQ", CategoryConstants.PRQ_MENU_PATH),
    UNKNOWN("UNKNOWN", List.of());

    private final String code;
    private final List<String> menuPath;

    Category(String code, List<String> menuPath) {
        this.code = code;
        this.menuPath = menuPath;
    }

    public String getCode() {
        return code;
    }

    public List<String> getMenuPath() {
        return menuPath;
    }

    /**
     * Gets Category from code.
     *
     * @param code the category code
     * @return Category
     */
    public static Category fromCode(String code) {
        if (code == null) {
            return UNKNOWN;
        }

        for (Category category : values()) {
            if (category.code.equalsIgnoreCase(code)) {
                return category;
            }
        }

        // Handle variations
        if (code.toUpperCase().contains("PREQUAL")) {
            return PRQ;
        }

        return UNKNOWN;
    }

    /**
     * Determines category from filename.
     *
     * @param fileName the file name
     * @return Category
     */
    public static Category fromFileName(String fileName) {
        String categoryCode = CategoryConstants.determineCategoryFromFileName(fileName);
        return fromCode(categoryCode);
    }
}
