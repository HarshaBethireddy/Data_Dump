package com.harsha.bureau.core.domain.model;

import lombok.*;

/**
 * Domain model representing a bureau section in extracted data.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BureauSection {

    /**
     * Bureau name (Equifax, TransUnion, Experian).
     */
    private String bureauName;

    /**
     * Type (request, response).
     */
    private String type;

    /**
     * Start line number in the file.
     */
    private int startLine;

    /**
     * End line number in the file.
     */
    private int endLine;

    /**
     * Checks if a line number is within this section.
     *
     * @param lineNumber the line number
     * @return true if within section
     */
    public boolean containsLine(int lineNumber) {
        return lineNumber >= startLine && lineNumber <= endLine;
    }

    /**
     * Gets the section size (number of lines).
     *
     * @return the section size
     */
    public int getSectionSize() {
        return endLine - startLine + 1;
    }
}
