package com.harsha.bureau.core.ports.output;

import com.harsha.bureau.core.domain.model.ComparisonResult;

import java.util.List;

/**
 * Output port for report generation.
 * This is a driven port in Hexagonal Architecture.
 * Infrastructure layer will implement this interface.
 */
public interface ReportGenerator {

    /**
     * Generates HTML report.
     *
     * @param results the comparison results
     * @param outputPath the output file path
     * @return path to generated report
     */
    String generateHtmlReport(List<ComparisonResult> results, String outputPath);

    /**
     * Generates text report.
     *
     * @param results the comparison results
     * @param outputPath the output file path
     * @return path to generated report
     */
    String generateTextReport(List<ComparisonResult> results, String outputPath);

    /**
     * Generates both HTML and text reports.
     *
     * @param results the comparison results
     * @param outputDirectory the output directory
     */
    void generateBothReports(List<ComparisonResult> results, String outputDirectory);
}
