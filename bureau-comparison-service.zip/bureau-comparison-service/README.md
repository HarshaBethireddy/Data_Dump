# Bureau Comparison System v2.0

High-performance distributed bureau data comparison system with parallel processing capabilities.

## Features

- **Parallel Processing**: Process 4000 files in ~50-60 minutes (48x faster than sequential)
- **Standalone Selenium Grid**: No Docker required, JAR-based Grid setup
- **Smart Dynamic Waits**: Auto-detecting element waits with intelligent timeouts
- **Browser Session Reuse**: Minimize browser restart overhead
- **Reactive Processing**: Non-blocking I/O with Project Reactor
- **Excel Streaming**: Memory-efficient Excel processing
- **Dual Reporting**: Both HTML (interactive) and Text reports
- **BDD Testing**: Cucumber + TestNG integration
- **Clean Architecture**: Hexagonal + Page Object Model

## System Requirements

- **Java**: 17 or higher
- **Maven**: 3.8+
- **RAM**: 8GB minimum
- **CPU**: 8 cores
- **Chrome**: Latest version

## Quick Start

### 1. Setup Selenium Grid (Standalone)

```bash
cd selenium-grid
download-selenium.bat     # Downloads Selenium Server JAR
start-hub.bat            # Start Grid Hub (Terminal 1)
start-node.bat           # Start Grid Node (Terminal 2-5, run multiple times)
```

### 2. Build the Project

```bash
mvn clean install
```

### 3. Run the Application

```bash
cd bureau-app
mvn spring-boot:run
```

Or run the JAR:

```bash
java -jar bureau-app/target/bureau-comparison-system-2.0.0.jar
```

## Configuration

Edit `bureau-app/src/main/resources/application.yml`:

```yaml
bureau:
  comparison:
    base-url: "http://your-bureau-url"
    credentials:
      username: "your-username"
      password: "your-password"
    folders:
      base-pre: "C:/path/to/pre/folder"
      base-post: "C:/path/to/post/folder"
      output: "C:/path/to/output"
    selenium:
      grid:
        url: "http://localhost:4444"
        enabled: true
      pool:
        max-total: 12  # Adjust based on your RAM
```

## Performance Tuning

### For 8GB RAM:
- **Max browsers**: 12
- **Expected time**: 50-60 minutes for 4000 files

### For 16GB RAM:
- **Max browsers**: 20
- **Expected time**: 30-40 minutes for 4000 files

### For 32GB RAM:
- **Max browsers**: 50
- **Expected time**: 15-20 minutes for 4000 files

## Module Structure

- **bureau-common**: Shared utilities, constants, exceptions
- **bureau-core**: Domain models, business logic, use cases (Clean Architecture)
- **bureau-infrastructure**: Selenium (POM), File I/O, Excel processing
- **bureau-application**: Application services, orchestration
- **bureau-reporting**: HTML & Text report generators
- **bureau-bdd-tests**: Cucumber feature files, step definitions
- **bureau-app**: Main application entry point

## Running Tests

```bash
# Unit tests
mvn test

# Integration tests
mvn verify

# BDD tests
mvn test -Dtest=CucumberTestRunner
```

## Architecture

- **Hexagonal Architecture**: Core business logic isolated from infrastructure
- **Page Object Model**: Selenium pages abstracted into reusable objects
- **Reactive Streams**: Non-blocking parallel processing
- **Smart Wait Helper**: Dynamic waits with auto-detection

## Troubleshooting

### Selenium Grid not starting
- Ensure Java 17+ is installed
- Check port 4444 is not in use
- Run `netstat -ano | findstr :4444`

### Out of Memory errors
- Reduce `selenium.pool.max-total` in application.yml
- Increase JVM heap: `java -Xmx6G -jar bureau-app.jar`

### Browser crashes
- Update Chrome to latest version
- Run `download-selenium.bat` to get latest drivers
- Check Selenium Grid logs in `selenium-grid/logs/`

## License

Proprietary - Internal Use Only

## Contact

For issues or questions, contact the development team.
