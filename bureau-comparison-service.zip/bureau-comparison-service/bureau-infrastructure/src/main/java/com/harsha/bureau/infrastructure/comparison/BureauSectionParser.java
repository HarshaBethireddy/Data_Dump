package com.harsha.bureau.infrastructure.comparison;

import com.harsha.bureau.common.constant.BureauConstants;
import com.harsha.bureau.core.domain.model.BureauSection;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Parses bureau sections from extracted file content.
 */
@Component
public class BureauSectionParser {

    /**
     * Parses bureau sections from file lines.
     *
     * @param lines the file lines
     * @return list of bureau sections
     */
    public List<BureauSection> parseSections(List<String> lines) {
        List<BureauSection> sections = new ArrayList<>();

        String currentBureau = "Unknown";
        String currentType = "Unknown";
        int sectionStart = -1;

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);

            if (line.startsWith(BureauConstants.SECTION_SEPARATOR)) {
                // End previous section
                if (sectionStart >= 0) {
                    sections.add(BureauSection.builder()
                        .bureauName(currentBureau)
                        .type(currentType)
                        .startLine(sectionStart)
                        .endLine(i - 1)
                        .build());
                }

                // Start new section
                if (i + 1 < lines.size() &&
                    lines.get(i + 1).startsWith(BureauConstants.SECTION_BUREAU_PREFIX)) {

                    currentBureau = lines.get(i + 1)
                        .substring(BureauConstants.SECTION_BUREAU_PREFIX.length()).trim();

                    if (i + 2 < lines.size() &&
                        lines.get(i + 2).startsWith(BureauConstants.SECTION_TYPE_PREFIX)) {
                        currentType = lines.get(i + 2)
                            .substring(BureauConstants.SECTION_TYPE_PREFIX.length()).trim();
                    }

                    sectionStart = i;
                }
            }
        }

        // Add last section
        if (sectionStart >= 0) {
            sections.add(BureauSection.builder()
                .bureauName(currentBureau)
                .type(currentType)
                .startLine(sectionStart)
                .endLine(lines.size() - 1)
                .build());
        }

        return sections;
    }

    /**
     * Finds the bureau section for a given line number.
     *
     * @param lineNumber the line number
     * @param sections the list of sections
     * @return the bureau section or null
     */
    public BureauSection findSectionForLine(int lineNumber, List<BureauSection> sections) {
        for (BureauSection section : sections) {
            if (section.containsLine(lineNumber)) {
                return section;
            }
        }
        return null;
    }
}
