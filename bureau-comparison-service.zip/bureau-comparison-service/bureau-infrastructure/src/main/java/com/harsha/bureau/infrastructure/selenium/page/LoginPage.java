package com.harsha.bureau.infrastructure.selenium.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Page Object Model for Login Page.
 */
public class LoginPage extends BasePage {

    // Locators
    private final By usernameInput = By.id("idToken1");
    private final By passwordInput = By.id("idToken2");
    private final By loginButton = By.id("loginButton_0");

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Performs login.
     *
     * @param username the username
     * @param password the password
     * @return GroupSelectionPage
     */
    public GroupSelectionPage login(String username, String password) {
        log.info("Performing login for user: {}", username);

        wait.smartSendKeys(usernameInput, username, true);
        wait.smartSendKeys(passwordInput, password, true);
        wait.smartClick(loginButton);

        wait.pauseLong(); // Wait for login to process

        log.info("Login successful");
        return new GroupSelectionPage(driver);
    }

    /**
     * Checks if on login page.
     *
     * @return true if on login page
     */
    public boolean isOnLoginPage() {
        return wait.isElementVisible(loginButton);
    }
}
