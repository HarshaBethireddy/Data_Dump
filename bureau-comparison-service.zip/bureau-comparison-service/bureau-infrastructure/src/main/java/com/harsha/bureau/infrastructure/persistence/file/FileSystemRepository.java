package com.harsha.bureau.infrastructure.persistence.file;

import com.harsha.bureau.common.util.FileUtils;
import com.harsha.bureau.core.ports.output.FileRepository;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

/**
 * File system implementation of FileRepository port.
 */
@Component
public class FileSystemRepository implements FileRepository {

    @Override
    public String readFile(String filePath) throws IOException {
        File file = new File(filePath);
        return FileUtils.readFileWithEncoding(file);
    }

    @Override
    public List<String> readLines(String filePath) throws IOException {
        return Files.readAllLines(Paths.get(filePath));
    }

    @Override
    public void writeFile(String filePath, String content) throws IOException {
        Files.writeString(Paths.get(filePath), content);
    }

    @Override
    public void writeLines(String filePath, List<String> lines) throws IOException {
        Files.write(Paths.get(filePath), lines);
    }

    @Override
    public boolean fileExists(String filePath) {
        return Files.exists(Paths.get(filePath));
    }

    @Override
    public Path createDirectory(String directoryPath) throws IOException {
        return FileUtils.ensureDirectoryExists(directoryPath);
    }

    @Override
    public List<String> listFiles(String directoryPath, String... extensions) {
        return FileUtils.listFilesWithExtensions(directoryPath, extensions)
            .stream()
            .map(File::getAbsolutePath)
            .collect(Collectors.toList());
    }

    @Override
    public String calculateFileHash(String filePath) throws IOException {
        return FileUtils.calculateFileHash(Paths.get(filePath));
    }
}
