package com.harsha.bureau.infrastructure.selenium.page;

import com.harsha.bureau.common.constant.CategoryConstants;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

/**
 * Page Object Model for Group Selection Page.
 */
public class GroupSelectionPage extends BasePage {

    // Locators
    private final By groupsDropdown = By.id("groups");
    private final By submitButton = By.id("id2");
    private final By menuWrapper = By.id("menu-wrapper");

    public GroupSelectionPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Selects administrator group and submits.
     *
     * @return SearchPage
     */
    public SearchPage selectAdministratorGroup() {
        log.info("Selecting administrator group");

        Select groupsSelect = new Select(wait.waitForVisible(groupsDropdown));
        groupsSelect.selectByVisibleText(CategoryConstants.ADMIN_GROUP);

        wait.smartClick(submitButton);
        wait.pauseLong();

        // Wait for menu to appear
        wait.waitForVisible(menuWrapper);

        log.info("Administrator group selected successfully");
        return new SearchPage(driver);
    }

    /**
     * Checks if on group selection page.
     *
     * @return true if on page
     */
    public boolean isOnGroupSelectionPage() {
        return wait.isElementVisible(groupsDropdown);
    }
}
