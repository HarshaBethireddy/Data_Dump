package com.harsha.bureau.infrastructure.selenium.page;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.List;

/**
 * Page Object Model for Search Page.
 */
public class SearchPage extends BasePage {

    private static final Logger log = LoggerFactory.getLogger(SearchPage.class);

    // Locators
    private final By applicationIdField = By.id("txt-appid");
    private final By searchButton = By.id("btn-search");
    private final By resultGrid = By.id("datagrid");
    private final By openApplicationLink = By.xpath("//table[@id='datagrid']//td//div//center//a");
    private final By menu = By.cssSelector("ul#menu");

    public SearchPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Navigates to search screen by clicking through menu path.
     *
     * @param menuPath the menu path (e.g., ["View Only", "Credit Full", "All"])
     * @return this page
     */
    public SearchPage navigateToSearch(List<String> menuPath) {
        log.info("Navigating to search via menu: {}", menuPath);

        navigateMenu(menuPath);
        wait.pauseLong();

        // Wait for application ID field to be visible
        wait.waitForVisible(applicationIdField);

        log.info("Navigation to search successful");
        return this;
    }

    /**
     * Searches for an application by ID.
     *
     * @param applicationId the application ID
     * @return ApplicationDetailsPage
     */
    public ApplicationDetailsPage searchApplication(String applicationId) {
        log.info("Searching for application: {}", applicationId);

        // Wait for field to be ready
        wait.waitForVisible(applicationIdField);
        wait.pauseMedium();

        // Clear and enter application ID (character by character)
        WebElement appIdField = wait.waitForClickable(applicationIdField);
        wait.scrollIntoView(appIdField);
        appIdField.click();

        // Clear existing value
        appIdField.sendKeys(Keys.CONTROL + "a");
        appIdField.sendKeys(Keys.DELETE);
        wait.pauseShort();

        // Type application ID
        wait.smartSendKeys(applicationIdField, applicationId, false);

        // Verify value was entered
        wait.waitForAttributeValue(applicationIdField, "value", applicationId);
        wait.pauseMedium();

        // Click search
        wait.smartClick(searchButton);
        log.info("Search button clicked");

        wait.pauseLong();

        // Wait for results
        wait.waitForVisible(resultGrid);

        return new ApplicationDetailsPage(driver);
    }

    /**
     * Opens the application from search results.
     *
     * @return ApplicationDetailsPage
     */
    public ApplicationDetailsPage openApplication() {
        log.info("Opening application from search results");

        wait.smartClick(openApplicationLink);
        wait.pauseLong();

        return new ApplicationDetailsPage(driver);
    }

    /**
     * Navigates through menu hierarchy.
     *
     * @param labels the menu labels
     */
    private void navigateMenu(List<String> labels) {
        if (labels == null || labels.isEmpty()) {
            throw new IllegalArgumentException("Menu path cannot be empty");
        }

        Actions actions = new Actions(driver);
        JavascriptExecutor js = (JavascriptExecutor) driver;

        WebElement scope = wait.waitForPresence(menu);

        for (int i = 0; i < labels.size(); i++) {
            String label = labels.get(i).trim().replaceAll("\\s+", " ");

            // Find anchor with matching text
            String anchorsXpath = scope.getTagName().equalsIgnoreCase("ul") ? "./li/a" : "./ul/li/a";
            List<WebElement> anchors = scope.findElements(By.xpath(anchorsXpath));

            WebElement link = anchors.stream().filter(a -> {
                String direct = (String) js.executeScript(
                    "const a=arguments[0]; return [...a.childNodes].filter(n=>n.nodeType===3)" +
                        ".map(n=>n.textContent).join('').replace(/\\s+/g,' ').trim();", a);
                return label.equals(direct);
            }).findFirstOrThrow(() -> new NoSuchElementException("Menu item not found: " + label));

            wait.scrollIntoView(link);
            wait.waitForVisible(By.xpath("//*[text()='" + label + "']"));

            boolean isLeaf = (i == labels.size() - 1);

            if (isLeaf) {
                // Final menu item - click it
                try {
                    wait.smartClick(By.xpath("//a[contains(.,'" + label + "')]"));
                } catch (Exception e) {
                    js.executeScript("arguments[0].click();", link);
                }
                return;
            } else {
                // Intermediate menu - hover to open submenu
                WebElement li = link.findElement(By.xpath("./ancestor::li[1]"));
                boolean opened = false;

                try {
                    actions.moveToElement(link).pause(Duration.ofMillis(150)).perform();
                    opened = waitForSubmenuVisible(li, Duration.ofSeconds(2));
                } catch (Exception ignored) {
                }

                if (!opened) {
                    // Fallback: click to open
                    try {
                        link.click();
                    } catch (Exception e) {
                        js.executeScript("arguments[0].click();", link);
                    }
                    opened = waitForSubmenuVisible(li, Duration.ofSeconds(4));
                }

                if (!opened) {
                    throw new TimeoutException("Submenu did not open for: " + label);
                }

                scope = li;
            }
        }
    }

    /**
     * Waits for submenu to become visible.
     *
     * @param li the list item element
     * @param timeout the timeout
     * @return true if visible
     */
    private boolean waitForSubmenuVisible(WebElement li, Duration timeout) {
        try {
            return wait.waitFor(d -> {
                try {
                    WebElement ul = li.findElement(By.xpath("./ul"));
                    Object visible = ((JavascriptExecutor) driver).executeScript(
                        "const u=arguments[0]; if(!u) return false;" +
                            "const s=getComputedStyle(u);" +
                            "if(s.display==='none' || s.visibility==='hidden' || +s.opacity===0) return false;" +
                            "const r=u.getBoundingClientRect(); return r.width>0 && r.height>0;", ul);
                    return Boolean.TRUE.equals(visible);
                } catch (NoSuchElementException | StaleElementReferenceException e) {
                    return false;
                }
            }, "Submenu to be visible");
        } catch (TimeoutException e) {
            return false;
        }
    }

    /**
     * Checks if on search page.
     *
     * @return true if on page
     */
    public boolean isOnSearchPage() {
        return wait.isElementVisible(applicationIdField);
    }
}
