package com.harsha.bureau.infrastructure.selenium.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * Page Object Model for Application Details Page.
 */
public class ApplicationDetailsPage extends BasePage {

    // Locators
    private final By viewBureauButton = By.xpath("//button[.='View Bureau']");
    private final By closeButton = By.xpath("//button[.='Close']");
    private final By confirmationModal = By.cssSelector(".wicket-modal");
    private final By modalOkButton = By.xpath("//*[@name='ok']");

    public ApplicationDetailsPage(WebDriver driver) {
        super(driver);
    }

    /**
     * Clicks View Bureau button.
     *
     * @return BureauDataPopupPage
     */
    public BureauDataPopupPage clickViewBureau() {
        log.info("Clicking View Bureau button");

        wait.smartClick(viewBureauButton);
        wait.pauseMedium();

        log.info("View Bureau button clicked");
        return new BureauDataPopupPage(driver);
    }

    /**
     * Closes application details and returns to search.
     *
     * @return SearchPage
     */
    public SearchPage closeAndReturnToSearch() {
        log.info("Closing application details");

        wait.smartClick(closeButton);
        wait.pauseMedium();

        handleConfirmationModal();

        // Wait for search page to be visible
        wait.waitForVisible(By.id("txt-appid"));
        wait.pauseMedium();

        log.info("Returned to search page");
        return new SearchPage(driver);
    }

    /**
     * Handles confirmation modal if present.
     */
    private void handleConfirmationModal() {
        try {
            wait.waitForVisible(confirmationModal);
            wait.smartClick(modalOkButton);
            wait.waitForInvisible(confirmationModal);
            log.debug("Confirmation modal handled");
        } catch (Exception e) {
            // Try alternative OK button
            try {
                By altOkButton = By.xpath("//input[@type='button' and @value='OK']");
                wait.smartClick(altOkButton);
                wait.pauseMedium();
            } catch (Exception altError) {
                log.debug("No modal to handle");
            }
        }
    }

    /**
     * Checks if on application details page.
     *
     * @return true if on page
     */
    public boolean isOnApplicationDetailsPage() {
        return wait.isElementVisible(viewBureauButton);
    }
}
