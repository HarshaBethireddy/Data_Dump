package com.harsha.bureau.infrastructure.selenium.adapter;

import com.harsha.bureau.common.exception.ExtractionException;
import com.harsha.bureau.core.domain.model.ExtractionResult;
import com.harsha.bureau.core.ports.output.BureauExtractor;
import com.harsha.bureau.core.ports.output.WebDriverProvider;
import com.harsha.bureau.infrastructure.selenium.page.*;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.FileWriter;
import java.util.List;

/**
 * Selenium implementation of BureauExtractor port.
 * Uses Page Object Model for browser automation.
 */
@Component
public class SeleniumBureauExtractor implements BureauExtractor {

    private static final Logger log = LoggerFactory.getLogger(SeleniumBureauExtractor.class);

    private final WebDriverProvider driverPool;

    @Value("${bureau.comparison.base-url}")
    private String baseUrl;

    @Value("${bureau.comparison.credentials.username}")
    private String username;

    @Value("${bureau.comparison.credentials.password}")
    private String password;

    private boolean initialized = false;

    public SeleniumBureauExtractor(WebDriverProvider driverPool) {
        this.driverPool = driverPool;
    }

    @Override
    public ExtractionResult extract(String applicationId, String type,
                                    String category, String outputPath) {
        long startTime = System.currentTimeMillis();
        WebDriver driver = null;

        try {
            log.info("Starting extraction for AppID {} ({}) - Category: {}", applicationId, type, category);

            // Acquire driver from pool
            driver = driverPool.acquire();

            // Navigate and login (if needed)
            if (!initialized) {
                performInitialSetup(driver, category);
                initialized = true;
            } else {
                // Already logged in, just navigate to search
                SearchPage searchPage = new SearchPage(driver);
                if (!searchPage.isOnSearchPage()) {
                    performInitialSetup(driver, category);
                }
            }

            // Search for application
            SearchPage searchPage = new SearchPage(driver);
            ApplicationDetailsPage detailsPage = searchPage
                .searchApplication(applicationId)
                .openApplication();

            // Extract bureau data
            BureauDataPopupPage popupPage = detailsPage.clickViewBureau();
            String bureauData = popupPage.extractBureauData(applicationId, type);

            // Close popup
            popupPage.closePopup();

            // Save to file
            try (FileWriter writer = new FileWriter(outputPath)) {
                writer.write(bureauData);
            }

            long duration = System.currentTimeMillis() - startTime;

            log.info("Extraction completed for AppID {} ({}) in {}ms", applicationId, type, duration);

            return ExtractionResult.success(applicationId, type, outputPath, duration);

        } catch (Exception e) {
            log.error("Extraction failed for AppID {} ({}): {}", applicationId, type, e.getMessage(), e);
            return ExtractionResult.failure(applicationId, type, e.getMessage());
        } finally {
            // Release driver back to pool
            if (driver != null) {
                driverPool.release(driver);
            }
        }
    }

    @Override
    public boolean isReady() {
        return driverPool.getIdleCount() > 0 || driverPool.getActiveCount() < driverPool.getPoolSize();
    }

    @Override
    public boolean login() {
        WebDriver driver = null;
        try {
            driver = driverPool.acquire();
            LoginPage loginPage = new LoginPage(driver);
            loginPage.navigateTo(baseUrl);
            loginPage.login(username, password);
            return true;
        } catch (Exception e) {
            log.error("Login failed: {}", e.getMessage());
            return false;
        } finally {
            if (driver != null) {
                driverPool.release(driver);
            }
        }
    }

    @Override
    public boolean navigateToSearch(String category) {
        WebDriver driver = null;
        try {
            driver = driverPool.acquire();
            SearchPage searchPage = new SearchPage(driver);
            List<String> menuPath = com.harsha.bureau.common.constant.CategoryConstants
                .getMenuPathForCategory(category);
            searchPage.navigateToSearch(menuPath);
            return true;
        } catch (Exception e) {
            log.error("Navigation to search failed: {}", e.getMessage());
            return false;
        } finally {
            if (driver != null) {
                driverPool.release(driver);
            }
        }
    }

    /**
     * Performs initial setup: login and navigate to search.
     *
     * @param driver the WebDriver
     * @param category the category
     */
    private void performInitialSetup(WebDriver driver, String category) {
        log.info("Performing initial setup for category: {}", category);

        // Navigate to base URL
        driver.get(baseUrl);

        // Login
        LoginPage loginPage = new LoginPage(driver);
        GroupSelectionPage groupPage = loginPage.login(username, password);

        // Select administrator group
        SearchPage searchPage = groupPage.selectAdministratorGroup();

        // Navigate to search for category
        List<String> menuPath = com.harsha.bureau.common.constant.CategoryConstants
            .getMenuPathForCategory(category);
        searchPage.navigateToSearch(menuPath);

        log.info("Initial setup completed");
    }
}
