package com.harsha.bureau.infrastructure.persistence.excel;

import com.harsha.bureau.common.constant.BureauConstants;
import com.harsha.bureau.common.util.FileUtils;
import com.harsha.bureau.common.util.StringUtils;
import com.harsha.bureau.core.domain.model.ApplicationData;
import com.harsha.bureau.core.ports.output.ApplicationRepository;
import com.harsha.bureau.infrastructure.persistence.file.JsonFileParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Excel-based implementation of ApplicationRepository port.
 */
@Component
public class ExcelApplicationRepository implements ApplicationRepository {

    private static final Logger log = LoggerFactory.getLogger(ExcelApplicationRepository.class);

    private final ExcelReader excelReader;
    private final ExcelWriter excelWriter;
    private final JsonFileParser jsonParser;

    public ExcelApplicationRepository(ExcelReader excelReader,
                                     ExcelWriter excelWriter,
                                     JsonFileParser jsonParser) {
        this.excelReader = excelReader;
        this.excelWriter = excelWriter;
        this.jsonParser = jsonParser;
    }

    @Override
    public Map<String, String> extractAppIds(String folderPath) {
        Map<String, String> appIds = new HashMap<>();

        File folder = new File(folderPath);
        if (!folder.exists() || !folder.isDirectory()) {
            log.warn("Folder not found: {}", folderPath);
            return appIds;
        }

        File[] files = folder.listFiles();
        if (files == null) {
            return appIds;
        }

        log.info("Extracting AppIDs from folder: {} ({} files)", folderPath, files.length);

        for (File file : files) {
            if (file == null || !file.isFile()) {
                continue;
            }

            String fileName = file.getName();
            String appId = "";

            if (fileName.toLowerCase().endsWith(BureauConstants.EXTENSION_JSON)) {
                // Extract from JSON
                appId = jsonParser.extractAppIdFromJson(file);
            } else if (fileName.toLowerCase().endsWith(BureauConstants.EXTENSION_TXT)) {
                // Try to extract from filename first
                appId = StringUtils.extractAppIdFromFileName(fileName);

                if (appId.isEmpty()) {
                    // Fallback: extract from content
                    try {
                        String content = FileUtils.readFileWithEncoding(file);
                        appId = StringUtils.extractAppIdFromContent(content);
                    } catch (Exception e) {
                        log.debug("Failed to read file {}: {}", fileName, e.getMessage());
                    }
                }
            }

            appIds.put(fileName, appId);
        }

        log.info("Extracted {} AppIDs from folder: {}", appIds.size(), folderPath);
        return appIds;
    }

    @Override
    public List<ApplicationData> readApplicationsFromExcel(String excelPath) {
        return excelReader.readApplications(excelPath);
    }

    @Override
    public void writeApplicationsToExcel(List<ApplicationData> applications, String excelPath) {
        excelWriter.writeApplications(applications, excelPath);
    }

    @Override
    public String compareAndGenerateExcel(String preFolder, String postFolder, String outputFolder) {
        log.info("Comparing AppIDs: PRE={}, POST={}", preFolder, postFolder);

        // Extract AppIDs from both folders
        Map<String, String> preAppIds = extractAppIds(preFolder);
        Map<String, String> postAppIds = extractAppIds(postFolder);

        // Ensure output folder exists
        try {
            FileUtils.ensureDirectoryExists(outputFolder);
        } catch (Exception e) {
            log.error("Failed to create output folder: {}", e.getMessage());
            throw new RuntimeException("Failed to create output folder", e);
        }

        // Generate Excel file
        String excelPath = outputFolder + File.separator + "APPIDComparison_ALL.xlsx";
        excelWriter.writeAppIdComparison(preAppIds, postAppIds, excelPath);

        log.info("Generated AppID comparison Excel: {}", excelPath);
        return excelPath;
    }
}
