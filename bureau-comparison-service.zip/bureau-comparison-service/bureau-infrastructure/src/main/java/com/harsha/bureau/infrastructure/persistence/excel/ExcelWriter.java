package com.harsha.bureau.infrastructure.persistence.excel;

import com.harsha.bureau.core.domain.model.ApplicationData;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Writes application data to Excel files.
 */
@Component
public class ExcelWriter {

    private static final Logger log = LoggerFactory.getLogger(ExcelWriter.class);

    /**
     * Writes applications to Excel file.
     *
     * @param applications the applications
     * @param excelPath the Excel file path
     */
    public void writeApplications(List<ApplicationData> applications, String excelPath) {
        try (Workbook workbook = new XSSFWorkbook();
             FileOutputStream fos = new FileOutputStream(excelPath)) {

            Sheet sheet = workbook.createSheet("AppID Comparison");

            // Create header row
            Row headerRow = sheet.createRow(0);
            CellStyle headerStyle = createHeaderStyle(workbook);

            String[] headers = {"File Name", "Pre-AppID", "Post-AppID", "Category"};
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // Write data rows
            int rowIndex = 1;
            for (ApplicationData app : applications) {
                Row row = sheet.createRow(rowIndex++);
                row.createCell(0).setCellValue(app.getFileName());
                row.createCell(1).setCellValue(app.getPreAppId());
                row.createCell(2).setCellValue(app.getPostAppId());
                row.createCell(3).setCellValue(app.getCategory());
            }

            // Auto-size columns
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(fos);
            log.info("Wrote {} applications to Excel: {}", applications.size(), excelPath);

        } catch (IOException e) {
            log.error("Error writing Excel file {}: {}", excelPath, e.getMessage(), e);
        }
    }

    /**
     * Writes AppID comparison to Excel file.
     *
     * @param preAppIds PRE AppIDs map (filename -> AppID)
     * @param postAppIds POST AppIDs map (filename -> AppID)
     * @param excelPath the Excel file path
     */
    public void writeAppIdComparison(Map<String, String> preAppIds,
                                     Map<String, String> postAppIds,
                                     String excelPath) {
        try (Workbook workbook = new XSSFWorkbook();
             FileOutputStream fos = new FileOutputStream(excelPath)) {

            Sheet sheet = workbook.createSheet("AppID Comparison");

            // Create header row
            Row headerRow = sheet.createRow(0);
            CellStyle headerStyle = createHeaderStyle(workbook);

            String[] headers = {"File Name", "Pre-AppID", "Post-AppID", "Category"};
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // Combine all filenames
            java.util.Set<String> allFiles = new java.util.TreeSet<>(String.CASE_INSENSITIVE_ORDER);
            allFiles.addAll(preAppIds.keySet());
            allFiles.addAll(postAppIds.keySet());

            // Write data rows
            int rowIndex = 1;
            for (String fileName : allFiles) {
                Row row = sheet.createRow(rowIndex++);
                row.createCell(0).setCellValue(fileName);
                row.createCell(1).setCellValue(preAppIds.getOrDefault(fileName, ""));
                row.createCell(2).setCellValue(postAppIds.getOrDefault(fileName, ""));
                row.createCell(3).setCellValue(determineCategory(fileName));
            }

            // Auto-size columns
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(fos);
            log.info("Wrote AppID comparison to Excel: {} ({} files)", excelPath, allFiles.size());

        } catch (IOException e) {
            log.error("Error writing Excel file {}: {}", excelPath, e.getMessage(), e);
        }
    }

    /**
     * Creates header cell style.
     *
     * @param workbook the workbook
     * @return the cell style
     */
    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    /**
     * Determines category from filename.
     *
     * @param fileName the filename
     * @return the category
     */
    private String determineCategory(String fileName) {
        if (fileName == null) {
            return "ACQ";
        }

        String upper = fileName.toUpperCase();
        if (upper.contains("CLI")) return "CLI";
        if (upper.contains("PRQ") || upper.contains("PREQUAL")) return "PRQ";
        return "ACQ";
    }
}
