package com.harsha.bureau.infrastructure.selenium.pool;

import com.harsha.bureau.core.ports.output.WebDriverProvider;
import com.harsha.bureau.infrastructure.selenium.config.SeleniumConfig;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

/**
 * WebDriver pool implementation using Apache Commons Pool2.
 * Implements WebDriverProvider port from core layer.
 */
@Component
public class WebDriverPool implements WebDriverProvider {

    private static final Logger log = LoggerFactory.getLogger(WebDriverPool.class);

    private final SeleniumConfig config;
    private GenericObjectPool<WebDriver> pool;

    public WebDriverPool(SeleniumConfig config) {
        this.config = config;
    }

    @PostConstruct
    public void initialize() {
        log.info("Initializing WebDriver pool with config: maxTotal={}, maxIdle={}, minIdle={}",
            config.getPool().getMaxTotal(),
            config.getPool().getMaxIdle(),
            config.getPool().getMinIdle());

        GenericObjectPoolConfig<WebDriver> poolConfig = new GenericObjectPoolConfig<>();
        poolConfig.setMaxTotal(config.getPool().getMaxTotal());
        poolConfig.setMaxIdle(config.getPool().getMaxIdle());
        poolConfig.setMinIdle(config.getPool().getMinIdle());
        poolConfig.setMaxWaitMillis(config.getPool().getMaxWaitMillis());
        poolConfig.setTestOnBorrow(config.getPool().isTestOnBorrow());
        poolConfig.setTestOnReturn(config.getPool().isTestOnReturn());
        poolConfig.setBlockWhenExhausted(true);

        WebDriverFactory factory = new WebDriverFactory(config);
        pool = new GenericObjectPool<>(factory, poolConfig);

        log.info("WebDriver pool initialized successfully");
    }

    @Override
    public WebDriver acquire() throws Exception {
        log.debug("Acquiring WebDriver from pool (active: {}, idle: {})",
            pool.getNumActive(), pool.getNumIdle());

        WebDriver driver = pool.borrowObject();

        log.debug("WebDriver acquired (active: {}, idle: {})",
            pool.getNumActive(), pool.getNumIdle());

        return driver;
    }

    @Override
    public void release(WebDriver driver) {
        if (driver == null) {
            return;
        }

        log.debug("Releasing WebDriver to pool");

        try {
            pool.returnObject(driver);
            log.debug("WebDriver released (active: {}, idle: {})",
                pool.getNumActive(), pool.getNumIdle());
        } catch (Exception e) {
            log.error("Error releasing WebDriver to pool: {}", e.getMessage());

            // Invalidate the object if return fails
            try {
                pool.invalidateObject(driver);
            } catch (Exception invalidateException) {
                log.error("Error invalidating WebDriver: {}", invalidateException.getMessage());
            }
        }
    }

    @Override
    public int getPoolSize() {
        return config.getPool().getMaxTotal();
    }

    @Override
    public int getActiveCount() {
        return pool.getNumActive();
    }

    @Override
    public int getIdleCount() {
        return pool.getNumIdle();
    }

    @Override
    @PreDestroy
    public void shutdown() {
        log.info("Shutting down WebDriver pool");

        if (pool != null) {
            pool.close();
        }

        log.info("WebDriver pool shut down successfully");
    }

    /**
     * Gets pool statistics.
     *
     * @return pool stats string
     */
    public String getPoolStats() {
        return String.format("WebDriver Pool Stats - Active: %d, Idle: %d, Max: %d",
            getActiveCount(), getIdleCount(), getPoolSize());
    }
}
