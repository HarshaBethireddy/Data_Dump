package com.harsha.bureau.infrastructure.selenium.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Selenium configuration properties.
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "selenium")
public class SeleniumConfig {

    private Grid grid = new Grid();
    private Browser browser = new Browser();
    private Pool pool = new Pool();

    @Data
    public static class Grid {
        private boolean enabled = true;
        private String url = "http://localhost:4444";
        private int maxSessions = 50;
        private int sessionTimeout = 300;
    }

    @Data
    public static class Browser {
        private String type = "chrome";
        private boolean headless = false;
        private String[] options = {
            "--start-maximized",
            "--disable-blink-features=AutomationControlled",
            "--no-sandbox",
            "--disable-dev-shm-usage"
        };
    }

    @Data
    public static class Pool {
        private int maxTotal = 12;  // For 8GB RAM
        private int maxIdle = 6;
        private int minIdle = 2;
        private long maxWaitMillis = 30000;
        private boolean testOnBorrow = true;
        private boolean testOnReturn = false;
    }
}
