package com.harsha.bureau.infrastructure.selenium.page;

import org.openqa.selenium.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Page Object Model for Bureau Data Popup Window.
 */
public class BureauDataPopupPage extends BasePage {

    // Locators
    private final By jsTree = By.cssSelector(".jstree");
    private final By requestResponseLinks = By.xpath("//a[@raw]");

    private String mainWindowHandle;
    private String popupWindowHandle;

    public BureauDataPopupPage(WebDriver driver) {
        super(driver);
        this.mainWindowHandle = driver.getWindowHandle();
        switchToPopup();
    }

    /**
     * Switches to popup window.
     */
    private void switchToPopup() {
        wait.pauseLong();

        Set<String> allWindows = driver.getWindowHandles();
        for (String windowHandle : allWindows) {
            if (!windowHandle.equals(mainWindowHandle)) {
                popupWindowHandle = windowHandle;
                driver.switchTo().window(popupWindowHandle);
                wait.waitForPageLoad();
                break;
            }
        }

        if (popupWindowHandle == null) {
            throw new RuntimeException("Popup window not found");
        }

        log.info("Switched to bureau data popup");
    }

    /**
     * Extracts all bureau data from popup.
     *
     * @param applicationId the application ID
     * @param type the type (PRE/POST)
     * @return extracted bureau data as string
     */
    public String extractBureauData(String applicationId, String type) {
        log.info("Extracting bureau data for AppID {} ({})", applicationId, type);

        StringBuilder bureauData = new StringBuilder();
        bureauData.append("===== BUREAU DATA EXTRACTION =====\n");
        bureauData.append("Type: ").append(type).append("\n");
        bureauData.append("Application ID: ").append(applicationId).append("\n");
        bureauData.append("Extraction Time: ").append(java.time.LocalDateTime.now()).append("\n");
        bureauData.append("==================================\n\n");

        try {
            // Expand all tree nodes
            expandAllTreeNodes();

            // Find all request/response links
            List<WebElement> links = findRequestResponseLinks();
            log.info("Found {} request/response links", links.size());

            // Extract data from each link
            for (int i = 0; i < links.size(); i++) {
                // Re-find links (to avoid stale element)
                links = findRequestResponseLinks();

                if (i < links.size()) {
                    WebElement link = links.get(i);

                    String bureauKey = link.getAttribute("bureaukey");
                    String linkType = link.getAttribute("type");

                    log.debug("Processing: {} - {}", bureauKey, linkType);

                    bureauData.append("\n").append("=".repeat(50)).append("\n");
                    bureauData.append("Bureau: ").append(bureauKey != null ? bureauKey : "Unknown").append("\n");
                    bureauData.append("Type: ").append(linkType != null ? linkType : "Unknown").append("\n");
                    bureauData.append("=".repeat(50)).append("\n");

                    // Click link to open data window
                    String linkData = clickAndExtractData(link);
                    bureauData.append(linkData).append("\n");

                    wait.pauseShort();
                }
            }

        } catch (Exception e) {
            log.error("Error during bureau data extraction: {}", e.getMessage(), e);
            bureauData.append("\n\nERROR: ").append(e.getMessage());
        }

        log.info("Bureau data extraction completed");
        return bureauData.toString();
    }

    /**
     * Expands all tree nodes in jsTree.
     */
    private void expandAllTreeNodes() {
        wait.waitForPresence(jsTree);

        // Try to use jsTree API first
        try {
            Object used = wait.executeScript(
                "try {" +
                    "  if (window.$ && $('.jstree').length && $('.jstree').jstree) {" +
                    "    var inst = $('.jstree').jstree(true) || $('.jstree').jstree(); " +
                    "    if (inst && inst.open_all) { inst.open_all(); return true; }" +
                    "  }" +
                    "} catch(e) {}" +
                    "return false;"
            );

            if (Boolean.TRUE.equals(used)) {
                wait.pauseMedium();
                return;
            }
        } catch (Exception ignored) {
        }

        // Fallback: Manual expansion by clicking togglers
        int maxPasses = 50;
        for (int i = 0; i < maxPasses; i++) {
            List<WebElement> closedTogglers = driver.findElements(
                By.cssSelector(".jstree li.jstree-closed > i.jstree-ocl, " +
                    ".jstree li.jstree-closed > i.jstree-icon.jstree-ocl")
            );

            if (closedTogglers.isEmpty()) break;

            for (WebElement toggler : closedTogglers) {
                try {
                    wait.scrollIntoView(toggler);
                    wait.smartClick(By.cssSelector(".jstree-ocl"));
                    wait.pause(150);
                } catch (Exception ignored) {
                }
            }
        }

        log.debug("Tree expansion completed");
    }

    /**
     * Finds all request/response links.
     *
     * @return list of links
     */
    private List<WebElement> findRequestResponseLinks() {
        List<WebElement> links = new ArrayList<>();

        try {
            List<WebElement> rawLinks = driver.findElements(requestResponseLinks);

            for (WebElement link : rawLinks) {
                String type = link.getAttribute("type");
                if ("request".equals(type) || "response".equals(type)) {
                    links.add(link);
                }
            }
        } catch (Exception e) {
            log.error("Error finding request/response links: {}", e.getMessage());
        }

        return links;
    }

    /**
     * Clicks link and extracts data from opened window.
     *
     * @param link the link element
     * @return extracted data
     */
    private String clickAndExtractData(WebElement link) {
        // Click link using JavaScript
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", link);
        wait.pauseMedium();

        // Find new window
        Set<String> currentWindows = driver.getWindowHandles();
        String dataWindow = null;

        for (String windowHandle : currentWindows) {
            if (!windowHandle.equals(mainWindowHandle) && !windowHandle.equals(popupWindowHandle)) {
                dataWindow = windowHandle;
                break;
            }
        }

        if (dataWindow == null) {
            return "[No data window opened]";
        }

        // Switch to data window
        driver.switchTo().window(dataWindow);

        String data;
        try {
            // Try to get data from <pre> tag
            try {
                WebElement preElement = wait.waitForPresence(By.tagName("pre"));
                data = preElement.getText();
            } catch (Exception e) {
                // Fallback: get body text
                data = driver.findElement(By.tagName("body")).getText();
            }
        } finally {
            // Close data window and switch back to popup
            driver.close();
            driver.switchTo().window(popupWindowHandle);
        }

        return data;
    }

    /**
     * Closes popup and returns to main window.
     */
    public void closePopup() {
        try {
            driver.close();
        } catch (Exception e) {
            log.debug("Error closing popup: {}", e.getMessage());
        }

        driver.switchTo().window(mainWindowHandle);
        log.info("Closed popup and returned to main window");
    }
}
