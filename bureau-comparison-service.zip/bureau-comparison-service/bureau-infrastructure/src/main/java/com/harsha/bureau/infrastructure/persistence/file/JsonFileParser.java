package com.harsha.bureau.infrastructure.persistence.file;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.harsha.bureau.common.constant.BureauConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.Iterator;
import java.util.Map;

/**
 * Parses JSON files to extract application IDs.
 */
@Component
public class JsonFileParser {

    private static final Logger log = LoggerFactory.getLogger(JsonFileParser.class);
    private final ObjectMapper objectMapper;

    public JsonFileParser() {
        this.objectMapper = new ObjectMapper();
    }

    /**
     * Extracts application ID from JSON file.
     *
     * @param file the JSON file
     * @return the application ID or empty string
     */
    public String extractAppIdFromJson(File file) {
        try {
            JsonNode root = objectMapper.readTree(file);
            return findAppId(root);
        } catch (Exception e) {
            log.warn("Failed to parse JSON file {}: {}", file.getName(), e.getMessage());
            return "";
        }
    }

    /**
     * Recursively searches for application ID in JSON tree.
     *
     * @param node the JSON node
     * @return the application ID or empty string
     */
    private String findAppId(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) {
            return "";
        }

        if (node.isObject()) {
            // Check known AppID keys
            for (String key : BureauConstants.APPID_KEYS) {
                JsonNode candidate = node.get(key);
                String value = nodeToIdString(candidate);
                if (!value.isEmpty()) {
                    return value;
                }
            }

            // Search in all fields
            Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> entry = fields.next();
                String fieldName = entry.getKey();
                JsonNode value = entry.getValue();

                // Check if field name contains "appid"
                if (fieldName != null && fieldName.toLowerCase().contains("appid")) {
                    String id = nodeToIdString(value);
                    if (!id.isEmpty()) {
                        return id;
                    }
                }

                // Recursive search
                String deeper = findAppId(value);
                if (!deeper.isEmpty()) {
                    return deeper;
                }
            }
        }

        if (node.isArray()) {
            for (JsonNode item : node) {
                String value = findAppId(item);
                if (!value.isEmpty()) {
                    return value;
                }
            }
        }

        return "";
    }

    /**
     * Converts JSON node to ID string.
     *
     * @param node the JSON node
     * @return the ID string
     */
    private String nodeToIdString(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) {
            return "";
        }

        if (node.isTextual() || node.isNumber() || node.isBoolean()) {
            return node.asText();
        }

        if (node.isObject()) {
            // Check for common ID keys
            for (String idKey : BureauConstants.ID_KEYS) {
                JsonNode inner = node.get(idKey);
                if (inner != null && !inner.isNull()) {
                    String value = nodeToIdString(inner);
                    if (!value.isEmpty()) {
                        return value;
                    }
                }
            }

            // Recursive search in object
            Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> entry = fields.next();
                String value = nodeToIdString(entry.getValue());
                if (!value.isEmpty()) {
                    return value;
                }
            }
        }

        if (node.isArray()) {
            for (JsonNode item : node) {
                String value = nodeToIdString(item);
                if (!value.isEmpty()) {
                    return value;
                }
            }
        }

        return "";
    }
}
