package com.harsha.bureau.infrastructure.persistence.excel;

import com.harsha.bureau.core.domain.model.ApplicationData;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Reads application data from Excel files.
 */
@Component
public class ExcelReader {

    private static final Logger log = LoggerFactory.getLogger(ExcelReader.class);

    /**
     * Reads applications from Excel file.
     *
     * @param excelPath the Excel file path
     * @return list of application data
     */
    public List<ApplicationData> readApplications(String excelPath) {
        List<ApplicationData> applications = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(excelPath);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);
            log.info("Reading applications from Excel: {} (rows: {})", excelPath, sheet.getLastRowNum());

            // Skip header row (row 0)
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) {
                    continue;
                }

                String fileName = getCellValueAsString(row.getCell(0));
                String preAppId = getCellValueAsString(row.getCell(1));
                String postAppId = getCellValueAsString(row.getCell(2));
                String category = getCellValueAsString(row.getCell(3));

                ApplicationData appData = ApplicationData.builder()
                    .fileName(fileName)
                    .preAppId(preAppId)
                    .postAppId(postAppId)
                    .category(category != null ? category : determineCategory(fileName))
                    .build();

                if (appData.isValid()) {
                    applications.add(appData);
                } else {
                    log.warn("Invalid application data at row {}: {}", i, fileName);
                }
            }

            log.info("Read {} valid applications from Excel", applications.size());

        } catch (IOException e) {
            log.error("Error reading Excel file {}: {}", excelPath, e.getMessage(), e);
        }

        return applications;
    }

    /**
     * Gets cell value as string, handling different cell types.
     *
     * @param cell the cell
     * @return the cell value as string
     */
    private String getCellValueAsString(Cell cell) {
        if (cell == null) {
            return null;
        }

        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                double numValue = cell.getNumericCellValue();
                if (numValue == Math.floor(numValue)) {
                    return String.valueOf((long) numValue);
                }
                return String.valueOf(numValue);
            case BLANK:
                return null;
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                try {
                    return cell.getStringCellValue().trim();
                } catch (Exception e) {
                    return String.valueOf(cell.getNumericCellValue());
                }
            default:
                return cell.toString().trim();
        }
    }

    /**
     * Determines category from filename.
     *
     * @param fileName the filename
     * @return the category
     */
    private String determineCategory(String fileName) {
        if (fileName == null) {
            return "ACQ";
        }

        String upper = fileName.toUpperCase();
        if (upper.contains("CLI")) return "CLI";
        if (upper.contains("PRQ") || upper.contains("PREQUAL")) return "PRQ";
        return "ACQ";
    }
}
