package com.harsha.bureau.infrastructure.selenium.wait;

import com.harsha.bureau.common.constant.BureauConstants;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.List;

/**
 * Smart wait helper with dynamic, auto-detecting waits.
 * No need to manually specify wait conditions - automatically handles common scenarios.
 */
public class SmartWaitHelper {

    private static final Logger log = LoggerFactory.getLogger(SmartWaitHelper.class);

    private final WebDriver driver;
    private final WebDriverWait defaultWait;
    private final WebDriverWait shortWait;
    private final WebDriverWait longWait;

    public SmartWaitHelper(WebDriver driver) {
        this.driver = driver;
        this.defaultWait = new WebDriverWait(driver, Duration.ofSeconds(BureauConstants.DEFAULT_WAIT_TIMEOUT));
        this.shortWait = new WebDriverWait(driver, Duration.ofSeconds(BureauConstants.SHORT_WAIT_TIMEOUT));
        this.longWait = new WebDriverWait(driver, Duration.ofSeconds(BureauConstants.LONG_WAIT_TIMEOUT));
    }

    /**
     * Smart click - waits for element to be clickable and clicks.
     * Automatically retries with JavaScript if normal click fails.
     *
     * @param locator the element locator
     */
    public void smartClick(By locator) {
        try {
            WebElement element = waitForClickable(locator);
            element.click();
            log.debug("Clicked element: {}", locator);
        } catch (Exception e) {
            log.debug("Normal click failed, trying JavaScript click for: {}", locator);
            WebElement element = waitForPresence(locator);
            ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
        }
    }

    /**
     * Smart send keys - waits for element and types with automatic retry.
     *
     * @param locator the element locator
     * @param text the text to type
     */
    public void smartSendKeys(By locator, String text) {
        smartSendKeys(locator, text, true);
    }

    /**
     * Smart send keys with options.
     *
     * @param locator the element locator
     * @param text the text to type
     * @param clearFirst whether to clear field first
     */
    public void smartSendKeys(By locator, String text, boolean clearFirst) {
        WebElement element = waitForVisible(locator);

        if (clearFirst) {
            element.clear();
            pauseShort();
        }

        // Type character by character for better reliability
        for (char c : text.toCharArray()) {
            element.sendKeys(String.valueOf(c));
            try {
                Thread.sleep(BureauConstants.TYPING_DELAY_MS);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
        }

        // Verify text was entered
        waitFor(() -> {
            String value = element.getAttribute("value");
            return value != null && value.equals(text);
        }, "Text to be entered correctly");

        log.debug("Sent keys to element: {}", locator);
    }

    /**
     * Smart get text - waits for element and retrieves text.
     *
     * @param locator the element locator
     * @return the element text
     */
    public String smartGetText(By locator) {
        WebElement element = waitForVisible(locator);
        return element.getText();
    }

    /**
     * Waits for element to be present in DOM.
     *
     * @param locator the element locator
     * @return the element
     */
    public WebElement waitForPresence(By locator) {
        return defaultWait.until(ExpectedConditions.presenceOfElementLocated(locator));
    }

    /**
     * Waits for element to be visible.
     *
     * @param locator the element locator
     * @return the element
     */
    public WebElement waitForVisible(By locator) {
        return defaultWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    /**
     * Waits for element to be clickable.
     *
     * @param locator the element locator
     * @return the element
     */
    public WebElement waitForClickable(By locator) {
        return defaultWait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    /**
     * Waits for element to be invisible.
     *
     * @param locator the element locator
     */
    public void waitForInvisible(By locator) {
        defaultWait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }

    /**
     * Waits for all elements to be visible.
     *
     * @param locator the element locator
     * @return list of elements
     */
    public List<WebElement> waitForAllVisible(By locator) {
        return defaultWait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator));
    }

    /**
     * Waits for custom condition.
     *
     * @param condition the condition
     * @param description the description for logging
     * @param <T> the return type
     * @return the result
     */
    public <T> T waitFor(ExpectedCondition<T> condition, String description) {
        log.debug("Waiting for: {}", description);
        return defaultWait.until(condition);
    }

    /**
     * Waits for page to load completely.
     */
    public void waitForPageLoad() {
        waitFor(driver -> {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            return js.executeScript("return document.readyState").equals("complete");
        }, "Page to load completely");
    }

    /**
     * Waits for jQuery/AJAX to complete (if page uses jQuery).
     */
    public void waitForAjax() {
        try {
            waitFor(driver -> {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                return (Boolean) js.executeScript("return typeof jQuery != 'undefined' && jQuery.active == 0");
            }, "AJAX to complete");
        } catch (Exception e) {
            log.debug("jQuery not present or AJAX wait failed, continuing");
        }
    }

    /**
     * Waits for element attribute to have specific value.
     *
     * @param locator the element locator
     * @param attribute the attribute name
     * @param value the expected value
     */
    public void waitForAttributeValue(By locator, String attribute, String value) {
        defaultWait.until(ExpectedConditions.attributeToBe(locator, attribute, value));
    }

    /**
     * Waits for text to be present in element.
     *
     * @param locator the element locator
     * @param text the text
     */
    public void waitForTextPresent(By locator, String text) {
        defaultWait.until(ExpectedConditions.textToBePresentInElementLocated(locator, text));
    }

    /**
     * Checks if element is present (no wait).
     *
     * @param locator the element locator
     * @return true if present
     */
    public boolean isElementPresent(By locator) {
        try {
            driver.findElement(locator);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    /**
     * Checks if element is visible (short wait).
     *
     * @param locator the element locator
     * @return true if visible
     */
    public boolean isElementVisible(By locator) {
        try {
            shortWait.until(ExpectedConditions.visibilityOfElementLocated(locator));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Scrolls element into view.
     *
     * @param element the element
     */
    public void scrollIntoView(WebElement element) {
        ((JavascriptExecutor) driver).executeScript(
            "arguments[0].scrollIntoView({block:'center', behavior: 'smooth'});", element);
        pauseShort();
    }

    /**
     * Scrolls to element by locator and returns it.
     *
     * @param locator the element locator
     * @return the element
     */
    public WebElement scrollToElement(By locator) {
        WebElement element = waitForPresence(locator);
        scrollIntoView(element);
        return element;
    }

    /**
     * Switches to window by index.
     *
     * @param windowIndex the window index
     */
    public void switchToWindow(int windowIndex) {
        waitFor(driver -> driver.getWindowHandles().size() > windowIndex,
            "Window " + windowIndex + " to be available");

        String windowHandle = (String) driver.getWindowHandles().toArray()[windowIndex];
        driver.switchTo().window(windowHandle);
        waitForPageLoad();
    }

    /**
     * Switches to latest window.
     */
    public void switchToLatestWindow() {
        String[] windows = driver.getWindowHandles().toArray(new String[0]);
        driver.switchTo().window(windows[windows.length - 1]);
        waitForPageLoad();
    }

    /**
     * Closes current window and switches back to previous.
     */
    public void closeCurrentWindow() {
        String currentWindow = driver.getWindowHandle();
        String[] allWindows = driver.getWindowHandles().toArray(new String[0]);

        driver.close();

        // Switch to previous window
        for (String window : allWindows) {
            if (!window.equals(currentWindow)) {
                driver.switchTo().window(window);
                break;
            }
        }
    }

    /**
     * Pauses for short duration.
     */
    public void pauseShort() {
        pause(BureauConstants.SLEEP_SHORT);
    }

    /**
     * Pauses for medium duration.
     */
    public void pauseMedium() {
        pause(BureauConstants.SLEEP_MEDIUM);
    }

    /**
     * Pauses for long duration.
     */
    public void pauseLong() {
        pause(BureauConstants.SLEEP_LONG);
    }

    /**
     * Pauses for specified milliseconds.
     *
     * @param milliseconds the duration
     */
    public void pause(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Executes JavaScript.
     *
     * @param script the script
     * @param args the arguments
     * @return the result
     */
    public Object executeScript(String script, Object... args) {
        return ((JavascriptExecutor) driver).executeScript(script, args);
    }

    /**
     * Handles alert if present.
     *
     * @param accept true to accept, false to dismiss
     * @return true if alert was handled
     */
    public boolean handleAlertIfPresent(boolean accept) {
        try {
            Alert alert = shortWait.until(ExpectedConditions.alertIsPresent());
            if (accept) {
                alert.accept();
            } else {
                alert.dismiss();
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
