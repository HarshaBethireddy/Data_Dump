package com.harsha.bureau.infrastructure.selenium.page;

import com.harsha.bureau.infrastructure.selenium.wait.SmartWaitHelper;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Base page for all Page Object Model classes.
 * Provides common functionality and smart wait helper.
 */
public abstract class BasePage {

    protected final Logger log = LoggerFactory.getLogger(getClass());
    protected final WebDriver driver;
    protected final SmartWaitHelper wait;

    protected BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new SmartWaitHelper(driver);
    }

    /**
     * Gets the page title.
     *
     * @return the page title
     */
    public String getPageTitle() {
        return driver.getTitle();
    }

    /**
     * Gets the current URL.
     *
     * @return the current URL
     */
    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    /**
     * Refreshes the page.
     */
    public void refresh() {
        driver.navigate().refresh();
        wait.waitForPageLoad();
    }

    /**
     * Navigates back.
     */
    public void navigateBack() {
        driver.navigate().back();
        wait.waitForPageLoad();
    }

    /**
     * Navigates to URL.
     *
     * @param url the URL
     */
    public void navigateTo(String url) {
        driver.get(url);
        wait.waitForPageLoad();
    }

    /**
     * Gets the smart wait helper.
     *
     * @return the smart wait helper
     */
    public SmartWaitHelper getWait() {
        return wait;
    }

    /**
     * Gets the web driver.
     *
     * @return the web driver
     */
    public WebDriver getDriver() {
        return driver;
    }
}
