package com.harsha.bureau.infrastructure.selenium.pool;

import com.harsha.bureau.infrastructure.selenium.config.SeleniumConfig;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.pool2.BasePooledObjectFactory;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URL;

/**
 * Factory for creating and managing WebDriver instances in pool.
 */
public class WebDriverFactory extends BasePooledObjectFactory<WebDriver> {

    private static final Logger log = LoggerFactory.getLogger(WebDriverFactory.class);

    private final SeleniumConfig config;

    public WebDriverFactory(SeleniumConfig config) {
        this.config = config;
    }

    @Override
    public WebDriver create() throws Exception {
        log.info("Creating new WebDriver instance");

        ChromeOptions options = new ChromeOptions();

        // Add configured options
        for (String option : config.getBrowser().getOptions()) {
            options.addArguments(option);
        }

        // Headless mode
        if (config.getBrowser().isHeadless()) {
            options.addArguments("--headless=new");
        }

        WebDriver driver;

        if (config.getGrid().isEnabled()) {
            // Use Selenium Grid
            log.debug("Creating RemoteWebDriver for Grid: {}", config.getGrid().getUrl());
            driver = new RemoteWebDriver(new URL(config.getGrid().getUrl()), options);
        } else {
            // Use local ChromeDriver
            log.debug("Creating local ChromeDriver");
            WebDriverManager.chromedriver().setup();
            driver = new org.openqa.selenium.chrome.ChromeDriver(options);
        }

        log.info("WebDriver instance created successfully");
        return driver;
    }

    @Override
    public PooledObject<WebDriver> wrap(WebDriver driver) {
        return new DefaultPooledObject<>(driver);
    }

    @Override
    public void destroyObject(PooledObject<WebDriver> p) throws Exception {
        WebDriver driver = p.getObject();
        log.info("Destroying WebDriver instance");

        try {
            driver.quit();
        } catch (Exception e) {
            log.error("Error destroying WebDriver: {}", e.getMessage());
        }
    }

    @Override
    public boolean validateObject(PooledObject<WebDriver> p) {
        WebDriver driver = p.getObject();

        try {
            // Check if browser is responsive
            String title = driver.getTitle();
            return true;
        } catch (Exception e) {
            log.warn("WebDriver validation failed: {}", e.getMessage());
            return false;
        }
    }

    @Override
    public void passivateObject(PooledObject<WebDriver> p) throws Exception {
        WebDriver driver = p.getObject();
        log.debug("Passivating WebDriver (returning to pool)");

        try {
            // Clear browser state before returning to pool
            clearBrowserState(driver);
        } catch (Exception e) {
            log.warn("Error passivating WebDriver: {}", e.getMessage());
        }
    }

    /**
     * Clears browser state (cookies, storage, navigate to blank).
     *
     * @param driver the WebDriver
     */
    private void clearBrowserState(WebDriver driver) {
        try {
            // Delete all cookies
            driver.manage().deleteAllCookies();

            // Clear local storage and session storage
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.localStorage.clear();");
            js.executeScript("window.sessionStorage.clear();");

            // Navigate to blank page
            driver.get("about:blank");

            log.debug("Browser state cleared");
        } catch (Exception e) {
            log.debug("Error clearing browser state: {}", e.getMessage());
        }
    }
}
