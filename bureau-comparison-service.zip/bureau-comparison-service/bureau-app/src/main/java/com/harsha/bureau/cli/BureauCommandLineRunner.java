package com.harsha.bureau.cli;

import com.harsha.bureau.application.service.BureauProcessingOrchestrator;
import com.harsha.bureau.core.ports.output.WebDriverProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * Command Line Runner for interactive execution.
 * Runs automatically when application starts (if enabled).
 */
@Component
@ConditionalOnProperty(
    name = "bureau.comparison.cli.enabled",
    havingValue = "true",
    matchIfMissing = true
)
public class BureauCommandLineRunner implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(BureauCommandLineRunner.class);

    private final BureauProcessingOrchestrator orchestrator;
    private final WebDriverProvider driverProvider;

    public BureauCommandLineRunner(BureauProcessingOrchestrator orchestrator,
                                   WebDriverProvider driverProvider) {
        this.orchestrator = orchestrator;
        this.driverProvider = driverProvider;
    }

    @Override
    public void run(String... args) throws Exception {
        try {
            log.info("Starting Bureau Comparison System...");

            // Display system info
            displaySystemInfo();

            // Execute interactive workflow
            orchestrator.executeInteractive();

        } catch (Exception e) {
            log.error("Application failed: {}", e.getMessage(), e);
            throw e;
        } finally {
            // Cleanup
            log.info("Shutting down WebDriver pool...");
            driverProvider.shutdown();
            log.info("Application completed.");
        }
    }

    /**
     * Displays system information.
     */
    private void displaySystemInfo() {
        log.info("=".repeat(80));
        log.info("SYSTEM INFORMATION");
        log.info("=".repeat(80));
        log.info("Java Version         : {}", System.getProperty("java.version"));
        log.info("OS                   : {} {}", System.getProperty("os.name"), System.getProperty("os.version"));
        log.info("Available Processors : {}", Runtime.getRuntime().availableProcessors());
        log.info("Max Memory           : {} MB", Runtime.getRuntime().maxMemory() / 1024 / 1024);
        log.info("WebDriver Pool Size  : {}", driverProvider.getPoolSize());
        log.info("=".repeat(80));
    }
}
