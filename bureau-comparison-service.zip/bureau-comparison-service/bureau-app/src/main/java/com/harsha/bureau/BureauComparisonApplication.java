package com.harsha.bureau;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Main Spring Boot Application for Bureau Comparison System.
 * Enterprise-grade, high-performance distributed system.
 *
 * Features:
 * - Parallel processing with 12+ browsers
 * - Reactive processing with Project Reactor
 * - WebDriver pooling with Commons Pool2
 * - Smart dynamic waits (no manual wait specifications)
 * - Page Object Model
 * - Hexagonal Architecture
 * - Interactive HTML + Text reports
 *
 * @author Harsha
 * @version 2.0.0
 */
@SpringBootApplication
@ComponentScan(basePackages = "com.harsha.bureau")
public class BureauComparisonApplication {

    public static void main(String[] args) {
        System.out.println("=".repeat(80));
        System.out.println("Bureau Comparison System v2.0 - Enterprise Edition");
        System.out.println("High-Performance Distributed Processing");
        System.out.println("=".repeat(80));

        SpringApplication.run(BureauComparisonApplication.class, args);
    }
}
