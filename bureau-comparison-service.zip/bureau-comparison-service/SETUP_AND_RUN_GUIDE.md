# Bureau Comparison System - Complete Setup & Run Guide

**Version 2.0.0 - Enterprise Edition**

This guide provides complete step-by-step instructions to set up, configure, and run the Bureau Comparison System.

---

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Installation & Build](#installation--build)
3. [Configuration](#configuration)
4. [Setting Up Selenium Grid](#setting-up-selenium-grid)
5. [Preparing Input Files](#preparing-input-files)
6. [Running the Application](#running-the-application)
7. [Understanding the Output](#understanding-the-output)
8. [Running Tests](#running-tests)
9. [Performance Tuning](#performance-tuning)
10. [Troubleshooting](#troubleshooting)
11. [Advanced Usage](#advanced-usage)

---

## Prerequisites

### Required Software

#### 1. Java Development Kit (JDK)
- **Version**: JDK 17 or higher
- **Download**: https://adoptium.net/
- **Verify Installation**:
```bash
java -version
# Should show: openjdk version "17.0.x" or higher
```

#### 2. Apache Maven
- **Version**: Maven 3.8.0 or higher
- **Download**: https://maven.apache.org/download.cgi
- **Verify Installation**:
```bash
mvn -version
# Should show: Apache Maven 3.8.x or higher
```

#### 3. Google Chrome Browser
- **Version**: Latest stable version
- **Download**: https://www.google.com/chrome/
- **Note**: ChromeDriver will be downloaded automatically by WebDriverManager

### System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| **RAM** | 6 GB | 8 GB or more |
| **CPU** | 4 cores | 8 cores |
| **Disk Space** | 2 GB | 5 GB (for data & reports) |
| **OS** | Windows 10 | Windows 10/11 |
| **Network** | Stable internet | High-speed connection |

---

## Installation & Build

### Step 1: Navigate to Project Directory

```bash
cd C:\Users\bhred\Desktop\bureau-comparison-service
```

### Step 2: Clean and Build Project

```bash
# Clean previous builds
mvn clean

# Build all modules (skip tests for faster build)
mvn install -DskipTests

# OR build with tests
mvn install
```

**Expected Output:**
```
[INFO] ------------------------------------------------------------------------
[INFO] Reactor Summary:
[INFO]
[INFO] Bureau Comparison System ...................... SUCCESS
[INFO] Bureau Common ................................. SUCCESS
[INFO] Bureau Core ................................... SUCCESS
[INFO] Bureau Infrastructure ......................... SUCCESS
[INFO] Bureau Application ............................ SUCCESS
[INFO] Bureau Reporting .............................. SUCCESS
[INFO] Bureau App .................................... SUCCESS
[INFO] Bureau BDD Tests .............................. SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
```

### Step 3: Verify Build

Check that the JAR file was created:
```bash
dir bureau-app\target\bureau-app-2.0.0.jar
```

---

## Configuration

### Configuration Files

The system uses YAML-based configuration with multiple profiles:

- **application.yml** - Main configuration (default settings)
- **application-dev.yml** - Development profile
- **application-prod.yml** - Production profile

### Key Configuration Sections

#### 1. Bureau System Credentials

**File**: `bureau-app/src/main/resources/application.yml`

```yaml
bureau:
  comparison:
    # Base URL of your bureau system
    base-url: "https://your-bureau-application-url.com"

    # Credentials (IMPORTANT: Change these!)
    credentials:
      username: "your_username"
      password: "your_password"
```

⚠️ **IMPORTANT**: Replace with your actual bureau system credentials!

#### 2. Folder Paths

```yaml
bureau:
  comparison:
    folders:
      base-pre: "C:/Bureau_Data/PRE/"      # PRE files folder
      base-post: "C:/Bureau_Data/POST/"    # POST files folder
      output: "C:/Bureau_Data/Output/"     # Output folder for reports
```

**Create these folders before running:**
```bash
mkdir C:\Bureau_Data\PRE
mkdir C:\Bureau_Data\POST
mkdir C:\Bureau_Data\Output
```

#### 3. Performance Settings

```yaml
bureau:
  comparison:
    performance:
      parallelism:
        file-level: 12              # Number of parallel browsers
        io-operations: 10           # Parallel I/O operations

      timeouts:
        extraction: 45              # Seconds per extraction
        comparison: 30              # Seconds per comparison
```

**For 8GB RAM systems**: Keep `file-level: 12` (default)
**For 16GB+ RAM systems**: You can increase to `file-level: 20-24`

#### 4. Selenium Grid Configuration

```yaml
bureau:
  comparison:
    selenium:
      grid:
        enabled: true               # Use Selenium Grid
        url: "http://localhost:4444"

      browser:
        type: "CHROME"
        headless: false             # Set true for production/servers
```

### Environment Variables (Optional)

Override configuration using environment variables:

```bash
# Windows Command Prompt
set BUREAU_USERNAME=your_username
set BUREAU_PASSWORD=your_password
set BUREAU_BASE_PRE=C:/Custom/PRE/
set BUREAU_BASE_POST=C:/Custom/POST/
set BUREAU_OUTPUT=C:/Custom/Output/

# Windows PowerShell
$env:BUREAU_USERNAME="your_username"
$env:BUREAU_PASSWORD="your_password"
```

---

## Setting Up Selenium Grid

Selenium Grid enables parallel browser execution. You need 1 Hub and multiple Nodes.

### Step 1: Download Selenium Server

```bash
cd selenium-grid
download-selenium.bat
```

This downloads `selenium-server-4.15.0.jar` (~70 MB)

### Step 2: Start Selenium Hub

**Open Terminal 1:**
```bash
cd selenium-grid
start-hub.bat
```

**Expected Output:**
```
Selenium Grid Hub is up and running
http://localhost:4444
```

**Verify Hub**: Open browser → http://localhost:4444

### Step 3: Start Selenium Nodes

For **12 parallel browsers**, start **4 nodes** (3 sessions each):

**Open Terminal 2:**
```bash
cd selenium-grid
start-node.bat
```

**Open Terminal 3:**
```bash
cd selenium-grid
start-node.bat
```

**Open Terminal 4:**
```bash
cd selenium-grid
start-node.bat
```

**Open Terminal 5:**
```bash
cd selenium-grid
start-node.bat
```

**Verify Nodes**: Open browser → http://localhost:4444/ui → Should show 4 nodes

### Architecture Diagram

```
┌─────────────────────────────────────────────┐
│         Bureau Comparison Application       │
│              (12 parallel tasks)            │
└──────────────────┬──────────────────────────┘
                   │
                   ▼
         ┌─────────────────┐
         │ Selenium Hub    │
         │ localhost:4444  │
         └────────┬────────┘
                  │
        ┌─────────┼─────────┬─────────┐
        │         │         │         │
        ▼         ▼         ▼         ▼
    ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐
    │Node 1│ │Node 2│ │Node 3│ │Node 4│
    │(3)   │ │(3)   │ │(3)   │ │(3)   │
    └──────┘ └──────┘ └──────┘ └──────┘

    Total: 12 parallel browser sessions
```

---

## Preparing Input Files

### Folder Structure

```
C:/Bureau_Data/
├── PRE/
│   ├── subfolder1/          # Example: "Jan2024"
│   │   ├── file1.xls
│   │   ├── file2.xls
│   │   └── file3.xls
│   └── subfolder2/          # Example: "Feb2024"
│       ├── file4.xls
│       └── file5.xls
│
└── POST/
    ├── subfolder1/          # Same name as PRE
    │   ├── file1.xls
    │   ├── file2.xls
    │   └── file3.xls
    └── subfolder2/
        ├── file4.xls
        └── file5.xls
```

### Excel File Format

Each Excel file should contain application IDs in specific columns:

**Required Columns** (at least one of these):
- `APPID`
- `AppID`
- `appId`
- `Application ID`

**Example Excel Structure:**

| APPID  | Customer Name | Status |
|--------|--------------|--------|
| 123456 | John Doe     | Active |
| 123457 | Jane Smith   | Active |

### File Naming Convention

- Files in PRE and POST folders should have **matching names**
- The system compares files with the same name from both folders
- Supported formats: `.xls`, `.xlsx`

### Category Detection

The system auto-detects category from filename:
- Files containing **"CLI"** → CLI category
- Files containing **"PRQ"** → PRQ category
- All others → **ACQ** category (default)

**Examples:**
- `ACQ_Jan2024.xls` → ACQ category
- `CLI_Applications.xls` → CLI category
- `PRQ_Master_List.xls` → PRQ category

---

## Running the Application

### Method 1: Using Maven (Development)

```bash
cd bureau-app
mvn spring-boot:run
```

### Method 2: Using JAR (Production)

```bash
cd bureau-app\target
java -jar bureau-app-2.0.0.jar
```

### Method 3: Using Specific Profile

**Development Profile:**
```bash
java -jar bureau-app-2.0.0.jar --spring.profiles.active=dev
```

**Production Profile:**
```bash
java -jar bureau-app-2.0.0.jar --spring.profiles.active=prod
```

### Interactive Execution Workflow

When you run the application, you'll see:

```
================================================================================
Bureau Comparison System v2.0 - Enterprise Edition
High-Performance Distributed Processing
================================================================================

  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/

Starting Bureau Comparison System...

================================================================================
SYSTEM INFORMATION
================================================================================
Java Version         : 17.0.8
OS                   : Windows 10 10.0
Available Processors : 8
Max Memory           : 7644 MB
WebDriver Pool Size  : 12
================================================================================

Enter PRE folder name (under C:/Bureau_Data/PRE/):
```

**Step-by-Step Interaction:**

1. **Enter PRE Folder**:
   ```
   Enter PRE folder name (under C:/Bureau_Data/PRE/): Jan2024
   ```

2. **Enter POST Folder**:
   ```
   Enter POST folder name (under C:/Bureau_Data/POST/): Jan2024
   ```

3. **System Processing Begins**:
   ```
   ========================================
   STEP 1: Comparing Application IDs
   ========================================
   Reading PRE files from: C:/Bureau_Data/PRE/Jan2024
   Reading POST files from: C:/Bureau_Data/POST/Jan2024

   Found 50 files in PRE folder
   Found 50 files in POST folder

   Generating AppID comparison Excel...
   ✅ Excel generated: C:/Bureau_Data/Output/APPIDComparison_ALL.xlsx

   ========================================
   STEP 2: Processing Applications
   ========================================
   Total applications to process: 100
   Parallel sessions: 12

   [Progress] 10/100 completed (10%)
   [Progress] 20/100 completed (20%)
   [Progress] 30/100 completed (30%)
   ...
   [Progress] 100/100 completed (100%)

   ========================================
   STEP 3: Generating Reports
   ========================================
   Generating HTML report...
   ✅ HTML report: C:/Bureau_Data/Output/index.html

   Generating text report...
   ✅ Text report: C:/Bureau_Data/Output/MASTER_comparison_report.txt

   ========================================
   PROCESSING COMPLETE
   ========================================
   Total Files: 100
   Matched: 85
   Different: 12
   Failed: 3
   Duration: 52m 34s
   Average: 31.6s per application
   ========================================

   Shutting down WebDriver pool...
   Application completed.
   ```

---

## Understanding the Output

### Output Folder Structure

After processing, the output folder contains:

```
C:/Bureau_Data/Output/
├── index.html                          # Interactive HTML report
├── MASTER_comparison_report.txt        # Legacy text report
├── APPIDComparison_ALL.xlsx            # AppID comparison Excel
├── PRE/                                # Extracted PRE bureau data
│   ├── 123456.txt
│   ├── 123457.txt
│   └── ...
└── POST/                               # Extracted POST bureau data
    ├── 123456.txt
    ├── 123457.txt
    └── ...
```

### 1. HTML Report (index.html)

**Open in browser**: Double-click `index.html`

**Features:**
- **Summary Cards**: Total files, matched, different, failed
- **Filter Controls**:
  - Filter by status (All/Matched/Different/Failed)
  - Filter by category (ACQ/CLI/PRQ)
  - Search by filename or AppID
- **Collapsible Tree**: Click on any file to expand details
- **Clickable File Links**: Click to open PRE/POST files
- **Color-Coded Status**:
  - 🟢 Green = Matched
  - 🟡 Yellow = Different
  - 🔴 Red = Failed
- **Difference Details**: Shows exact differences with line numbers

**Screenshot of HTML Report:**
```
┌─────────────────────────────────────────────────────────┐
│  Bureau Comparison Report                               │
│  ─────────────────────────────────────────────────────  │
│                                                          │
│  📊 Summary                                             │
│  ┌────────┬────────┬──────────┬────────┐               │
│  │ Total  │Matched │Different │ Failed │               │
│  │  100   │   85   │    12    │   3    │               │
│  └────────┴────────┴──────────┴────────┘               │
│                                                          │
│  🔍 Filters                                             │
│  Status: [All ▼]  Category: [All ▼]  Search: [____]    │
│                                                          │
│  📄 Results                                             │
│  ┌─────────────────────────────────────────────┐       │
│  │ ▼ file1.xls                  [MATCHED] 🟢  │       │
│  │   AppID: 123456 | Category: ACQ            │       │
│  │   PRE: 150 lines | POST: 150 lines         │       │
│  │   [Open PRE] [Open POST]                   │       │
│  ├─────────────────────────────────────────────┤       │
│  │ ▼ file2.xls                [DIFFERENT] 🟡  │       │
│  │   AppID: 123457 | Category: CLI            │       │
│  │   Differences: 5                            │       │
│  │   1. CIBIL > Credit Score: 720 → 750       │       │
│  │   2. EXPERIAN > Total Debt: 50000 → 45000  │       │
│  └─────────────────────────────────────────────┘       │
└─────────────────────────────────────────────────────────┘
```

### 2. Text Report (MASTER_comparison_report.txt)

Legacy format report with complete details:

```
===== BUREAU DATA COMPARISON REPORT =====
Generated: 2024-10-30 14:30:45

SUMMARY
=======
Total Applications: 100
Matched: 85 (85.00%)
Different: 12 (12.00%)
Failed: 3 (3.00%)
Total Duration: 52m 34s
Average Time: 31.6s per application

DETAILED RESULTS
================

1. File: file1.xls
   Status: MATCHED
   PRE AppID: 123456
   POST AppID: 123456
   Category: ACQ
   PRE Lines: 150
   POST Lines: 150
   Duration: 28.5s
   ✓ No differences found

2. File: file2.xls
   Status: DIFFERENT
   PRE AppID: 123457
   POST AppID: 123457
   Category: CLI
   PRE Lines: 148
   POST Lines: 152
   Duration: 32.1s

   Differences (5):
   ─────────────────────────────────────
   Section: CIBIL
   Field: Credit Score
   PRE Value: 720
   POST Value: 750
   ─────────────────────────────────────
   Section: EXPERIAN
   Field: Total Debt
   PRE Value: 50000
   POST Value: 45000
   ─────────────────────────────────────
   ...
```

### 3. AppID Comparison Excel (APPIDComparison_ALL.xlsx)

Spreadsheet showing all AppIDs found in PRE and POST files:

| File Name    | PRE AppID | POST AppID | Match Status | Category |
|--------------|-----------|------------|--------------|----------|
| file1.xls    | 123456    | 123456     | ✓ Matched    | ACQ      |
| file2.xls    | 123457    | 123457     | ✓ Matched    | CLI      |
| file3.xls    | 123458    | 123459     | ✗ Different  | ACQ      |
| file4.xls    | 123460    | -          | ✗ Missing    | PRQ      |

### 4. Extracted Bureau Data Files

**PRE/123456.txt Example:**

```
Application ID: 123456
Bureau Type: PRE
Category: ACQ
Extraction Date: 2024-10-30 14:25:10

==================================================
SECTION: CIBIL
==================================================
Credit Score: 720
Account Status: Active
Total Accounts: 5
...

==================================================
SECTION: EXPERIAN
==================================================
Total Debt: 50000
Payment History: Good
...
```

---

## Running Tests

### BDD Tests (Cucumber + TestNG)

#### Run All Tests

```bash
cd bureau-bdd-tests
mvn test
```

#### Run Specific Test Suites

```bash
# Smoke tests only
mvn test -Dcucumber.filter.tags="@Smoke"

# Login tests
mvn test -Dcucumber.filter.tags="@Login"

# Extraction tests
mvn test -Dcucumber.filter.tags="@Extraction"

# Comparison tests
mvn test -Dcucumber.filter.tags="@Comparison"

# Reporting tests
mvn test -Dcucumber.filter.tags="@Reporting"

# All except negative tests
mvn test -Dcucumber.filter.tags="not @Negative"
```

#### Test Reports

After running tests, reports are in:

```
bureau-bdd-tests/target/
├── cucumber-reports/
│   ├── cucumber.html              # Cucumber HTML report
│   ├── cucumber.json              # JSON format
│   └── cucumber.xml               # JUnit XML
└── surefire-reports/
    └── index.html                 # TestNG report
```

**View Reports:**
```bash
# Open in browser
start bureau-bdd-tests\target\cucumber-reports\cucumber.html
```

---

## Performance Tuning

### For Different RAM Configurations

#### 8 GB RAM (Default)
```yaml
performance:
  parallelism:
    file-level: 12
```

#### 16 GB RAM
```yaml
performance:
  parallelism:
    file-level: 20
```

#### 32 GB RAM
```yaml
performance:
  parallelism:
    file-level: 30
```

### Headless Mode (Faster)

For servers or background processing:

```yaml
selenium:
  browser:
    headless: true
```

**Benefits:**
- 10-15% faster execution
- Lower memory usage
- No GUI overhead

### Timeout Adjustments

If experiencing timeout errors:

```yaml
timeouts:
  extraction: 60        # Increase from 45 to 60
  comparison: 45        # Increase from 30 to 45
```

### Retry Configuration

```yaml
retry:
  enabled: true
  max-attempts: 3       # Retry up to 3 times
  backoff-delay: 2000   # Wait 2 seconds between retries
```

---

## Troubleshooting

### Issue 1: "OutOfMemoryError"

**Symptom:**
```
java.lang.OutOfMemoryError: Java heap space
```

**Solution:**
Increase JVM memory:
```bash
java -Xmx6g -jar bureau-app-2.0.0.jar
```

---

### Issue 2: "Cannot connect to Selenium Grid"

**Symptom:**
```
Could not start a new session. Unable to connect to http://localhost:4444
```

**Solution:**
1. Check if Hub is running:
   ```bash
   # Open browser
   http://localhost:4444
   ```

2. Restart Hub:
   ```bash
   cd selenium-grid
   start-hub.bat
   ```

3. Check firewall settings (allow port 4444)

---

### Issue 3: "WebDriver timeout"

**Symptom:**
```
TimeoutException: Expected condition failed
```

**Solution:**
1. Increase timeout in `application.yml`:
   ```yaml
   waits:
     default-explicit: 90  # Increase from 60
   ```

2. Check network connectivity to bureau system

3. Verify bureau system is not down/slow

---

### Issue 4: "Login failed"

**Symptom:**
```
Login failed: Invalid credentials
```

**Solution:**
1. Verify credentials in `application.yml`:
   ```yaml
   credentials:
     username: "correct_username"
     password: "correct_password"
   ```

2. Test credentials manually in browser

3. Check if bureau system requires VPN/special network

---

### Issue 5: "No files found in folder"

**Symptom:**
```
No Excel files found in: C:/Bureau_Data/PRE/Jan2024
```

**Solution:**
1. Check folder path is correct
2. Verify Excel files exist (`.xls` or `.xlsx`)
3. Check file permissions
4. Use absolute paths instead of relative

---

### Issue 6: "Port already in use"

**Symptom:**
```
Address already in use: bind
```

**Solution:**
Find and kill process on port 4444:
```bash
netstat -ano | findstr :4444
taskkill /PID <process_id> /F
```

---

### Issue 7: Slow Performance

**Symptom:**
Taking longer than expected (>90 minutes)

**Solution:**
1. Increase parallel sessions (if you have RAM):
   ```yaml
   parallelism:
     file-level: 16  # Increase from 12
   ```

2. Enable headless mode:
   ```yaml
   browser:
     headless: true
   ```

3. Check network speed to bureau system

4. Close unnecessary applications

5. Verify all Grid nodes are running:
   ```
   http://localhost:4444/ui
   ```

---

## Advanced Usage

### Custom Output Directory

```bash
java -jar bureau-app-2.0.0.jar \
  --bureau.comparison.folders.output=C:/Custom/Output/
```

### Programmatic Usage

You can use the system as a library in your own Java application:

```java
import com.harsha.bureau.application.orchestrator.BureauProcessingOrchestrator;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;

public class CustomBureauProcessor {
    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(
            BureauComparisonApplication.class, args
        );

        BureauProcessingOrchestrator orchestrator =
            context.getBean(BureauProcessingOrchestrator.class);

        // Custom processing logic
        orchestrator.executeInteractive();
    }
}
```

### Scheduled Execution

Run automatically every day at 2 AM:

**Windows Task Scheduler:**
1. Open Task Scheduler
2. Create Basic Task
3. Trigger: Daily at 2:00 AM
4. Action: Start a program
5. Program: `java`
6. Arguments: `-jar C:\Path\To\bureau-app-2.0.0.jar`

### CI/CD Integration

**GitHub Actions Example:**

```yaml
name: Bureau Comparison
on:
  schedule:
    - cron: '0 2 * * *'  # Daily at 2 AM

jobs:
  process:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with:
          java-version: '17'

      - name: Build
        run: mvn clean install -DskipTests

      - name: Start Selenium Grid
        run: |
          cd selenium-grid
          start-hub.bat &
          start-node.bat &

      - name: Run Processing
        run: java -jar bureau-app/target/bureau-app-2.0.0.jar

      - name: Upload Reports
        uses: actions/upload-artifact@v3
        with:
          name: reports
          path: C:/Bureau_Data/Output/
```

---

## Best Practices

### 1. Backup Strategy

Before each run:
```bash
# Backup previous output
xcopy C:\Bureau_Data\Output C:\Bureau_Data\Backup\%date% /E /I
```

### 2. Organize by Date

Use date-based folders:
```
C:/Bureau_Data/
├── PRE/
│   ├── 2024-01-15/
│   ├── 2024-01-16/
│   └── 2024-01-17/
└── POST/
    ├── 2024-01-15/
    ├── 2024-01-16/
    └── 2024-01-17/
```

### 3. Monitor Logs

Check logs for issues:
```bash
tail -f logs/bureau-comparison.log
```

### 4. Regular Maintenance

Weekly tasks:
- Clear old output folders
- Update Chrome browser
- Restart Selenium Grid nodes
- Check available disk space

---

## Quick Reference Commands

### Build & Run
```bash
# Build
mvn clean install -DskipTests

# Run
java -jar bureau-app\target\bureau-app-2.0.0.jar
```

### Selenium Grid
```bash
# Start Hub
cd selenium-grid && start-hub.bat

# Start Node
cd selenium-grid && start-node.bat
```

### Testing
```bash
# All tests
cd bureau-bdd-tests && mvn test

# Smoke tests
mvn test -Dcucumber.filter.tags="@Smoke"
```

### Logs
```bash
# View logs
type logs\bureau-comparison.log

# View errors only
findstr /C:"ERROR" logs\bureau-comparison.log
```

---

## Support & Resources

### Documentation
- **Architecture Guide**: See `README.md`
- **API Documentation**: JavaDoc in each module
- **BDD Tests Guide**: `bureau-bdd-tests/README.md`

### Troubleshooting
- Check `logs/bureau-comparison.log`
- Check `logs/bureau-comparison-error.log`
- Enable DEBUG logging:
  ```yaml
  logging:
    level:
      com.harsha.bureau: DEBUG
  ```

### Performance Monitoring
- **Actuator Endpoints**: http://localhost:8080/actuator/health
- **Metrics**: http://localhost:8080/actuator/metrics
- **Prometheus**: http://localhost:8080/actuator/prometheus

---

## Appendix

### A. Expected Processing Time

| Files | 8GB RAM (12 parallel) | 16GB RAM (20 parallel) |
|-------|-----------------------|------------------------|
| 100   | ~5-8 minutes         | ~3-5 minutes          |
| 500   | ~25-30 minutes       | ~15-20 minutes        |
| 1000  | ~50-60 minutes       | ~30-40 minutes        |
| 4000  | ~200-240 minutes     | ~120-160 minutes      |

### B. Browser Resource Usage

Per browser session:
- **RAM**: ~400-500 MB
- **CPU**: 5-10% per core

Total for 12 sessions:
- **RAM**: ~5-6 GB
- **CPU**: 60-80% utilization

### C. Folder Size Estimates

| Component | Size |
|-----------|------|
| Application JAR | ~150 MB |
| Selenium Server | ~70 MB |
| ChromeDriver | ~10 MB |
| Logs (per run) | ~50-100 MB |
| Reports (per run) | ~10-20 MB |
| Extracted Data (1000 files) | ~200-500 MB |

---

## Changelog

### Version 2.0.0 (2024-10-30)
- ✅ Complete rewrite with Hexagonal Architecture
- ✅ 12 parallel browser sessions
- ✅ Reactive processing with Project Reactor
- ✅ Interactive HTML reports
- ✅ Smart auto-detecting waits
- ✅ 48x performance improvement
- ✅ Comprehensive BDD test coverage

---

**End of Setup & Run Guide**

For additional help, check the main README.md or contact the development team.
