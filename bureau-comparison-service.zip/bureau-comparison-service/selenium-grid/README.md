# Selenium Grid - Standalone Setup (No Docker)

## Quick Start Guide

### Step 1: Download Selenium Server
```bash
download-selenium.bat
```
This downloads `selenium-server-4.15.0.jar` (~10MB)

### Step 2: Start Grid Hub (Terminal 1)
```bash
start-hub.bat
```
- Hub will start on port 4444
- Grid Console: http://localhost:4444/ui
- **Keep this terminal open!**

### Step 3: Start Grid Nodes (Terminals 2-5)
```bash
# Terminal 2
start-node.bat

# Terminal 3
start-node.bat

# Terminal 4
start-node.bat

# Terminal 5
start-node.bat
```

Each node provides **3 browser sessions**, so 4 nodes = **12 parallel browsers**

**Keep all terminals open!**

### Step 4: Verify Grid Status
Open in browser: http://localhost:4444/ui

You should see:
- 1 Hub (running)
- 4 Nodes (connected)
- 12 Available slots

## Scaling Options

### For 8GB RAM (Current Setup):
- **4 nodes** × 3 sessions = **12 parallel browsers** ✅
- Expected time: ~50-60 minutes for 4000 files

### For 16GB RAM:
- **7 nodes** × 3 sessions = **20 parallel browsers**
- Expected time: ~30-40 minutes for 4000 files

### For 32GB RAM:
- **15 nodes** × 3 sessions = **45 parallel browsers**
- Expected time: ~15-20 minutes for 4000 files

## Troubleshooting

### Hub won't start - "Port 4444 already in use"
```bash
# Find process using port 4444
netstat -ano | findstr :4444

# Kill the process (use PID from above command)
taskkill /PID <pid> /F
```

### Node won't connect to Hub
- Ensure Hub is running first
- Check Hub URL: http://localhost:4444
- Verify firewall is not blocking

### Browser not launching
- Update Chrome to latest version
- Ensure ChromeDriver is compatible
- Check PATH environment variable

### Performance issues
- Reduce max-sessions per node (change `MAX_SESSIONS=3` to `2`)
- Start fewer nodes
- Close other applications to free RAM

## Advanced Configuration

### Custom Hub Port
Edit `start-hub.bat`:
```batch
set HUB_PORT=4445
```

### Custom Sessions per Node
Edit `start-node.bat`:
```batch
set MAX_SESSIONS=5  # Increase for more parallelism
```

### Enable Logging
```bash
java -jar selenium-server-4.15.0.jar hub --log-level INFO > hub.log 2>&1
```

## Stopping the Grid

1. Press `Ctrl+C` in each Node terminal
2. Press `Ctrl+C` in Hub terminal
3. All browsers will be closed automatically

## Files Generated

- `selenium-server-4.15.0.jar` - Selenium Server (downloaded)
- `hub.log` - Hub logs (if logging enabled)
- `node.log` - Node logs (if logging enabled)
