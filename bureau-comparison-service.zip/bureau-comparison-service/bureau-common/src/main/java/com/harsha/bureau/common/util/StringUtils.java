package com.harsha.bureau.common.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * String utility methods for bureau data processing.
 */
public final class StringUtils {

    private StringUtils() {
        // Prevent instantiation
    }

    /**
     * Checks if a string is null or empty.
     *
     * @param str the string to check
     * @return true if null or empty
     */
    public static boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

    /**
     * Checks if a string is not null and not empty.
     *
     * @param str the string to check
     * @return true if not null and not empty
     */
    public static boolean isNotEmpty(String str) {
        return !isEmpty(str);
    }

    /**
     * Gets a default value if string is null or empty.
     *
     * @param str the string
     * @param defaultValue the default value
     * @return the string or default value
     */
    public static String defaultIfEmpty(String str, String defaultValue) {
        return isEmpty(str) ? defaultValue : str;
    }

    /**
     * Truncates a string to specified length with ellipsis.
     *
     * @param str the string
     * @param maxLength the maximum length
     * @return truncated string
     */
    public static String truncate(String str, int maxLength) {
        if (str == null) {
            return null;
        }
        if (str.length() <= maxLength) {
            return str;
        }
        return str.substring(0, maxLength - 3) + "...";
    }

    /**
     * Extracts application ID from text content.
     *
     * @param content the content
     * @return the application ID or empty string
     */
    public static String extractAppIdFromContent(String content) {
        if (isEmpty(content)) {
            return "";
        }

        Pattern pattern = Pattern.compile("Application ID:\\s*(\\d+)");
        Matcher matcher = pattern.matcher(content);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return "";
    }

    /**
     * Extracts application ID from filename.
     *
     * @param fileName the filename
     * @return the application ID or empty string
     */
    public static String extractAppIdFromFileName(String fileName) {
        if (isEmpty(fileName)) {
            return "";
        }

        Pattern pattern = Pattern.compile("_(PRE|POST)_(\\d+)\\.txt$");
        Matcher matcher = pattern.matcher(fileName);
        if (matcher.find()) {
            return matcher.group(2);
        }
        return "";
    }

    /**
     * Normalizes a string by trimming and removing extra whitespace.
     *
     * @param str the string
     * @return normalized string
     */
    public static String normalize(String str) {
        if (str == null) {
            return null;
        }
        return str.trim().replaceAll("\\s+", " ");
    }

    /**
     * Removes special characters from a string.
     *
     * @param str the string
     * @return cleaned string
     */
    public static String removeSpecialCharacters(String str) {
        if (str == null) {
            return null;
        }
        return str.replaceAll("[^a-zA-Z0-9\\s]", "");
    }

    /**
     * Pads a string to the right with spaces.
     *
     * @param str the string
     * @param length the target length
     * @return padded string
     */
    public static String padRight(String str, int length) {
        if (str == null) {
            str = "";
        }
        return String.format("%-" + length + "s", str);
    }

    /**
     * Pads a string to the left with spaces.
     *
     * @param str the string
     * @param length the target length
     * @return padded string
     */
    public static String padLeft(String str, int length) {
        if (str == null) {
            str = "";
        }
        return String.format("%" + length + "s", str);
    }

    /**
     * Repeats a string n times.
     *
     * @param str the string
     * @param count the count
     * @return repeated string
     */
    public static String repeat(String str, int count) {
        if (str == null || count <= 0) {
            return "";
        }
        return new String(new char[count]).replace("\0", str);
    }

    /**
     * Checks if a string contains any of the given substrings.
     *
     * @param str the string
     * @param substrings the substrings to check
     * @return true if contains any
     */
    public static boolean containsAny(String str, String... substrings) {
        if (str == null || substrings == null) {
            return false;
        }
        for (String substring : substrings) {
            if (str.contains(substring)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Capitalizes the first letter of a string.
     *
     * @param str the string
     * @return capitalized string
     */
    public static String capitalize(String str) {
        if (isEmpty(str)) {
            return str;
        }
        return str.substring(0, 1).toUpperCase() + str.substring(1).toLowerCase();
    }
}
