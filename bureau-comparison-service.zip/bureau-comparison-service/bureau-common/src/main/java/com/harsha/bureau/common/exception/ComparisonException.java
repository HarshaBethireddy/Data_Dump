package com.harsha.bureau.common.exception;

/**
 * Exception thrown when file comparison fails.
 */
public class ComparisonException extends BureauComparisonException {

    private final String preFilePath;
    private final String postFilePath;

    public ComparisonException(String preFilePath, String postFilePath, String message) {
        super("Comparison failed between " + preFilePath + " and " + postFilePath + ": " + message);
        this.preFilePath = preFilePath;
        this.postFilePath = postFilePath;
    }

    public ComparisonException(String preFilePath, String postFilePath, String message, Throwable cause) {
        super("Comparison failed between " + preFilePath + " and " + postFilePath + ": " + message, cause);
        this.preFilePath = preFilePath;
        this.postFilePath = postFilePath;
    }

    public String getPreFilePath() {
        return preFilePath;
    }

    public String getPostFilePath() {
        return postFilePath;
    }
}
