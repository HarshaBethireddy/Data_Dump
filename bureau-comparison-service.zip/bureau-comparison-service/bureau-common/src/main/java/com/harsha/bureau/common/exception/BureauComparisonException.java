package com.harsha.bureau.common.exception;

/**
 * Base exception for all bureau comparison errors.
 */
public class BureauComparisonException extends RuntimeException {

    public BureauComparisonException(String message) {
        super(message);
    }

    public BureauComparisonException(String message, Throwable cause) {
        super(message, cause);
    }

    public BureauComparisonException(Throwable cause) {
        super(cause);
    }
}
