package com.harsha.bureau.common.exception;

/**
 * Exception thrown when bureau data extraction fails.
 */
public class ExtractionException extends BureauComparisonException {

    private final String applicationId;

    public ExtractionException(String applicationId, String message) {
        super("Extraction failed for AppID " + applicationId + ": " + message);
        this.applicationId = applicationId;
    }

    public ExtractionException(String applicationId, String message, Throwable cause) {
        super("Extraction failed for AppID " + applicationId + ": " + message, cause);
        this.applicationId = applicationId;
    }

    public String getApplicationId() {
        return applicationId;
    }
}
