package com.harsha.bureau.common.util;

import java.io.File;
import java.util.regex.Pattern;

/**
 * Validation utility methods.
 */
public final class ValidationUtils {

    private ValidationUtils() {
        // Prevent instantiation
    }

    private static final Pattern APPID_PATTERN = Pattern.compile("^\\d+$");
    private static final Pattern SAFE_PATH_PATTERN = Pattern.compile("^[a-zA-Z0-9_\\-./:\\\\]+$");

    /**
     * Validates if a string is a valid application ID (numeric).
     *
     * @param appId the application ID
     * @return true if valid
     */
    public static boolean isValidAppId(String appId) {
        return appId != null && APPID_PATTERN.matcher(appId).matches();
    }

    /**
     * Validates if a path is safe (no path traversal attempts).
     *
     * @param path the path
     * @return true if safe
     */
    public static boolean isSafePath(String path) {
        if (path == null || path.trim().isEmpty()) {
            return false;
        }

        // Check for path traversal attempts
        if (path.contains("..")) {
            return false;
        }

        // Check for only allowed characters
        return SAFE_PATH_PATTERN.matcher(path).matches();
    }

    /**
     * Validates if a directory exists and is accessible.
     *
     * @param directoryPath the directory path
     * @return true if valid
     */
    public static boolean isValidDirectory(String directoryPath) {
        if (directoryPath == null || directoryPath.trim().isEmpty()) {
            return false;
        }

        File dir = new File(directoryPath);
        return dir.exists() && dir.isDirectory() && dir.canRead();
    }

    /**
     * Validates if a file exists and is readable.
     *
     * @param filePath the file path
     * @return true if valid
     */
    public static boolean isValidFile(String filePath) {
        if (filePath == null || filePath.trim().isEmpty()) {
            return false;
        }

        File file = new File(filePath);
        return file.exists() && file.isFile() && file.canRead();
    }

    /**
     * Requires that a condition is true, throws IllegalArgumentException otherwise.
     *
     * @param condition the condition
     * @param message the error message
     * @throws IllegalArgumentException if condition is false
     */
    public static void require(boolean condition, String message) {
        if (!condition) {
            throw new IllegalArgumentException(message);
        }
    }

    /**
     * Requires that an object is not null.
     *
     * @param obj the object
     * @param paramName the parameter name
     * @param <T> the type
     * @return the object
     * @throws IllegalArgumentException if null
     */
    public static <T> T requireNonNull(T obj, String paramName) {
        if (obj == null) {
            throw new IllegalArgumentException(paramName + " cannot be null");
        }
        return obj;
    }

    /**
     * Requires that a string is not null or empty.
     *
     * @param str the string
     * @param paramName the parameter name
     * @return the string
     * @throws IllegalArgumentException if null or empty
     */
    public static String requireNonEmpty(String str, String paramName) {
        if (str == null || str.trim().isEmpty()) {
            throw new IllegalArgumentException(paramName + " cannot be null or empty");
        }
        return str;
    }

    /**
     * Validates category name.
     *
     * @param category the category
     * @return true if valid
     */
    public static boolean isValidCategory(String category) {
        if (category == null) {
            return false;
        }
        return category.equals("ACQ") || category.equals("CLI") ||
               category.equals("PRQ") || category.equals("PREQUAL");
    }

    /**
     * Validates bureau name.
     *
     * @param bureauName the bureau name
     * @return true if valid
     */
    public static boolean isValidBureauName(String bureauName) {
        if (bureauName == null) {
            return false;
        }
        return bureauName.equals("Equifax") ||
               bureauName.equals("TransUnion") ||
               bureauName.equals("Experian");
    }

    /**
     * Validates port number.
     *
     * @param port the port
     * @return true if valid (1-65535)
     */
    public static boolean isValidPort(int port) {
        return port > 0 && port <= 65535;
    }

    /**
     * Validates URL format.
     *
     * @param url the URL
     * @return true if valid
     */
    public static boolean isValidUrl(String url) {
        if (url == null || url.trim().isEmpty()) {
            return false;
        }
        return url.startsWith("http://") || url.startsWith("https://");
    }
}
