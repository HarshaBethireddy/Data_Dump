package com.harsha.bureau.common.constant;

/**
 * Bureau-related constants for the application.
 */
public final class BureauConstants {

    private BureauConstants() {
        // Prevent instantiation
    }

    // Bureau Names
    public static final String BUREAU_EQUIFAX = "Equifax";
    public static final String BUREAU_TRANSUNION = "TransUnion";
    public static final String BUREAU_EXPERIAN = "Experian";

    // Bureau Types
    public static final String TYPE_REQUEST = "request";
    public static final String TYPE_RESPONSE = "response";

    // Application ID Keys (for JSON parsing)
    public static final String[] APPID_KEYS = {
        "APPID", "AppID", "AppId", "appId", "appid",
        "APP_ID", "app_id", "APP-ID", "app-id"
    };

    // ID Keys (fallback for JSON parsing)
    public static final String[] ID_KEYS = {
        "id", "ID", "Id", "value", "appId", "APPID"
    };

    // File Extensions
    public static final String EXTENSION_JSON = ".json";
    public static final String EXTENSION_TXT = ".txt";
    public static final String EXTENSION_XLSX = ".xlsx";

    // File Patterns
    public static final String PATTERN_PRE_FILE = "_(PRE|Pre)_";
    public static final String PATTERN_POST_FILE = "_(POST|Post)_";

    // Section Markers in Bureau Data
    public static final String SECTION_SEPARATOR = "==================================================";
    public static final String SECTION_BUREAU_PREFIX = "Bureau: ";
    public static final String SECTION_TYPE_PREFIX = "Type: ";

    // Metadata Fields (to exclude from comparison)
    public static final String METADATA_EXTRACTION_TIME = "Extraction Time:";
    public static final String METADATA_APPLICATION_ID = "Application ID:";
    public static final String METADATA_TYPE = "Type:";

    // Comparison Status
    public static final String STATUS_MATCHED = "MATCHED";
    public static final String STATUS_DIFFERENT = "DIFFERENT";
    public static final String STATUS_FAILED = "FAILED";

    // Default Values
    public static final int DEFAULT_COMPARISON_DISPLAY_LIMIT = 20;
    public static final int DEFAULT_MAX_LINE_LENGTH = 100;

    // Wait Timeouts (seconds)
    public static final int DEFAULT_WAIT_TIMEOUT = 60;
    public static final int SHORT_WAIT_TIMEOUT = 10;
    public static final int LONG_WAIT_TIMEOUT = 120;

    // Retry Configuration
    public static final int DEFAULT_MAX_RETRIES = 3;
    public static final long DEFAULT_RETRY_DELAY_MS = 2000;

    // Thread Sleep Intervals (milliseconds)
    public static final long SLEEP_SHORT = 1000;
    public static final long SLEEP_MEDIUM = 2000;
    public static final long SLEEP_LONG = 3000;

    // Character Typing Delay (milliseconds)
    public static final long TYPING_DELAY_MS = 50;
}
