package com.harsha.bureau.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * File utility methods for bureau data processing.
 */
public final class FileUtils {

    private static final Logger log = LoggerFactory.getLogger(FileUtils.class);
    private static final DateTimeFormatter DIR_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");

    private FileUtils() {
        // Prevent instantiation
    }

    /**
     * Reads file content with automatic charset detection.
     *
     * @param file the file
     * @return the content
     * @throws IOException if read fails
     */
    public static String readFileWithEncoding(File file) throws IOException {
        // Try UTF-8 first
        try {
            String content = Files.readString(file.toPath(), StandardCharsets.UTF_8);
            if (!content.contains("\uFFFD")) {
                return content;
            }
        } catch (Exception e) {
            log.debug("UTF-8 encoding failed for {}, trying Windows-1252", file.getName());
        }

        // Try Windows-1252
        try {
            String content = Files.readString(file.toPath(), Charset.forName("Windows-1252"));
            return content;
        } catch (Exception e) {
            log.debug("Windows-1252 encoding failed for {}, trying ISO-8859-1", file.getName());
        }

        // Fallback to ISO-8859-1
        return Files.readString(file.toPath(), Charset.forName("ISO-8859-1"));
    }

    /**
     * Ensures a directory exists, creating it if necessary.
     *
     * @param directoryPath the directory path
     * @return the created/existing directory path
     * @throws IOException if creation fails
     */
    public static Path ensureDirectoryExists(String directoryPath) throws IOException {
        Path path = Paths.get(directoryPath);
        if (!Files.exists(path)) {
            Files.createDirectories(path);
            log.debug("Created directory: {}", path);
        }
        return path;
    }

    /**
     * Creates a timestamped output directory.
     *
     * @param baseDirectory the base directory
     * @param prefix the directory prefix
     * @return the created directory path
     * @throws IOException if creation fails
     */
    public static Path createTimestampedDirectory(String baseDirectory, String prefix) throws IOException {
        String timestamp = LocalDateTime.now().format(DIR_FORMATTER);
        String dirName = prefix + "_" + timestamp;
        Path path = Paths.get(baseDirectory, dirName);
        Files.createDirectories(path);
        log.info("Created output directory: {}", path);
        return path;
    }

    /**
     * Lists all files in a directory with specified extensions.
     *
     * @param directoryPath the directory path
     * @param extensions the file extensions (e.g., ".json", ".txt")
     * @return list of files
     */
    public static List<File> listFilesWithExtensions(String directoryPath, String... extensions) {
        File directory = new File(directoryPath);
        if (!directory.exists() || !directory.isDirectory()) {
            log.warn("Directory not found: {}", directoryPath);
            return List.of();
        }

        File[] files = directory.listFiles();
        if (files == null) {
            return List.of();
        }

        return Arrays.stream(files)
            .filter(File::isFile)
            .filter(file -> hasExtension(file, extensions))
            .collect(Collectors.toList());
    }

    /**
     * Checks if a file has any of the specified extensions.
     *
     * @param file the file
     * @param extensions the extensions
     * @return true if file has one of the extensions
     */
    private static boolean hasExtension(File file, String... extensions) {
        String fileName = file.getName().toLowerCase();
        for (String ext : extensions) {
            if (fileName.endsWith(ext.toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    /**
     * Calculates SHA-256 hash of file content.
     *
     * @param filePath the file path
     * @return the hash as hex string
     * @throws IOException if read fails
     */
    public static String calculateFileHash(Path filePath) throws IOException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] fileBytes = Files.readAllBytes(filePath);
            byte[] hashBytes = digest.digest(fileBytes);

            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IOException("SHA-256 algorithm not available", e);
        }
    }

    /**
     * Gets file extension.
     *
     * @param fileName the file name
     * @return the extension (e.g., ".json") or empty string
     */
    public static String getFileExtension(String fileName) {
        if (fileName == null) {
            return "";
        }
        int lastDot = fileName.lastIndexOf('.');
        if (lastDot == -1) {
            return "";
        }
        return fileName.substring(lastDot);
    }

    /**
     * Gets file name without extension.
     *
     * @param fileName the file name
     * @return the name without extension
     */
    public static String getFileNameWithoutExtension(String fileName) {
        if (fileName == null) {
            return "";
        }
        int lastDot = fileName.lastIndexOf('.');
        if (lastDot == -1) {
            return fileName;
        }
        return fileName.substring(0, lastDot);
    }

    /**
     * Builds output file path.
     *
     * @param baseFolder the base folder
     * @param category the category
     * @param fileName the file name
     * @param suffix the suffix (e.g., "_PRE_12345")
     * @param extension the extension (e.g., ".txt")
     * @return the full path
     */
    public static String buildOutputFilePath(String baseFolder, String category,
                                             String fileName, String suffix, String extension) {
        return baseFolder + File.separator + category + File.separator +
               fileName + suffix + extension;
    }

    /**
     * Sanitizes a filename by removing invalid characters.
     *
     * @param fileName the file name
     * @return sanitized file name
     */
    public static String sanitizeFileName(String fileName) {
        if (fileName == null) {
            return "";
        }
        return fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    /**
     * Checks if a file exists and is readable.
     *
     * @param filePath the file path
     * @return true if exists and readable
     */
    public static boolean isFileReadable(String filePath) {
        Path path = Paths.get(filePath);
        return Files.exists(path) && Files.isReadable(path) && Files.isRegularFile(path);
    }

    /**
     * Gets human-readable file size.
     *
     * @param filePath the file path
     * @return file size (e.g., "1.5 MB")
     * @throws IOException if read fails
     */
    public static String getHumanReadableFileSize(Path filePath) throws IOException {
        long bytes = Files.size(filePath);
        if (bytes < 1024) return bytes + " B";
        int exp = (int) (Math.log(bytes) / Math.log(1024));
        String pre = "KMGTPE".charAt(exp - 1) + "";
        return String.format("%.1f %sB", bytes / Math.pow(1024, exp), pre);
    }
}
