package com.harsha.bureau.common.constant;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * Category-related constants and menu paths.
 */
public final class CategoryConstants {

    private CategoryConstants() {
        // Prevent instantiation
    }

    // Category Names
    public static final String CATEGORY_ACQ = "ACQ";
    public static final String CATEGORY_CLI = "CLI";
    public static final String CATEGORY_PRQ = "PRQ";
    public static final String CATEGORY_PREQUAL = "PREQUAL";
    public static final String CATEGORY_UNKNOWN = "UNKNOWN";

    // Administrator Group
    public static final String ADMIN_GROUP = "Administrators";

    // Menu Paths for Each Category
    public static final List<String> ACQ_MENU_PATH = Arrays.asList(
        "View Only",
        "Credit Full",
        "All"
    );

    public static final List<String> CLI_MENU_PATH = Arrays.asList(
        "View Only",
        "CLI Credit Full",
        "All"
    );

    public static final List<String> PRQ_MENU_PATH = Arrays.asList(
        "View Only",
        "PreQual Credit Full",
        "All"
    );

    // Category to Menu Path Mapping
    public static final Map<String, List<String>> CATEGORY_MENU_MAP = Map.of(
        CATEGORY_ACQ, ACQ_MENU_PATH,
        CATEGORY_CLI, CLI_MENU_PATH,
        CATEGORY_PRQ, PRQ_MENU_PATH,
        "Prequal", PRQ_MENU_PATH,
        "PreQual", PRQ_MENU_PATH,
        "PREQUAL", PRQ_MENU_PATH
    );

    // Category Keywords (for auto-detection from filename)
    public static final String[] CLI_KEYWORDS = {"CLI", "cli"};
    public static final String[] PRQ_KEYWORDS = {"PRQ", "prq", "PREQUAL", "Prequal", "PreQual"};
    public static final String[] ACQ_KEYWORDS = {"ACQ", "acq"};

    /**
     * Determines category from filename.
     *
     * @param fileName the file name
     * @return the category (ACQ, CLI, PRQ, or UNKNOWN)
     */
    public static String determineCategoryFromFileName(String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            return CATEGORY_UNKNOWN;
        }

        String upperFileName = fileName.toUpperCase();

        // Check CLI first (more specific)
        for (String keyword : CLI_KEYWORDS) {
            if (upperFileName.contains(keyword.toUpperCase())) {
                return CATEGORY_CLI;
            }
        }

        // Check PRQ
        for (String keyword : PRQ_KEYWORDS) {
            if (upperFileName.contains(keyword.toUpperCase())) {
                return CATEGORY_PRQ;
            }
        }

        // Check ACQ
        for (String keyword : ACQ_KEYWORDS) {
            if (upperFileName.contains(keyword.toUpperCase())) {
                return CATEGORY_ACQ;
            }
        }

        // Default to ACQ if no match
        return CATEGORY_ACQ;
    }

    /**
     * Gets menu path for a category.
     *
     * @param category the category
     * @return the menu path
     */
    public static List<String> getMenuPathForCategory(String category) {
        return CATEGORY_MENU_MAP.getOrDefault(category, ACQ_MENU_PATH);
    }
}
