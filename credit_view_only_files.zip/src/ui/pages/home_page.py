from allure import title
from playwright.sync_api import expect
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
import re
import time

from src.ui.pages.base_page import BasePage


class HomePage(BasePage):

    SEARCH_BOX = "textarea[name='q'], input[name='q']"
    USERNAME_INPUT = "#input-username"
    PASSWORD_INPUT = "#input-password"
    LOGIN_BUTTON = "#login-button"
    POWER_CURVE_CASE_MANAGEMENT_BUTTON = "[data-atp-click-asset-title='Home:My Workbench:PlatformTool:PowerCurve Case Management']"
    CONTINUE_BUTTON = "text=Continue"
    POPUP_CONTINUE_BUTTON = "#Continue"
    SEARCH_BUTTON = "span[aria-label='search']"
    OPEN_APPLICATION_BUTTON = "#application-id-0"
    LETTER_HISTORY_BUTTON = "text=Letter History"
    BUREAU_PULL_DROPDOWN = "select[aria-label='Bureau Pull Dropdown']"
    # NumCalls renders as a label/value pair - "NumCalls" is a plain text span, its
    # value sits in a sibling span wrapping a div, both inside one shared container.
    NUMCALLS_LABEL_TEXT = "NumCalls"

    # ---- CRM decision services (crm_search_screen.feature) ----
    # Save on the CRM Decision Services page (Close is reused via click_button("Close")).
    CRM_SAVE_BUTTON = "[data-testid='Save']"
    CRM_SAVE_WAIT_MS = 10000
    # Search-results row link (same ids as OPEN_APPLICATION_BUTTON, which is row 0).
    SEARCH_RESULT_ROWS = "[id^='application-id-']"
    # "Audit log" icon on the search-result row.
    SEARCH_RESULT_AUDIT_ICON = "span[aria-label='assignment']:visible"
    # Audit Trail modal - {app_id} / {index} are filled in per call.
    AUDIT_TRAIL_HEADER = "[data-testid='audit-trail-header-{app_id}']"
    AUDIT_TRAIL_RECORD = "[data-testid='audit-trail-{app_id}-{index}']"
    AUDIT_DETAILS_SEARCH = "[data-testid='audit-trail-details-search']"
    AUDIT_DETAILS_TABLE = "table#auditTrailDetails"
    # Postback confirmation dialog.
    POSTBACK_DIALOG_MESSAGE = "[data-testid='Post-back Successful']"
    POSTBACK_OK_BUTTON = "[data-testid='Ok']:visible"
    # Data Viewer (embedded iframe) - first data-source row is the same row
    # is_data_source_entry_visible() already reads.
    DATA_VIEWER_FRAME = "iframe[title='Embedded Content']"
    DATA_SOURCE_FIRST_ROW = "xpath=//*[@id='host']/div/div[3]/main/div/div[1]/table/tbody/tr[1]"
    # Raw-data content element inside the Data Viewer iframe. The iframe's own HTML was
    # not available when this was written, so this is a best guess - tweak it here if
    # the Request/Response text lives in a different element.
    RAW_DATA_CONTENT_SELECTOR = "pre, code, textarea"
    # Words treated as "error text" in the raw Request data. Tune here if a legitimate
    # field name (e.g. "...ErrorTree") ever triggers a false positive.
    RAW_DATA_ERROR_KEYWORDS = ("error", "exception", "failed", "failure")

    # ---- CRM decision services TC_06-TC_15 ----
    # Solit lookup dialog (ids taken from the supplied HTML).
    SOLIT_DIALOG = "section[role='dialog']:has([data-testid='solit-lookup-close-button'])"
    SOLIT_PROSPECT_ID_INPUT = "[data-testid='prospect-id']"
    SOLIT_SUBMIT_BUTTON = "[data-testid='Submit']"
    SOLIT_CLOSE_BUTTON = "[data-testid='solit-lookup-close-button']"
    # label shown in the dialog -> data-testid of its value (Prospect ID is an input, handled separately).
    SOLIT_VALUE_TESTIDS = {
        "Application ID": "application-id-value",
        "Prequal app ID": "prequal-app-id-value",
        "Rcv date": "rcv-date-value",
    }
    # SSN / Tax ID lookup panel.
    SSN_LOOKUP_LABEL = "[data-testid='ssn-lookup-label']"
    SSN_LOOKUP_OPTIONS = "[data-testid='ssn-lookup-options']"
    SSN_LOOKUP_SUBMIT_BUTTON = "[data-testid='Submit']:visible"
    SSN_LOOKUP_CLOSE_BUTTON = "[data-testid='Close']:visible"
    # Notes side panel.
    RIGHT_SECTION_TOGGLE = "[data-testid='right-section-toggle-button']"
    # Audit Trail grid (main records table).
    AUDIT_TRAIL_TABLE = "table#auditTrail"
    AUDIT_DETAILS_ROWS = "table#auditTrailDetails tbody tr[data-testid^='row-']"

    def is_search_box_visible(self) -> bool:
        return self.page.locator(self.SEARCH_BOX).first.is_visible()

    def enter_username(self, username: str) -> None:
        self.page.locator(self.USERNAME_INPUT).fill(username)

    def enter_password(self, password: str) -> None:
        self.page.locator(self.PASSWORD_INPUT).fill(password)

    def click_login(self) -> None:
        self.page.locator(self.LOGIN_BUTTON).click()

    def click_powercurve_case_management(self) -> None:
        self.page.locator(self.POWER_CURVE_CASE_MANAGEMENT_BUTTON).click()
    
    def click_continue(self) -> None:
        self.page.locator(self.CONTINUE_BUTTON).click()

    def click_search(self) -> None:
        self.page.locator(self.SEARCH_BUTTON).click()

    def click_open_application(self) -> None:
        self.page.locator(self.OPEN_APPLICATION_BUTTON).click()
        self.page.wait_for_load_state("networkidle")
        self.page.wait_for_timeout(1200)
        continue_button = self.page.locator(self.POPUP_CONTINUE_BUTTON)
        try:
            # Bounded wait: the Continue popup is optional, so don't hang the test if it never appears.
            continue_button.wait_for(state="visible", timeout=5000)
        except PlaywrightTimeoutError:
            return
        continue_button.click()

    def click_letter_history(self) -> None:
        self.page.locator(self.LETTER_HISTORY_BUTTON).click()

    def navigate_to_credit_page(self, credit_page: str) -> None:
        self.page.get_by_text(credit_page, exact=True).click()
        self.page.wait_for_load_state("networkidle")

    def select_credit_page_option(self, option: str) -> None:
        self.page.get_by_text(option, exact=True).click()
        self.page.wait_for_load_state("networkidle")

    def is_credit_view_column_visible(self, column_name: str, max_scroll_attempts: int = 15) -> bool:
        # The grid's accessible name varies per Option (e.g. "credit-view-quick" vs the
        # "Credit full" view's own name), so target whichever data table is on screen.
        credit_view_table = self.page.get_by_role("table").first
        # Column header casing in the UI doesn't always match the feature file (e.g. "My apps" vs "My Apps").
        pattern = re.compile(rf"^{re.escape(column_name)}$", re.IGNORECASE)
        column_header = credit_view_table.get_by_text(pattern).first
        if column_header.is_visible():
            return True

        # The table's own horizontal scrollbar only shows up once the page is scrolled
        # down to the table, so scroll it into view first before scrolling sideways.
        credit_view_table.scroll_into_view_if_needed()
        box = credit_view_table.bounding_box()
        if box is None:
            return False
        self.page.mouse.move(box["x"] + box["width"] / 2, box["y"] + box["height"] / 2)

        get_scroll_left = """(table) => {
            let el = table;
            while (el && el !== document.body) {
                if (el.scrollWidth > el.clientWidth + 1) return el.scrollLeft;
                el = el.parentElement;
            }
            return null;
        }"""
        previous_scroll_left = None
        for _ in range(max_scroll_attempts):
            self.page.mouse.wheel(400, 0)
            self.page.wait_for_timeout(300)
            if column_header.is_visible():
                return True
            scroll_left = credit_view_table.evaluate(get_scroll_left)
            if scroll_left is not None and scroll_left == previous_scroll_left:
                break  # reached the end of the scrollable area
            previous_scroll_left = scroll_left
        return column_header.is_visible()

    def is_section_visible(self, section_name: str) -> bool:
        # Accordion sections (e.g. "Applicant & Business info") render as <h2> headings,
        # not inside the data grid, so look them up by heading role rather than table text.
        heading = self.page.get_by_role("heading", name=section_name, exact=True).first
        heading.scroll_into_view_if_needed()
        return heading.is_visible()

    def click_existing_customer_field(self) -> None:
        self.page.get_by_text("Existing Customer", exact=True).click()
        self.page.wait_for_load_state("networkidle")

    def click_close_button_on_existing_customer_page(self) -> None:
        self.page.get_by_text("Close", exact=True).click()
        self.page.wait_for_load_state("networkidle")

    def click_close_button_on_letter_history_page(self) -> None:
        self.page.get_by_text("Close", exact=True).click()
        self.page.wait_for_load_state("networkidle")

    def click_data_viewer(self) -> None:
        try:
            data_viewer_button = self.page.get_by_text("Data Viewer", exact=True).first
            data_viewer_button.wait_for(state="visible", timeout=10000)
            try:
                data_viewer_button.scroll_into_view_if_needed(timeout=5000)
            except:
                # If scroll fails, just try clicking anyway
                pass
            data_viewer_button.click()
        except Exception as e:
            print(f"Error clicking Data Viewer: {str(e)}")
            # Try alternative selector as fallback
            try:
                alt_button = self.page.locator("button:has-text('Data Viewer')").first
                alt_button.wait_for(state="visible", timeout=5000)
                try:
                    alt_button.scroll_into_view_if_needed(timeout=5000)
                except:
                    pass
                alt_button.click()
            except Exception as e2:
                print(f"Fallback Data Viewer click also failed: {str(e2)}")
                # Try one more alternative
                try:
                    third_attempt = self.page.locator("*:has-text('Data Viewer')").first
                    third_attempt.click(force=True)
                except Exception as e3:
                    print(f"All Data Viewer click attempts failed: {str(e3)}")
                    raise

    def is_data_viewer_page_displayed(self) -> bool:
        # The Data Viewer page title renders as a plain product-name div, not a heading.
        # Data Viewer polls for live bureau data continuously, so it never reaches
        # networkidle - don't wait on that here, the locator's own auto-wait is enough.
        title = self.page.get_by_text("Data Viewer", exact=True).first
        title.scroll_into_view_if_needed()
        return title.is_visible()

    def click_close_button_on_data_viewer(self) -> None:
        # Existing Customer/Letter History panels can leave their own now-hidden
        # "[aria-label='close']" icon mounted in the DOM, so an unscoped locator can
        # resolve to one of those instead of Data Viewer's - filter to the visible one.
        close_button = self.page.locator('[aria-label="close"]:visible').first
        close_button.scroll_into_view_if_needed()
        close_button.click()
        self.page.wait_for_timeout(15000)

    def is_button_visible(self, button_name: str) -> bool:
        # Buttons render their label as a plain div (e.g. class "wyfr-button___label"),
        # not a native <button>, so match on text rather than role.
        button = self.page.get_by_text(button_name, exact=True).first
        button.scroll_into_view_if_needed()
        return button.is_visible()

    def click_button(self, button_name: str) -> None:
        button = self.page.get_by_text(button_name, exact=True).first
        button.scroll_into_view_if_needed()
        button.click()

    def click_bureau_pull_dropdown(self) -> None:
        self.page.locator(self.BUREAU_PULL_DROPDOWN).click()

    def select_bureau_pull_option(self, bureau: str) -> None:
        # Native <select> element - use select_option rather than click (e.g. "Equifax", "Experian", "Transunion").
        self.page.locator(self.BUREAU_PULL_DROPDOWN).select_option(label=bureau)

    def is_bureau_option_visible(self, bureau: str) -> bool:
        # <option> elements of a native <select> have no box/aren't "visible" to Playwright
        # unless the dropdown is actually open, so check DOM presence instead of visibility.
        option = self.page.locator(f"{self.BUREAU_PULL_DROPDOWN} option", has_text=bureau).first
        return option.count() > 0

    def click_call_bureau_button(self) -> None:
        self.page.get_by_text("Call Bureau", exact=True).first.scroll_into_view_if_needed()
        self.page.get_by_text("Call Bureau", exact=True).first.click()

    def click_continue_on_popup_alert(self, timeout: int = 10000) -> None:
        # Popup is optional (bureau call doesn't always trigger it) - don't fail the
        # test if it never shows up within the wait window, just skip the click.
        continue_button = self.page.get_by_text("Continue", exact=True).first
        try:
            self.page.wait_for_timeout(3000)
            continue_button.wait_for(state="visible", timeout=timeout)
        except PlaywrightTimeoutError:
            return
        continue_button.scroll_into_view_if_needed()
        continue_button.click()
        self.page.wait_for_timeout(15000)

    def get_numcalls_value(self) -> int:
        label = self.page.get_by_text(self.NUMCALLS_LABEL_TEXT, exact=True).first
        label.scroll_into_view_if_needed()
        numcalls_field = label.locator("xpath=..").locator("div").first
        # Cell can briefly render empty while the grid repopulates - poll for real text.
        deadline = time.monotonic() + 10
        text = numcalls_field.inner_text().strip()
        while not text and time.monotonic() < deadline:
            self.page.wait_for_timeout(500)
            text = numcalls_field.inner_text().strip()
        return int(text)

    def is_numcalls_incremented(self, previous_value: int) -> bool:
        # Bureau call completes asynchronously - give the network response and grid
        # refresh time to land before re-reading NumCalls (bounded, won't hang if the
        # page never reaches networkidle).
        try:
            self.page.wait_for_timeout(10000)
        except PlaywrightTimeoutError:
            pass
        self.page.wait_for_timeout(10000)
        return self.get_numcalls_value() == previous_value + 1

    def is_data_source_entry_visible(self, data_source: str) -> bool:
        # Data Viewer's table lives inside an embedded iframe, not the top-level page.
        self.page.wait_for_timeout(10000)
        frame = self.page.frame_locator("iframe[title='Embedded Content']")
        entry = frame.locator("xpath=//*[@id='host']/div/div[3]/main/div/div[1]/table/tbody/tr[1]/td[1]")
        entry.scroll_into_view_if_needed()
        return entry.inner_text().strip() == data_source


    def click_change_bureau_decision_button(self) -> None:
        button = self.page.get_by_text("Change Decision Bureau", exact=True).first
        button.scroll_into_view_if_needed()
        button.click()
    
    def scroll_to_credit_report_section(self) -> None:
        # Renders as an <h2> heading (like other accordion sections), not a plain text div.
        section = self.page.get_by_role("heading", name="Credit report viewer", exact=True).first
        section.scroll_into_view_if_needed()

    def is_tty_report_generated(self) -> bool:
        # TTY report is expected to be present in the Credit report section.
        self.scroll_to_credit_report_section()
        report = self.page.get_by_role("heading", name="TTY report", exact=True).first
        report.scroll_into_view_if_needed()
        return report.is_visible()

    def get_credit_report_text(self) -> str:
        viewer = self.page.locator('div[aria-label="Credit Report Viewer content"]')
        viewer.scroll_into_view_if_needed()
        return viewer.inner_text()

    def is_fico_score_displayed(self) -> bool:
        self.page.wait_for_timeout(10000)
        self.scroll_to_credit_report_section()
        report_text = self.get_credit_report_text()
        return "FICO SCORE" in report_text.upper()

    def is_vantage_score_displayed(self) -> bool:
        self.page.wait_for_timeout(10000)
        self.scroll_to_credit_report_section()
        report_text = self.get_credit_report_text()
        return "VANTAGE SCORE" in report_text.upper()


    def are_no_errors_displayed(self) -> bool:
        self.page.wait_for_timeout(10000)
        report_text = self.get_credit_report_text()
        return "ERROR" not in report_text.upper()

    def scroll_to_preciseid_summary(self) -> None:
        # Renders as an <h2> heading (like other accordion sections), not a plain text div.
        section = self.page.get_by_role("heading", name="PreciseID summary", exact=True).first
        section.scroll_into_view_if_needed()

    def click_call_pid_button(self) -> None:
        button = self.page.locator("#Call-PID")
        button.scroll_into_view_if_needed()
        button.click()
        self.page.wait_for_timeout(10000)
        yes_button = self.page.get_by_text("Yes", exact=True).first
        try:
            # Confirmation popup is optional - don't hang the test if it never appears.
            yes_button.wait_for(state="visible", timeout=5000)
        except PlaywrightTimeoutError:
            return
        yes_button.click()
        self.page.wait_for_timeout(10000)

    def navigate_to_applicant_and_business_info_section(self) -> None:
        section = self.page.get_by_role("heading", name="Applicant & Business info", exact=True).first
        section.scroll_into_view_if_needed()

    def click_edit_applicant_data_button(self) -> None:
        button = self.page.locator("#Edit-applicant-data")
        button.scroll_into_view_if_needed()
        button.click()
        self.page.wait_for_timeout(10000)

    def is_edit_applicant_data_button_displayed(self) -> bool:
        button = self.page.locator("#Edit-applicant-data")
        button.scroll_into_view_if_needed()
        return button.is_visible()

    def is_edit_applicant_page_displayed(self) -> bool:
        heading = self.page.get_by_role("heading", name="Edit Applicant", exact=True).first
        heading.scroll_into_view_if_needed()
        return heading.is_visible()

    def edit_application_address_primary_phone(self, phone: str) -> None:
        edit_button = self.page.locator("xpath=//*[@id='edit-btn-Application-address']/div/div/div[1]/div")
        edit_button.scroll_into_view_if_needed()
        edit_button.click()
        phone_input = self.page.locator("#HomePhone")
        phone_input.scroll_into_view_if_needed()
        phone_input.fill("")
        phone_input.fill(phone)
        save_button = self.page.locator("xpath=//*[@id='card-check-Application-address']/div/div/div")
        save_button.scroll_into_view_if_needed()
        save_button.click()
        Emedit_button = self.page.locator("//*[@id='edit-btn-Employment']/div/div/div[1]/div")
        Emedit_button.scroll_into_view_if_needed()
        Emedit_button.click()
        source_of_income = self.page.get_by_label("Source of income")
        source_of_income.scroll_into_view_if_needed()
        source_of_income.select_option(label="Homemaker")
        occupation = self.page.get_by_label("Occupation")
        occupation.scroll_into_view_if_needed()
        occupation.select_option(label="Homemaker")
        Emsave_button = self.page.locator("//*[@id='card-check-Employment']/div/div/div")
        Emsave_button.scroll_into_view_if_needed()
        Emsave_button.click()
        BTedit_button = self.page.locator("//*[@id='edit-btn-Balance-transfer-requests']/div/div/div[1]/div")
        BTedit_button.scroll_into_view_if_needed()
        BTedit_button.click()

        for index, value in enumerate(["10", "20", "30"], start=1):
            field = self.page.locator(f"//*[@id='ACQResults-DV.RSL5.Approved-Bal-Xfer-{index}']")
            field.scroll_into_view_if_needed()
            field.fill("")
            field.fill(value)

        for index, value in enumerate(["1500", "20", "30"], start=1):
            field = self.page.locator(f"//*[@id='Application-DV.BT_AmountRequested_{index}']")
            field.scroll_into_view_if_needed()
            field.fill("")
            field.fill(value)

        for index in range(1, 4):
            field = self.page.locator(f"//*[@id='Application-DV.BT_FromAccountNumber_{index}']")
            field.scroll_into_view_if_needed()
            field.fill("")
            field.fill("string_7878790")

        BTsave_button = self.page.locator("//*[@id='card-check-Balance-transfer-requests']/div/div/div")
        BTsave_button.scroll_into_view_if_needed()
        BTsave_button.click()

        # Overall page Save sits above the edited sections - scroll back up to reach it.
        self.page.mouse.wheel(0, -5000)
        save_button = self.page.get_by_text("Save", exact=True).first
        save_button.scroll_into_view_if_needed()
        save_button.click()
        
    def are_no_errors_popup_displayed(self) -> bool:
        # Error alert's id (e.g. ":ro:") is auto-generated and changes per render - match on its class/text instead.
        error_popup = self.page.locator("h1.wyfr-alert-content___error", has_text="Error").first
        return not error_popup.is_visible()

    def execute_pid_calls(self):
        
        #-------------Fail bypass---
        Exit_button = self.page.locator("text=Exit").first
        Exit_button.scroll_into_view_if_needed()
        Exit_button.click()
        self.page.wait_for_timeout(5000)
        ok_button = self.page.locator("//*[@id='Ok']/div/div").first
        ok_button.wait_for(state="visible")
     
        #-------------Fail bypass---

        # Execute PID calls 3 times
        for i in range(3):
            call_pid_button = self.page.locator("text=Call PID").first
            call_pid_button.scroll_into_view_if_needed()
            call_pid_button.click()
            
            # Wait 15 seconds for a popup to appear
            try:
                yes_button = self.page.locator("text=Yes").first
                yes_button.wait_for(state="visible", timeout=15000)
                # If popup appeared, click "Yes"
                yes_button.click()
            except PlaywrightTimeoutError:
                # No popup appeared within 15 seconds, continue
                pass
            
            # Wait for page load to complete
            self.page.wait_for_load_state("networkidle")


    def click_save_and_exit_button(self):
        save_and_exit_button = self.page.locator("text=Save & exit").first
        save_and_exit_button.scroll_into_view_if_needed()
        save_and_exit_button.click()

    def click_alter_button(self):
        alter_button = self.page.locator("text=Alter").first
        alter_button.scroll_into_view_if_needed()
        alter_button.click()
        self.page.wait_for_timeout(10000)

    def is_alter_screen_displayed(self) -> bool:
        alter_screen = self.page.locator("h1[data-testid='page-main-title']:has-text('Alter')").first
        self.page.wait_for_timeout(5000)
        return alter_screen.is_visible()


    def select_manual_decision(self, decision: str = "Refer"):
        # Click the edit button to enable the dropdown
        edit_button = self.page.locator("//*[@id='edit-btn-Decision']/div/div/div[1]/div").first
        try:
            edit_button.scroll_into_view_if_needed(timeout=5000)
        except:
            pass
        edit_button.click()
        self.page.wait_for_timeout(500)
        
        # Select the manual decision dropdown and choose the option
        manual_decision_dropdown = self.page.locator("//*[@id='WS-Screen.Alter-Screen-Data.ManualDecision']").first
        try:
            manual_decision_dropdown.scroll_into_view_if_needed(timeout=5000)
        except:
            pass
        manual_decision_dropdown.select_option(label=decision)

    def select_refer_checkboxes_and_confirm(self):
        # Wait a bit for the checkboxes to become available after selecting Refer
        self.page.wait_for_timeout(1000)
        
        # Select "Refer To Fraud" checkbox by clicking the label
        refer_to_fraud_label = self.page.locator("label[for='WS-Screen.Alter-Screen-Data.ReferToCredit[0]']").first
        try:
            refer_to_fraud_label.scroll_into_view_if_needed(timeout=5000)
        except:
            pass
        
        # Wait for label to be visible
        try:
            refer_to_fraud_label.wait_for(state="visible", timeout=10000)
        except Exception as e:
            print(f"ReferToFraud label not visible: {str(e)}")
            raise
        
        # Click the label to check the checkbox
        refer_to_fraud_label.click()
        self.page.wait_for_timeout(500)
        
        # Verify checkbox is checked
        refer_to_fraud_checkbox = self.page.locator("label[for='WS-Screen.Alter-Screen-Data.ReferToCredit[0]']").first
        is_fraud_checked = refer_to_fraud_checkbox.is_checked()
        print(f"Refer To Fraud checked: {is_fraud_checked}")
        
        # Select "Refer To KYC" checkbox by clicking the label
        refer_to_kyc_label = self.page.locator("label[for='WS-Screen.Alter-Screen-Data.ReferToKYC[0]']").first
        try:
            refer_to_kyc_label.scroll_into_view_if_needed(timeout=5000)
        except:
            pass
        
        # Wait for label to be visible
        try:
            refer_to_kyc_label.wait_for(state="visible", timeout=10000)
        except Exception as e:
            print(f"ReferToKYC label not visible: {str(e)}")
            raise
        
        # Click the label to check the checkbox
        refer_to_kyc_label.click()
        self.page.wait_for_timeout(500)
        
        # Verify checkbox is checked
        refer_to_kyc_checkbox = self.page.locator("//*[@id='WS-Screen.Alter-Screen-Data.ReferToKYC[0]']").first
        is_kyc_checked = refer_to_kyc_checkbox.is_checked()
        print(f"Refer To KYC checked: {is_kyc_checked}")
        
        # Click the confirmation button (check_circle icon)
        confirm_button = self.page.locator("div.wyfr-disc___item span.material-icons:text-is('check_circle')").first
        try:
            confirm_button.scroll_into_view_if_needed(timeout=5000)
        except:
            pass
        confirm_button.wait_for(state="visible")
        confirm_button.click()
        
        # Wait for page load after confirmation
        self.page.wait_for_load_state("networkidle")


    def click_save_button(self):
        save_button = self.page.locator("text=Save").first
        save_button.scroll_into_view_if_needed()
        save_button.click()
        self.page.wait_for_timeout(10000)
        try:
                yes_button = self.page.locator("text=Yes").first
                yes_button.wait_for(state="visible", timeout=15000)
                # If popup appeared, click "Yes"
                yes_button.click()
        except PlaywrightTimeoutError:
                # No popup appeared within 15 seconds, continue
                pass
                self.page.wait_for_timeout(10000)
    
    def is_no_errors_in_data_viewer(self) -> bool:
        # Check for errors in the Data Viewer iframe
        # The iframe has title="Embedded Content"
        try:
            # First, try to find error elements in the main page
            self.page.wait_for_timeout(10000)
            error_alert = self.page.locator("h1.wyfr-alert-content___error", has_text="Error").first
            if error_alert.is_visible():
                print(f"Error found in main page: {error_alert.text_content()}")
                return False
            
            # Try to find the iframe with title "Embedded Content"
            iframe = self.page.locator("iframe[title='Embedded Content']").first
            if iframe.is_visible():
                # Access the iframe's content
                frame = iframe.content_frame()
                
                # Check for error text in the iframe
                error_texts = ["error", "failed", "Error", "Failed", "ERROR", "FAILED"]
                for error_text in error_texts:
                    error_element = frame.locator(f"text=/{error_text}/i").first
                    if error_element.is_visible():
                        print(f"Error found in Data Viewer iframe: {error_text}")
                        return False
            
            print("No errors found in Data Viewer")
            return True
            
        except Exception as e:
            print(f"Error checking for errors in Data Viewer: {str(e)}")
            return True  # Don't fail if we can't check


    def select_decline_reason_code(self, reason_code: str):
        # Dropdown's actual option value is just the short code (e.g. "NAI"); feature
        # files pass the full label ("NAI - Needs Add'l Info"), so extract the code.
        code = reason_code.split(" - ")[0].strip()
        # Locate the Decline Reason Code dropdown by its exact ID
        dropdown = self.page.locator("select#WS-Screen\\.Alter-Screen-Data\\.ManualDecisionRC").first
        try:
            dropdown.scroll_into_view_if_needed(timeout=5000)
        except:
            pass
        # Custom-styled <select> stays visually hidden behind its own widget, so wait
        # for DOM attachment rather than visibility, and force the selection.
        dropdown.wait_for(state="attached", timeout=15000)
        dropdown.select_option(value=code, force=True)
        self.page.wait_for_timeout(5000)
    
    def select_letter_code(self, letter_code: str):
        # Dropdown's actual option value is just the short code (e.g. "AICC"); feature
        # files pass the full label ("AICC - Credit Contact"), so extract the code.
        code = letter_code.split(" - ")[0].strip()
        # Locate the Letter Code dropdown by its exact ID
        dropdown = self.page.locator("//*[@id='WS-Screen.Alter-Screen-Data.LetterSelection1']").first
        try:
            dropdown.scroll_into_view_if_needed(timeout=5000)
        except Exception as e:
            if "scroll_into_view_if_needed" in str(e):
                pass
        # Custom-styled <select> stays visually hidden behind its own widget, so wait
        # for DOM attachment rather than visibility, and force the selection.
        dropdown.wait_for(state="attached", timeout=15000)
        dropdown.select_option(value=code, force=True)
        self.page.wait_for_timeout(500)

    def click_on_save_button(self):
        save_button = self.page.locator("button:has-text('Save')").first
        try:
            save_button.scroll_into_view_if_needed(timeout=5000)
        except:
            pass
        save_button.wait_for(state="visible")
        save_button.click()
        self.page.wait_for_timeout(500)
        # Confirmation popup renders its label as a plain div, not an element with id="Yes".
        yes_button = self.page.get_by_text("Yes", exact=True).first
        try:
            # Confirmation popup is optional - don't hang the test if it never appears.
            yes_button.wait_for(state="visible", timeout=15000)
        except PlaywrightTimeoutError:
            return
        yes_button.click()
        self.page.wait_for_timeout(15000)

    def is_fraud_check_button_enabled(self):
        try:
            button = self.page.locator("//*[@id='Fraud-check']/div/div/div/div").first
            button.wait_for(state="visible", timeout=10000)
            return button.is_enabled()
        except Exception as e:
            print(f"Error checking if Fraud Check button is enabled: {str(e)}")
            return False
        
    def click_fraud_check_button(self):
        button = self.page.locator("//*[@id='Fraud-check']/div/div/div/div").first
        try:
            button.scroll_into_view_if_needed(timeout=5000)
        except:
            pass
        button.wait_for(state="visible")
        button.click()
        self.page.wait_for_timeout(500)
        # Confirmation popup renders its label as a plain div, not an element with id="Yes".
        yes_button = self.page.get_by_text("Yes", exact=True).first
        try:
            # Confirmation popup is optional - don't hang the test if it never appears.
            yes_button.wait_for(state="visible", timeout=15000)
        except PlaywrightTimeoutError:
            return
        yes_button.click()
        self.page.wait_for_timeout(15000)

    def click_submit_button(self):
        submit_button = self.page.locator("//*[@id='submit-button']/div/div/div/div").first
        comment_box = self.page.locator("//*[@id='comment-box']").first
        add_button = self.page.locator("//*[@id='add-icon']/div/div/div/div").first
        continue_button = self.page.locator("//*[@id='Continue']/div/div/div/div").first
        try:
            submit_button.scroll_into_view_if_needed(timeout=5000)
        except:
            pass
        submit_button.wait_for(state="visible")
        comment_box.fill("")
        comment_box.fill("Opened Application-Automation")
        add_button.click()
        submit_button.click()
        continue_button.click()
        self.page.wait_for_timeout(500)

    def uncheck_all_queue_assignment_checkboxes(self):
        checkboxes = self.page.locator("//*[@id='uncheck-credit-button']/div/div/div/div")
        checkboxes.click()

    def click_submit_application_button(self):
        submit_application_button = self.page.get_by_text("Submit application").first
        Ok_button = self.page.get_by_text("Ok", exact=True).first
        try:
            submit_application_button.scroll_into_view_if_needed(timeout=5000)
        except:
            pass
        submit_application_button.wait_for(state="visible")
        submit_application_button.click()
        self.page.wait_for_timeout(5000)
        Ok_button.click()
        self.page.wait_for_timeout(10000)

    def search_application_and_validate_status(self, status: str) -> None:
        status_cell = self.page.locator("//*[@id='credit-view-quick']/tbody/tr/td[12]")
        expect(status_cell).to_have_text(status)

    def enter_notes_in_notes_section(self):
        comment_box = self.page.locator("//*[@id='comment-box']").first
        comment_box.fill("")
        comment_box.fill("Automation Note")

    def click_add_button(self):
        add_button = self.page.locator("//*[@id='add-icon']/div/div/div/div").first
        try:
            add_button.scroll_into_view_if_needed(timeout=5000)
        except:
            pass
        add_button.wait_for(state="visible")
        add_button.click()
        self.page.wait_for_timeout(500)

    def click_attachment_button_in_notes_section(self):
        attachment_button = self.page.locator("//*[@id='clip-icon']/div/div/div").first
        try:
            attachment_button.scroll_into_view_if_needed(timeout=5000)
        except:
            pass
        attachment_button.wait_for(state="visible")
        attachment_button.click()
        self.page.wait_for_timeout(500)

    def upload_file(self, file_path):
        file_path = str(file_path)
        # Setting files on the hidden input avoids opening the native Windows dialog at all.
        file_input = self.page.locator("input[type='file']")
        if file_input.count() > 0:
            file_input.first.set_input_files(file_path)
        else:
            upload_button = self.page.locator("[data-testid='upload-icon']").first
            upload_button.wait_for(state="visible")
            with self.page.expect_file_chooser(timeout=10000) as fc_info:
                upload_button.click()
            fc_info.value.set_files(file_path)
        self.page.wait_for_timeout(500)
        comment_box = self.page.locator("textarea[data-testid='comment-box']").first
        comment_box.wait_for(state="attached")
        comment_box.scroll_into_view_if_needed()
        comment_box.fill("Upload Automation Note")
        add_button = self.page.locator("//*[@id='add-icon']/div/div/div/div").first
        try:
            add_button.scroll_into_view_if_needed(timeout=5000)
        except:
            pass
        add_button.wait_for(state="visible")
        add_button.click()
        self.page.wait_for_timeout(5000)
        

    # ------------------------------------------------------------------
    # CRM decision services - Save, search results, Audit Trail, Postback,
    # Data Viewer raw data (added for crm_search_screen.feature)
    # ------------------------------------------------------------------

    def click_crm_save_and_wait(self) -> None:
        save_button = self.page.locator(self.CRM_SAVE_BUTTON).first
        save_button.scroll_into_view_if_needed()
        save_button.click()
        try:
            # Bounded: the page may keep polling and never go fully idle.
            self.page.wait_for_load_state("networkidle", timeout=10000)
        except PlaywrightTimeoutError:
            pass
        self.page.wait_for_timeout(self.CRM_SAVE_WAIT_MS)

    def get_search_result_application_ids(self) -> list[str]:
        self.page.locator(self.OPEN_APPLICATION_BUTTON).wait_for(state="visible")
        return [text.strip() for text in self.page.locator(self.SEARCH_RESULT_ROWS).all_inner_texts()]

    def click_audit_trail_icon_in_search_results(self) -> None:
        icon = self.page.locator(self.SEARCH_RESULT_AUDIT_ICON).first
        icon.wait_for(state="visible")
        icon.click()

    def is_audit_trail_displayed(self, app_id: str) -> bool:
        header = self.page.locator(self.AUDIT_TRAIL_HEADER.format(app_id=app_id))
        try:
            header.wait_for(state="visible")
        except PlaywrightTimeoutError:
            return False
        return True

    def open_audit_trail_record(self, app_id: str, index: int = 0) -> None:
        # Records are listed newest first, so index 0 is the latest change.
        record = self.page.locator(self.AUDIT_TRAIL_RECORD.format(app_id=app_id, index=index))
        record.scroll_into_view_if_needed()
        record.click()
        self.page.locator(self.AUDIT_DETAILS_TABLE).wait_for(state="visible")

    def get_audit_detail_values(self, field_name: str, timeout_ms: int = 15000) -> tuple[str, str] | None:
        """Filters the Audit Trail details grid by field name and returns
        (previous_value, current_value) for that exact field, or None if it never shows up."""
        search_box = self.page.locator(self.AUDIT_DETAILS_SEARCH)
        search_box.wait_for(state="visible")
        search_box.fill("")
        search_box.fill(field_name)
        rows = self.page.locator(f"{self.AUDIT_DETAILS_TABLE} tbody tr[data-testid^='row-']")
        deadline = time.monotonic() + timeout_ms / 1000
        while True:
            for row in rows.all():
                cells = [cell.strip() for cell in row.locator("td").all_inner_texts()]
                # Cells are: [#, Field, Previous Value, Current Value]
                if len(cells) >= 4 and cells[1] == field_name:
                    return cells[2], cells[3]
            if time.monotonic() > deadline:
                return None
            self.page.wait_for_timeout(500)

    def is_postback_dialog_displayed(self, timeout_ms: int = 60000) -> bool:
        # Postback takes a while to come back, so allow a long bounded wait.
        try:
            self.page.locator(self.POSTBACK_DIALOG_MESSAGE).wait_for(state="visible", timeout=timeout_ms)
        except PlaywrightTimeoutError:
            return False
        return True

    def click_postback_ok_button(self) -> None:
        ok_button = self.page.locator(self.POSTBACK_OK_BUTTON).first
        ok_button.wait_for(state="visible")
        ok_button.click()
        self.page.locator(self.POSTBACK_DIALOG_MESSAGE).wait_for(state="hidden")

    def click_view_data_for_first_data_source(self, data_source: str) -> None:
        frame = self.page.frame_locator(self.DATA_VIEWER_FRAME)
        row = frame.locator(self.DATA_SOURCE_FIRST_ROW)
        row.wait_for(state="visible")
        first_cell = row.locator("td").first.inner_text().strip()
        assert first_cell == data_source, f"First Data source entry is '{first_cell}', expected '{data_source}'"
        view_pattern = re.compile(r"^\s*view data\s*$", re.IGNORECASE)
        view_data = (
            row.get_by_role("button", name=view_pattern)
            .or_(row.get_by_role("link", name=view_pattern))
            .or_(row.get_by_text(view_pattern))
        ).first
        view_data.click()

    def click_raw_data_in_data_viewer(self) -> None:
        frame = self.page.frame_locator(self.DATA_VIEWER_FRAME)
        raw_pattern = re.compile(r"^\s*raw data\s*$", re.IGNORECASE)
        raw_data = (
            frame.get_by_role("tab", name=raw_pattern)
            .or_(frame.get_by_role("button", name=raw_pattern))
            .or_(frame.get_by_text(raw_pattern))
        ).first
        raw_data.click()

    def select_raw_data_view(self, view: str) -> None:
        # The Request / Response toggle is a pair of role="radio" buttons.
        frame = self.page.frame_locator(self.DATA_VIEWER_FRAME)
        radio = frame.get_by_role("radio", name=view, exact=True)
        radio.click()
        expect(radio).to_have_attribute("aria-checked", "true")

    def get_raw_data_text(self) -> str:
        frame = self.page.frame_locator(self.DATA_VIEWER_FRAME)
        content = frame.locator(self.RAW_DATA_CONTENT_SELECTOR)
        content.first.wait_for(state="visible")
        texts = content.evaluate_all("els => els.map(e => (e.value !== undefined ? e.value : e.innerText) || '')")
        # Several matching elements can exist (e.g. nested pre > code) - the raw payload is the longest.
        return max(texts, key=len)

    def find_error_text_in_raw_data(self) -> str | None:
        """Returns the first error keyword found in the raw data currently shown, else None."""
        text = self.get_raw_data_text().lower()
        for keyword in self.RAW_DATA_ERROR_KEYWORDS:
            if keyword in text:
                return keyword
        return None

    def is_success_in_raw_data(self) -> bool:
        return "success" in self.get_raw_data_text().lower()

    # ------------------------------------------------------------------
    # CRM decision services TC_06-TC_15 (Tactical param, Address parser,
    # Solit lookup, SSN lookup, Refresh ATB, form blocks, Notes, Audit Trail)
    # ------------------------------------------------------------------

    def wait_for_page_to_finish_loading(self, settle_ms: int = 5000) -> None:
        try:
            # Bounded: Data Viewer / polling screens may never reach networkidle.
            self.page.wait_for_load_state("networkidle", timeout=15000)
        except PlaywrightTimeoutError:
            pass
        self.page.wait_for_timeout(settle_ms)

    def is_heading_displayed(self, text: str, timeout_ms: int = 15000) -> bool:
        """Heading with exactly this text, ignoring case (UI casing differs from test-case docs)."""
        heading = self.page.get_by_role("heading", name=re.compile(rf"^\s*{re.escape(text)}\s*$", re.IGNORECASE)).first
        try:
            heading.wait_for(state="visible", timeout=timeout_ms)
        except PlaywrightTimeoutError:
            return False
        return True

    # ---- Audit Trail ----

    def get_audit_detail_field_names(self, timeout_ms: int = 15000) -> list[str]:
        """Field names listed in the Audit Trail details grid for the opened record
        (waits until at least one row shows up, returns [] if none ever does)."""
        rows = self.page.locator(self.AUDIT_DETAILS_ROWS)
        deadline = time.monotonic() + timeout_ms / 1000
        while rows.count() == 0 and time.monotonic() < deadline:
            self.page.wait_for_timeout(500)
        names = []
        for row in rows.all():
            cells = [cell.strip() for cell in row.locator("td").all_inner_texts()]
            if len(cells) >= 2:
                names.append(cells[1])
        return names

    def get_audit_trail_service_ids(self) -> list[str]:
        """The 'Service ID' column of every record in the Audit Trail grid (newest first)."""
        table = self.page.locator(self.AUDIT_TRAIL_TABLE)
        table.wait_for(state="visible")
        column_ids = table.locator("thead th").evaluate_all("els => els.map(e => e.id)")
        service_index = column_ids.index("serviceId")
        service_ids = []
        for row in table.locator("tbody tr[data-testid^='row-']").all():
            cells = row.locator("th, td").all_inner_texts()  # document order == header order
            service_ids.append(cells[service_index].strip())
        return service_ids

    # ---- Solit lookup ----

    def is_solit_lookup_displayed(self) -> bool:
        try:
            self.page.locator(self.SOLIT_DIALOG).wait_for(state="visible")
        except PlaywrightTimeoutError:
            return False
        return True

    def is_solit_lookup_detail_displayed(self, label: str) -> bool:
        dialog = self.page.locator(self.SOLIT_DIALOG)
        return dialog.get_by_text(label, exact=True).first.is_visible()

    def get_solit_lookup_value(self, label: str) -> str:
        """Value shown next to a label in the Solit lookup dialog (Prospect ID is an input)."""
        dialog = self.page.locator(self.SOLIT_DIALOG)
        if label == "Prospect ID":
            return dialog.locator(self.SOLIT_PROSPECT_ID_INPUT).input_value().strip()
        return dialog.get_by_test_id(self.SOLIT_VALUE_TESTIDS[label]).inner_text().strip()

    def change_solit_prospect_id(self, value: str) -> None:
        prospect_id = self.page.locator(self.SOLIT_DIALOG).locator(self.SOLIT_PROSPECT_ID_INPUT)
        prospect_id.fill("")
        prospect_id.fill(value)

    def click_solit_lookup_submit(self) -> None:
        self.page.locator(self.SOLIT_DIALOG).locator(self.SOLIT_SUBMIT_BUTTON).click()
        self.wait_for_page_to_finish_loading()

    def click_solit_lookup_close(self) -> None:
        self.page.locator(self.SOLIT_DIALOG).locator(self.SOLIT_CLOSE_BUTTON).click()
        self.page.locator(self.SOLIT_DIALOG).wait_for(state="hidden")

    # ---- SSN / Tax ID lookup ----

    def is_ssn_lookup_panel_displayed(self) -> bool:
        try:
            self.page.locator(self.SSN_LOOKUP_LABEL).wait_for(state="visible")
        except PlaywrightTimeoutError:
            return False
        return True

    def select_ssn_lookup_option(self, option: str) -> None:
        self.page.locator(self.SSN_LOOKUP_OPTIONS).select_option(label=option)

    def click_ssn_lookup_submit(self) -> None:
        self.page.locator(self.SSN_LOOKUP_SUBMIT_BUTTON).first.click()
        self.wait_for_page_to_finish_loading()

    def click_ssn_lookup_close(self) -> None:
        self.page.locator(self.SSN_LOOKUP_CLOSE_BUTTON).first.click()
        self.page.locator(self.SSN_LOOKUP_LABEL).wait_for(state="hidden")

    # ---- Editable form blocks (CRM decision, Robot fields, Refer to teams) ----

    def _get_form_block(self, title: str):
        """The card for a block such as "Robot fields": the nearest ancestor of its <h2> title
        that holds both the edit/confirm icon and the block's fields (so not just the header row)."""
        heading = self.page.locator("h2").filter(has_text=re.compile(re.escape(title), re.IGNORECASE)).first
        return heading.locator(
            "xpath=ancestor::div[.//*[@aria-label='edit' or @aria-label='check_circle']"
            " and (.//input or .//select or .//span[@role='text'])][1]"
        )

    def _get_form_field_control(self, block, label: str):
        # get_by_label also matches the read-only <span aria-label=...>, so keep only real form controls.
        return block.get_by_label(label, exact=True).and_(block.locator("input, select, textarea")).first

    def click_edit_in_form_block(self, title: str) -> None:
        block = self._get_form_block(title)
        block.scroll_into_view_if_needed()
        block.get_by_role("button", name=re.compile(r"edit", re.IGNORECASE)).first.click()

    def set_form_block_field(self, title: str, label: str, value: str) -> None:
        block = self._get_form_block(title)
        control = self._get_form_field_control(block, label)
        control.scroll_into_view_if_needed()
        if control.evaluate("e => e.tagName.toLowerCase()") == "select":
            option_labels = [text.strip() for text in control.locator("option").all_inner_texts()]
            if value in option_labels:
                control.select_option(label=value)
            else:
                control.select_option(value=value)
        else:
            control.fill("")
            control.fill(value)

    def confirm_changes_in_form_block(self, title: str) -> None:
        block = self._get_form_block(title)
        block.locator("[aria-label='check_circle']").first.click()
        self.page.wait_for_timeout(1000)

    def get_form_block_field_value(self, title: str, label: str, timeout_ms: int = 15000) -> str:
        """Current value of a field, whether the block is still in edit mode (control) or read-only (text span)."""
        block = self._get_form_block(title)
        read_only_slug = re.sub(r"\s+", "-", label.strip())
        deadline = time.monotonic() + timeout_ms / 1000
        while True:
            control = self._get_form_field_control(block, label)
            if control.count() > 0 and control.is_visible():
                if control.evaluate("e => e.tagName.toLowerCase()") == "select":
                    return control.evaluate("e => e.options[e.selectedIndex].text").strip()
                return control.input_value().strip()
            read_only = block.locator(f"[aria-labelledby='label-{read_only_slug}']").first
            if read_only.count() > 0:
                return read_only.inner_text().strip()
            if time.monotonic() > deadline:
                raise AssertionError(f"Field '{label}' was not found in the '{title}' block")
            self.page.wait_for_timeout(500)

    def is_form_block_option_displayed(self, title: str, option: str) -> bool:
        block = self._get_form_block(title)
        return block.get_by_text(option, exact=True).first.is_visible()

    # ---- Notes side panel ----

    def ensure_notes_section_open(self) -> None:
        toggle = self.page.locator(self.RIGHT_SECTION_TOGGLE)
        toggle.wait_for(state="visible")
        if toggle.get_attribute("aria-expanded") == "false":
            toggle.click()
        self.page.locator("#comment-box").wait_for(state="visible")

    # ---- Data Viewer raw data: key lookup ----

    def get_value_for_key_in_raw_data(self, key: str) -> str | None:
        """Value of an exactly-named JSON key in the raw data currently shown (None if absent)."""
        import json

        text = self.get_raw_data_text()
        start, end = text.find("{"), text.rfind("}")
        if start != -1 and end > start:
            try:
                found = self._find_json_key(json.loads(text[start:end + 1]), key)
                if found is not None:
                    return str(found)
            except ValueError:
                pass  # not clean JSON - fall back to a regex over the raw text
        match = re.search(rf'"{re.escape(key)}"\s*:\s*"?([^",}}\s]+)', text)
        return match.group(1) if match else None

    @staticmethod
    def _find_json_key(node, key: str):
        if isinstance(node, dict):
            if key in node:
                return node[key]
            for value in node.values():
                found = HomePage._find_json_key(value, key)
                if found is not None:
                    return found
        elif isinstance(node, list):
            for item in node:
                found = HomePage._find_json_key(item, key)
                if found is not None:
                    return found
        return None

    # ---- Credit View Only screen ----

    def get_displayed_application_id(self, timeout_ms: int = 15000) -> str:
        """Application ID shown in the header strip of an opened application
        (<li> holding the 'Application ID' section title and a section-value-<id> span)."""
        item = self.page.locator("li:has([data-testid='section-title-Application ID'])").first
        value = item.locator("[data-testid^='section-value-']").first
        value.wait_for(state="visible", timeout=timeout_ms)
        return value.inner_text().strip()

    def is_status_displayed(self, status: str, timeout_ms: int = 15000) -> bool:
        """Status pill (e.g. 'Pending', 'Declined') shown on the Letter History page."""
        pill = self.page.get_by_text(status, exact=True).first
        try:
            pill.wait_for(state="visible", timeout=timeout_ms)
        except PlaywrightTimeoutError:
            return False
        return True
