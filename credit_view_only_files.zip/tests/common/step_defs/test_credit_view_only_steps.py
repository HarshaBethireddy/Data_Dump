"""Step definitions for tests/common/features/credit_view_only.feature.

Every step used by this feature lives in tests/common/step_defs/conftest.py (shared with the
other features), so this module only links the feature file.
"""
from pytest_bdd import scenarios

scenarios("../features/credit_view_only.feature")
