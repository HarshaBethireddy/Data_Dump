import json
from pathlib import Path

import allure
from playwright.sync_api import expect
from pytest_bdd import given, when, then, parsers

from src.api.api_client import ApiClient
from src.ui.pages.home_page import HomePage
from src.utils.app_id_store import get_app_id
from src.utils.screenshots import capture_step_screenshot

TEST_DATA_DIR = Path("test_data")


# ---------------------------------------------------------------------------
# Shared API steps - CLI application (ACQ Credit and Fraud features)
# ---------------------------------------------------------------------------

@given(parsers.parse('a valid CLI application JSON payload loaded from "{file_name}" for a {method} request'))
@allure.step('Load and validate CLI application JSON payload from "{file_name}" for a {method} request')
def load_cli_payload(bdd_context, file_name, method):
    with open(TEST_DATA_DIR / file_name, encoding="utf-8") as f:
        payload = json.load(f)  # raises json.JSONDecodeError if the file is malformed
    assert isinstance(payload, dict) and payload, f"{file_name} did not contain a valid, non-empty JSON object"
    bdd_context["payload"] = payload
    bdd_context["method"] = method.upper()


@given("an auth token is generated")
@allure.step("Generate auth token")
def generate_auth_token(bdd_context, auth_token):
    assert auth_token, "Expected an auth token to be generated for the API request"
    bdd_context["auth_token"] = auth_token


@when("I send the request and receive a response")
@allure.step("Send the request and receive a response")
def submit_cli_application(bdd_context, api_client: ApiClient):
    # api_base_url already points at the full NewCLIApp endpoint, so call it with "".
    send = getattr(api_client, bdd_context["method"].lower())
    bdd_context["response"] = send("", data=bdd_context["payload"])


@then(parsers.parse("the response status code should be {status_code:d}"))
@allure.step("Verify response status code is {status_code}")
def assert_status_code(bdd_context, status_code):
    assert bdd_context["response"].status == status_code, bdd_context["response"].text()


# ---------------------------------------------------------------------------
# Shared UI steps (login -> PowerCurve -> role -> page/option)
# ---------------------------------------------------------------------------

@given("I open the homepage")
@allure.step("Open the homepage")
def open_homepage(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Open the homepage"):
        home_page.open("/")
        home_page.page.wait_for_timeout(5000)


@when(parsers.parse('I enter username "{username}" and password "{password}"'))
@allure.step("Login page - enter username and password")
def enter_credentials(home_page: HomePage, bdd_context, username, password):
    with capture_step_screenshot(home_page.page, "Enter username and password"):
        bdd_context["username"] = username
        home_page.enter_username(username)
        home_page.enter_password(password)


@when("I click the login button")
@allure.step("Login page - click the login button")
def click_login_button(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the login button"):
        home_page.click_login()


@when("I click on PowerCurve Case Management button")
@allure.step("Click on PowerCurve Case Management button")
def click_powercurve_case_management(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click on PowerCurve Case Management button"):
        home_page.click_powercurve_case_management()


@when(parsers.parse('I select the dropdown Role Selection as "{string}"'))
@allure.step("Select the dropdown Role Selection")
def select_role(home_page: HomePage, string):
    with capture_step_screenshot(home_page.page, f"Select the dropdown Role Selection as {string}"):
        home_page.page.locator("#role-selection").select_option(label=string)
        home_page.click_continue()


@when(parsers.parse('I navigate to "{page_name}" and select "{option}"'))
@allure.step("Navigate to page and select option")
def navigate_to_page_and_select_option(home_page: HomePage, page_name, option):
    with capture_step_screenshot(home_page.page, f"Navigate to {page_name} and select {option}"):
        home_page.navigate_to_credit_page(page_name)
        home_page.select_credit_page_option(option)


# ---------------------------------------------------------------------------
# Shared Credit/Fraud application screen steps
# ---------------------------------------------------------------------------

@when("I search the application using Application ID")
@allure.step("Search the application using Application ID")
def search_application_by_id(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Search the application using Application ID"):
        home_page.page.locator("#ApplicationID").fill(get_app_id())
        home_page.click_search()
        home_page.click_open_application()


@when(parsers.parse('I logout and relogin with username "{username}" and password "{password}"'))
@allure.step('Logout and relogin with username "{username}" and password "{password}"')
def logout_and_relogin(home_page: HomePage, bdd_context, username, password):
    with capture_step_screenshot(home_page.page, f"Logout and relogin with username '{username}' and password '{password}'"):
        home_page.page.locator("#user-menu-button").click()
        home_page.page.wait_for_timeout(2000)
        home_page.page.locator("//*[@id='user-menu-content']/div[2]/button/span").click()
        home_page.page.wait_for_timeout(2000)
        home_page.page.locator("#input-username").fill(username)
        home_page.page.locator("#input-password").fill(password)
        home_page.page.locator("#login-button").click()
        home_page.page.wait_for_timeout(5000)
        bdd_context["username"] = username


@when('I search the application using Application ID on Application case list page')
@allure.step('Search the application using Application ID on Application case list page')
def search_application_by_id_on_case_list(home_page: HomePage):
    home_page.page.locator("#ApplicationID").fill(get_app_id())
    home_page.click_search()


@then('the application should be displayed as locked')
@allure.step('Verify the application should be displayed as locked')
def verify_application_locked(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the application should be displayed as locked"):
        lock_icon = home_page.page.locator("[aria-label='lock']").first
        expect(lock_icon).to_be_visible()


@then(parsers.parse('the Locked By column should display "{locked_by}"'))
@allure.step('Verify the Locked By column should display "{locked_by}"')
def verify_locked_by_column(home_page: HomePage, locked_by):
    with capture_step_screenshot(home_page.page, f"Verify the Locked By column should display '{locked_by}'"):
        locked_by_cell = home_page.page.locator("text='mock-user_1'").first
        expect(locked_by_cell).to_have_text(locked_by)


@then('I should see the following sections in ACQ Credit View screen')
@allure.step("Verify sections in ACQ Credit View screen")
def verify_sections(home_page: HomePage, datatable):
    with capture_step_screenshot(home_page.page, "Verify sections in ACQ Credit View screen"):
        for row in datatable:
            section_name = row[0].strip()
            assert home_page.is_section_visible(section_name), f"Section '{section_name}' not visible"


@when('I open the ACQ fraud View screen')
@allure.step("Open the ACQ fraud View screen")
def open_acq_fraud_view_screen(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Open the ACQ fraud View screen"):
        # Application detail screen is already opened by the preceding search step -
        # verify it landed on the right screen via a section that's always present.
        assert home_page.is_section_visible("Applicant & Business info"), "ACQ Fraud View screen was not displayed"


@when('I click on Existing Customer field')
@allure.step("Click on Existing Customer field")
def click_existing_customer_field(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click on Existing Customer field"):
        home_page.click_existing_customer_field()


@then('the Existing Customer page should be displayed')
@allure.step("Verify Existing Customer page is displayed")
def verify_existing_customer_page(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify Existing Customer page is displayed"):
        assert home_page.is_section_visible("Existing Customer"), "Existing Customer page not visible"


@when('I click the Close button on Existing Customer page')
@allure.step("Click the Close button on Existing Customer page")
def click_close_button_on_existing_customer_page(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Close button on Existing Customer page"):
        home_page.click_close_button_on_existing_customer_page()


@then('the Existing Customer page should be closed')
@allure.step("Verify Existing Customer page is closed")
def verify_existing_customer_page_closed(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify Existing Customer page is closed"):
        assert home_page.is_section_visible("Credit view"), "Existing Customer page still visible"


@when('I click on Letter History')
@allure.step("Click on Letter History")
def click_letter_history(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click on Letter History"):
        home_page.click_letter_history()


@then('the Letter info section should be displayed')
@allure.step("Verify Letter info section is displayed")
def verify_letter_info_section(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify Letter info section is displayed"):
        assert home_page.is_section_visible("Letter info"), "Letter info section not visible"


@when('I click the Close button on Letter History page')
@allure.step("Click the Close button on Letter History page")
def click_close_button_on_letter_history_page(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Close button on Letter History page"):
        home_page.click_close_button_on_letter_history_page()


@then('the Letter History page should be closed')
@allure.step("Verify Letter History page is closed")
def verify_letter_history_page_closed(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify Letter History page is closed"):
        assert home_page.is_section_visible("Credit view"), "Letter History page still visible"


@when('I click on Data Viewer')
@allure.step("Click on Data Viewer")
def click_data_viewer(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click on Data Viewer"):
        home_page.click_data_viewer()


@then('the Data Viewer page should be displayed')
@allure.step("Verify Data Viewer page is displayed")
def verify_data_viewer_page(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify Data Viewer page is displayed"):
        assert home_page.is_data_viewer_page_displayed(), "Data Viewer page not visible"


@when('I click the Close button on Data Viewer')
@allure.step("Click the Close button on Data Viewer")
def click_close_button_on_data_viewer(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Close button on Data Viewer"):
        home_page.click_close_button_on_data_viewer()


@when('I should see the following buttons in ACQ Credit View screen')
@allure.step("Verify buttons in ACQ Credit View screen")
def verify_buttons_in_acq_credit_view_screen(home_page: HomePage, datatable):
    with capture_step_screenshot(home_page.page, "Verify buttons in ACQ Credit View screen"):
        for row in datatable:
            button_name = row[0].strip()
            assert home_page.is_button_visible(button_name), f"Button '{button_name}' not visible"


@when(parsers.parse('I click the "{button_name}" button'))
@allure.step("Click the {button_name} button")
def click_button(home_page: HomePage, button_name: str):
    with capture_step_screenshot(home_page.page, f"Click the {button_name} button"):
        home_page.click_button(button_name)


@when('I click the Close button')
@allure.step("Click the Close button")
def click_close_button(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Close button"):
        home_page.click_button("Close")


@then('the Credit View screen should be closed successfully Navigate to Application case list page')
@allure.step("Verify Credit View screen is closed and navigate to Application case list page")
def verify_credit_view_screen_closed(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify Credit View screen is closed and navigate to Application case list page"):
        assert home_page.is_section_visible("Application case list"), "Credit View screen still visible"


# ---------------------------------------------------------------------------
# Shared Bureau / Credit report / PID steps
# ---------------------------------------------------------------------------

@when('I click on the Bureau pull dropdown')
@allure.step("Click on the Bureau pull dropdown")
def click_bureau_pull_dropdown(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click on the Bureau pull dropdown"):
        home_page.click_bureau_pull_dropdown()


@then('the following bureaus should be displayed')
@allure.step("Verify the following bureaus are displayed")
def verify_bureaus_displayed(home_page: HomePage, datatable):
    with capture_step_screenshot(home_page.page, "Verify the following bureaus are displayed"):
        for row in datatable:
            bureau = row[0].strip()
            assert home_page.is_bureau_option_visible(bureau), f"Bureau '{bureau}' not visible"


@when(parsers.parse('I select "{bureau}" from the Bureau pull dropdown'))
@allure.step("Select {bureau} from the Bureau pull dropdown")
def select_bureau_from_pull_dropdown(home_page: HomePage, bdd_context, bureau: str):
    with capture_step_screenshot(home_page.page, f"Select {bureau} from the Bureau pull dropdown"):
        home_page.select_bureau_pull_option(bureau)
        bdd_context["bureau"] = bureau


@when('I fetch the NumCalls value before calling the bureau')
@allure.step("Fetch the NumCalls value before calling the bureau")
def fetch_numcalls_value_before_calling_bureau(home_page: HomePage, bdd_context):
    with capture_step_screenshot(home_page.page, "Fetch the NumCalls value before calling the bureau"):
        bdd_context["numcalls_before"] = home_page.get_numcalls_value()
        print(f"NumCalls value before calling the bureau: {bdd_context['numcalls_before']}")


@when('I click the Call Bureau button')
@allure.step("Click the Call Bureau button")
def click_call_bureau_button(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Call Bureau button"):
        home_page.click_call_bureau_button()


@when('I click the Continue on pop-up alert')
@allure.step("Click the Continue on pop-up alert")
def click_continue_on_popup_alert(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Continue on pop-up alert"):
        home_page.click_continue_on_popup_alert()


@then('the NumCalls field should be incremented')
@allure.step("Verify the NumCalls field is incremented")
def verify_numcalls_incremented(home_page: HomePage, bdd_context):
    with capture_step_screenshot(home_page.page, "Verify the NumCalls field is incremented"):
        previous_value = bdd_context["numcalls_before"]
        incremented = home_page.is_numcalls_incremented(previous_value)
        after_value = home_page.get_numcalls_value()
        print(f"NumCalls value after calling the bureau: {after_value}")
        assert incremented, (
            f"NumCalls field was not incremented by 1 (before={previous_value}, after={after_value})"
        )


@then(parsers.parse('I should see the Data source entry "{string}"'))
@allure.step("Verify the Data source entry is visible")
def verify_data_source_entry_visible(home_page: HomePage, bdd_context, string: str):
    with capture_step_screenshot(home_page.page, f"Verify the Data source entry is visible: {string}"):
        assert home_page.is_data_source_entry_visible(string), f"Data source entry '{string}' not visible"


@when('I click the Change Bureau Decision button')
@allure.step("Click the Change Bureau Decision button")
def click_change_bureau_decision_button(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Change Bureau Decision button"):
        home_page.click_change_bureau_decision_button()


@when('I scroll to Credit report section')
@allure.step("Scroll to Credit report section")
def scroll_to_credit_report_section(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Scroll to Credit report section"):
        home_page.scroll_to_credit_report_section()


@then('the FICO score should be displayed')
@allure.step("Verify the FICO score is displayed")
def verify_fico_score_displayed(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the FICO score is displayed"):
        assert home_page.is_fico_score_displayed(), "FICO score was not displayed"


@then('the Vantage score should be displayed')
@allure.step("Verify the Vantage score is displayed")
def verify_vantage_score_displayed(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the Vantage score is displayed"):
        assert home_page.is_vantage_score_displayed(), "Vantage score was not displayed"


@then('no errors should be displayed')
@allure.step("Verify no errors are displayed")
def verify_no_errors_displayed(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify no errors are displayed"):
        assert home_page.are_no_errors_displayed(), "Errors were displayed on the page"


@then('I scroll to PreciseID summary')
@allure.step("Scroll to PreciseID summary")
def scroll_to_preciseid_summary(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Scroll to PreciseID summary"):
        home_page.scroll_to_preciseid_summary()


@then('I click the Call PID button')
@allure.step("Click the Call PID button")
def click_call_pid_button(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Call PID button"):
        home_page.click_call_pid_button()


# ---------------------------------------------------------------------------
# Shared Applicant / Edit Applicant Data steps
# ---------------------------------------------------------------------------

@when('I navigate to the Applicant and Business Info section')
@allure.step("Navigate to the Applicant and Business Info section")
def navigate_to_applicant_and_business_info_section(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Navigate to the Applicant and Business Info section"):
        home_page.navigate_to_applicant_and_business_info_section()


@then('the Edit applicant data button should be displayed')
@allure.step("Verify the Edit applicant data button is displayed")
def verify_edit_applicant_data_button_displayed(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the Edit applicant data button is displayed"):
        assert home_page.is_edit_applicant_data_button_displayed(), "Edit applicant data button was not displayed"


@when('I click the Edit Applicant Data button')
@allure.step("Click the Edit Applicant Data button")
def click_edit_applicant_data_button(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Edit Applicant Data button"):
        home_page.click_edit_applicant_data_button()


@then('the Edit Applicant page should be displayed')
@allure.step("Verify the Edit Applicant page is displayed")
def verify_edit_applicant_page_displayed(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the Edit Applicant page is displayed"):
        assert home_page.is_edit_applicant_page_displayed(), "Edit Applicant page was not displayed"


@then('No validation errors should be displayed')
@allure.step("Verify no validation errors are displayed")
def verify_no_validation_errors_displayed(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify no validation errors are displayed"):
        assert home_page.are_no_errors_popup_displayed(), "Validation errors were displayed on the page"


@then('I execute PID calls for Applicant Address, UBO and Controller information')
@allure.step("Execute PID calls for Applicant Address, UBO and Controller information")
def execute_pid_calls(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Execute PID calls for Applicant Address, UBO and Controller information"):
        home_page.execute_pid_calls()


@then(parsers.parse('I can edit Application address Primary phone "{phone}"'))
@allure.step("Edit Application address Primary phone {phone}")
def edit_application_address_primary_phone(home_page: HomePage, phone: str):
    with capture_step_screenshot(home_page.page, f"Edit Application address Primary phone {phone}"):
        home_page.edit_application_address_primary_phone(phone)


@then(parsers.parse('I Click on "{button}" button'))
@allure.step('Click on "{button}" button')
def click_on_button(home_page: HomePage, button: str):
    with capture_step_screenshot(home_page.page, f"Click on {button} button"):
        if button == "Save & exit":
            home_page.click_save_and_exit_button()
        else:
            raise ValueError(f"Button '{button}' is not implemented in the step definition.")


# ---------------------------------------------------------------------------
# Shared Alter / Manual Decision steps
# ---------------------------------------------------------------------------

@when('I click on Alter button , Should see the Alter screen')
@allure.step("Click on Alter button and verify Alter screen")
def click_alter_button_and_verify(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click on Alter button and verify Alter screen"):
        home_page.click_alter_button()
        assert home_page.is_alter_screen_displayed(), "Alter screen was not displayed"


@then(parsers.parse('I Click on "{button}" button and no errors should be displayed in the Data Viewer'))
@allure.step('Click on "{button}" button and no errors should be displayed in the Data Viewer')
def click_button_and_check_no_errors(home_page: HomePage, button: str):
    with capture_step_screenshot(home_page.page, f'Click on "{button}" button and no errors should be displayed in the Data Viewer'):
        if button == "Save":
            home_page.click_save_button()
            home_page.page.wait_for_timeout(2000)  # give any errors time to appear
            assert home_page.is_no_errors_in_data_viewer(), "Errors were displayed in the Data Viewer after clicking Save"
        else:
            raise ValueError(f"Button '{button}' is not implemented in the step definition.")


@when(parsers.parse('I select "{decision}" from the Manual Decision dropdown'))
@allure.step('Select "{decision}" from the Manual Decision dropdown')
def select_manual_decision(home_page: HomePage, decision: str):
    with capture_step_screenshot(home_page.page, f'Select "{decision}" from the Manual Decision dropdown'):
        home_page.select_manual_decision(decision)


@then('I check the Refer to KYC and Refer to Fraud checkboxes and confirm')
@allure.step('Check the Refer to KYC and Refer to Fraud checkboxes and confirm')
def check_refer_checkboxes_and_confirm(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Check Refer to KYC and Refer to Fraud checkboxes and confirm"):
        home_page.select_refer_checkboxes_and_confirm()


@then('no errors should be displayed in the Data Viewer')
@when('no errors should be displayed in the Data Viewer')
@allure.step('Verify no errors should be displayed in the Data Viewer')
def verify_no_errors_in_data_viewer(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify no errors in the Data Viewer"):
        assert home_page.is_no_errors_in_data_viewer(), "Errors were displayed in the Data Viewer"


@when('I click on save button')
@allure.step('Click on save button')
def click_on_save_button(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click on save button"):
        home_page.click_on_save_button()


@when(parsers.parse('I select a "{reason_code}" Decline Reason Code'))
@allure.step('Select a "{reason_code}" Decline Reason Code')
def select_decline_reason_code(home_page: HomePage, reason_code: str):
    with capture_step_screenshot(home_page.page, f'Select a "{reason_code}" Decline Reason Code'):
        home_page.select_decline_reason_code(reason_code)


@when(parsers.parse('I select a valid Letter Code "{letter_code}"'))
@allure.step('Select a valid Letter Code "{letter_code}"')
def select_letter_code(home_page: HomePage, letter_code: str):
    with capture_step_screenshot(home_page.page, f'Select a valid Letter Code "{letter_code}"'):
        home_page.select_letter_code(letter_code)


# ---------------------------------------------------------------------------
# Shared Notes section steps
# ---------------------------------------------------------------------------

@when('I enter notes in the Notes section')
@allure.step('Enter notes in the Notes section')
def enter_notes_in_notes_section(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Enter notes in the Notes section"):
        home_page.enter_notes_in_notes_section()


@when('I click on Add button')
@allure.step('Click on Add button')
def click_add_button(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click on Add button"):
        home_page.click_add_button()


@then('the notes should be added successfully')
@allure.step('Verify the notes should be added successfully')
def verify_notes_added(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the notes should be added successfully"):
        comment_box = home_page.page.locator("span.wyfr-text___container", has_text="Automation Note").first
        expect(comment_box).to_have_text("Automation Note")


@when('I click the Attachment button in the Notes section')
@allure.step('Click the Attachment button in the Notes section')
def click_attachment_button_in_notes_section(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Attachment button in the Notes section"):
        home_page.click_attachment_button_in_notes_section()


@when('I upload a valid file')
@allure.step('Upload a valid file')
def upload_valid_file(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Upload a valid file"):
        file_path = Path(__file__).resolve().parents[3] / "test_data" / "Upload_Test_File.txt"
        assert file_path.exists(), f"Upload file not found: {file_path}"
        home_page.upload_file(file_path)


@then('the uploaded file should be displayed in the attachment list')
@allure.step('Verify the uploaded file should be displayed in the attachment list')
def verify_uploaded_file_in_attachment_list(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the uploaded file should be displayed in the attachment list"):
        attachment = home_page.page.get_by_text("Upload_Test_File.txt").first
        expect(attachment, "Uploaded file 'Upload_Test_File.txt' is not displayed").to_be_visible(timeout=10000)


@when('I enter additional notes in the Notes section')
@allure.step('Enter additional notes in the Notes section')
def enter_additional_notes(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Enter additional notes in the Notes section"):
        comment_box = home_page.page.locator("textarea[data-testid='comment-box']").first
        comment_box.wait_for(state="attached")
        comment_box.scroll_into_view_if_needed()
        comment_box.fill("Additional Automation Note")


@when('I click the Clear button')
@allure.step('Click the Clear button')
def click_clear_button(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Clear button"):
        clear_button = home_page.page.locator("//*[@id='clear-comment']/div/div/div/div").first
        try:
            clear_button.scroll_into_view_if_needed(timeout=5000)
        except:
            pass
        clear_button.wait_for(state="visible")
        clear_button.click()


@then('the Notes text area should be cleared')
@allure.step('Verify the Notes text area should be cleared')
def verify_notes_cleared(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the Notes text area should be cleared"):
        comment_box = home_page.page.locator("textarea[data-testid='comment-box']").first
        expect(comment_box).to_have_text("")


# ---------------------------------------------------------------------------
# Shared Fraud Check / Submit steps
# ---------------------------------------------------------------------------

@then('the Fraud Check button should be enabled')
@allure.step('Verify the Fraud Check button is enabled')
def verify_fraud_check_button_enabled(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the Fraud Check button is enabled"):
        assert home_page.is_fraud_check_button_enabled(), "Fraud Check button is not enabled"


@when('I click the Fraud Check button and Fraud Check iscompleted successfully')
@allure.step('Click the Fraud Check button and verify it is completed successfully')
def click_fraud_check_button(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Fraud Check button and verify it is completed successfully"):
        home_page.click_fraud_check_button()


@when('I click the Submit button')
@allure.step('Click the Submit button')
def click_submit_button(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Submit button"):
        home_page.click_submit_button()


@when('I uncheck all queue assignment checkboxes if selected')
@allure.step('Uncheck all queue assignment checkboxes if selected')
def uncheck_all_queue_assignment_checkboxes(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Uncheck all queue assignment checkboxes if selected"):
        home_page.uncheck_all_queue_assignment_checkboxes()


@when('I click the Submit Application button')
@allure.step('Click the Submit Application button')
def click_submit_application_button(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Submit Application button"):
        home_page.click_submit_application_button()


@then(parsers.parse('I search the application and validate application status should be updated to "{status}" successfully'))
@allure.step('Search the application and validate application status should be updated to "{status}" successfully')
def search_application_and_validate_status(home_page: HomePage, status: str):
    with capture_step_screenshot(home_page.page, f'Search the application and validate application status should be updated to "{status}" successfully'):
        home_page.page.locator("#ApplicationID").fill(get_app_id())
        home_page.click_search()
        home_page.search_application_and_validate_status(status)


# ---------------------------------------------------------------------------
# Shared My Apps / Assigned User (Queue Assignment) steps
# ---------------------------------------------------------------------------

@when('I select the My Apps checkbox in the Queue Assignment page')
@allure.step('Select the My Apps checkbox in the Queue Assignment page')
def select_my_apps_checkbox(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Select the My Apps checkbox in the Queue Assignment page"):
        my_apps_checkbox = home_page.page.locator("input[data-testid='assign-to-myapps']").first
        my_apps_checkbox.wait_for(state="attached")
        my_apps_checkbox.scroll_into_view_if_needed()
        my_apps_checkbox.check()
        home_page.page.wait_for_timeout(500)


@then('the My Apps field should be updated correctly')
@allure.step('Verify the My Apps field should be updated correctly')
def verify_my_apps_field(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the My Apps field should be updated correctly"):
        my_apps_cell = home_page.page.locator(
            "xpath=//tr[1]/td[count(//div[.='My apps']/ancestor::th/preceding-sibling::th)]"
        ).first
        expect(my_apps_cell).to_have_text("Yes")


@then('the Assigned User field should display the logged in user')
@allure.step('Verify the Assigned User field should display the logged in user')
def verify_assigned_user_field(home_page: HomePage, bdd_context):
    with capture_step_screenshot(home_page.page, "Verify the Assigned User field should display the logged in user"):
        expected_user = bdd_context["username"].split("@")[0]
        assigned_user_cell = home_page.page.locator(
            "//tr[1]/td[count(//div[.='Assigned user']/ancestor::th/preceding-sibling::th)]"
        ).first
        expect(assigned_user_cell).to_have_text(expected_user)


@when('click on Continue button')
@allure.step('Click on Continue button')
def click_continue_button(home_page: HomePage):
    home_page.page.wait_for_timeout(500)
    with capture_step_screenshot(home_page.page, "Click on Continue button"):
        button = home_page.page.locator("//*[@id='Continue']/div/div").first
        button.wait_for(state="visible")
        button.click()
        home_page.page.wait_for_timeout(5000)


# ===========================================================================
# Shared CRM Decision Services steps
# Used by crm_search_screen.feature AND crm_completed_screen.feature, so they
# live here (conftest) instead of in either feature's own step module.
# ===========================================================================

# ---------------------------------------------------------------------------
# TC_01 - homepage
# ---------------------------------------------------------------------------

@then("the following columns should be displayed on the homepage for the logged in user role")
@allure.step("Verify columns on the homepage for the logged in user role")
def verify_homepage_columns(home_page: HomePage, datatable):
    with capture_step_screenshot(home_page.page, "Verify columns on the homepage for the logged in user role"):
        for row in datatable:
            column_name = row[0].strip()
            assert home_page.is_credit_view_column_visible(column_name), f"Column '{column_name}' not visible"


# ---------------------------------------------------------------------------
# TC_02 - CRM Decision Services page
# ---------------------------------------------------------------------------

@then("the following buttons should be displayed in the CRM Decision Services page")
@allure.step("Verify buttons in the CRM Decision Services page")
def verify_crm_decision_services_buttons(home_page: HomePage, datatable):
    with capture_step_screenshot(home_page.page, "Verify buttons in the CRM Decision Services page"):
        for row in datatable:
            button_name = row[0].strip()
            assert home_page.is_button_visible(button_name), f"Button '{button_name}' not visible"


# ---------------------------------------------------------------------------
# TC_03 / TC_04 - Pre bureau / Post bureau, Save, Close, Audit Trail
# ---------------------------------------------------------------------------

@when("I click the Save button and wait for the changes to be saved")
@allure.step("Click the Save button and wait for the changes to be saved")
def click_crm_save_and_wait(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Save button and wait for the changes to be saved"):
        home_page.click_crm_save_and_wait()


@when("I open the application from the search results")
@allure.step("Open the application from the search results")
def open_application_from_search_results(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Open the application from the search results"):
        home_page.click_open_application()


@then("the search results should show exactly 1 record for the searched Application ID")
@allure.step("Verify the search results show exactly 1 record for the searched Application ID")
def verify_single_search_result(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the search results show exactly 1 record"):
        app_id = get_app_id()
        results = home_page.get_search_result_application_ids()
        assert len(results) == 1, f"Expected exactly 1 search result, found {len(results)}: {results}"
        assert app_id in results[0], f"Search result '{results[0]}' does not match Application ID {app_id}"


@when("I click the Audit trail icon of the application")
@allure.step("Click the Audit trail icon of the application")
def click_audit_trail_icon(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click the Audit trail icon of the application"):
        home_page.click_audit_trail_icon_in_search_results()


@then("the Audit Trail dialog should be displayed for the application")
@allure.step("Verify the Audit Trail dialog is displayed for the application")
def verify_audit_trail_dialog(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the Audit Trail dialog is displayed"):
        app_id = get_app_id()
        assert home_page.is_audit_trail_displayed(app_id), f"Audit Trail dialog for {app_id} was not displayed"


@when("I open the first record of the Audit Trail")
@allure.step("Open the first record of the Audit Trail")
def open_first_audit_trail_record(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Open the first record of the Audit Trail"):
        home_page.open_audit_trail_record(get_app_id(), index=0)


@then(parsers.re(
    r'the Audit Trail details should show field "(?P<field>[^"]+)" '
    r'with previous value "(?P<previous>[^"]*)" and current value "(?P<current>[^"]*)"'
))
@allure.step("Verify the Audit Trail details for the field")
def verify_audit_trail_field_values(home_page: HomePage, field: str, previous: str, current: str):
    with capture_step_screenshot(home_page.page, f"Verify Audit Trail details for field {field}"):
        values = home_page.get_audit_detail_values(field)
        assert values is not None, f"Field '{field}' was not found in the Audit Trail details"
        actual_previous, actual_current = values
        assert (actual_previous, actual_current) == (previous, current), (
            f"Field '{field}': expected previous='{previous}', current='{current}' "
            f"but found previous='{actual_previous}', current='{actual_current}'"
        )


# ---------------------------------------------------------------------------
# TC_05 - Postback and Data Viewer raw data
# ---------------------------------------------------------------------------

@then("the Post-back dialog should be displayed")
@allure.step("Verify the Post-back dialog is displayed")
def verify_postback_dialog(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the Post-back dialog is displayed"):
        assert home_page.is_postback_dialog_displayed(), "Post-back dialog was not displayed"


@when("I click Ok on the Post-back dialog")
@allure.step("Click Ok on the Post-back dialog")
def click_ok_on_postback_dialog(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click Ok on the Post-back dialog"):
        home_page.click_postback_ok_button()


@when(parsers.parse('I click View data for the Data source entry "{data_source}"'))
@allure.step('Click View data for the Data source entry "{data_source}"')
def click_view_data_for_data_source(home_page: HomePage, data_source: str):
    with capture_step_screenshot(home_page.page, f"Click View data for the Data source entry {data_source}"):
        home_page.click_view_data_for_first_data_source(data_source)


@when("I click on Raw data in the Data Viewer")
@allure.step("Click on Raw data in the Data Viewer")
def click_raw_data(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click on Raw data in the Data Viewer"):
        home_page.click_raw_data_in_data_viewer()


@when(parsers.parse('I select "{view}" in the Raw data view'))
@allure.step('Select "{view}" in the Raw data view')
def select_raw_data_view(home_page: HomePage, view: str):
    with capture_step_screenshot(home_page.page, f"Select {view} in the Raw data view"):
        home_page.select_raw_data_view(view)


@then("the Raw data should not contain any error text")
@allure.step("Verify the Raw data does not contain any error text")
def verify_no_error_in_raw_data(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the Raw data does not contain any error text"):
        keyword = home_page.find_error_text_in_raw_data()
        assert keyword is None, f"Error text '{keyword}' found in the Raw data"


@then("the Raw data should indicate success")
@allure.step("Verify the Raw data indicates success")
def verify_success_in_raw_data(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the Raw data indicates success"):
        assert home_page.is_success_in_raw_data(), "'success' was not found in the Response raw data"


# ---------------------------------------------------------------------------
# Page loading / Tactical param / Address parser (TC_06, TC_07)
# ---------------------------------------------------------------------------

@when("I wait for the page to finish loading")
@allure.step("Wait for the page to finish loading")
def wait_for_page_to_finish_loading(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Wait for the page to finish loading"):
        home_page.wait_for_page_to_finish_loading()


@then(parsers.parse("the Audit Trail details should list at least {count:d} changed field"))
@allure.step("Verify the Audit Trail details list at least {count} changed field")
def verify_audit_trail_has_changed_fields(home_page: HomePage, count: int):
    with capture_step_screenshot(home_page.page, f"Verify the Audit Trail details list at least {count} changed field"):
        names = home_page.get_audit_detail_field_names()
        assert len(names) >= count, f"Expected at least {count} changed field(s) in the Audit Trail details, found {names}"


@when(parsers.parse('I capture the "{key}" value from the Raw data as "{name}"'))
@allure.step('Capture the "{key}" value from the Raw data as "{name}"')
def capture_raw_data_value(home_page: HomePage, bdd_context, key: str, name: str):
    with capture_step_screenshot(home_page.page, f"Capture the {key} value from the Raw data as {name}"):
        value = home_page.get_value_for_key_in_raw_data(key)
        assert value, f"Key '{key}' was not found in the Raw data"
        bdd_context[name] = value


@then(parsers.parse('the captured "{first}" and "{second}" values should match'))
@allure.step('Verify the captured "{first}" and "{second}" values match')
def verify_captured_values_match(home_page: HomePage, bdd_context, first: str, second: str):
    with capture_step_screenshot(home_page.page, f"Verify the captured {first} and {second} values match"):
        assert bdd_context[first] == bdd_context[second], (
            f"'{first}' = {bdd_context[first]!r} but '{second}' = {bdd_context[second]!r}"
        )


# ---------------------------------------------------------------------------
# Solit lookup (TC_08)
# ---------------------------------------------------------------------------

@then("the Solit lookup window should display the following details")
@allure.step("Verify the Solit lookup window displays the following details")
def verify_solit_lookup_details(home_page: HomePage, datatable):
    with capture_step_screenshot(home_page.page, "Verify the Solit lookup window details"):
        assert home_page.is_solit_lookup_displayed(), "Solit lookup window was not displayed"
        for row in datatable:
            label = row[0].strip()
            assert home_page.is_solit_lookup_detail_displayed(label), f"'{label}' not visible in the Solit lookup window"
        shown_app_id = home_page.get_solit_lookup_value("Application ID")
        assert shown_app_id == get_app_id(), f"Solit lookup shows Application ID {shown_app_id}, expected {get_app_id()}"


@when(parsers.parse('I change the Prospect ID to "{value}" in the Solit lookup window'))
@allure.step('Change the Prospect ID to "{value}" in the Solit lookup window')
def change_solit_prospect_id(home_page: HomePage, value: str):
    with capture_step_screenshot(home_page.page, f"Change the Prospect ID to {value}"):
        home_page.change_solit_prospect_id(value)


@when("I click Submit in the Solit lookup window")
@allure.step("Click Submit in the Solit lookup window")
def click_solit_lookup_submit(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click Submit in the Solit lookup window"):
        home_page.click_solit_lookup_submit()


@then(parsers.parse('the Prospect ID in the Solit lookup window should be "{value}"'))
@allure.step('Verify the Prospect ID in the Solit lookup window is "{value}"')
def verify_solit_prospect_id(home_page: HomePage, value: str):
    with capture_step_screenshot(home_page.page, f"Verify the Prospect ID is {value}"):
        actual = home_page.get_solit_lookup_value("Prospect ID")
        assert actual == value, f"Prospect ID is '{actual}', expected '{value}'"


@when("I click Close in the Solit lookup window")
@allure.step("Click Close in the Solit lookup window")
def click_solit_lookup_close(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click Close in the Solit lookup window"):
        home_page.click_solit_lookup_close()


# ---------------------------------------------------------------------------
# SSN / Tax ID lookups (TC_09)
# ---------------------------------------------------------------------------

@then(parsers.parse('the "{heading}" heading should be displayed'))
@allure.step('Verify the "{heading}" heading is displayed')
def verify_heading_displayed(home_page: HomePage, heading: str):
    with capture_step_screenshot(home_page.page, f"Verify the {heading} heading is displayed"):
        assert home_page.is_heading_displayed(heading), f"Heading '{heading}' was not displayed"


@then("the SSN lookup options should be displayed")
@allure.step("Verify the SSN lookup options are displayed")
def verify_ssn_lookup_panel(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the SSN lookup options are displayed"):
        assert home_page.is_ssn_lookup_panel_displayed(), "SSN lookup options were not displayed"


@when(parsers.parse('I select "{option}" in the SSN lookup dropdown'))
@allure.step('Select "{option}" in the SSN lookup dropdown')
def select_ssn_lookup_option(home_page: HomePage, option: str):
    with capture_step_screenshot(home_page.page, f"Select {option} in the SSN lookup dropdown"):
        home_page.select_ssn_lookup_option(option)


@when("I click Submit in the SSN lookup panel")
@allure.step("Click Submit in the SSN lookup panel")
def click_ssn_lookup_submit(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click Submit in the SSN lookup panel"):
        home_page.click_ssn_lookup_submit()


@when("I click Close in the SSN lookup panel")
@allure.step("Click Close in the SSN lookup panel")
def click_ssn_lookup_close(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Click Close in the SSN lookup panel"):
        home_page.click_ssn_lookup_close()


# ---------------------------------------------------------------------------
# Editable blocks: CRM decision / Robot fields / Refer to teams (TC_10 - TC_12)
# ---------------------------------------------------------------------------

@when(parsers.parse('I click Edit in the "{block}" block'))
@allure.step('Click Edit in the "{block}" block')
def click_edit_in_block(home_page: HomePage, block: str):
    with capture_step_screenshot(home_page.page, f"Click Edit in the {block} block"):
        home_page.click_edit_in_form_block(block)


@when(parsers.parse('I set "{field}" to "{value}" in the "{block}" block'))
@allure.step('Set "{field}" to "{value}" in the "{block}" block')
def set_field_in_block(home_page: HomePage, field: str, value: str, block: str):
    with capture_step_screenshot(home_page.page, f"Set {field} to {value} in the {block} block"):
        home_page.set_form_block_field(block, field, value)


@when(parsers.parse('I confirm the changes in the "{block}" block'))
@allure.step('Confirm the changes in the "{block}" block')
def confirm_changes_in_block(home_page: HomePage, block: str):
    with capture_step_screenshot(home_page.page, f"Confirm the changes in the {block} block"):
        home_page.confirm_changes_in_form_block(block)


@then(parsers.parse('the "{block}" block should display "{field}" as "{value}"'))
@allure.step('Verify the "{block}" block displays "{field}" as "{value}"')
def verify_block_field_value(home_page: HomePage, block: str, field: str, value: str):
    with capture_step_screenshot(home_page.page, f"Verify the {block} block displays {field} as {value}"):
        actual = home_page.get_form_block_field_value(block, field)
        assert actual == value, f"'{field}' in the '{block}' block is '{actual}', expected '{value}'"


@then(parsers.parse('the "{block}" block should display the following options'))
@allure.step('Verify the "{block}" block displays the following options')
def verify_block_options(home_page: HomePage, block: str, datatable):
    with capture_step_screenshot(home_page.page, f"Verify the {block} block displays the following options"):
        for row in datatable:
            option = row[0].strip()
            assert home_page.is_form_block_option_displayed(block, option), f"'{option}' not visible in the '{block}' block"


# ---------------------------------------------------------------------------
# Notes panel (TC_13, TC_14) - the add / clear / verify steps already exist above
# ---------------------------------------------------------------------------

@when("I open the Notes section")
@allure.step("Open the Notes section")
def open_notes_section(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Open the Notes section"):
        home_page.ensure_notes_section_open()


# ---------------------------------------------------------------------------
# Audit Trail record counts (TC_15)
# ---------------------------------------------------------------------------

@then(parsers.parse('the Audit Trail should list at least {count:d} "{service_id}" records'))
@allure.step('Verify the Audit Trail lists at least {count} "{service_id}" records')
def verify_audit_trail_service_count(home_page: HomePage, count: int, service_id: str):
    with capture_step_screenshot(home_page.page, f"Verify the Audit Trail lists at least {count} {service_id} records"):
        service_ids = home_page.get_audit_trail_service_ids()
        actual = service_ids.count(service_id)
        assert actual >= count, f"Expected at least {count} '{service_id}' Audit Trail records, found {actual} in {service_ids}"


# ---------------------------------------------------------------------------
# Credit View Only screen (credit_view_only.feature)
# ---------------------------------------------------------------------------

@then("the opened Application ID should match the searched Application ID")
@allure.step("Verify the opened Application ID matches the searched Application ID")
def verify_opened_application_id(home_page: HomePage):
    with capture_step_screenshot(home_page.page, "Verify the opened Application ID matches the searched Application ID"):
        expected = str(get_app_id()).strip()
        actual = home_page.get_displayed_application_id()
        assert actual == expected, f"Searched Application ID '{expected}' but the screen shows '{actual}'"


@then(parsers.parse('the application status "{status}" should be displayed'))
@allure.step('Verify the application status "{status}" is displayed')
def verify_application_status_displayed(home_page: HomePage, status: str):
    with capture_step_screenshot(home_page.page, f"Verify the application status {status} is displayed"):
        assert home_page.is_status_displayed(status), f"Application status '{status}' was not displayed"
