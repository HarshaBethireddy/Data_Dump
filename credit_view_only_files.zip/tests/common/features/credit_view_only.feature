Feature: Credit View Only screen (Credit CL Analyst)

  Verify the "View only" > "Credit view" screen for the Credit CL Analyst role:
  homepage columns, opening an application, sections, Alter, Existing Customer,
  Letter History, Edit applicant data and Notes.
  (Unmask PII scenarios are intentionally left out for now.)

  Background:
    Given I open the homepage
    When I enter username "mock-user_1@bcuscc-ucb-qa.com" and password "123"
    And I click the login button
    And I click on PowerCurve Case Management button
    And I select the dropdown Role Selection as "Credit CL Analyst"

  @ui @smoke
  Scenario: TC_01 Verify the homepage is displayed for the Credit CL Analyst user role
    When I navigate to "View only" and select "Credit view"
    Then the following columns should be displayed on the homepage for the logged in user role
        | Locked                      |
        | Application ID              |
        | Locked by                   |
        | My apps                     |
        | Assigned user               |
        | Name                        |
        | Request type                |
        | PreQual ID                  |
        | SSN/Tax ID                  |
        | Updated date                |
        | Creation date               |
        | Status                      |
        | Credit review               |
        | Fraud review                |
        | KYC review                  |
        | Credit pend indicator       |
        | Fraud pend indicator        |
        | KYC pend indicator          |
        | Partner ID                  |
        | Awaiting consent - queue DC |
        | Decision type               |
        | Audit log                   |

  @ui @smoke
  Scenario: TC_02 Verify the ACQ Credit View only screen for a particular application
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "View only" and select "Credit view"
    And I search the application using Application ID
    Then the opened Application ID should match the searched Application ID

  @ui @smoke
  Scenario: TC_03 Verify all the sections in the ACQ Credit View only page
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "View only" and select "Credit view"
    And I search the application using Application ID
    Then I should see the following sections in ACQ Credit View screen
        | Applicant & Business info |
        | Bureau summary            |
        | Credit report viewer      |
        | Additional info           |

  @ui @smoke
  Scenario: TC_04 Verify the buttons enabled in the Credit View only screen
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "View only" and select "Credit view"
    And I search the application using Application ID
    And I click the "Alter" button
    Then the "Alter" heading should be displayed
    When I click the "Cancel" button
    Then the "Credit view" heading should be displayed
    When I click the Close button

  @ui @smoke
  Scenario: TC_05 Verify the Existing Customer field
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "View only" and select "Credit view"
    And I search the application using Application ID
    And I click on Existing Customer field
    Then the Existing Customer page should be displayed
    And I should see the following sections in ACQ Credit View screen
        | Application Summary  |
        | Multi Use SSN/Tax ID |
        | Card accounts        |
        | Consumer loan        |
        | Deposits             |
    When I click the Close button on Existing Customer page
    Then the Existing Customer page should be closed

  @ui @smoke
  Scenario: TC_06 Verify Letter History
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "View only" and select "Credit view"
    And I search the application using Application ID
    And I click on Letter History
    Then the Letter info section should be displayed
    And I should see the following sections in ACQ Credit View screen
        | Letter 1 |
        | Letter 2 |
        | Letter 3 |
        | Letter 4 |
        | Letter 5 |
    And the application status "Pending" should be displayed
    When I click the Close button on Letter History page
    Then the Letter History page should be closed

  @ui @smoke
  Scenario: TC_07 Verify Edit applicant data screen
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "View only" and select "Credit view"
    And I search the application using Application ID
    And I click the Edit Applicant Data button
    Then the "Edit applicant data" heading should be displayed
    When I click the "Exit" button

  # TC_08 / TC_09 (Unmask PII - Cancel / Proceed) - to be added later.

  @ui @smoke
  Scenario: TC_10 Verify Notes
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "View only" and select "Credit view"
    And I search the application using Application ID
    And I enter notes in the Notes section
    And I click on Add button
    Then the notes should be added successfully

  @ui @smoke
  Scenario: TC_11 Verify Clear button
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "View only" and select "Credit view"
    And I search the application using Application ID
    And I enter additional notes in the Notes section
    And I click the Clear button
    Then the Notes text area should be cleared
