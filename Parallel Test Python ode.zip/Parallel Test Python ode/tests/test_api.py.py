import pytest
from utils.http_client import HttpClient
from utils.xml_handler import XMLHandler
from utils.config import BASE_URL

xml_handler = XMLHandler("xml_files")
client = HttpClient(BASE_URL)

@pytest.mark.parametrize("file_name", ["request1.xml", "request2.xml"])
def test_send_raw_xml(file_name):
    # Load XML content
    xml_content = xml_handler.get_xml_content(file_name)

    # Send POST request with XML as payload
    headers = {"Content-Type": "application/xml"}
    response = client.post("/api/endpoint", headers=headers, data=xml_content)

    # Validate response
    assert response.status_code == 200
    assert "<success>true</success>" in response.text
