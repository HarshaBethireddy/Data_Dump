import os
import requests
import warnings
import logging
import time  # Import the time module
from concurrent.futures import ThreadPoolExecutor, as_completed

# Suppress SSL warnings
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# Configuration
API_URL = "http://10.31.208.250:9080/IBService?workflow=InboundJSONCPF"
JSON_FOLDER = "json_files"
TEST_RESPONSE_FOLDER = "TestResponse_VM3_run2"
REPORT_FOLDER = "Report"
PARALLEL_TEST_COUNT = 2
THINK_TIME = 3  # Think time in seconds

# Headers for JSON requests
HEADERS = {
    "Content-Type": "application/json",
    "User-Agent": "PostmanRuntime/7.32.2",
    "Host": "10.31.208.250:9080"
}

# Log configuration
LOG_FILE = os.path.join(REPORT_FOLDER, "test_log.log")
logging.basicConfig(filename=LOG_FILE, level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Ensure necessary folders exist
os.makedirs(TEST_RESPONSE_FOLDER, exist_ok=True)
os.makedirs(REPORT_FOLDER, exist_ok=True)

def send_json_request(session, file_path, json_data):
    """Send a JSON request using a shared session and save the response."""
    try:
        headers = HEADERS.copy()
        headers["Content-Length"] = str(len(json_data))

        response = session.post(API_URL, headers=headers, data=json_data, verify=False)

        response_file = os.path.join(TEST_RESPONSE_FOLDER, os.path.basename(file_path).replace('.json', '_response.json'))
        with open(response_file, "w") as file:
            file.write(response.text)

        logging.info(f"File: {file_path} | Status Code: {response.status_code}")
        return {"file": file_path, "status_code": response.status_code, "response": response.text}

    except Exception as e:
        logging.error(f"Error processing {file_path}: {e}")
        return {"file": file_path, "status_code": None, "response": str(e)}

def process_all_json_files_parallel():
    """Process all JSON files in parallel with optimized requests."""
    if not os.path.exists(JSON_FOLDER):
        print(f"Folder '{JSON_FOLDER}' not found.")
        return

    json_files = [os.path.join(JSON_FOLDER, file) for file in os.listdir(JSON_FOLDER) if file.endswith(".json")]
    
    if not json_files:
        print("No JSON files found.")
        return

    print(f"Found {len(json_files)} JSON files. Sending requests in parallel...")

    results = []
    
    # Read all JSON files into memory first to reduce I/O overhead
    json_data_dict = {file: open(file, "r").read() for file in json_files}

    with requests.Session() as session:  # Use a single session for connection pooling
        with ThreadPoolExecutor(max_workers=PARALLEL_TEST_COUNT) as executor:
            futures = {executor.submit(send_json_request, session, file, json_data_dict[file]): file for file in json_files}

            for i, future in enumerate(as_completed(futures)):
                results.append(future.result())
                print(f"Progress: {i + 1}/{len(json_files)} ({((i + 1) / len(json_files)) * 100:.2f}%)")
                time.sleep(THINK_TIME)  # Add a delay between requests

    generate_html_report(results)

def generate_html_report(results):
    """Generate an HTML report of test results."""
    try:
        report_file = os.path.join(REPORT_FOLDER, "test_report.html")
        with open(report_file, "w") as file:
            file.write("<html><head><title>Test Report</title></head><body>")
            file.write("<h1>Test Results</h1><table border='1'><tr><th>Request File</th><th>Status Code</th><th>Response</th></tr>")
            for result in results:
                file.write(f"<tr><td>{result['file']}</td><td>{result['status_code']}</td><td>{result['response']}</td></tr>")
            file.write("</table></body></html>")
        logging.info(f"HTML report generated: {report_file}")
    except Exception as e:
        logging.error(f"Error generating HTML report: {e}")

if __name__ == "__main__":
    process_all_json_files_parallel()