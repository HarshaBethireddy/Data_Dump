import os
import requests
import warnings
import logging
import time
import csv
from concurrent.futures import ThreadPoolExecutor, as_completed

# Suppress SSL warnings
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# Configuration
JSON_FOLDER = "json_files"
PARALLEL_TEST_COUNT = 2
THINK_TIME = 3  # Think time in seconds

# Token endpoint configuration
TOKEN_URL = "https://your-token-endpoint.com/token"
TOKEN_HEADERS = {
    "Content-Type": "application/x-www-form-urlencoded",
    "Authorization": "Basic your_base64_encoded_credentials"
}
TOKEN_PAYLOAD = {
    "grant_type": "client_credentials"
}

# Headers for JSON requests (Authorization will be added dynamically)
HEADERS = {
    "Content-Type": "application/json",
    "User-Agent": "PostmanRuntime/7.32.2"
}

# Function to get the next run ID
def get_next_run_id():
    run_id_file = os.path.join("Report", "run_id.txt")
    if os.path.exists(run_id_file):
        with open(run_id_file, "r") as file:
            run_id = int(file.read().strip()) + 1
    else:
        run_id = 100000

    with open(run_id_file, "w") as file:
        file.write(str(run_id))

    return run_id

# Function to read API URL and Host from CSV file
def read_api_config_from_csv(csv_file):
    with open(csv_file, mode='r') as file:
        csv_reader = csv.DictReader(file)
        for row in csv_reader:
            return row['API_URL'], row['Host']

# Read the API URL and Host from the CSV file
API_URL, HOST = read_api_config_from_csv('api_config.csv')

# Update the Host in headers
HEADERS["Host"] = HOST

# Get the next run ID and create subfolders
run_id = get_next_run_id()
TEST_RESPONSE_FOLDER = os.path.join("TestResponse", f"{run_id:06d}")
REPORT_FOLDER = os.path.join("Report", f"{run_id:06d}")

# Ensure necessary folders exist
os.makedirs(TEST_RESPONSE_FOLDER, exist_ok=True)
os.makedirs(REPORT_FOLDER, exist_ok=True)

# Log configuration
LOG_FILE = os.path.join(REPORT_FOLDER, "test_log.log")
logging.basicConfig(filename=LOG_FILE, level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def fetch_access_token():
    """Fetch a new access token from the token endpoint."""
    try:
        response = requests.post(TOKEN_URL, headers=TOKEN_HEADERS, data=TOKEN_PAYLOAD, verify=False)
        response.raise_for_status()
        token_data = response.json()
        return token_data.get("access_token")
    except Exception as e:
        logging.error(f"Failed to fetch token: {e}")
        return None

def send_json_request(session, file_path, json_data):
    """Send a JSON request using a shared session and save the response."""
    try:
        access_token = fetch_access_token()
        if not access_token:
            raise Exception("Access token not retrieved.")

        headers = HEADERS.copy()
        headers["Authorization"] = f"Bearer {access_token}"
        headers["Content-Length"] = str(len(json_data))

        response = session.post(API_URL, headers=headers, data=json_data, verify=False)

        response_file = os.path.join(TEST_RESPONSE_FOLDER, os.path.basename(file_path).replace('.json', '_response.json'))
        with open(response_file, "w") as file:
            file.write(response.text)

        logging.info(f"File: {file_path} | Status Code: {response.status_code}")
        return {"file": file_path, "status_code": response.status_code, "response": response.text}

    except Exception as e:
        logging.error(f"Error processing {file_path}: {e}")
        return {"file": file_path, "status_code": None, "response": str(e)}

def process_all_json_files_parallel():
    """Process all JSON files in parallel with optimized requests."""
    if not os.path.exists(JSON_FOLDER):
        print(f"Folder '{JSON_FOLDER}' not found.")
        return

    json_files = [os.path.join(JSON_FOLDER, file) for file in os.listdir(JSON_FOLDER) if file.endswith(".json")]
    
    if not json_files:
        print("No JSON files found.")
        return

    print(f"Found {len(json_files)} JSON files. Sending requests in parallel...")

    results = []
    
    # Read all JSON files into memory first to reduce I/O overhead
    json_data_dict = {file: open(file, "r").read() for file in json_files}

    start_time = time.time()  # Start time

    with requests.Session() as session:  # Use a single session for connection pooling
        with ThreadPoolExecutor(max_workers=PARALLEL_TEST_COUNT) as executor:
            futures = {executor.submit(send_json_request, session, file, json_data_dict[file]): file for file in json_files}

            for i, future in enumerate(as_completed(futures)):
                results.append(future.result())
                print(f"Progress: {i + 1}/{len(json_files)} ({((i + 1) / len(json_files)) * 100:.2f}%)")
                time.sleep(THINK_TIME)  # Add a delay between requests

    end_time = time.time()  # End time

    generate_html_report(results)

    # Calculate total execution duration
    total_duration_seconds = end_time - start_time
    total_duration_hours = int(total_duration_seconds // 3600)
    total_duration_minutes = int((total_duration_seconds % 3600) // 60)

    print(f"Total Execution Duration is {total_duration_hours}Hr and {total_duration_minutes} Mins")

def generate_html_report(results):
    """Generate an HTML report of test results, including only responses with 'ERROR' or 'Error'."""
    try:
        report_file = os.path.join(REPORT_FOLDER, "test_report.html")
        with open(report_file, "w") as file:
            file.write("<html><head><title>Test Report</title></head><body>")
            file.write("<h1>Test Results</h1><table border='1'><tr><th>Request File</th><th>Status Code</th><th>Response</th></tr>")
            for result in results:
                if "ERROR" in result['response'] or "Error" in result['response']:
                    file.write(f"<tr><td>{result['file']}</td><td>{result['status_code']}</td><td>{result['response']}</td></tr>")
                else:
                    file.write(f"<tr><td>{result['file']}</td><td>{result['status_code']}</td><td>Response does not contain 'ERROR' or 'Error'</td></tr>")
            file.write("</table></body></html>")
        logging.info(f"HTML report generated: {report_file}")
    except Exception as e:
        logging.error(f"Error generating HTML report: {e}")

if __name__ == "__main__":
    process_all_json_files_parallel()
