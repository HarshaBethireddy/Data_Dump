import os
import json
from openpyxl import load_workbook

# Paths
source_folder = "FullSetRequest"  # Replace with the path to your JSON folder
destination_folder = "json_files"  # Replace with the path to save updated JSON files
excel_file = "MasterTestdata.xlsx"  # Replace with your Excel file path

# Load Excel file
workbook = load_workbook(excel_file)
sheet = workbook.active

# Find the last value in the column and increment from there
last_row = sheet.max_row  # Get the last row with data in the column
last_value = int(sheet.cell(row=last_row, column=1).value)  # Get the last value in the column
increment_start = last_value + 1  # Start incrementing from the next value

# Update Excel column with incremented values
row = 2  # Start updating from A2
while sheet.cell(row=row, column=1).value is not None:
    sheet.cell(row=row, column=1).value = increment_start + (row - 2)  # Increment by position
    row += 1

# Save the updated Excel sheet
workbook.save(excel_file)  # This step ensures changes are written back to the file
print("Excel APPID values updated successfully.")

# Ensure destination folder exists
os.makedirs(destination_folder, exist_ok=True)

# Iterate over JSON files in the source folder
for idx, filename in enumerate(sorted(os.listdir(source_folder))):
    if filename.endswith(".json"):
        # Get the updated APPID value from the Excel file
        appid_cell = sheet.cell(row=idx + 2, column=1).value  # A2, A3, etc.

        if appid_cell is None:
            print(f"No APPID found for row {idx + 2}. Skipping file {filename}.")
            continue

        # Read the JSON file
        with open(os.path.join(source_folder, filename), "r") as file:
            try:
                data = json.load(file)
            except json.JSONDecodeError:
                print(f"Invalid JSON in file: {filename}. Skipping.")
                continue

        # Replace $APPID with the Excel value
        json_str = json.dumps(data)  # Convert JSON to string for replacement
        json_str = json_str.replace("$APPID", str(appid_cell))
        updated_data = json.loads(json_str)  # Convert back to JSON

        # Save updated JSON to the destination folder
        with open(os.path.join(destination_folder, filename), "w") as file:
            json.dump(updated_data, file, indent=4)

        print(f"Updated file saved: {filename}")
