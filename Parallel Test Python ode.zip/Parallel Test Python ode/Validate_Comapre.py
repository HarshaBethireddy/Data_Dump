import os
import json
import csv
from pathlib import Path

def compare_json_files(file1, file2):
    with open(file1, 'r') as f1, open(file2, 'r') as f2:
        json1 = json.load(f1)
        json2 = json.load(f2)
        
    differences = []
    compare_json(differences, json1, json2)
    
    return differences

def compare_json(differences, json1, json2, current_path=''):
    for key, value in json1.items():
        path = f"{current_path}.{key}" if current_path else key
        if isinstance(value, dict):
            if key in json2 and isinstance(json2[key], dict):
                compare_json(differences, value, json2[key], path)
            else:
                append_result(differences, path, value, None, False)
        elif isinstance(value, list):
            if key in json2 and isinstance(json2[key], list):
                list1 = format_value(value)
                list2 = format_value(json2[key])
                if list1 != list2:
                    append_result(differences, path, list1, list2, False)
            else:
                append_result(differences, path, format_value(value), None, False)
        else:
            if key in json2:
                if value != json2[key]:
                    append_result(differences, path, format_value(value), format_value(json2[key]), False)
            else:
                append_result(differences, path, format_value(value), None, False)
    
    for key, value in json2.items():
        path = f"{current_path}.{key}" if current_path else key
        if key not in json1:
            append_result(differences, path, None, format_value(value), False)

def append_result(differences, path, value1, value2, comparison_result):
    differences.append({
        'Path': path,
        'Value in File 1': truncate_value(value1),
        'Value in File 2': truncate_value(value2),
        'Comparison Result': comparison_result
    })

def format_value(value):
    return str(value).replace("\n", "").replace(",", ";")

def truncate_value(value, max_length=200):
    value_str = str(value) if value is not None else ''
    return value_str if len(value_str) <= max_length else value_str[:max_length] + '...'

def save_differences_to_csv(differences, output_file):
    with open(output_file, 'w', newline='') as csvfile:
        fieldnames = ['Path', 'Value in File 1', 'Value in File 2', 'Comparison Result']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        for diff in differences:
            writer.writerow(diff)

def main():
    pre_folder = input("Enter pre folder name: ")
    post_folder = input("Enter post folder name: ")
    
    folder1 = os.path.join('TestResponse', pre_folder)
    folder2 = os.path.join('TestResponse', post_folder)
    output_folder = os.path.join('CompareResult', f"{pre_folder}_vs_{post_folder}")
    
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    
    files1 = {f.stem: f for f in Path(folder1).glob('*.json')}
    files2 = {f.stem: f for f in Path(folder2).glob('*.json')}
    
    common_files = set(files1.keys()).intersection(set(files2.keys()))
    
    for file_key in common_files:
        file1 = files1[file_key]
        file2 = files2[file_key]
        
        differences = compare_json_files(file1, file2)
        
        if differences:
            output_file = os.path.join(output_folder, f"{file_key}_comparison_result.csv")
            save_differences_to_csv(differences, output_file)

# Run the main function
main()