import os

class XMLHandler:
    def __init__(self, folder_path):
        self.folder_path = folder_path

    def get_xml_content(self, file_name):
        file_path = os.path.join(self.folder_path, file_name)
        with open(file_path, 'r') as file:
            return file.read()
