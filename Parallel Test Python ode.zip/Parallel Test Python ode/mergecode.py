import pandas as pd
import os
from openpyxl import Workbook
from openpyxl.styles import PatternFill
from openpyxl.utils.dataframe import dataframe_to_rows
from datetime import datetime

# Function to merge CSV files into a single Excel sheet
def merge_csv_to_excel(parent_folder, sub_folder, output_folder):
    # Get the full path of the input folder
    input_folder = os.path.join(parent_folder, sub_folder)
    
    # Get list of CSV files in the input folder
    csv_files = [file for file in os.listdir(input_folder) if file.endswith('.csv')]
    
    # Extract common names from CSV files
    common_names = set(file.split('_')[0] for file in csv_files)
    
    # Create a new subfolder with the current date and time in the output folder
    current_datetime = datetime.now().strftime("%d%m%y%H%M")
    output_subfolder = os.path.join(output_folder, current_datetime)
    os.makedirs(output_subfolder, exist_ok=True)
    
    for common_name in common_names:
        # Filter CSV files with the same common name
        filtered_files = [file for file in csv_files if file.startswith(common_name)]
        
        # Create a new Excel workbook and select the active worksheet
        wb = Workbook()
        ws = wb.active

        # Define the yellow fill for separation rows
        yellow_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")

        # Add the header row from the first CSV file
        header_added = False

        for csv_file in filtered_files:
            # Read the CSV file into a DataFrame with error handling for encoding
            try:
                df = pd.read_csv(os.path.join(input_folder, csv_file), encoding='utf-8')
            except UnicodeDecodeError:
                df = pd.read_csv(os.path.join(input_folder, csv_file), encoding='ISO-8859-1')
            
            if not header_added:
                # Write the header row to the Excel sheet
                ws.append(['File Name'] + list(df.columns))
                header_added = True
            
            # Write the DataFrame to the Excel sheet, including the file name
            for row in dataframe_to_rows(df, index=False, header=False):
                ws.append([csv_file] + row)
            
            # Add a blank separation row with yellow fill above it
            ws.append([])
            for cell in ws[ws.max_row]:
                cell.fill = yellow_fill

        # Save the workbook to the specified output file with the common name
        output_excel = os.path.join(output_subfolder, f"{common_name}.xlsx")
        wb.save(output_excel)

        print(f"CSV files with common name '{common_name}' have been merged into {output_excel} successfully.")

# Parent folder containing the subfolders with CSV files
parent_folder = "CompareResult"

# Ask user for the subfolder name containing the CSV files
sub_folder = input("Enter the subfolder name containing the CSV files: ")

# Output folder path to save the Excel files
output_folder = "MergedOut_File"

# Merge the CSV files into separate Excel sheets based on common names
merge_csv_to_excel(parent_folder, sub_folder, output_folder)
