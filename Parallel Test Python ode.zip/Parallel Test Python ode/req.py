import os

# List of XML content for each request (dynamically created)
xml_data = []

for i in range(1, 201):
    xml_data.append(f"""<?xml version="1.0" encoding="UTF-8"?>
<request>
    <id>{i}</id>
    <name>Test {i}</name>
    <value>Value {i}</value>
</request>""")

# Create the folder if it doesn't exist
folder_path = "xml_files"
if not os.path.exists(folder_path):
    os.makedirs(folder_path)

# Write each XML to a file
for i, xml in enumerate(xml_data, start=1):
    file_path = os.path.join(folder_path, f"req{i}.xml")
    with open(file_path, "w") as file:
        file.write(xml)

print("200 XML files have been created and saved to the 'xml_files' folder.")
