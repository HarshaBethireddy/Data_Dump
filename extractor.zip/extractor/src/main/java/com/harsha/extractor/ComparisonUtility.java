package com.harsha.extractor;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;

/**
 * Refactored: writes one Excel per prefix (ACQ, CLI, EXP, Manual, PRQ, TU+) into a single folder.
 */
public class ComparisonUtility {

    // ---- CONFIG ----
    private static final String PRE_FOLDER_PATH  = "C:/Users/C24692E/Downloads/100005";
    private static final String POST_FOLDER_PATH = "C:/Users/C24692E/Downloads/100006";
    private static final String OUTPUT_FOLDER    = "C:/Users/C24692E/Downloads/APPIDComparison_Output";

    // Toggle for case sensitivity in prefix matching
    private static final boolean CASE_SENSITIVE = false;

    // Exact prefixes (in display form). "TU+" is literal (not regex).
    private static final List<String> CATEGORIES = Arrays.asList(
            "ACQ", "CLI", "EXP", "Manual", "PRQ", "TU+"
    );

    // If true, also emit an OTHERS file for items that don't match any category
    private static final boolean EMIT_OTHERS = true;

    // ---- APPID search keys (unchanged) ----
    private static final List<String> APPID_KEYS = Arrays.asList(
            "APPID","AppID","AppId","appId","appid","APP_ID","app_id","APP-ID","app-id"
    );
    private static final List<String> ID_KEYS = Arrays.asList(
            "id","ID","Id","value","appId","APPID"
    );

    public static void main(String[] args) throws Exception {
        compareAppIDsPartitioned(PRE_FOLDER_PATH, POST_FOLDER_PATH, OUTPUT_FOLDER);
    }

    /**
     * Main entry: read pre/post, compute union, then write multiple categorized Excel files.
     */
    public static void compareAppIDsPartitioned(String preFolderPath, String postFolderPath, String outputFolder) throws Exception {
        ObjectMapper mapper = new ObjectMapper();

        // 1) Extract Pre/Post AppIDs
        Map<String, String> preAppIds  = extractAppIDs(preFolderPath, mapper);
        Map<String, String> postAppIds = extractAppIDs(postFolderPath, mapper);

        // 2) Union of file names (case-insensitive order for readability)
        Set<String> allFileNames = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        allFileNames.addAll(preAppIds.keySet());
        allFileNames.addAll(postAppIds.keySet());

        // 3) Ensure output folder exists
        File outDir = new File(outputFolder);
        if (!outDir.exists() && !outDir.mkdirs()) {
            throw new IllegalStateException("Failed to create output directory: " + outDir.getAbsolutePath());
        }

        // 4) Emit one Excel per category
        int totalWritten = 0;
        Set<String> matched = new HashSet<>();

        for (String category : CATEGORIES) {
            List<RowData> rows = new ArrayList<>();
            for (String fileName : allFileNames) {
                if (belongsToCategory(fileName, category)) {
                    rows.add(new RowData(
                            fileName,
                            preAppIds.getOrDefault(fileName, ""),
                            postAppIds.getOrDefault(fileName, "")
                    ));
                    matched.add(fileName);
                }
            }
            if (!rows.isEmpty()) {
                String outPath = new File(outDir, "APPIDComparison_" + sanitizeForFileName(category) + ".xlsx").getAbsolutePath();
                writeExcel(rows, outPath);
                System.out.println("✅ Wrote: " + outPath + " (" + rows.size() + " rows)");
                totalWritten += rows.size();
            } else {
                System.out.println("ℹ️ No matches for category: " + category);
            }
        }

        // 5) Optional: OTHERS
        if (EMIT_OTHERS) {
            List<RowData> others = new ArrayList<>();
            for (String fileName : allFileNames) {
                if (!matched.contains(fileName)) {
                    others.add(new RowData(
                            fileName,
                            preAppIds.getOrDefault(fileName, ""),
                            postAppIds.getOrDefault(fileName, "")
                    ));
                }
            }
            if (!others.isEmpty()) {
                String outPath = new File(outDir, "APPIDComparison_OTHERS.xlsx").getAbsolutePath();
                writeExcel(others, outPath);
                System.out.println("✅ Wrote: " + outPath + " (" + others.size() + " rows)");
                totalWritten += others.size();
            }
        }

        System.out.println("🎯 Done. Total rows written across files: " + totalWritten);
        System.out.println("📁 Output folder: " + outDir.getAbsolutePath());
    }

    /** Returns true iff fileName starts with the literal category prefix (case per CASE_SENSITIVE flag). */
    private static boolean belongsToCategory(String fileName, String category) {
        if (CASE_SENSITIVE) {
            return fileName.startsWith(category);
        } else {
            return fileName.toUpperCase(Locale.ROOT).startsWith(category.toUpperCase(Locale.ROOT));
        }
    }

    /** Safe for Windows paths (keeps '+' which is allowed). */
    private static String sanitizeForFileName(String s) {
        // remove characters that are invalid on Windows: \ / : * ? " < > |
        return s.replace("\\", "")
                .replace("/", "")
                .replace(":", "")
                .replace("*", "")
                .replace("?", "")
                .replace("\"", "")
                .replace("<", "")
                .replace(">", "")
                .replace("|", "");
    }

    // ----------------- Excel writer -----------------
    private static void writeExcel(List<RowData> rows, String excelPath) throws Exception {
        try (Workbook workbook = new XSSFWorkbook();
             FileOutputStream fos = new FileOutputStream(excelPath)) {

            Sheet sheet = workbook.createSheet("AppID Comparison");

            // Header
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("File Name");
            header.createCell(1).setCellValue("Pre-AppID");
            header.createCell(2).setCellValue("Post-AppID");

            int rowIndex = 1;
            for (RowData rd : rows) {
                Row r = sheet.createRow(rowIndex++);
                r.createCell(0).setCellValue(rd.fileName);
                r.createCell(1).setCellValue(rd.preAppId);
                r.createCell(2).setCellValue(rd.postAppId);
            }

            for (int i = 0; i < 3; i++) sheet.autoSizeColumn(i);
            workbook.write(fos);
        }
    }

    // ----------------- Keep your existing JSON traversal logic -----------------
    private static Map<String, String> extractAppIDs(String folderPath, ObjectMapper mapper) throws Exception {
        Map<String, String> appIds = new HashMap<>();
        File folder = new File(folderPath);
        if (!folder.exists() || !folder.isDirectory()) {
            System.out.println("⚠️ Folder not found: " + folderPath);
            return appIds; // empty
        }
        File[] files = folder.listFiles();
        if (files == null) {
            System.out.println("⚠️ Could not list files in: " + folderPath);
            return appIds;
        }
        for (File file : files) {
            if (file == null || !file.isFile()) continue;
            String name = file.getName();
            if (!name.toLowerCase(Locale.ROOT).endsWith(".json")) continue;

            try {
                String content = Files.readString(file.toPath(), StandardCharsets.UTF_8);
                JsonNode root = mapper.readTree(content);
                String appId = findAppId(root);
                if (appId.isEmpty()) {
                    System.out.println("ℹ️ No APPID found in: " + name);
                } else {
                    System.out.println("✅ Found APPID in " + name + " -> " + appId);
                }
                appIds.put(name, appId);
            } catch (Exception e) {
                System.out.println("⚠️ Failed to parse " + name + ": " + e.getMessage());
                appIds.put(name, "");
            }
        }
        return appIds;
    }

    /** Recursively searches the JSON for APPID (various casings/variants). */
    private static String findAppId(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) return "";

        // 1) Direct lookup for known APPID keys at this level
        if (node.isObject()) {
            for (String key : APPID_KEYS) {
                JsonNode candidate = node.get(key);
                String v = nodeToIdString(candidate);
                if (!v.isEmpty()) return v;
            }
        }

        // 2) If object: also try fields whose name contains "appid", and recurse
        if (node.isObject()) {
            Iterator<Map.Entry<String, JsonNode>> it = node.fields();
            while (it.hasNext()) {
                Map.Entry<String, JsonNode> e = it.next();
                String fieldName = e.getKey();
                JsonNode value = e.getValue();

                if (fieldName != null && fieldName.toLowerCase(Locale.ROOT).contains("appid")) {
                    String v = nodeToIdString(value);
                    if (!v.isEmpty()) return v;
                }

                String deeper = findAppId(value);
                if (!deeper.isEmpty()) return deeper;
            }
        }

        // 3) If array: search each element
        if (node.isArray()) {
            for (JsonNode item : node) {
                String v = findAppId(item);
                if (!v.isEmpty()) return v;
            }
        }
        return "";
    }

    /** Converts candidate node (string/number/object/array) into the actual id string. */
    private static String nodeToIdString(JsonNode n) {
        if (n == null || n.isMissingNode() || n.isNull()) return "";
        if (n.isTextual() || n.isNumber() || n.isBoolean()) {
            return n.asText();
        }
        if (n.isObject()) {
            for (String idKey : ID_KEYS) {
                JsonNode inner = n.get(idKey);
                if (inner != null && !inner.isNull()) {
                    String v = nodeToIdString(inner);
                    if (!v.isEmpty()) return v;
                }
            }
            Iterator<Map.Entry<String, JsonNode>> it = n.fields();
            while (it.hasNext()) {
                Map.Entry<String, JsonNode> e = it.next();
                String v = nodeToIdString(e.getValue());
                if (!v.isEmpty()) return v;
            }
        }
        if (n.isArray()) {
            for (JsonNode item : n) {
                String v = nodeToIdString(item);
                if (!v.isEmpty()) return v;
            }
        }
        return "";
    }

    // Simple row holder
    private static class RowData {
        final String fileName;
        final String preAppId;
        final String postAppId;

        RowData(String fileName, String preAppId, String postAppId) {
            this.fileName = fileName;
            this.preAppId = preAppId;
            this.postAppId = postAppId;
        }
    }
}
