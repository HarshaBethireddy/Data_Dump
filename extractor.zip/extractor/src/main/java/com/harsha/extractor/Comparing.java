//package com.harsha.extractor;
//
//import org.apache.poi.ss.usermodel.*;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.openqa.selenium.*;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.support.ui.WebDriverWait;
//
//import java.io.*;
//import java.nio.file.Files;
//import java.nio.file.Paths;
//import java.time.Duration;
//import java.time.LocalDateTime;
//import java.util.*;
//import java.util.stream.Collectors;
//import java.time.format.DateTimeFormatter;
//
//public class Comparing {
//
//    // ======= Configuration =======
//    private static final String BASE_URL = "http://usaqwblbcus30.us.experian.eeca:8080/WebEngine/";
//    private static final String USERNAME = "Harsh";
//    private static final String PASSWORD = "Friday@0123!";
//    private static final String TARGET_GROUP_VISIBLE_TEXT = "Credit CLI Team Group";
//    private static final String TARGET_GROUP_VALUE = null;
//
//    private static final String EXCEL_FILE_PATH = "C:\\Users\\C24692E\\Downloads\\APPIDComparison.xlsx";
//    private static final String BASE_OUTPUT_DIRECTORY = "C:\\Users\\C24692E\\Downloads\\bureau_comparisons";
//
//    private static final DateTimeFormatter RUN_DIR_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");
//    private static final String OUTPUT_DIRECTORY = BASE_OUTPUT_DIRECTORY + "\\run_" + LocalDateTime.now().format(RUN_DIR_FORMATTER) + "\\";
//    private static final String COMPARISON_REPORT_PATH = OUTPUT_DIRECTORY + "comparison_report.txt";
//    // =============================
//
//    static class ApplicationData {
//        String fileName;
//        String preAppId;
//        String postAppId;
//
//        public ApplicationData(String fileName, String preAppId, String postAppId) {
//            this.fileName = fileName;
//            this.preAppId = preAppId;
//            this.postAppId = postAppId;
//        }
//
//        public boolean isValid() {
//            return fileName != null && !fileName.trim().isEmpty()
//                    && preAppId != null && !preAppId.trim().isEmpty()
//                    && postAppId != null && !postAppId.trim().isEmpty();
//        }
//    }
//
//    // ============================= MAIN (CHANGED) =============================
//    public static void main(String[] args) {
//        // Create output directory if it doesn't exist
//        try {
//            Files.createDirectories(Paths.get(OUTPUT_DIRECTORY));
//        } catch (IOException e) {
//            System.err.println("Failed to create output directory: " + e.getMessage());
//            return;
//        }
//
//        // Read Excel file and get valid application data
//        List<ApplicationData> applications = readExcelFile(EXCEL_FILE_PATH);
//        if (applications.isEmpty()) {
//            System.out.println("No valid application data found in Excel file.");
//            return;
//        }
//        System.out.println("Found " + applications.size() + " valid applications to process.");
//
//        StringBuilder comparisonReport = new StringBuilder();
//        comparisonReport.append("===== BUREAU DATA COMPARISON REPORT =====\n");
//        comparisonReport.append("Generated: ").append(LocalDateTime.now()).append("\n");
//        comparisonReport.append("==========================================\n\n");
//
//        // --- Start one browser session for all work ---
//        ChromeOptions options = new ChromeOptions();
//        options.addArguments("--start-maximized");
//        options.addArguments("--disable-blink-features=AutomationControlled");
//        WebDriver driver = new ChromeDriver(options);
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
//
//        try {
//            // Login once and land on Search screen (NEW)
//            loginAndOpenSearch(driver, wait);
//
//            // Process each row (pre + post with one session)
//            for (ApplicationData app : applications) {
//                System.out.println("\n" + "=".repeat(60));
//                System.out.println("Processing: " + app.fileName);
//                System.out.println("Pre-App ID: " + app.preAppId);
//                System.out.println("Post-App ID: " + app.postAppId);
//                System.out.println("=".repeat(60));
//
//                // PRE
//                String preOutputPath = OUTPUT_DIRECTORY + app.fileName + "_PRE_" + app.preAppId + ".txt";
//                boolean preSuccess = extractBureauDataForApplication(driver, wait, app.preAppId, preOutputPath, "PRE");
//                // Always return to Search screen after an attempt
//                returnToSearch(driver, wait);
//
//                // POST
//                String postOutputPath = OUTPUT_DIRECTORY + app.fileName + "_POST_" + app.postAppId + ".txt";
//                boolean postSuccess = extractBureauDataForApplication(driver, wait, app.postAppId, postOutputPath, "POST");
//                returnToSearch(driver, wait);
//
//                // Compare if both succeeded
//                if (preSuccess && postSuccess) {
//                    String comparisonResult = compareFiles(preOutputPath, postOutputPath, app.fileName);
//                    comparisonReport.append(comparisonResult).append("\n\n");
//                    System.out.println(comparisonResult);
//                } else {
//                    String errorMsg = "File: " + app.fileName + "\n"
//                            + "Status: EXTRACTION FAILED\n"
//                            + "Pre-App extraction: " + (preSuccess ? "SUCCESS" : "FAILED") + "\n"
//                            + "Post-App extraction: " + (postSuccess ? "SUCCESS" : "FAILED");
//                    comparisonReport.append(errorMsg).append("\n\n");
//                    System.err.println(errorMsg);
//                }
//            }
//
//            // Save comparison report
//            try (FileWriter writer = new FileWriter(COMPARISON_REPORT_PATH)) {
//                writer.write(comparisonReport.toString());
//                System.out.println("\n" + "=".repeat(60));
//                System.out.println("Comparison report saved to: " + COMPARISON_REPORT_PATH);
//                System.out.println("=".repeat(60));
//            } catch (IOException e) {
//                System.err.println("Failed to save comparison report: " + e.getMessage());
//            }
//
//        } finally {
//            sleepSeconds(2);
//            driver.quit();
//        }
//    }
//    // ========================= END MAIN (CHANGED) ============================
//
//    private static List<ApplicationData> readExcelFile(String excelPath) {
//        List<ApplicationData> applications = new ArrayList<>();
//        try (FileInputStream fis = new FileInputStream(excelPath);
//             Workbook workbook = new XSSFWorkbook(fis)) {
//            Sheet sheet = workbook.getSheetAt(0);
//            // Skip header row
//            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
//                Row row = sheet.getRow(i);
//                if (row == null) continue;
//                String fileName = getCellValueAsString(row.getCell(0));
//                String preAppId = getCellValueAsString(row.getCell(1));
//                String postAppId = getCellValueAsString(row.getCell(2));
//                ApplicationData appData = new ApplicationData(fileName, preAppId, postAppId);
//                if (appData.isValid()) {
//                    applications.add(appData);
//                    System.out.println("Added: " + fileName + " (Pre: " + preAppId + ", Post: " + postAppId + ")");
//                } else {
//                    System.out.println("Skipped: " + fileName + " (incomplete data)");
//                }
//            }
//        } catch (IOException e) {
//            System.err.println("Error reading Excel file: " + e.getMessage());
//            e.printStackTrace();
//        }
//        return applications;
//    }
//
//    private static String getCellValueAsString(Cell cell) {
//        if (cell == null) return null;
//        switch (cell.getCellType()) {
//            case STRING:
//                return cell.getStringCellValue().trim();
//            case NUMERIC:
//                double numValue = cell.getNumericCellValue();
//                if (numValue == Math.floor(numValue)) {
//                    return String.valueOf((long) numValue);
//                }
//                return String.valueOf(numValue);
//            case BLANK:
//                return null;
//            default:
//                return cell.toString().trim();
//        }
//    }
//
//    // ====================== NEW: One-time login + open Search =================
//    private static void loginAndOpenSearch(WebDriver driver, WebDriverWait wait) {
//        System.out.println("Opening login page and signing in...");
//        driver.get(BASE_URL);
//        sleepSeconds(3);
//
//        // Login
//        WebElement usernameInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idToken1")));
//        WebElement passwordInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idToken2")));
//        WebElement loginButton   = wait.until(ExpectedConditions.elementToBeClickable(By.id("loginButton_0")));
//        usernameInput.clear(); usernameInput.sendKeys(USERNAME);
//        passwordInput.clear(); passwordInput.sendKeys(PASSWORD);
//        loginButton.click();
//
//        // Select Group
//        sleepSeconds(3);
//        WebElement groupsSelectEl = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("groups")));
//        Select groupsSelect = new Select(groupsSelectEl);
//        if (TARGET_GROUP_VALUE != null && !TARGET_GROUP_VALUE.isBlank()) {
//            groupsSelect.selectByValue(TARGET_GROUP_VALUE);
//        } else {
//            groupsSelect.selectByVisibleText(TARGET_GROUP_VISIBLE_TEXT);
//        }
//        WebElement submitBtn = wait.until(ExpectedConditions.elementToBeClickable(By.id("id2")));
//        submitBtn.click();
//
//        // Navigate Menu → Search
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu-wrapper")));
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu")));
//        openMenuAndClick(driver, wait, "CLI Credit View", "CLI Full Search", "Search");
//        sleepSeconds(3);
//
//        // Verify Search screen
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("txt-appid")));
//        System.out.println("Ready on Search screen.");
//    }
//
//    // ================= CHANGED: Reuse driver per application ==================
//    private static boolean extractBureauDataForApplication(WebDriver driver,
//                                                           WebDriverWait wait,
//                                                           String applicationId,
//                                                           String outputPath,
//                                                           String type) {
//        try {
//            System.out.println("Starting extraction for " + type + " App ID: " + applicationId);
//
//            // 1) Ensure we're on Search screen (if prior step failed to return)
//            ensureOnSearchScreen(driver, wait);
//
//            // 2) Fill Application ID and Search
//            fillApplicationIdAndSearch(driver, wait, applicationId);
//
//            // 3) Click on the application link
//            clickOpenApplicationLink(driver, wait);
//
//            // 4) Click View Bureau button
//            clickViewBureauButton(driver, wait);
//
//            // 5) Extract bureau data (handles popup + child windows)
//            extractBureauData(driver, wait, applicationId, outputPath, type);
//
//            System.out.println("Successfully extracted " + type + " bureau data for App ID: " + applicationId);
//            return true;
//
//        } catch (Exception e) {
//            System.err.println("Error during extraction for " + type + " App ID " + applicationId + ": " + e.getMessage());
//            e.printStackTrace();
//
//            // Attempt to recover state back to Search for next iteration
//            try {
//                returnToSearch(driver, wait);
//            } catch (Exception ignore) { /* best-effort */ }
//
//            return false;
//        }
//    }
//
//    // ====================== NEW: Return to Search screen ======================
//    private static void returnToSearch(WebDriver driver, WebDriverWait wait) {
//        System.out.println("Returning to Search screen...");
//        // We should currently be on the application details page (with "View Bureau" button) after closing the popup.
//        // Try a "Back" button if the page provides one.
//        try {
//            // If your UI has a back button, add its locator here:
//            // Example: By.id("btn-back") or By.xpath("//button[normalize-space()='Back']")
//            // Adjust if needed for your app.
//            List<By> backLocators = Arrays.asList(
//                    By.id("btn-back"),
//                    By.xpath("//button[contains(@id,'back') or normalize-space(.)='Back']"),
//                    By.xpath("//a[contains(@id,'back') or normalize-space(.)='Back']")
//            );
//            boolean clicked = false;
//            for (By locator : backLocators) {
//                List<WebElement> btns = driver.findElements(locator);
//                if (!btns.isEmpty()) {
//                    wait.until(ExpectedConditions.elementToBeClickable(btns.get(0))).click();
//                    clicked = true;
//                    break;
//                }
//            }
//            if (!clicked) {
//                // Fall back to browser back
//                driver.navigate().back();
//            }
//            sleepSeconds(2);
//        } catch (Exception ignored) {
//            // As a fallback, browser back
//            driver.navigate().back();
//            sleepSeconds(2);
//        }
//
//        // If still not on search, fall back to menu navigation
//        if (driver.findElements(By.id("txt-appid")).isEmpty()) {
//            try {
//                wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu-wrapper")));
//                wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu")));
//                openMenuAndClick(driver, wait, "CLI Credit View", "CLI Full Search", "Search");
//            } catch (Exception e) {
//                // If menu not accessible (e.g., got logged out), try re-login
//                System.out.println("Menu navigation failed; attempting to re-login and open Search.");
//                loginAndOpenSearch(driver, wait);
//            }
//        }
//
//        // Confirm
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("txt-appid")));
//        System.out.println("Back on Search screen.");
//    }
//
//    private static void ensureOnSearchScreen(WebDriver driver, WebDriverWait wait) {
//        if (!driver.findElements(By.id("txt-appid")).isEmpty()) {
//            return;
//        }
//        
//        try {
//            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu-wrapper")));
//            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu")));
//            openMenuAndClick(driver, wait, "CLI Credit View", "CLI Full Search", "Search");
//        } catch (Exception e) {
//            // If we hit login page again (session timeout), re-login
//            if (!driver.findElements(By.id("idToken1")).isEmpty()) {
//                loginAndOpenSearch(driver, wait);
//            } else {
//                driver.navigate().back();
//                sleepSeconds(1);
//                openMenuAndClick(driver, wait, "CLI Credit View", "CLI Full Search", "Search");
//            }
//        }
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("txt-appid")));
//    }
//
//    // ================ (unchanged helpers reused/referenced) ===================
//    private static void fillApplicationIdAndSearch(WebDriver driver, WebDriverWait wait, String applicationId) {
//        System.out.println("Filling Application ID and searching...");
//        WebElement appIdField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("txt-appid")));
//        appIdField.clear();
//        for(char c : applicationId.toCharArray()) {
//        	appIdField.sendKeys(c + "");
//        	sleepSeconds(1);
//        }
//        WebElement searchButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("btn-search")));
//        searchButton.click();
//        sleepSeconds(3);
//    }
//
//    private static void clickOpenApplicationLink(WebDriver driver, WebDriverWait wait) {
//        System.out.println("Clicking on application link...");
//        WebElement openLink = wait.until(ExpectedConditions.elementToBeClickable(
//                By.xpath("//table[@id='datagrid']//td//div//center//a")));
//        openLink.click();
//        sleepSeconds(3);
//    }
//
//    private static void clickViewBureauButton(WebDriver driver, WebDriverWait wait) {
//        System.out.println("Clicking View Bureau button...");
//        WebElement viewBureauButton = wait.until(ExpectedConditions.elementToBeClickable(
//                By.id("PL__32-_ _32Main__46buttonViewBureau".replace(" ", "")) // keep your original id; fixed spaces if any
//        ));
//        viewBureauButton.click();
//        sleepSeconds(2);
//    }
//
//    private static void extractBureauData(WebDriver driver, WebDriverWait wait,
//                                          String applicationId, String outputPath, String type) throws IOException {
//        System.out.println("Extracting bureau data from popup...");
//        String mainWindow = driver.getWindowHandle();
//        Set<String> allWindows = driver.getWindowHandles();
//
//        String popupWindow = null;
//        for (String windowHandle : allWindows) {
//            if (!windowHandle.equals(mainWindow)) {
//                popupWindow = windowHandle;
//                break;
//            }
//        }
//        if (popupWindow == null) {
//            throw new RuntimeException("Popup window not found");
//        }
//
//        driver.switchTo().window(popupWindow);
//        System.out.println("Switched to popup window");
//        sleepSeconds(3);
//
//        StringBuilder allBureauData = new StringBuilder();
//        allBureauData.append("===== BUREAU DATA EXTRACTION =====\n");
//        allBureauData.append("Type: ").append(type).append("\n");
//        allBureauData.append("Application ID: ").append(applicationId).append("\n");
//        allBureauData.append("Extraction Time: ").append(LocalDateTime.now()).append("\n");
//        allBureauData.append("==================================\n\n");
//
//        try {
//            List<WebElement> requestResponseLinks = findRequestResponseLinks(driver, wait);
//            System.out.println("Found " + requestResponseLinks.size() + " request/response links");
//            for (int i = 0; i < requestResponseLinks.size(); i++) {
//                requestResponseLinks = findRequestResponseLinks(driver, wait);
//                if (i < requestResponseLinks.size()) {
//                    WebElement link = requestResponseLinks.get(i);
//                    String linkText = link.getText();
//                    String bureauKey = link.getAttribute("bureaukey");
//                    String linkType = link.getAttribute("type");
//                    System.out.println("Processing: " + bureauKey + " - " + linkType);
//
//                    allBureauData.append("\n").append("=".repeat(50)).append("\n");
//                    allBureauData.append("Bureau: ").append(bureauKey != null ? bureauKey : "Unknown").append("\n");
//                    allBureauData.append("Type: ").append(linkType != null ? linkType : linkText).append("\n");
//                    allBureauData.append("=".repeat(50)).append("\n");
//
//                    JavascriptExecutor js = (JavascriptExecutor) driver;
//                    js.executeScript("arguments[0].click();", link);
//                    sleepSeconds(2);
//
//                    Set<String> currentWindows = driver.getWindowHandles();
//                    String dataWindow = null;
//                    for (String windowHandle : currentWindows) {
//                        if (!windowHandle.equals(mainWindow) && !windowHandle.equals(popupWindow)) {
//                            dataWindow = windowHandle;
//                            break;
//                        }
//                    }
//                    if (dataWindow != null) {
//                        driver.switchTo().window(dataWindow);
//                        try {
//                            WebElement preElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("pre")));
//                            String preContent = preElement.getText();
//                            allBureauData.append(preContent).append("\n");
//                            System.out.println("Extracted " + preContent.length() + " characters");
//                        } catch (Exception e) {
//                            String bodyText = driver.findElement(By.tagName("body")).getText();
//                            allBureauData.append(bodyText).append("\n");
//                            System.out.println("Extracted body text: " + bodyText.length() + " characters");
//                        }
//                        driver.close(); // close data window
//                        driver.switchTo().window(popupWindow);
//                    }
//                    sleepSeconds(1);
//                }
//            }
//        } catch (Exception e) {
//            System.err.println("Error during data extraction: " + e.getMessage());
//            e.printStackTrace();
//        }
//
//        try (FileWriter writer = new FileWriter(outputPath)) {
//            writer.write(allBureauData.toString());
//            System.out.println("Bureau data saved to: " + outputPath);
//        }
//
//        // Close the popup window and return to main app details page
//        driver.close();
//        driver.switchTo().window(mainWindow);
//    }
//
//    private static String compareFiles(String preFilePath, String postFilePath, String fileName) {
//        StringBuilder result = new StringBuilder();
//        result.append("File: ").append(fileName).append("\n");
//        try {
//            List<String> preLines  = normalizeContent(Files.readAllLines(Paths.get(preFilePath)));
//            List<String> postLines = normalizeContent(Files.readAllLines(Paths.get(postFilePath)));
//
//            preLines  = removeMetadata(preLines);
//            postLines = removeMetadata(postLines);
//
//            if (preLines.equals(postLines)) {
//                result.append("Status: MATCHED - No differences found");
//            } else {
//                result.append("Status: DIFFERENCES FOUND\n");
//                result.append(findDifferences(preLines, postLines));
//            }
//        } catch (IOException e) {
//            result.append("Status: ERROR - Could not compare files\n");
//            result.append("Error: ").append(e.getMessage());
//        }
//        return result.toString();
//    }
//
//    private static List<String> normalizeContent(List<String> lines) {
//        return lines.stream()
//                .map(String::trim)
//                .filter(line -> !line.isEmpty())
//                .collect(Collectors.toList());
//    }
//
//    private static List<String> removeMetadata(List<String> lines) {
//        List<String> filtered = new ArrayList<>();
//        boolean skipMetadata = true;
//        for (String line : lines) {
//            // Skip initial metadata section
//            if (skipMetadata && line.contains("==================================")) {
//                skipMetadata = false;
//                continue;
//            }
//            // Skip timestamp and header lines
//            if (line.contains("Extraction Time:")
//                    || line.contains("Application ID:")
//                    || line.contains("Type:")) {
//                continue;
//            }
//            if (!skipMetadata) {
//                filtered.add(line);
//            }
//        }
//        return filtered;
//    }
//
//    private static String findDifferences(List<String> preLines, List<String> postLines) {
//        StringBuilder diff = new StringBuilder();
//        diff.append("Differences Details:\n");
//        int maxLines = Math.max(preLines.size(), postLines.size());
//        int diffCount = 0;
//        for (int i = 0; i < maxLines; i++) {
//            String preLine  = i < preLines.size()  ? preLines.get(i)  : "[MISSING]";
//            String postLine = i < postLines.size() ? postLines.get(i) : "[MISSING]";
//            if (!preLine.equals(postLine)) {
//                diffCount++;
//                if (diffCount <= 10) { // Show first 10 differences
//                    diff.append("\nLine ").append(i + 1).append(":\n");
//                    diff.append(" PRE: ").append(preLine.length() > 100 ? preLine.substring(0, 100) + "..." : preLine).append("\n");
//                    diff.append(" POST: ").append(postLine.length() > 100 ? postLine.substring(0, 100) + "..." : postLine).append("\n");
//                }
//            }
//        }
//        if (diffCount > 10) {
//            diff.append("\n... and ").append(diffCount - 10).append(" more differences");
//        }
//        diff.append("\n\nTotal differences found: ").append(diffCount);
//        diff.append("\nPre file lines: ").append(preLines.size());
//        diff.append("\nPost file lines: ").append(postLines.size());
//        return diff.toString();
//    }
//
//    // Expands all nodes inside any .jstree container.
//    private static void expandAllJsTreeNodes(WebDriver driver, WebDriverWait wait) {
//        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".jstree")));
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//
//        try {
//            Object usedApi = js.executeScript(
//                    "try {"
//                            + " if (window.$ && $('.jstree').length && $('.jstree').jstree) {"
//                            + "   var inst = $('.jstree').jstree(true) || $('.jstree').jstree();"
//                            + "   if (inst && inst.open_all) { inst.open_all(); return true; }"
//                            + " }"
//                            + "} catch(e) {}"
//                            + "return false;"
//            );
//            if (Boolean.TRUE.equals(usedApi)) {
//                try {
//                    wait.until(d -> driver.findElements(By.cssSelector(".jstree .jstree-loading")).isEmpty());
//                } catch (TimeoutException ignored) {}
//                return;
//            }
//        } catch (Exception ignored) {}
//
//        int safety = 0;
//        final int maxPasses = 50;
//        while (safety++ < maxPasses) {
//            List<WebElement> closedTogglers = driver.findElements(
//                    By.cssSelector(".jstree li.jstree-closed > i.jstree-ocl, .jstree li.jstree-closed > i.jstree-icon.jstree-ocl")
//            );
//            if (closedTogglers.isEmpty()) break;
//            int before = closedTogglers.size();
//            for (WebElement toggler : closedTogglers) {
//                try { js.executeScript("arguments[0].scrollIntoView({block:'center'});", toggler); } catch (JavascriptException ignored) {}
//                try {
//                    new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.elementToBeClickable(toggler)).click();
//                } catch (Exception clickEx) {
//                    js.executeScript("arguments[0].click();", toggler);
//                }
//                try { Thread.sleep(150); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
//            }
//            try {
//                wait.until(d -> {
//                    int after = driver.findElements(
//                            By.cssSelector(".jstree li.jstree-closed > i.jstree-ocl, .jstree li.jstree-closed > i.jstree-icon.jstree-ocl")
//                    ).size();
//                    return after < before;
//                });
//            } catch (TimeoutException ignored) {}
//        }
//    }
//
//    private static List<WebElement> findRequestResponseLinks(WebDriver driver, WebDriverWait wait) {
//        List<WebElement> links = new ArrayList<>();
//        try {
//            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("jstree")));
//            expandAllJsTreeNodes(driver, wait);
//            List<WebElement> rawLinks = driver.findElements(By.xpath("//a[@raw]"));
//            for (WebElement link : rawLinks) {
//                String type = link.getAttribute("type");
//                if ("request".equals(type) || "response".equals(type)) {
//                    links.add(link);
//                }
//            }
//        } catch (Exception e) {
//            System.err.println("Error finding request/response links: " + e.getMessage());
//        }
//        return links;
//    }
//
//    private static void openMenuAndClick(WebDriver driver, WebDriverWait wait, String... labels) {
//        if (labels == null || labels.length == 0) {
//            throw new IllegalArgumentException("At least one label is required");
//        }
//        Actions actions = new Actions(driver);
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//
//        WebElement menuWrapper = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu-wrapper")));
//        WebElement menuRoot    = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu")));
//
//        for (int i = 0; i < labels.length; i++) {
//            String label = labels[i].trim();
//            String anchorXPath = ".//ul[@id='menu']//a[" +
//                    "normalize-space(translate(., '»\u00BB', '')) = " + literalXPath(label) +
//                    "]";
//            WebElement link = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(anchorXPath)));
//            try { js.executeScript("arguments[0].scrollIntoView({block:'center'});", link); } catch (JavascriptException ignored) {}
//
//            if (i < labels.length - 1) {
//                actions.moveToElement(link).pause(Duration.ofMillis(250)).perform();
//                WebElement subMenu = link.findElement(By.xpath("./parent::li/ul"));
//                wait.until(ExpectedConditions.visibilityOf(subMenu));
//            } else {
//                try {
//                    wait.until(ExpectedConditions.elementToBeClickable(link)).click();
//                } catch (ElementClickInterceptedException | TimeoutException e) {
//                    js.executeScript("arguments[0].click();", link);
//                }
//            }
//        }
//    }
//
//    private static String literalXPath(String s) {
//        if (!s.contains("'")) {
//            return "'" + s + "'";
//        }
//        if (!s.contains("\"")) {
//            return "\"" + s + "\"";
//        }
//        String[] parts = s.split("'");
//        StringBuilder sb = new StringBuilder("concat(");
//        for (int i = 0; i < parts.length; i++) {
//            if (i > 0) sb.append(", \"'\", ");
//            sb.append("'").append(parts[i]).append("'");
//        }
//        sb.append(")");
//        return sb.toString();
//    }
//
//    private static void sleepSeconds(int seconds) {
//        try {
//            Thread.sleep(seconds * 1000L);
//        } catch (InterruptedException ie) {
//            Thread.currentThread().interrupt();
//        }
//    }
//}
