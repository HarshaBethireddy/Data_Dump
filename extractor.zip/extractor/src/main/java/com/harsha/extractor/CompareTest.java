//package com.harsha.extractor;
//
//import org.openqa.selenium.*;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.support.ui.WebDriverWait;
//
//import java.io.FileWriter;
//import java.io.IOException;
//import java.time.Duration;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Set;
//
//public class CompareTest {
//    // ======= Replace these with your actual values =======
//    private static final String BASE_URL = "http://usaqwblbcus30.us.experian.eeca:8080/WebEngine/";
//    private static final String USERNAME = "Harsh";
//    private static final String PASSWORD = "Friday@0123!";
//    // Choose ONE of the below ways to select group:
//    private static final String TARGET_GROUP_VISIBLE_TEXT = "Credit CLI Team Group";
//    private static final String TARGET_GROUP_VALUE = null;
//    private static final String APPLICATION_ID = "100256615";
//    private static final String OUTPUT_FILE_PATH = "C:\\Users\\C24692E\\Downloads\\res\\bureau_data_output.txt";
//    // =====================================================
//
//    public static void main(String[] args) {
//        ChromeOptions options = new ChromeOptions();
//        options.addArguments("--start-maximized");
//
//        WebDriver driver = new ChromeDriver(options);
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
//        WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(10));
//
//        try {
//            // 1) Open login page
//            driver.get(BASE_URL);
//
//            // 2) Optional hold
//            sleepSeconds(3);
//
//            // 3) Login
//            WebElement usernameInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idToken1")));
//            WebElement passwordInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idToken2")));
//            WebElement loginButton   = wait.until(ExpectedConditions.elementToBeClickable(By.id("loginButton_0")));
//
//            usernameInput.clear();
//            usernameInput.sendKeys(USERNAME);
//
//            passwordInput.clear();
//            passwordInput.sendKeys(PASSWORD);
//
//            loginButton.click();
//
//            // 4) Select Group
//            sleepSeconds(3);
//            WebElement groupsSelectEl = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("groups")));
//            Select groupsSelect = new Select(groupsSelectEl);
//
//            if (TARGET_GROUP_VALUE != null && !TARGET_GROUP_VALUE.isBlank()) {
//                groupsSelect.selectByValue(TARGET_GROUP_VALUE);
//            } else {
//                groupsSelect.selectByVisibleText(TARGET_GROUP_VISIBLE_TEXT);
//            }
//
//            WebElement submitBtn = wait.until(ExpectedConditions.elementToBeClickable(By.id("id2")));
//            submitBtn.click();
//
//            // 5) Navigate through menu
//            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu-wrapper")));
//            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu")));
//
//            openMenuAndClick(driver, wait,
//                    "CLI Credit View",
//                    "CLI Full Search",
//                    "Search"
//            );
//
//            System.out.println("Menu navigation completed successfully.");
//            sleepSeconds(3);
//
//            // 6) Fill Application ID and Search
//            fillApplicationIdAndSearch(driver, wait);
//
//            // 7) Click on the id44 link to open the application
//            clickOpenApplicationLink(driver, wait);
//
//            // 8) Click View Bureau button
//            clickViewBureauButton(driver, wait);
//
//            // 9) Switch to popup window and extract data
//            extractBureauData(driver, wait);
//
//            System.out.println("Bureau data extraction completed successfully.");
//
//        } catch (Exception e) {
//            System.err.println("Error during automation: " + e.getMessage());
//            e.printStackTrace();
//        } finally {
//            // Close the browser after a delay to observe results
//            sleepSeconds(5);
//            driver.quit();
//        }
//    }
//
//    private static void fillApplicationIdAndSearch(WebDriver driver, WebDriverWait wait) {
//        System.out.println("Filling Application ID and searching...");
//        
//        // Wait for the search form to load
//        WebElement appIdField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("txt-appid")));
//        
//        // Clear and fill the Application ID field
//        appIdField.clear();
//        appIdField.sendKeys(APPLICATION_ID);
//        
//        // Click the Search button
//        WebElement searchButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("btn-search")));
//        searchButton.click();
//        
//        // Wait for search results to load
//        sleepSeconds(3);
//    }
//
//    private static void clickOpenApplicationLink(WebDriver driver, WebDriverWait wait) {
//        System.out.println("Clicking on application link...");
//        
//        // Wait for and click the id44 link
//        WebElement openLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='datagrid']//td//div//center//a")));
//        openLink.click();
//        
//        // Wait for the page to load
//        sleepSeconds(3);
//    }
//
//    private static void clickViewBureauButton(WebDriver driver, WebDriverWait wait) {
//        System.out.println("Clicking View Bureau button...");
//        
//        // Store the current window handle
//        String mainWindow = driver.getWindowHandle();
//        
//        // Click the View Bureau button
//        WebElement viewBureauButton = wait.until(ExpectedConditions.elementToBeClickable(
//            By.id("PL__32-__32Main__46buttonViewBureau")));
//        viewBureauButton.click();
//        
//        // Wait for the popup window to open
//        sleepSeconds(2);
//    }
//
//    private static void extractBureauData(WebDriver driver, WebDriverWait wait) throws IOException {
//        System.out.println("Extracting bureau data from popup...");
//        
//        // Get all window handles
//        String mainWindow = driver.getWindowHandle();
//        Set<String> allWindows = driver.getWindowHandles();
//        String popupWindow = null;
//        
//        // Find the popup window
//        for (String windowHandle : allWindows) {
//            if (!windowHandle.equals(mainWindow)) {
//                popupWindow = windowHandle;
//                break;
//            }
//        }
//        
//        if (popupWindow == null) {
//            throw new RuntimeException("Popup window not found");
//        }
//        
//        // Switch to popup window
//        driver.switchTo().window(popupWindow);
//        System.out.println("Switched to popup window");
//        
//        // Wait for the tree structure to load
//        sleepSeconds(3);
//        
//        // Create a StringBuilder to collect all data
//        StringBuilder allBureauData = new StringBuilder();
//        allBureauData.append("===== BUREAU DATA EXTRACTION =====\n");
//        allBureauData.append("Application ID: ").append(APPLICATION_ID).append("\n");
//        allBureauData.append("Extraction Time: ").append(java.time.LocalDateTime.now()).append("\n");
//        allBureauData.append("==================================\n\n");
//        
//        try {
//            // Find all request/response links
//            List<WebElement> requestResponseLinks = findRequestResponseLinks(driver, wait);
//            
//            System.out.println("Found " + requestResponseLinks.size() + " request/response links");
//            
//            // Process each link
//            for (int i = 0; i < requestResponseLinks.size(); i++) {
//                // Re-find the links as the DOM might change after clicking
//                requestResponseLinks = findRequestResponseLinks(driver, wait);
//                
//                if (i < requestResponseLinks.size()) {
//                    WebElement link = requestResponseLinks.get(i);
//                    
//                    // Get link details
//                    String linkText = link.getText();
//                    String bureauKey = link.getAttribute("bureaukey");
//                    String type = link.getAttribute("type");
//                    
//                    System.out.println("Processing: " + bureauKey + " - " + type);
//                    
//                    // Add section header
//                    allBureauData.append("\n").append("=".repeat(50)).append("\n");
//                    allBureauData.append("Bureau: ").append(bureauKey != null ? bureauKey : "Unknown").append("\n");
//                    allBureauData.append("Type: ").append(type != null ? type : linkText).append("\n");
//                    allBureauData.append("=".repeat(50)).append("\n");
//                    
//                    // Click the link
//                    JavascriptExecutor js = (JavascriptExecutor) driver;
//                    js.executeScript("arguments[0].click();", link);
//                    
//                    // Wait for new window to open
//                    sleepSeconds(2);
//                    
//                    // Get all windows again
//                    Set<String> currentWindows = driver.getWindowHandles();
//                    String dataWindow = null;
//                    
//                    // Find the new window
//                    for (String windowHandle : currentWindows) {
//                        if (!windowHandle.equals(mainWindow) && !windowHandle.equals(popupWindow)) {
//                            dataWindow = windowHandle;
//                            break;
//                        }
//                    }
//                    
//                    if (dataWindow != null) {
//                        // Switch to data window
//                        driver.switchTo().window(dataWindow);
//                        
//                        // Extract the pre tag content
//                        try {
//                            WebElement preElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("pre")));
//                            String preContent = preElement.getText();
//                            allBureauData.append(preContent).append("\n");
//                            System.out.println("Extracted " + preContent.length() + " characters");
//                        } catch (Exception e) {
//                            // Try to get any text content if pre tag is not found
//                            String bodyText = driver.findElement(By.tagName("body")).getText();
//                            allBureauData.append(bodyText).append("\n");
//                            System.out.println("Extracted body text: " + bodyText.length() + " characters");
//                        }
//                        
//                        // Close the data window
//                        driver.close();
//                        
//                        // Switch back to popup window
//                        driver.switchTo().window(popupWindow);
//                    } else {
//                        System.out.println("Data window not opened for: " + linkText);
//                    }
//                    
//                    sleepSeconds(1);
//                }
//            }
//            
//        } catch (Exception e) {
//            System.err.println("Error during data extraction: " + e.getMessage());
//            e.printStackTrace();
//        }
//        
//        // Write all collected data to file
//        try (FileWriter writer = new FileWriter(OUTPUT_FILE_PATH)) {
//            writer.write(allBureauData.toString());
//            System.out.println("Bureau data saved to: " + OUTPUT_FILE_PATH);
//        }
//        
//        // Close popup window and switch back to main window
//        driver.close();
//        driver.switchTo().window(mainWindow);
//    }
//
//    private static List<WebElement> findRequestResponseLinks(WebDriver driver, WebDriverWait wait) {
//        List<WebElement> links = new ArrayList<>();
//        
//        try {
//            // Wait for the tree structure
//            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("jstree")));
//            
//            // Find all anchors with raw attribute (these are request/response links)
//            List<WebElement> rawLinks = driver.findElements(By.xpath("//a[@raw]"));
//            
//            for (WebElement link : rawLinks) {
//                String type = link.getAttribute("type");
//                if ("request".equals(type) || "response".equals(type)) {
//                    links.add(link);
//                }
//            }
//        } catch (Exception e) {
//            System.err.println("Error finding request/response links: " + e.getMessage());
//        }
//        
//        return links;
//    }
//
//    /**
//     * Hovers through each parent label and clicks the final leaf label.
//     * This ignores the '»' indicator span by normalizing the link text in XPath.
//     */
//    private static void openMenuAndClick(WebDriver driver, WebDriverWait wait, String... labels) {
//        if (labels == null || labels.length == 0) {
//            throw new IllegalArgumentException("At least one label is required");
//        }
//
//        Actions actions = new Actions(driver);
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//
//        // Ensure the menu is present
//        WebElement menuWrapper = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu-wrapper")));
//        WebElement menuRoot    = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu")));
//
//        for (int i = 0; i < labels.length; i++) {
//            String label = labels[i].trim();
//
//            // XPath notes:
//            // - translate(., '»\u00BB', '') removes the right-angle quote if present in the anchor's text (indicator).
//            // - normalize-space collapses spaces and trims.
//            String anchorXPath = ".//ul[@id='menu']//a[" +
//                    "normalize-space(translate(., '»\u00BB', '')) = " + literalXPath(label) +
//                    "]";
//
//            WebElement link = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(anchorXPath)));
//
//            // Scroll into view for stability
//            try {
//                js.executeScript("arguments[0].scrollIntoView({block:'center'});", link);
//            } catch (JavascriptException ignored) {}
//
//            if (i < labels.length - 1) {
//                // Intermediate level: hover to reveal the submenu <ul>
//                actions.moveToElement(link).pause(Duration.ofMillis(250)).perform();
//
//                // The submenu is usually the UL inside the same LI
//                WebElement subMenu = link.findElement(By.xpath("./parent::li/ul"));
//
//                // Wait for submenu to become visible
//                wait.until(ExpectedConditions.visibilityOf(subMenu));
//
//            } else {
//                // Final level: click the link
//                try {
//                    wait.until(ExpectedConditions.elementToBeClickable(link)).click();
//                } catch (ElementClickInterceptedException | TimeoutException e) {
//                    // Fallback to JS click if something intercepts
//                    js.executeScript("arguments[0].click();", link);
//                }
//            }
//        }
//    }
//
//    /**
//     * Safely wraps a Java string as an XPath string literal.
//     * Handles cases where the text may contain quotes.
//     */
//    private static String literalXPath(String s) {
//        if (!s.contains("'")) {
//            return "'" + s + "'";
//        }
//        if (!s.contains("\"")) {
//            return "\"" + s + "\"";
//        }
//        // Split at single quotes and concat using concat()
//        String[] parts = s.split("'");
//        StringBuilder sb = new StringBuilder("concat(");
//        for (int i = 0; i < parts.length; i++) {
//            if (i > 0) sb.append(", \"'\", ");
//            sb.append("'").append(parts[i]).append("'");
//        }
//        sb.append(")");
//        return sb.toString();
//    }
//
//    private static void sleepSeconds(int seconds) {
//        try {
//            Thread.sleep(seconds * 1000L);
//        } catch (InterruptedException ie) {
//            Thread.currentThread().interrupt();
//        }
//    }
//}