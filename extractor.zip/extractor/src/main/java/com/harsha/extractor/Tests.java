package com.harsha.extractor;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import java.time.format.DateTimeFormatter;

public class Tests {
    // ======= Configuration =======
    private static final String BASE_URL = "http://usaqwblbcus30.us.experian.eeca:8080/WebEngine/";
    private static final String USERNAME = "Harsh";
    private static final String PASSWORD = "Friday@0123!";
    private static final String TARGET_GROUP_VISIBLE_TEXT = "Credit Team Group";
    private static final String TARGET_GROUP_VALUE = null;
    private static String EXCEL_FILE_PATH = "C:\\Users\\C24692E\\Downloads\\APPIDComparison.xlsx";
    private static final String BASE_OUTPUT_DIRECTORY = "C:\\Users\\C24692E\\Downloads\\bureau_comparisons";
    private static final DateTimeFormatter RUN_DIR_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");
    private static final String OUTPUT_DIRECTORY =  BASE_OUTPUT_DIRECTORY + "\\run_" + LocalDateTime.now().format(RUN_DIR_FORMATTER) + "\\";
    private static final String COMPARISON_REPORT_PATH = OUTPUT_DIRECTORY + "comparison_report.txt";

    // =============================

    static class ApplicationData {
        String fileName;
        String preAppId;
        String postAppId;
        
        public ApplicationData(String fileName, String preAppId, String postAppId) {
            this.fileName = fileName;
            this.preAppId = preAppId;
            this.postAppId = postAppId;
        }
        
        public boolean isValid() {
            return fileName != null && !fileName.trim().isEmpty() &&
                   preAppId != null && !preAppId.trim().isEmpty() &&
                   postAppId != null && !postAppId.trim().isEmpty();
        }
    }

    public static void main(String[] args) {
        try {
            Files.createDirectories(Paths.get(OUTPUT_DIRECTORY));
        } catch (IOException e) {
            System.err.println("Failed to create output directory: " + e.getMessage());
            return;
        }

        // Read Excel file and get valid application data
        List<ApplicationData> applications = readExcelFile(EXCEL_FILE_PATH);
        
        if (applications.isEmpty()) {
            System.out.println("No valid application data found in Excel file.");
            return;
        }
        
        System.out.println("Found " + applications.size() + " valid applications to process.");
        
        // Initialize WebDriver once
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        options.addArguments("--disable-blink-features=AutomationControlled");
        
        WebDriver driver = new ChromeDriver(options);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        
        try {
            // Perform login and initial setup once
            if (!performInitialSetup(driver, wait)) {
                System.err.println("Initial setup failed. Exiting...");
                return;
            }
            
            // Process each application with the same driver
            StringBuilder comparisonReport = new StringBuilder();
            comparisonReport.append("===== BUREAU DATA COMPARISON REPORT =====\n");
            comparisonReport.append("Generated: ").append(LocalDateTime.now()).append("\n");
            comparisonReport.append("==========================================\n\n");
            
            for (int i = 0; i < applications.size(); i++) {
                ApplicationData app = applications.get(i);
                System.out.println("\n" + "=".repeat(60));
                System.out.println("Processing (" + (i + 1) + "/" + applications.size() + "): " + app.fileName);
                System.out.println("Pre-App ID: " + app.preAppId);
                System.out.println("Post-App ID: " + app.postAppId);
                System.out.println("=".repeat(60));
                
                // Extract bureau data for Pre-App ID
                String preOutputPath = OUTPUT_DIRECTORY + app.fileName + "_PRE_" + app.preAppId + ".txt";
                boolean preSuccess = extractBureauDataForApplication(driver, wait, app.preAppId, preOutputPath, "PRE");
                
                // Navigate back to search screen after pre extraction
                if (preSuccess) {
                    navigateBackToSearch(driver, wait);
                }
                
                // Extract bureau data for Post-App ID
                String postOutputPath = OUTPUT_DIRECTORY + app.fileName + "_POST_" + app.postAppId + ".txt";
                boolean postSuccess = extractBureauDataForApplication(driver, wait, app.postAppId, postOutputPath, "POST");
                
                // Navigate back to search screen after post extraction (except for the last iteration)
                if (postSuccess && i < applications.size() - 1) {
                    navigateBackToSearch(driver, wait);
                }
                
                // Compare the files if both extractions were successful
                if (preSuccess && postSuccess) {
                    String comparisonResult = compareFiles(preOutputPath, postOutputPath, app.fileName, app.preAppId, app.postAppId);
                    comparisonReport.append(comparisonResult).append("\n\n");
                    System.out.println(comparisonResult);
                } else {
                    String errorMsg = "File: " + app.fileName + "\n" +
                                     "Status: EXTRACTION FAILED\n" +
                                     "Pre-App extraction: " + (preSuccess ? "SUCCESS" : "FAILED") + "\n" +
                                     "Post-App extraction: " + (postSuccess ? "SUCCESS" : "FAILED");
                    comparisonReport.append(errorMsg).append("\n\n");
                    System.err.println(errorMsg);
                }
            }
            
            // Save comparison report
            try (FileWriter writer = new FileWriter(COMPARISON_REPORT_PATH)) {
                writer.write(comparisonReport.toString());
                System.out.println("\n" + "=".repeat(60));
                System.out.println("Comparison report saved to: " + COMPARISON_REPORT_PATH);
                System.out.println("=".repeat(60));
            } catch (IOException e) {
                System.err.println("Failed to save comparison report: " + e.getMessage());
            }
            
        } catch (Exception e) {
            System.err.println("Unexpected error during processing: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Close driver at the very end
            sleepSeconds(2);
            driver.quit();
            System.out.println("WebDriver closed successfully.");
        }
    }

    private static boolean performInitialSetup(WebDriver driver, WebDriverWait wait) {
        try {
            System.out.println("Performing initial setup (login and navigation)...");
            
            // 1) Open login page
            driver.get(BASE_URL);
            sleepSeconds(3);
            
            // 2) Login
            WebElement usernameInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idToken1")));
            WebElement passwordInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idToken2")));
            WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("loginButton_0")));
            
            usernameInput.clear();
            usernameInput.sendKeys(USERNAME);
            passwordInput.clear();
            passwordInput.sendKeys(PASSWORD);
            loginButton.click();
            
            // 3) Select Group
            sleepSeconds(3);
            WebElement groupsSelectEl = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("groups")));
            Select groupsSelect = new Select(groupsSelectEl);
            
            if (TARGET_GROUP_VALUE != null && !TARGET_GROUP_VALUE.isBlank()) {
                groupsSelect.selectByValue(TARGET_GROUP_VALUE);
            } else {
                groupsSelect.selectByVisibleText(TARGET_GROUP_VISIBLE_TEXT);
            }
            
            WebElement submitBtn = wait.until(ExpectedConditions.elementToBeClickable(By.id("id2")));
            submitBtn.click();
            
            // 4) Navigate to search screen
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu-wrapper")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu")));
            
            openMenuAndClick(driver, wait, "Credit View", "Credit Full", "Search");
            sleepSeconds(3);
            
            System.out.println("Initial setup completed successfully.");
            return true;
            
        } catch (Exception e) {
            System.err.println("Error during initial setup: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    private static boolean extractBureauDataForApplication(WebDriver driver, WebDriverWait wait, 
                                                           String applicationId, String outputPath, String type) {
        try {
            System.out.println("Starting extraction for " + type + " App ID: " + applicationId);
            
            // Fill Application ID and Search
            fillApplicationIdAndSearch(driver, wait, applicationId);
            
            // Click on the application link
            clickOpenApplicationLink(driver, wait);
            
            // Click View Bureau button
            clickViewBureauButton(driver, wait);
            
            // Extract bureau data
            extractBureauData(driver, wait, applicationId, outputPath, type);
            
            System.out.println("Successfully extracted " + type + " bureau data for App ID: " + applicationId);
            return true;
            
        } catch (Exception e) {
            System.err.println("Error during extraction for " + type + " App ID " + applicationId + ": " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    private static void navigateBackToSearch(WebDriver driver, WebDriverWait wait) {
        try {
            System.out.println("Navigating back to search screen...");
            
            // Click the Close button
            WebElement closeButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.id("PL__32-__32Main__46buttonClose")));
            closeButton.click();
            
            sleepSeconds(2);
            
            // Handle the confirmation modal
            handleConfirmationModal(driver, wait);
            
            // Wait for search screen to be ready
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("txt-appid")));
            sleepSeconds(2);
            
            System.out.println("Successfully navigated back to search screen.");
            
        } catch (Exception e) {
            System.err.println("Error navigating back to search: " + e.getMessage());
            // Fallback: try to navigate to search page directly
            try {
            	openMenuAndClick(driver, wait, "Credit View", "Credit Full", "Search");
                sleepSeconds(3);
            } catch (Exception fallbackError) {
                System.err.println("Fallback navigation also failed: " + fallbackError.getMessage());
                throw new RuntimeException("Failed to navigate back to search screen", e);
            }
        }
    }

    private static void handleConfirmationModal(WebDriver driver, WebDriverWait wait) {
        try {
            // Wait for the modal to appear
            WebElement modal = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(".wicket-modal")));
            
            // Click OK button in the modal
            WebElement okButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//*[@name='ok']")));
            okButton.click();
            
            // Wait for modal to disappear
            wait.until(ExpectedConditions.invisibilityOf(modal));
            
            System.out.println("Confirmation modal handled successfully.");
            
        } catch (Exception e) {
            System.err.println("Error handling confirmation modal: " + e.getMessage());
            // Try alternative selectors for OK button
            try {
                WebElement okButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//input[@type='button' and @value='OK']")));
                okButton.click();
                sleepSeconds(2);
            } catch (Exception altError) {
                System.err.println("Alternative modal handling also failed: " + altError.getMessage());
                throw e;
            }
        }
    }

    private static List<ApplicationData> readExcelFile(String excelPath) {
        List<ApplicationData> applications = new ArrayList<>();
        
        try (FileInputStream fis = new FileInputStream(excelPath);
             Workbook workbook = new XSSFWorkbook(fis)) {
            
            Sheet sheet = workbook.getSheetAt(0);
            
            // Skip header row (assuming first row is header)
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;
                
                String fileName = getCellValueAsString(row.getCell(0));
                String preAppId = getCellValueAsString(row.getCell(1));
                String postAppId = getCellValueAsString(row.getCell(2));
                
                ApplicationData appData = new ApplicationData(fileName, preAppId, postAppId);
                
                // Only add if both Pre and Post App IDs are present
                if (appData.isValid()) {
                    applications.add(appData);
                    System.out.println("Added: " + fileName + " (Pre: " + preAppId + ", Post: " + postAppId + ")");
                } else {
                    System.out.println("Skipped: " + fileName + " (incomplete data)");
                }
            }
            
        } catch (IOException e) {
            System.err.println("Error reading Excel file: " + e.getMessage());
            e.printStackTrace();
        }
        
        return applications;
    }

    private static String getCellValueAsString(Cell cell) {
        if (cell == null) return null;
        
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                // Handle numeric values (remove decimal point if it's a whole number)
                double numValue = cell.getNumericCellValue();
                if (numValue == Math.floor(numValue)) {
                    return String.valueOf((long) numValue);
                }
                return String.valueOf(numValue);
            case BLANK:
                return null;
            default:
                return cell.toString().trim();
        }
    }

//    private static void fillApplicationIdAndSearch(WebDriver driver, WebDriverWait wait, String applicationId) {
//        System.out.println("Filling Application ID and searching...");
//        WebElement appIdField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("txt-appid")));
//        appIdField.clear();
//        appIdField.sendKeys(applicationId);
//        WebElement searchButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("btn-search")));
//        searchButton.click();
//        
//        sleepSeconds(3);
//    }
    
    private static void fillApplicationIdAndSearch(WebDriver driver, WebDriverWait wait, String applicationId) {
        System.out.println("Filling Application ID and searching for: " + applicationId);
        
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("txt-appid")));
            
            sleepSeconds(2);

            WebElement appIdField = wait.until(ExpectedConditions.elementToBeClickable(By.id("txt-appid")));

            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", appIdField);
            appIdField.click();

            appIdField.sendKeys(Keys.CONTROL + "a");
            appIdField.sendKeys(Keys.DELETE);

            sleepSeconds(1);

            String currentValue = appIdField.getAttribute("value");
            if (currentValue != null && !currentValue.trim().isEmpty()) {
                ((JavascriptExecutor) driver).executeScript("arguments[0].value = '';", appIdField);
            }

            for (char c : applicationId.toCharArray()) {
                appIdField.sendKeys(String.valueOf(c));
                Thread.sleep(50);
            }

            wait.until(ExpectedConditions.attributeToBe(By.id("txt-appid"), "value", applicationId));

            sleepSeconds(2);

            String finalValue = appIdField.getAttribute("value");
            if (!applicationId.equals(finalValue)) {
                throw new RuntimeException("Application ID field value mismatch. Expected: " + 
                                         applicationId + ", Found: " + finalValue);
            }
            
            System.out.println("Application ID successfully entered: " + finalValue);

            WebElement searchButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("btn-search")));

            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", searchButton);
            sleepSeconds(1);
            
            searchButton.click();
            System.out.println("Search button clicked successfully");
            
            sleepSeconds(3);
            
        } catch (Exception e) {
            System.err.println("Error in fillApplicationIdAndSearch: " + e.getMessage());
            try {
                System.out.println("Attempting fallback method...");
                fillApplicationIdAndSearchFallback(driver, wait, applicationId);
            } catch (Exception fallbackError) {
                System.err.println("Fallback method also failed: " + fallbackError.getMessage());
                throw new RuntimeException("Both primary and fallback methods failed", e);
            }
        }
    }

    private static void fillApplicationIdAndSearchFallback(WebDriver driver, WebDriverWait wait, String applicationId) {
        System.out.println("Using JavaScript fallback method for: " + applicationId);
        
        JavascriptExecutor js = (JavascriptExecutor) driver;

        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("txt-appid")));

        js.executeScript(
            "var element = document.getElementById('txt-appid');" +
            "element.focus();" +
            "element.value = '';" +
            "element.value = arguments[0];" +
            "element.dispatchEvent(new Event('input', { bubbles: true }));" +
            "element.dispatchEvent(new Event('change', { bubbles: true }));" +
            "element.blur();",
            applicationId
        );

        sleepSeconds(2);

        String setValue = (String) js.executeScript("return document.getElementById('txt-appid').value;");
        if (!applicationId.equals(setValue)) {
            throw new RuntimeException("JavaScript fallback failed. Expected: " + 
                                     applicationId + ", Found: " + setValue);
        }
        
        System.out.println("JavaScript method successfully set value: " + setValue);

        js.executeScript("document.getElementById('btn-search').click();");
        System.out.println("Search button clicked via JavaScript");
        
        sleepSeconds(3);
    }

    private static void fillApplicationIdAndSearchWithRetry(WebDriver driver, WebDriverWait wait, String applicationId) {
        int maxRetries = 3;
        
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                System.out.println("Attempt " + attempt + " to search for: " + applicationId);
                fillApplicationIdAndSearch(driver, wait, applicationId);

                verifySearchResults(driver, wait, applicationId);
                
                System.out.println("Search successful on attempt " + attempt);
                return;
                
            } catch (Exception e) {
                System.err.println("Attempt " + attempt + " failed: " + e.getMessage());
                
                if (attempt < maxRetries) {
                    System.out.println("Retrying in 3 seconds...");
                    sleepSeconds(3);
                    
                    try {
                        refreshSearchForm(driver, wait);
                    } catch (Exception refreshError) {
                        System.err.println("Could not refresh search form: " + refreshError.getMessage());
                    }
                } else {
                    throw new RuntimeException("All " + maxRetries + " attempts failed for: " + applicationId, e);
                }
            }
        }
    }

    private static void verifySearchResults(WebDriver driver, WebDriverWait wait, String applicationId) {
        try {
            // Wait for either results table or no results message
            WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(30));
            
            boolean hasResults = false;
            try {
                // Check if results table appeared
                WebElement resultsTable = shortWait.until(ExpectedConditions.presenceOfElementLocated(
                    By.xpath("//table[@id='datagrid']//td//div//center//a")));
                hasResults = true;
                System.out.println("Search results found for: " + applicationId);
            } catch (TimeoutException e) {
                // Check for "no results" message
                List<WebElement> noResultsElements = driver.findElements(
                    By.xpath("//*[contains(text(), 'No records found') or contains(text(), 'No results')]"));
                
                if (!noResultsElements.isEmpty()) {
                    throw new RuntimeException("No records found for Application ID: " + applicationId);
                } else {
                    throw new RuntimeException("Search did not return expected results for: " + applicationId);
                }
            }
            
        } catch (Exception e) {
            throw new RuntimeException("Failed to verify search results for: " + applicationId, e);
        }
    }

    private static void refreshSearchForm(WebDriver driver, WebDriverWait wait) {
        try {
            WebElement appIdField = driver.findElement(By.id("txt-appid"));
            appIdField.clear();
            wait.until(ExpectedConditions.attributeToBe(By.id("txt-appid"), "value", ""));
            
            sleepSeconds(1);
            System.out.println("Search form refreshed");
            
        } catch (Exception e) {
            System.err.println("Failed to refresh search form: " + e.getMessage());
            throw e;
        }
    }

    private static void clickOpenApplicationLink(WebDriver driver, WebDriverWait wait) {
        System.out.println("Clicking on application link...");
        
        WebElement openLink = wait.until(ExpectedConditions.elementToBeClickable(
            By.xpath("//table[@id='datagrid']//td//div//center//a")));
        openLink.click();
        
        sleepSeconds(3);
    }

    private static void clickViewBureauButton(WebDriver driver, WebDriverWait wait) {
        System.out.println("Clicking View Bureau button...");
        
        WebElement viewBureauButton = wait.until(ExpectedConditions.elementToBeClickable(
            By.id("PL__32-__32Main__46buttonViewBureau")));
        viewBureauButton.click();
        
        sleepSeconds(2);
    }

    private static void extractBureauData(WebDriver driver, WebDriverWait wait, String applicationId, 
                                         String outputPath, String type) throws IOException {
        System.out.println("Extracting bureau data from popup...");
        
        String mainWindow = driver.getWindowHandle();
        Set<String> allWindows = driver.getWindowHandles();
        String popupWindow = null;
        
        for (String windowHandle : allWindows) {
            if (!windowHandle.equals(mainWindow)) {
                popupWindow = windowHandle;
                break;
            }
        }
        
        if (popupWindow == null) {
            throw new RuntimeException("Popup window not found");
        }
        
        driver.switchTo().window(popupWindow);
        System.out.println("Switched to popup window");
        
        sleepSeconds(3);
        
        StringBuilder allBureauData = new StringBuilder();
        allBureauData.append("===== BUREAU DATA EXTRACTION =====\n");
        allBureauData.append("Type: ").append(type).append("\n");
        allBureauData.append("Application ID: ").append(applicationId).append("\n");
        allBureauData.append("Extraction Time: ").append(LocalDateTime.now()).append("\n");
        allBureauData.append("==================================\n\n");
        
        try {
            List<WebElement> requestResponseLinks = findRequestResponseLinks(driver, wait);
            System.out.println("Found " + requestResponseLinks.size() + " request/response links");
            
            for (int i = 0; i < requestResponseLinks.size(); i++) {
                requestResponseLinks = findRequestResponseLinks(driver, wait);
                
                if (i < requestResponseLinks.size()) {
                    WebElement link = requestResponseLinks.get(i);
                    
                    String linkText = link.getText();
                    String bureauKey = link.getAttribute("bureaukey");
                    String linkType = link.getAttribute("type");
                    
                    System.out.println("Processing: " + bureauKey + " - " + linkType);
                    
                    allBureauData.append("\n").append("=".repeat(50)).append("\n");
                    allBureauData.append("Bureau: ").append(bureauKey != null ? bureauKey : "Unknown").append("\n");
                    allBureauData.append("Type: ").append(linkType != null ? linkType : linkText).append("\n");
                    allBureauData.append("=".repeat(50)).append("\n");
                    
                    JavascriptExecutor js = (JavascriptExecutor) driver;
                    js.executeScript("arguments[0].click();", link);
                    
                    sleepSeconds(2);
                    
                    Set<String> currentWindows = driver.getWindowHandles();
                    String dataWindow = null;
                    
                    for (String windowHandle : currentWindows) {
                        if (!windowHandle.equals(mainWindow) && !windowHandle.equals(popupWindow)) {
                            dataWindow = windowHandle;
                            break;
                        }
                    }
                    
                    if (dataWindow != null) {
                        driver.switchTo().window(dataWindow);
                        
                        try {
                            WebElement preElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("pre")));
                            String preContent = preElement.getText();
                            allBureauData.append(preContent).append("\n");
                            System.out.println("Extracted " + preContent.length() + " characters");
                        } catch (Exception e) {
                            String bodyText = driver.findElement(By.tagName("body")).getText();
                            allBureauData.append(bodyText).append("\n");
                            System.out.println("Extracted body text: " + bodyText.length() + " characters");
                        }
                        
                        driver.close();
                        driver.switchTo().window(popupWindow);
                    }
                    
                    sleepSeconds(1);
                }
            }
            
        } catch (Exception e) {
            System.err.println("Error during data extraction: " + e.getMessage());
            e.printStackTrace();
        }
        
        try (FileWriter writer = new FileWriter(outputPath)) {
            writer.write(allBureauData.toString());
            System.out.println("Bureau data saved to: " + outputPath);
        }
        
        driver.close();
        driver.switchTo().window(mainWindow);
    }

    private static String compareFiles(String preFilePath, String postFilePath, String fileName, String preAppId, String postAppId) {
        StringBuilder result = new StringBuilder();
        result.append("File: ").append(fileName).append("\n");
        result.append("Pre APP ID: ").append(preAppId).append("\n");
        result.append("Post APP ID: ").append(postAppId).append("\n");
        try {
            // Read and normalize both files
            List<String> preLines = normalizeContent(Files.readAllLines(Paths.get(preFilePath)));
            List<String> postLines = normalizeContent(Files.readAllLines(Paths.get(postFilePath)));
            
            // Remove metadata lines (timestamp, etc.) for comparison
            preLines = removeMetadata(preLines);
            postLines = removeMetadata(postLines);
            
            if (preLines.equals(postLines)) {
                result.append("Status: MATCHED - No differences found");
            } else {
                result.append("Status: DIFFERENCES FOUND\n");
                result.append(findDifferences(preLines, postLines));
            }
            
        } catch (IOException e) {
            result.append("Status: ERROR - Could not compare files\n");
            result.append("Error: ").append(e.getMessage());
        }
        
        return result.toString();
    }

    private static List<String> normalizeContent(List<String> lines) {
        return lines.stream()
                   .map(line -> line.trim())
                   .filter(line -> !line.isEmpty())
                   .collect(Collectors.toList());
    }

    private static List<String> removeMetadata(List<String> lines) {
        List<String> filtered = new ArrayList<>();
        boolean skipMetadata = true;
        
        for (String line : lines) {
            // Skip initial metadata section
            if (skipMetadata && line.contains("==================================")) {
                skipMetadata = false;
                continue;
            }
            
            // Skip timestamp lines
            if (line.contains("Extraction Time:") || line.contains("Application ID:") || line.contains("Type:")) {
                continue;
            }
            
            if (!skipMetadata) {
                filtered.add(line);
            }
        }
        
        return filtered;
    }

    private static String findDifferences(List<String> preLines, List<String> postLines) {
        StringBuilder diff = new StringBuilder();
        diff.append("Differences Details:\n");
        
        int maxLines = Math.max(preLines.size(), postLines.size());
        int diffCount = 0;
        
        for (int i = 0; i < maxLines; i++) {
            String preLine = i < preLines.size() ? preLines.get(i) : "[MISSING]";
            String postLine = i < postLines.size() ? postLines.get(i) : "[MISSING]";
            
            if (!preLine.equals(postLine)) {
                diffCount++;
                if (diffCount <= 20) { // Show first 10 differences
                    diff.append("\nLine ").append(i + 1).append(":\n");
                    diff.append("  PRE:  ").append(preLine.length() > 100 ? preLine.substring(0, 100) + "..." : preLine).append("\n");
                    diff.append("  POST: ").append(postLine.length() > 100 ? postLine.substring(0, 100) + "..." : postLine).append("\n");
                }
            }
        }
        
        if (diffCount > 20) {
            diff.append("\n... and ").append(diffCount - 20).append(" more differences");
        }
        
        diff.append("\n\nTotal differences found: ").append(diffCount);
        diff.append("\nPre file lines: ").append(preLines.size());
        diff.append("\nPost file lines: ").append(postLines.size());
        
        return diff.toString();
    }
    
    // Expands all nodes inside any .jstree container.
    private static void expandAllJsTreeNodes(WebDriver driver, WebDriverWait wait) {
        // Ensure the tree is present
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".jstree")));

        JavascriptExecutor js = (JavascriptExecutor) driver;

        // -------- Attempt fast path via jsTree API (if jQuery + jsTree are available) --------
        try {
            Object usedApi = js.executeScript(
                "try {" +
                "  if (window.$ && $('.jstree').length && $('.jstree').jstree) {" +
                "    var inst = $('.jstree').jstree(true) || $('.jstree').jstree(); " +
                "    if (inst && inst.open_all) { inst.open_all(); return true; }" +
                "  }" +
                "} catch(e) {}" +
                "return false;"
            );
            // Give the UI a moment if API was used
            if (Boolean.TRUE.equals(usedApi)) {
                // wait for any loading indicators to disappear (if used by your theme)
                try {
                    wait.until(d -> driver.findElements(By.cssSelector(".jstree .jstree-loading")).isEmpty());
                } catch (TimeoutException ignored) {}
                return; // fully expanded via API
            }
        } catch (Exception ignored) {
            // If API path fails, we fall back to clicking togglers
        }

        // -------- Fallback: iteratively click all closed togglers --------
        int safety = 0;           // prevent infinite loops
        final int maxPasses = 50; // adjust if your tree is very deep/lazy loaded
        while (safety++ < maxPasses) {
            // Only togglers for nodes that are currently 'closed'
            List<WebElement> closedTogglers = driver.findElements(
                By.cssSelector(".jstree li.jstree-closed > i.jstree-ocl, .jstree li.jstree-closed > i.jstree-icon.jstree-ocl")
            );

            if (closedTogglers.isEmpty()) break;

            int before = closedTogglers.size();
            for (WebElement toggler : closedTogglers) {
                try {
                    js.executeScript("arguments[0].scrollIntoView({block:'center'});", toggler);
                } catch (JavascriptException ignored) {}

                try {
                    wait.until(ExpectedConditions.elementToBeClickable(toggler)).click();
                } catch (Exception clickEx) {
                    // JS click as a fallback (covers overlay/offset issues)
                    js.executeScript("arguments[0].click();", toggler);
                }

                // If expansion triggers lazy loading, give it a brief pause
                try { Thread.sleep(150); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
            }

            // Wait for the number of closed nodes to decrease before next pass
            try {
                wait.until(d -> {
                    int after = driver.findElements(
                        By.cssSelector(".jstree li.jstree-closed > i.jstree-ocl, .jstree li.jstree-closed > i.jstree-icon.jstree-ocl")
                    ).size();
                    return after < before;
                });
            } catch (TimeoutException ignored) {
                // If it didn't change, loop will exit on next iteration if no new closed nodes are found
            }
        }
    }

    private static List<WebElement> findRequestResponseLinks(WebDriver driver, WebDriverWait wait) {
        List<WebElement> links = new ArrayList<>();
        
        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.className("jstree")));
            expandAllJsTreeNodes(driver, wait);
            List<WebElement> rawLinks = driver.findElements(By.xpath("//a[@raw]"));
            
            for (WebElement link : rawLinks) {
                String type = link.getAttribute("type");
                if ("request".equals(type) || "response".equals(type)) {
                    links.add(link);
                }
            }
        } catch (Exception e) {
            System.err.println("Error finding request/response links: " + e.getMessage());
        }
        
        return links;
    }

//    private static void openMenuAndClick(WebDriver driver, WebDriverWait wait, String... labels) {
//        if (labels == null || labels.length == 0) {
//            throw new IllegalArgumentException("At least one label is required");
//        }
//
//        Actions actions = new Actions(driver);
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//
//        WebElement menuWrapper = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu-wrapper")));
//        WebElement menuRoot = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu")));
//
//        for (int i = 0; i < labels.length; i++) {
//            String label = labels[i].trim();
//
//            String anchorXPath = ".//ul[@id='menu']//a[" +
//                    "normalize-space(translate(., 'Â»\u00BB', '')) = " + literalXPath(label) +
//                    "]";
//
//            WebElement link = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(anchorXPath)));
//
//            try {
//                js.executeScript("arguments[0].scrollIntoView({block:'center'});", link);
//            } catch (JavascriptException ignored) {}
//
//            if (i < labels.length - 1) {
//                actions.moveToElement(link).pause(Duration.ofMillis(250)).perform();
//                WebElement subMenu = link.findElement(By.xpath("./parent::li/ul"));
//                wait.until(ExpectedConditions.visibilityOf(subMenu));
//            } else {
//                try {
//                    wait.until(ExpectedConditions.elementToBeClickable(link)).click();
//                } catch (ElementClickInterceptedException | TimeoutException e) {
//                    js.executeScript("arguments[0].click();", link);
//                }
//            }
//        }
//    }
    
    private static void openMenuAndClick(WebDriver driver, WebDriverWait wait, String... labels) {
        if (labels == null || labels.length == 0) throw new IllegalArgumentException("At least one label is required");
        Actions actions = new Actions(driver);
        JavascriptExecutor js = (JavascriptExecutor) driver;

        WebElement scope = wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector("ul#menu")));

        for (int i = 0; i < labels.length; i++) {
            String label = labels[i].trim().replaceAll("\\s+", " ");

            // scope to direct children ONLY
            String anchorsXpath = scope.getTagName().equalsIgnoreCase("ul") ? "./li/a" : "./ul/li/a";
            List<WebElement> anchors = scope.findElements(By.xpath(anchorsXpath));

            // choose by direct text
            WebElement link = anchors.stream().filter(a -> {
                String direct = (String) js.executeScript(
                        "const a=arguments[0]; return [...a.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join('').replace(/\\s+/g,' ').trim();",
                        a);
                return label.equals(direct);
            }).findFirst().orElseThrow(() -> new NoSuchElementException("Not found: " + label));

            js.executeScript("arguments[0].scrollIntoView({block:'center'});", link);
            wait.until(ExpectedConditions.visibilityOf(link));

            boolean isLeaf = (i == labels.length - 1);
            if (isLeaf) {
                try {
                    wait.until(ExpectedConditions.elementToBeClickable(link)).click();
                } catch (Exception e) {
                    js.executeScript("arguments[0].click();", link);
                }
                return;
            } else {
                WebElement li = link.findElement(By.xpath("./ancestor::li[1]"));
                boolean opened = false;

                // Try hover, then click
                try {
                    actions.moveToElement(link).pause(Duration.ofMillis(150)).perform();
                    opened = waitChildVisibleByJs(driver, li, Duration.ofSeconds(2));
                } catch (Exception ignored) {}

                if (!opened) {
                    try {
                        wait.until(ExpectedConditions.elementToBeClickable(link)).click();
                    } catch (Exception e) {
                        js.executeScript("arguments[0].click();", link);
                    }
                    opened = waitChildVisibleByJs(driver, li, Duration.ofSeconds(4));
                }

                if (!opened) {
                    throw new TimeoutException("Submenu did not open for: " + label);
                }
                scope = li; // narrow scope
            }
        }
    }

    private static boolean waitChildVisibleByJs(WebDriver driver, WebElement li, Duration timeout) {
        WebDriverWait w = new WebDriverWait(driver, timeout);
        try {
            return w.until(d -> {
                try {
                    WebElement ul = li.findElement(By.xpath("./ul"));
                    Object visible = ((JavascriptExecutor) d).executeScript(
                        "const u=arguments[0]; if(!u) return false;" +
                        "const s=getComputedStyle(u);" +
                        "if(s.display==='none' || s.visibility==='hidden' || +s.opacity===0) return false;" +
                        "const r=u.getBoundingClientRect(); return r.width>0 && r.height>0;", ul);
                    return Boolean.TRUE.equals(visible);
                } catch (NoSuchElementException | StaleElementReferenceException e) {
                    return false;
                }
            });
        } catch (TimeoutException e) {
            return false;
        }
    }


    private static String literalXPath(String s) {
        if (!s.contains("'")) {
            return "'" + s + "'";
        }
        if (!s.contains("\"")) {
            return "\"" + s + "\"";
        }
        String[] parts = s.split("'");
        StringBuilder sb = new StringBuilder("concat(");
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) sb.append(", \"'\", ");
            sb.append("'").append(parts[i]).append("'");
        }
        sb.append(")");
        return sb.toString();
    }

    private static void sleepSeconds(int seconds) {
        try {
            Thread.sleep(seconds * 1000L);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
    }
}