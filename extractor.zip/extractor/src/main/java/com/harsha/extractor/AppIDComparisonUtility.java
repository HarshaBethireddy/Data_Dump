package com.harsha.extractor;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;

public class AppIDComparisonUtility {

    private static final List<String> APPID_KEYS = Arrays.asList(
            "APPID","AppID","AppId","appId","appid","APP_ID","app_id","APP-ID","app-id"
    );
    private static final List<String> ID_KEYS = Arrays.asList(
            "id","ID","Id","value","appId","APPID"
    );

    public static void main(String[] args) throws Exception {
        String preFolderPath = "C:/Users/C24692E/Downloads/100005";
        String postFolderPath = "C:/Users/C24692E/Downloads/100006";
        String excelPath = "C:/Users/C24692E/Downloads/APPIDComparison.xlsx";

        compareAppIDs(preFolderPath, postFolderPath, excelPath);
    }

    public static void compareAppIDs(String preFolderPath, String postFolderPath, String excelPath) throws Exception {
        ObjectMapper mapper = new ObjectMapper();

        // Step 1: Extract Pre AppIDs
        Map<String, String> preAppIds = extractAppIDs(preFolderPath, mapper);

        // Step 2: Extract Post AppIDs
        Map<String, String> postAppIds = extractAppIDs(postFolderPath, mapper);

        // Step 3: Merge keys (union of both Pre + Post file names)
        Set<String> allFileNames = new TreeSet<>();
        allFileNames.addAll(preAppIds.keySet());
        allFileNames.addAll(postAppIds.keySet());

        // Step 4: Write to Excel
        try (Workbook workbook = new XSSFWorkbook();
             FileOutputStream fos = new FileOutputStream(excelPath)) {

            Sheet sheet = workbook.createSheet("AppID Comparison");

            // Header
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("File Name");
            header.createCell(1).setCellValue("Pre-AppID");
            header.createCell(2).setCellValue("Post-AppID");

            int rowIndex = 1;
            for (String fileName : allFileNames) {
                Row row = sheet.createRow(rowIndex++);
                row.createCell(0).setCellValue(fileName);
                row.createCell(1).setCellValue(preAppIds.getOrDefault(fileName, ""));
                row.createCell(2).setCellValue(postAppIds.getOrDefault(fileName, ""));
            }

            // Auto-size columns
            for (int i = 0; i < 3; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(fos);
        }

        System.out.println("✅ Excel file created at: " + excelPath);
    }

    private static Map<String, String> extractAppIDs(String folderPath, ObjectMapper mapper) throws Exception {
        Map<String, String> appIds = new HashMap<>();
        File folder = new File(folderPath);

        if (!folder.exists() || !folder.isDirectory()) {
            System.out.println("⚠️ Folder not found: " + folderPath);
            return appIds; // return empty
        }

        File[] files = folder.listFiles();
        if (files == null) {
            System.out.println("⚠️ Could not list files in: " + folderPath);
            return appIds;
        }

        for (File file : files) {
            if (file == null || !file.isFile()) continue;

            String name = file.getName();
            if (!name.toLowerCase(Locale.ROOT).endsWith(".json")) continue;

            try {
                // Read as UTF-8 to avoid encoding surprises/BOM issues
                String content = Files.readString(file.toPath(), StandardCharsets.UTF_8);
                JsonNode root = mapper.readTree(content);

                String appId = findAppId(root);
                if (appId.isEmpty()) {
                    System.out.println("ℹ️  No APPID found in: " + name);
                } else {
                    System.out.println("✅ Found APPID in " + name + " -> " + appId);
                }
                appIds.put(name, appId);
            } catch (Exception e) {
                System.out.println("⚠️ Failed to parse " + name + ": " + e.getMessage());
                appIds.put(name, "");
            }
        }
        return appIds;
    }

    /**
     * Recursively searches the JSON for APPID (various casings/variants).
     * If APPID is an object, tries to fetch common ID keys inside it.
     */
    private static String findAppId(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) return "";

        // 1) Direct lookup for known APPID keys at this level
        if (node.isObject()) {
            for (String key : APPID_KEYS) {
                JsonNode candidate = node.get(key);
                String v = nodeToIdString(candidate);
                if (!v.isEmpty()) return v;
            }
        }

        // 2) If object: also try fields whose name *contains* "appid"
        if (node.isObject()) {
            Iterator<Map.Entry<String, JsonNode>> it = node.fields();
            while (it.hasNext()) {
                Map.Entry<String, JsonNode> e = it.next();
                String fieldName = e.getKey();
                JsonNode value = e.getValue();

                if (fieldName != null && fieldName.toLowerCase(Locale.ROOT).contains("appid")) {
                    String v = nodeToIdString(value);
                    if (!v.isEmpty()) return v;
                }

                // Recurse deeper
                String deeper = findAppId(value);
                if (!deeper.isEmpty()) return deeper;
            }
        }

        // 3) If array: search each element
        if (node.isArray()) {
            for (JsonNode item : node) {
                String v = findAppId(item);
                if (!v.isEmpty()) return v;
            }
        }

        return "";
    }

    /**
     * Converts a node that represents APPID (string/number/object/array) into the actual id string.
     * - If text/number -> return as string
     * - If object -> try common inner keys: id, value, appId, APPID
     * - If array -> search inside
     */
    private static String nodeToIdString(JsonNode n) {
        if (n == null || n.isMissingNode() || n.isNull()) return "";

        if (n.isTextual() || n.isNumber() || n.isBoolean()) {
            return n.asText();
        }

        if (n.isObject()) {
            // Try direct known ID keys inside the object
            for (String idKey : ID_KEYS) {
                JsonNode inner = n.get(idKey);
                if (inner != null && !inner.isNull()) {
                    // Inner might itself be object/array; recurse
                    String v = nodeToIdString(inner);
                    if (!v.isEmpty()) return v;
                }
            }
            // Fallback: search any nested field
            Iterator<Map.Entry<String, JsonNode>> it = n.fields();
            while (it.hasNext()) {
                Map.Entry<String, JsonNode> e = it.next();
                String v = nodeToIdString(e.getValue());
                if (!v.isEmpty()) return v;
            }
        }

        if (n.isArray()) {
            for (JsonNode item : n) {
                String v = nodeToIdString(item);
                if (!v.isEmpty()) return v;
            }
        }

        return "";
    }
}
