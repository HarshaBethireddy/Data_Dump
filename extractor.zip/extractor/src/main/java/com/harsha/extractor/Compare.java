//package com.harsha.extractor;
//
//import org.openqa.selenium.*;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.support.ui.WebDriverWait;
//
//import java.time.Duration;
//
//public class Compare {
//    // ======= Replace these with your actual values =======
//    private static final String BASE_URL = "http://usaqwblbcus30.us.experian.eeca:8080/WebEngine/";
//    private static final String USERNAME = "Harsh";
//    private static final String PASSWORD = "Friday@0123!";
//    // Choose ONE of the below ways to select group:
//    private static final String TARGET_GROUP_VISIBLE_TEXT = "Credit CLI Team Group";
//    private static final String TARGET_GROUP_VALUE = null;
//    // =====================================================
//
//    public static void main(String[] args) {
//        ChromeOptions options = new ChromeOptions();
//        options.addArguments("--start-maximized");
//
//        WebDriver driver = new ChromeDriver(options);
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
//
//        try {
//            // 1) Open login page
//            driver.get(BASE_URL);
//
//            // 2) Optional hold
//            sleepSeconds(3);
//
//            // 3) Login
//            WebElement usernameInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idToken1")));
//            WebElement passwordInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("idToken2")));
//            WebElement loginButton   = wait.until(ExpectedConditions.elementToBeClickable(By.id("loginButton_0")));
//
//            usernameInput.clear();
//            usernameInput.sendKeys(USERNAME);
//
//            passwordInput.clear();
//            passwordInput.sendKeys(PASSWORD);
//
//            loginButton.click();
//
//            // 4) Select Group
//            sleepSeconds(3);
//            WebElement groupsSelectEl = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("groups")));
//            Select groupsSelect = new Select(groupsSelectEl);
//
//            if (TARGET_GROUP_VALUE != null && !TARGET_GROUP_VALUE.isBlank()) {
//                groupsSelect.selectByValue(TARGET_GROUP_VALUE);
//            } else {
//                groupsSelect.selectByVisibleText(TARGET_GROUP_VISIBLE_TEXT);
//            }
//
//            WebElement submitBtn = wait.until(ExpectedConditions.elementToBeClickable(By.id("id2")));
//            submitBtn.click();
//
//            // ====== CONTINUATION FROM HERE: open menu and click by names ======
//
//            // Wait for menu wrapper to be present/visible after navigation
//            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu-wrapper")));
//            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu")));
//
//            // Example 1: CLI Credit View -> CLI Full Search -> Search
//            openMenuAndClick(driver, wait,
//                    "CLI Credit View",
//                    "CLI Full Search",
//                    "Search"
//            );
//
//            // Example 2 (another path if needed): View Only -> CLI Credit Full -> All
//            // openMenuAndClick(driver, wait, "View Only", "CLI Credit Full", "All");
//
//            System.out.println("Menu navigation completed successfully.");
//
//            // Optional: small wait to observe result page
//            sleepSeconds(3);
//
//        } catch (Exception e) {
//            System.err.println("Error during automation: " + e.getMessage());
//            e.printStackTrace();
//        } finally {
//            // Close the browser
//            // driver.quit();
//        }
//    }
//
//    /**
//     * Hovers through each parent label and clicks the final leaf label.
//     * This ignores the '»' indicator span by normalizing the link text in XPath.
//     */
//    private static void openMenuAndClick(WebDriver driver, WebDriverWait wait, String... labels) {
//        if (labels == null || labels.length == 0) {
//            throw new IllegalArgumentException("At least one label is required");
//        }
//
//        Actions actions = new Actions(driver);
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//
//        // Ensure the menu is present
//        WebElement menuWrapper = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu-wrapper")));
//        WebElement menuRoot    = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("menu")));
//
//        for (int i = 0; i < labels.length; i++) {
//            String label = labels[i].trim();
//
//            // XPath notes:
//            // - translate(., '»\u00BB', '') removes the right-angle quote if present in the anchor's text (indicator).
//            // - normalize-space collapses spaces and trims.
//            String anchorXPath = ".//ul[@id='menu']//a[" +
//                    "normalize-space(translate(., '»\u00BB', '')) = " + literalXPath(label) +
//                    "]";
//
//            WebElement link = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(anchorXPath)));
//
//            // Scroll into view for stability
//            try {
//                js.executeScript("arguments[0].scrollIntoView({block:'center'});", link);
//            } catch (JavascriptException ignored) {}
//
//            if (i < labels.length - 1) {
//                // Intermediate level: hover to reveal the submenu <ul>
//                actions.moveToElement(link).pause(Duration.ofMillis(250)).perform();
//
//                // The submenu is usually the UL inside the same LI
//                // <li> <a class='sf-with-ul'>Label <span>»</span></a> <ul> ... </ul> </li>
//                WebElement subMenu = link.findElement(By.xpath("./parent::li/ul"));
//
//                // Wait for submenu to become visible (Superfish toggles display)
//                wait.until(ExpectedConditions.visibilityOf(subMenu));
//
//            } else {
//                // Final level: click the link
//                try {
//                    wait.until(ExpectedConditions.elementToBeClickable(link)).click();
//                } catch (ElementClickInterceptedException | TimeoutException e) {
//                    // Fallback to JS click if something intercepts
//                    js.executeScript("arguments[0].click();", link);
//                }
//            }
//        }
//    }
//
//    /**
//     * Safely wraps a Java string as an XPath string literal.
//     * Handles cases where the text may contain quotes.
//     */
//    private static String literalXPath(String s) {
//        if (!s.contains("'")) {
//            return "'" + s + "'";
//        }
//        if (!s.contains("\"")) {
//            return "\"" + s + "\"";
//        }
//        // Split at single quotes and concat using concat()
//        String[] parts = s.split("'");
//        StringBuilder sb = new StringBuilder("concat(");
//        for (int i = 0; i < parts.length; i++) {
//            if (i > 0) sb.append(", \"'\", ");
//            sb.append("'").append(parts[i]).append("'");
//        }
//        sb.append(")");
//        return sb.toString();
//    }
//
//    private static void sleepSeconds(int seconds) {
//        try {
//            Thread.sleep(seconds * 1000L);
//        } catch (InterruptedException ie) {
//            Thread.currentThread().interrupt();
//        }
//    }
//}
