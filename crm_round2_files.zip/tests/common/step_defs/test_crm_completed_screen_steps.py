"""Step definitions for tests/common/features/crm_completed_screen.feature.

Every step used by this feature lives in tests/common/step_defs/conftest.py (shared with
crm_search_screen.feature), so this module only links the feature file.
"""
from pytest_bdd import scenarios

scenarios("../features/crm_completed_screen.feature")
