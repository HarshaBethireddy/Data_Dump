Feature: CRM screen - Search (CRM Decision Services)

  Verify the CRM decision services Search flow for the BCUS Admin (RTB) role:
  homepage columns, the CRM Decision Services buttons, Pre bureau / Post bureau
  refresh with Audit Trail verification, and Postback with Data Viewer
  request / response verification.

  Background:
    Given I open the homepage
    When I enter username "mock-user_1@bcuscc-ucb-qa.com" and password "123"
    And I click the login button
    And I click on PowerCurve Case Management button
    And I select the dropdown Role Selection as "BCUS Admin (RTB)"

  @ui @smoke
  Scenario: TC_01 Verify the homepage is displayed for the BCUS Admin (RTB) user role
    Then the following columns should be displayed on the homepage for the logged in user role
        | Locked                       |
        | Application ID               |
        | Locked by                    |
        | My apps                      |
        | Assigned user                |
        | Name                         |
        | Request type                 |
        | PreQual ID                   |
        | Updated date                 |
        | Creation date                |
        | Status                       |
        | Credit review                |
        | Fraud review                 |
        | KYC review                   |
        | Credit pend indicator        |
        | Fraud pend indicator         |
        | KYC pend indicator           |
        | Partner ID                   |
        | Awaiting consent - queue DC  |
        | Decision type                |
        | Audit log                    |

  @ui @smoke
  Scenario: TC_02 Verify CRM Decision services - Search
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "CRM decision services" and select "Search"
    And I search the application using Application ID
    Then the following buttons should be displayed in the CRM Decision Services page
        | Pre bureau         |
        | Post bureau        |
        | Tactical param     |
        | Address parser     |
        | Solit lookup       |
        | SSN/Tax ID lookups |
        | Refresh ATB        |

  @ui @smoke
  Scenario: TC_03 Verify Pre bureau button in CRM Decision services page
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "CRM decision services" and select "Search"
    And I search the application using Application ID
    And I click the "Pre bureau" button
    And I click the Save button and wait for the changes to be saved
    And I click the Close button
    Then the search results should show exactly 1 record for the searched Application ID
    When I click the Audit trail icon of the application
    Then the Audit Trail dialog should be displayed for the application
    When I open the first record of the Audit Trail
    Then the Audit Trail details should show field "Application.Application Flags.SMUpdateCode" with previous value "" and current value "CRMPRE"

  @ui @smoke
  Scenario: TC_04 Verify Post bureau button in CRM Decision services page
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "CRM decision services" and select "Search"
    And I search the application using Application ID
    # -- Precondition: Pre bureau refresh first, so the Post bureau change shows CRMPRE -> CRMPOST
    And I click the "Pre bureau" button
    And I click the Save button and wait for the changes to be saved
    And I click the Close button
    Then the search results should show exactly 1 record for the searched Application ID
    # -- Post bureau refresh on the same application
    When I open the application from the search results
    And I click the "Post bureau" button
    And I click the Save button and wait for the changes to be saved
    And I click the Close button
    Then the search results should show exactly 1 record for the searched Application ID
    When I click the Audit trail icon of the application
    Then the Audit Trail dialog should be displayed for the application
    When I open the first record of the Audit Trail
    Then the Audit Trail details should show field "Application.Application Flags.SMUpdateCode" with previous value "CRMPRE" and current value "CRMPOST"

  @ui @smoke
  Scenario: TC_05 Verify Postback button in the CRM Decision Services page
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "CRM decision services" and select "Search"
    And I search the application using Application ID
    And I click the "Postback" button
    Then the Post-back dialog should be displayed
    When I click Ok on the Post-back dialog
    And I click on Data Viewer
    Then I should see the Data source entry "Postback ACQ RDS1_Outcome 200"
    When I click View data for the Data source entry "Postback ACQ RDS1_Outcome 200"
    And I click on Raw data in the Data Viewer
    And I select "Request" in the Raw data view
    Then the Raw data should not contain any error text
    When I select "Response" in the Raw data view
    Then the Raw data should indicate success

  @ui @smoke
  Scenario: TC_06 Verify Tactical Parameter button in the CRM Decision Services page
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "CRM decision services" and select "Search"
    And I search the application using Application ID
    And I click the "Tactical param" button
    And I click the Save button and wait for the changes to be saved
    And I click the Close button
    Then the search results should show exactly 1 record for the searched Application ID
    When I click the Audit trail icon of the application
    Then the Audit Trail dialog should be displayed for the application
    When I open the first record of the Audit Trail
    Then the Audit Trail details should list at least 1 changed field

  @ui @smoke
  Scenario: TC_07 Verify Address parser button in the CRM Decision Services page
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "CRM decision services" and select "Search"
    And I search the application using Application ID
    And I click the "Address parser" button
    And I wait for the page to finish loading
    And I click on Data Viewer
    Then I should see the Data source entry "Address Parser Persist_Outcome 200"
    When I click View data for the Data source entry "Address Parser Persist_Outcome 200"
    And I click on Raw data in the Data Viewer
    And I select "Request" in the Raw data view
    And I capture the "transactionId" value from the Raw data as "request transactionId"
    And I select "Response" in the Raw data view
    And I capture the "transactionId" value from the Raw data as "response transactionId"
    Then the captured "request transactionId" and "response transactionId" values should match

  @ui @smoke
  Scenario: TC_08 Verify Solit lookup
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "CRM decision services" and select "Search"
    And I search the application using Application ID
    And I click the "Solit lookup" button
    Then the Solit lookup window should display the following details
        | Application ID |
        | Prospect ID    |
        | Prequal app ID |
        | Rcv date       |
    When I change the Prospect ID to "7654321" in the Solit lookup window
    And I click Submit in the Solit lookup window
    Then the Prospect ID in the Solit lookup window should be "7654321"
    When I click Close in the Solit lookup window

  @ui @smoke
  Scenario: TC_09 Verify SSN/Tax ID lookup
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "CRM decision services" and select "Search"
    And I search the application using Application ID
    And I click the "SSN/Tax ID lookups" button
    Then the SSN lookup options should be displayed
    When I select "SSN Lookup" in the SSN lookup dropdown
    And I click Submit in the SSN lookup panel
    Then No validation errors should be displayed
    When I select "Multiuse SSN Lookup" in the SSN lookup dropdown
    And I click Submit in the SSN lookup panel
    Then No validation errors should be displayed
    When I select "Both" in the SSN lookup dropdown
    And I click Submit in the SSN lookup panel
    Then No validation errors should be displayed
    When I click Close in the SSN lookup panel

  @ui @smoke
  Scenario: TC_10 Verify Refresh ATB button
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "CRM decision services" and select "Search"
    And I search the application using Application ID
    And I click Edit in the "CRM decision" block
    And I set "CREDLINE_AMT" to "99998" in the "CRM decision" block
    And I confirm the changes in the "CRM decision" block
    And I click the "Refresh ATB" button
    And I wait for the page to finish loading
    Then the "CRM decision" block should display "CREDLINE_AMT" as "99998"

  @ui @smoke
  Scenario: TC_11 Verify Robot fields block
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "CRM decision services" and select "Search"
    And I search the application using Application ID
    And I click Edit in the "Robot fields" block
    And I set "Batch Repair Counter" to "2" in the "Robot fields" block
    And I set "Decision Robot Wait Period in Minutes" to "45" in the "Robot fields" block
    And I confirm the changes in the "Robot fields" block
    And I click the Save button and wait for the changes to be saved
    Then the "Robot fields" block should display "Batch Repair Counter" as "2"
    And the "Robot fields" block should display "Decision Robot Wait Period in Minutes" as "45"

  @ui @smoke
  Scenario: TC_12 Verify Refer to teams block
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "CRM decision services" and select "Search"
    And I search the application using Application ID
    And I click Edit in the "Refer to teams" block
    Then the "Refer to teams" block should display the following options
        | Refer to Credit |
        | Refer to Fraud  |
        | Refer to KYC    |
    When I set "Application Type Code" to "4" in the "Refer to teams" block
    And I confirm the changes in the "Refer to teams" block
    And I click the "Update app type" button
    And I click the Save button and wait for the changes to be saved
    Then the "Refer to teams" block should display "Application Type Code" as "4"

  @ui @smoke
  Scenario: TC_13 Verify Notes
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "CRM decision services" and select "Search"
    And I search the application using Application ID
    And I open the Notes section
    And I enter notes in the Notes section
    And I click on Add button
    Then the notes should be added successfully
    When I click the Save button and wait for the changes to be saved
    And I click the Close button

  @ui @smoke
  Scenario: TC_14 Verify Notes Clear button
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "CRM decision services" and select "Search"
    And I search the application using Application ID
    And I open the Notes section
    And I enter notes in the Notes section
    And I click the Clear button
    Then the Notes text area should be cleared

  @ui @smoke
  Scenario: TC_15 Verify Audit Trail
    Given a valid CLI application JSON payload loaded from "ACQ_EQ.json" for a POST request
    And an auth token is generated
    When I send the request and receive a response
    Then the response status code should be 200
    When I navigate to "CRM decision services" and select "Search"
    And I search the application using Application ID
    # -- Make two saved changes (Pre bureau, then Post bureau) so the Audit Trail has changes to verify
    And I click the "Pre bureau" button
    And I click the Save button and wait for the changes to be saved
    And I click the Close button
    Then the search results should show exactly 1 record for the searched Application ID
    When I open the application from the search results
    And I click the "Post bureau" button
    And I click the Save button and wait for the changes to be saved
    And I click the Close button
    Then the search results should show exactly 1 record for the searched Application ID
    When I click the Audit trail icon of the application
    Then the Audit Trail dialog should be displayed for the application
    And the Audit Trail should list at least 2 "CaseDetailsUpdateCRMAdmin" records
    And the Audit Trail should list at least 1 "NewACQApp" records
    When I open the first record of the Audit Trail
    Then the Audit Trail details should show field "Application.Application Flags.SMUpdateCode" with previous value "CRMPRE" and current value "CRMPOST"
