# Bureau Comparison Automation Framework

Enterprise-grade test automation framework for bureau data extraction and comparison using Selenium WebDriver, TestNG, and Cucumber BDD.

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Architecture](#architecture)
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Configuration](#configuration)
- [Project Structure](#project-structure)
- [Running Tests](#running-tests)
- [Reports](#reports)
- [Design Patterns](#design-patterns)
- [Best Practices](#best-practices)
- [Troubleshooting](#troubleshooting)
- [Contributing](#contributing)

## 🎯 Overview

This framework automates the extraction and comparison of bureau data between PRE and POST deployments. It supports multiple categories (ACQ, CLI, PRQ) and parallel execution for improved performance.

### Key Capabilities

- **APP ID Extraction**: Extracts application IDs from JSON/TXT files in PRE and POST folders
- **Excel Generation**: Creates comparison Excel files with all application data
- **Bureau Data Extraction**: Navigates web application and extracts bureau data
- **Parallel Processing**: Supports multiple browser instances for faster execution
- **Comparison Reports**: Generates detailed comparison reports with differences
- **BDD Support**: Cucumber feature files for behavior-driven testing

## ✨ Features

- ✅ Page Object Model (POM) design pattern
- ✅ ThreadLocal WebDriver for parallel execution
- ✅ Automatic WebDriver management (WebDriverManager)
- ✅ ExtentReports with screenshots
- ✅ Log4j2 logging framework
- ✅ Cucumber BDD integration
- ✅ TestNG parallel execution
- ✅ Custom retry mechanism for flaky tests
- ✅ Excel and JSON data handling
- ✅ Comprehensive error handling
- ✅ Configurable via properties file

## 🏗️ Architecture

```
bureau-comparison-automation/
├── src/main/java/           # Main source code
│   ├── config/              # Configuration management
│   ├── core/                # Core framework components
│   │   ├── driver/          # WebDriver management
│   │   ├── base/            # Base classes
│   │   └── listeners/       # TestNG listeners
│   ├── enums/               # Enumerations
│   ├── exceptions/          # Custom exceptions
│   ├── models/              # Data models
│   ├── pages/               # Page Object classes
│   ├── services/            # Business logic layer
│   └── utils/               # Utility classes
├── src/test/java/           # Test source code
│   ├── tests/               # TestNG test classes
│   ├── runners/             # Cucumber test runners
│   └── stepdefinitions/     # Cucumber step definitions
└── src/test/resources/      # Test resources
    ├── features/            # Cucumber feature files
    ├── test-data/           # Test data files
    └── testng.xml           # TestNG configuration
```

## 📋 Prerequisites

- **Java**: JDK 17 or higher
- **Maven**: 3.9.x or higher
- **Chrome/Firefox/Edge**: Latest version
- **IDE**: IntelliJ IDEA (recommended) or Eclipse
- **Git**: For version control

## 🚀 Installation

### 1. Clone the Repository

```bash
git clone <repository-url>
cd bureau-comparison-automation
```

### 2. Install Dependencies

```bash
mvn clean install -DskipTests
```

### 3. Verify Installation

```bash
mvn clean compile
```

## ⚙️ Configuration

### Application Configuration

Edit `src/main/resources/config/application.properties`:

```properties
# Application URL and Credentials
app.base.url=http://usaqwblbcus30.us.experian.eeca:8080/WebEngine/
app.username=YourUsername
app.password=YourPassword
app.admin.group=Administrators

# Browser Configuration
browser.type=CHROME
browser.headless=false
browser.maximized=true

# Wait Configuration (in seconds)
wait.implicit.seconds=10
wait.explicit.seconds=60

# Parallel Execution
parallel.browser.instances=3
parallel.thread.count=3

# Folder Paths
folder.pre.base=C:/Users/YOUR_USER/Downloads/
folder.post.base=C:/Users/YOUR_USER/Downloads/
folder.output.base=C:\\Users\\YOUR_USER\\Downloads\\bureau_comparisons

# Retry Configuration
retry.max.count=1
retry.failed.tests=true

# Screenshot Configuration
screenshot.on.failure=true
screenshot.on.success=false
```

### TestNG Configuration

Edit `src/test/resources/testng.xml` to configure:
- Test suites
- Parallel execution
- Test groups (smoke, regression)
- Listeners

## 📁 Project Structure

### Main Source (`src/main/java`)

```
com.harsha.automation/
├── config/                  # Configuration classes
│   ├── ConfigurationManager.java
│   └── TestConfiguration.java
├── core/
│   ├── driver/             # WebDriver management
│   │   ├── DriverManager.java
│   │   ├── DriverFactory.java
│   │   └── ThreadLocalDriver.java
│   ├── base/               # Base classes
│   │   ├── BasePage.java
│   │   └── BaseTest.java
│   └── listeners/          # TestNG listeners
│       ├── TestListener.java
│       ├── RetryAnalyzer.java
│       └── ExtentReportListener.java
├── pages/                  # Page Object classes
│   ├── LoginPage.java
│   ├── GroupSelectionPage.java
│   ├── SearchPage.java
│   ├── ApplicationDetailsPage.java
│   └── DataViewerPage.java
├── services/               # Business logic
│   ├── FileService.java
│   ├── AppIdExtractionService.java
│   ├── BureauDataExtractionService.java
│   ├── ComparisonService.java
│   └── ReportGenerationService.java
└── utils/                  # Utility classes
    ├── WaitUtils.java
    ├── JavaScriptUtils.java
    ├── ExcelUtils.java
    ├── JsonUtils.java
    ├── FileUtils.java
    └── DateTimeUtils.java
```

## 🏃 Running Tests

### Command Line Execution

#### Run All Tests
```bash
mvn clean test
```

#### Run Smoke Tests Only
```bash
mvn clean test -Dgroups=smoke
```

#### Run Regression Tests
```bash
mvn clean test -Dgroups=regression
```

#### Run with Specific TestNG XML
```bash
mvn clean test -DsuiteXmlFile=src/test/resources/testng.xml
```

#### Run Cucumber Tests
```bash
mvn clean test -Dtest=TestRunner
```

#### Run with Custom Thread Count
```bash
mvn clean test -Dthreadcount=5
```

### IDE Execution

#### IntelliJ IDEA
1. Right-click on `testng.xml`
2. Select "Run" or "Debug"

#### Eclipse
1. Right-click on `testng.xml`
2. Run As → TestNG Suite

### Running Specific Tests

```bash
# Run specific test class
mvn clean test -Dtest=BureauComparisonTest

# Run specific test method
mvn clean test -Dtest=BureauComparisonTest#testLogin
```

## 📊 Reports

### ExtentReports

Located at: `reports/extent-report.html`

Features:
- Detailed test execution summary
- Screenshots on failures
- Execution timeline
- System information
- Test categorization

### Cucumber Reports

Located at: `reports/cucumber-reports/`
- HTML report: `cucumber-html-report.html`
- JSON report: `cucumber.json`
- XML report: `cucumber.xml`

### TestNG Reports

Located at: `test-output/`
- `index.html` - Test execution report
- `emailable-report.html` - Email-friendly report

### Comparison Reports

Located at: `<output-folder>/`
- `APPIDComparison_ALL.xlsx` - Excel comparison file
- `<CATEGORY>/comparison_report.txt` - Per-category reports
- `MASTER_comparison_report.txt` - Consolidated report

### Logs

Located at: `logs/`
- `bureau-comparison-automation.log` - Main log file
- `bureau-comparison-automation-debug.log` - Debug logs
- `bureau-comparison-automation-error.log` - Error logs
- `test-execution.log` - Test execution logs

## 🎨 Design Patterns

### 1. Page Object Model (POM)
- Separates page structure from test logic
- Encapsulates page elements and actions
- Improves maintainability

### 2. Singleton Pattern
- ConfigurationManager
- DriverManager

### 3. Factory Pattern
- DriverFactory for WebDriver creation

### 4. Builder Pattern
- ApplicationData
- ComparisonResult

### 5. Strategy Pattern
- Category-specific navigation strategies

### 6. Service Layer Pattern
- Business logic separated from tests

## 💡 Best Practices

### Code Quality
- Follow SOLID principles
- Use meaningful variable and method names
- Keep methods small and focused
- Add JavaDoc comments for public APIs

### Test Design
- Write independent tests
- Use data-driven approach
- Implement proper assertions
- Handle errors gracefully

### WebDriver Management
- Use explicit waits over Thread.sleep()
- Implement ThreadLocal for parallel execution
- Clean up resources properly
- Use WebDriverManager for driver setup

### Reporting
- Capture screenshots on failures
- Log meaningful messages
- Generate comprehensive reports
- Include execution metadata

## 🔧 Troubleshooting

### Common Issues

#### 1. WebDriver Not Found
```
Solution: WebDriverManager should handle this automatically.
If issues persist, manually download the driver and set system property.
```

#### 2. Tests Failing Due to Timeouts
```
Solution: Increase wait times in application.properties:
wait.explicit.seconds=90
```

#### 3. Parallel Execution Issues
```
Solution: Ensure ThreadLocal is used for WebDriver.
Reduce parallel thread count if resource-constrained.
```

#### 4. Login Failures
```
Solution: Verify credentials in application.properties.
Check if application URL is accessible.
```

#### 5. Excel File Not Generated
```
Solution: Verify folder paths in configuration.
Ensure PRE and POST folders contain valid data files.
```

### Debug Mode

Enable debug logging in `log4j2.xml`:
```xml
<Logger name="com.harsha.automation" level="DEBUG"/>
```

## 📝 Usage Example

### Basic Workflow

```java
// 1. Initialize services
AppIdExtractionService appIdService = new AppIdExtractionService();
BureauDataExtractionService bureauService = new BureauDataExtractionService();
ComparisonService comparisonService = new ComparisonService();

// 2. Extract and compare APP IDs
String excelPath = appIdService.compareAndExtractAppIds(
    preFolderPath, postFolderPath, outputFolder);

// 3. Read applications from Excel
List<ApplicationData> applications = ExcelUtils.readApplicationData(excelPath);

// 4. Extract bureau data
for (ApplicationData app : applications) {
    bureauService.extractBureauDataForApplication(
        driver, app, outputFolder, searchPage);
}

// 5. Generate reports
reportGenerationService.generateMasterReport(results, masterReportPath);
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/YourFeature`)
3. Commit changes (`git commit -m 'Add YourFeature'`)
4. Push to branch (`git push origin feature/YourFeature`)
5. Create a Pull Request

## 📄 License

This project is proprietary and confidential.

## 👥 Support

For issues and questions:
- Create an issue in the repository
- Contact the automation team

---

**Built with ❤️ using Selenium WebDriver, TestNG, and Cucumber**
