package com.harsha.automation.services;

import com.harsha.automation.exceptions.DataExtractionException;
import com.harsha.automation.utils.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

/**
 * Service class for file operations.
 * Handles file reading, writing, and directory operations.
 */
public class FileService {
    private static final Logger logger = LogManager.getLogger(FileService.class);

    /**
     * Reads file content with automatic encoding detection.
     *
     * @param filePath Path to file
     * @return File content as string
     * @throws DataExtractionException if file cannot be read
     */
    public String readFile(String filePath) {
        logger.debug("Reading file: {}", filePath);

        try {
            File file = new File(filePath);
            if (!file.exists()) {
                throw new DataExtractionException("File not found: " + filePath);
            }

            return FileUtils.readFileWithEncoding(file);
        } catch (IOException e) {
            logger.error("Failed to read file {}: {}", filePath, e.getMessage());
            throw new DataExtractionException("Failed to read file: " + filePath, e);
        }
    }

    /**
     * Reads all lines from a file.
     *
     * @param filePath Path to file
     * @return List of lines
     * @throws DataExtractionException if file cannot be read
     */
    public List<String> readAllLines(String filePath) {
        logger.debug("Reading all lines from: {}", filePath);

        try {
            return FileUtils.readAllLines(filePath);
        } catch (IOException e) {
            logger.error("Failed to read lines from {}: {}", filePath, e.getMessage());
            throw new DataExtractionException("Failed to read lines from file", e);
        }
    }

    /**
     * Writes content to a file.
     *
     * @param filePath Path to file
     * @param content  Content to write
     * @throws DataExtractionException if file cannot be written
     */
    public void writeFile(String filePath, String content) {
        logger.debug("Writing to file: {}", filePath);

        try {
            FileUtils.writeToFile(filePath, content);
        } catch (IOException e) {
            logger.error("Failed to write file {}: {}", filePath, e.getMessage());
            throw new DataExtractionException("Failed to write file: " + filePath, e);
        }
    }

    /**
     * Creates directory structure.
     *
     * @param directoryPath Path to directory
     * @throws DataExtractionException if directory cannot be created
     */
    public void createDirectory(String directoryPath) {
        logger.debug("Creating directory: {}", directoryPath);

        try {
            FileUtils.createDirectoryIfNotExists(directoryPath);
        } catch (IOException e) {
            logger.error("Failed to create directory {}: {}", directoryPath, e.getMessage());
            throw new DataExtractionException("Failed to create directory", e);
        }
    }

    /**
     * Lists all files in a directory with specific extension.
     *
     * @param directoryPath Path to directory
     * @param extension     File extension filter
     * @return Array of files
     */
    public File[] listFilesByExtension(String directoryPath, String extension) {
        logger.debug("Listing {} files in: {}", extension, directoryPath);
        return FileUtils.listFilesByExtension(directoryPath, extension);
    }

    /**
     * Checks if file exists.
     *
     * @param filePath Path to file
     * @return true if exists, false otherwise
     */
    public boolean fileExists(String filePath) {
        return FileUtils.fileExists(filePath);
    }

    /**
     * Checks if directory exists.
     *
     * @param directoryPath Path to directory
     * @return true if exists, false otherwise
     */
    public boolean directoryExists(String directoryPath) {
        return FileUtils.directoryExists(directoryPath);
    }

    /**
     * Creates output directory with timestamp.
     *
     * @param baseDirectory Base output directory
     * @param folderName    Folder name
     * @return Created directory path
     */
    public String createOutputDirectory(String baseDirectory, String folderName) {
        String outputPath = baseDirectory + File.separator + folderName;
        createDirectory(outputPath);
        return outputPath;
    }
}
