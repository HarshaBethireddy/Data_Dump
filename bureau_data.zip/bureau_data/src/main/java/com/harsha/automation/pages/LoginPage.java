package com.harsha.automation.pages;

import com.harsha.automation.core.base.BasePage;
import com.harsha.automation.exceptions.PageNavigationException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Page Object for Login Page.
 * Handles login functionality and element interactions.
 */
public class LoginPage extends BasePage {

    @FindBy(id = "idToken1")
    private WebElement usernameInput;

    @FindBy(id = "idToken2")
    private WebElement passwordInput;

    @FindBy(id = "loginButton_0")
    private WebElement loginButton;

    /**
     * Constructor initializes the page.
     *
     * @param driver WebDriver instance
     */
    public LoginPage(WebDriver driver) {
        super(driver);
    }

    @Override
    public boolean isLoaded() {
        try {
            return isDisplayed(usernameInput) &&
                   isDisplayed(passwordInput) &&
                   isDisplayed(loginButton);
        } catch (Exception e) {
            logger.debug("Login page not loaded: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Performs login with username and password.
     *
     * @param username Username
     * @param password Password
     * @return GroupSelectionPage
     * @throws PageNavigationException if login fails
     */
    public GroupSelectionPage login(String username, String password) {
        logger.info("Performing login with username: {}", username);

        try {
            // Wait for page to load
            hardWait(3);

            // Enter username
            usernameInput.clear();
            usernameInput.sendKeys(username);
            logger.debug("Username entered");

            // Enter password
            passwordInput.clear();
            passwordInput.sendKeys(password);
            logger.debug("Password entered");

            // Click login button
            loginButton.click();
            logger.debug("Login button clicked");

            // Wait for navigation
            hardWait(3);

            logger.info("Login successful");
            return new GroupSelectionPage(driver);

        } catch (Exception e) {
            logger.error("Login failed: {}", e.getMessage());
            throw new PageNavigationException("Failed to perform login", e);
        }
    }

    /**
     * Checks if login button is enabled.
     *
     * @return true if enabled, false otherwise
     */
    public boolean isLoginButtonEnabled() {
        return isEnabled(loginButton);
    }

    /**
     * Gets the page title.
     *
     * @return Page title
     */
    public String getLoginPageTitle() {
        return getPageTitle();
    }
}
