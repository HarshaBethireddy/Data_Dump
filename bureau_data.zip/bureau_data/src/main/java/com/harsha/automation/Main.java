package com.harsha.automation;

import com.harsha.automation.config.TestConfiguration;
import com.harsha.automation.core.driver.DriverManager;
import com.harsha.automation.enums.Category;
import com.harsha.automation.models.ApplicationData;
import com.harsha.automation.models.ComparisonResult;
import com.harsha.automation.pages.ApplicationDetailsPage;
import com.harsha.automation.pages.GroupSelectionPage;
import com.harsha.automation.pages.LoginPage;
import com.harsha.automation.pages.SearchPage;
import com.harsha.automation.services.*;
import com.harsha.automation.utils.DateTimeUtils;
import com.harsha.automation.utils.ExcelUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Main class for CLI-based Bureau Data Comparison Tool.
 * NEW FILE: Created to support interactive command-line usage similar to the monolithic code.
 *
 * This provides an alternative to TestNG-based execution, allowing users to:
 * - Input PRE and POST folder names interactively
 * - Execute the complete workflow from command line
 * - View progress and results in console output
 *
 * Usage:
 *   java -cp target/bureau-comparison-automation-1.0.0.jar com.harsha.automation.Main
 */
public class Main {
    private static final Logger logger = LogManager.getLogger(Main.class);

    private final TestConfiguration config;
    private final AppIdExtractionService appIdExtractionService;
    private final BureauDataExtractionService bureauDataExtractionService;
    private final ComparisonService comparisonService;
    private final ReportGenerationService reportGenerationService;
    private final FileService fileService;

    /**
     * Constructor initializes all services.
     */
    public Main() {
        this.config = new TestConfiguration();
        this.appIdExtractionService = new AppIdExtractionService();
        this.bureauDataExtractionService = new BureauDataExtractionService();
        this.comparisonService = new ComparisonService();
        this.reportGenerationService = new ReportGenerationService();
        this.fileService = new FileService();
    }

    /**
     * Main entry point for CLI execution.
     *
     * @param args Command line arguments (optional: preFolderName postFolderName)
     */
    public static void main(String[] args) {
        Main main = new Main();

        try {
            main.run(args);
        } catch (Exception e) {
            logger.error("Fatal error in main execution: {}", e.getMessage(), e);
            System.err.println("\n❌ Error: " + e.getMessage());
            System.exit(1);
        }
    }

    /**
     * Runs the complete bureau comparison workflow.
     *
     * @param args Command line arguments
     */
    public void run(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ExecutorService executorService = null;

        try {
            System.out.println("=== Bureau Data Comparison Tool (Parallel Version) ===\n");

            // Get folder names from user or command line arguments
            String preFolderName;
            String postFolderName;

            if (args.length >= 2) {
                preFolderName = args[0];
                postFolderName = args[1];
                System.out.println("Using command line arguments:");
                System.out.println("PRE folder: " + preFolderName);
                System.out.println("POST folder: " + postFolderName);
            } else {
                System.out.print("Enter PRE folder name (in Downloads): ");
                preFolderName = scanner.nextLine().trim();

                System.out.print("Enter POST folder name (in Downloads): ");
                postFolderName = scanner.nextLine().trim();
            }

            // Validate folder names
            if (preFolderName.isEmpty() || postFolderName.isEmpty()) {
                throw new IllegalArgumentException("Folder names cannot be empty");
            }

            String preFolderPath = config.getBasePrefolder() + preFolderName;
            String postFolderPath = config.getBasePostFolder() + postFolderName;

            // Step 1: Compare APP IDs
            System.out.println("\n=== Step 1: Comparing APP IDs ===");
            String outputFolder = config.getBaseOutputDirectory() + File.separator +
                                "comparison_" + DateTimeUtils.getCurrentTimestampForRunDir();

            String excelFilePath = appIdExtractionService.compareAndExtractAppIds(
                    preFolderPath, postFolderPath, outputFolder);

            if (excelFilePath == null) {
                System.out.println("\n❌ No Excel file generated. Exiting.");
                return;
            }

            System.out.println("✅ Excel comparison file created: " + excelFilePath);

            // Step 2: Extract Bureau Data
            System.out.println("\n=== Step 2: Extracting Bureau Data (Parallel Processing) ===");
            System.out.println("Processing Excel file: " + excelFilePath);
            System.out.println("Using " + config.getBrowserInstances() + " parallel browser instances");

            List<ApplicationData> applications = ExcelUtils.readApplicationData(excelFilePath);
            Map<String, List<ApplicationData>> categoryGroups = applications.stream()
                    .collect(Collectors.groupingBy(app -> app.getCategory().getCategoryName()));

            System.out.println("Total applications: " + applications.size());
            System.out.println("Categories: " + categoryGroups.keySet());

            // Process categories in parallel
            executorService = Executors.newFixedThreadPool(config.getBrowserInstances());
            List<Future<List<ComparisonResult>>> futures = new ArrayList<>();

            for (Map.Entry<String, List<ApplicationData>> entry : categoryGroups.entrySet()) {
                String category = entry.getKey();
                List<ApplicationData> categoryApps = entry.getValue();

                Future<List<ComparisonResult>> future = executorService.submit(() ->
                        processCategoryWithBrowser(category, categoryApps, outputFolder));
                futures.add(future);
            }

            // Collect results
            List<ComparisonResult> allResults = new ArrayList<>();
            for (Future<List<ComparisonResult>> future : futures) {
                try {
                    List<ComparisonResult> categoryResults = future.get(30, TimeUnit.MINUTES);
                    allResults.addAll(categoryResults);
                    System.out.println("\n✅ Completed category processing");
                } catch (Exception e) {
                    logger.error("Error processing category: {}", e.getMessage(), e);
                    System.err.println("❌ Error processing category: " + e.getMessage());
                }
            }

            // Step 3: Generate Master Report
            System.out.println("\n=== Step 3: Generating Master Report ===");
            String masterReportPath = outputFolder + File.separator + "MASTER_comparison_report.txt";
            reportGenerationService.generateMasterReport(allResults, masterReportPath);

            System.out.println("✅ Master comparison report saved: " + masterReportPath);

            // Print summary
            printSummary(allResults);

            System.out.println("\n=== All Processing Complete ===");
            System.out.println("Output location: " + outputFolder);

        } catch (Exception e) {
            logger.error("Error in main execution: {}", e.getMessage(), e);
            System.err.println("\n❌ Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (executorService != null) {
                executorService.shutdown();
                try {
                    if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                        executorService.shutdownNow();
                    }
                } catch (InterruptedException e) {
                    executorService.shutdownNow();
                    Thread.currentThread().interrupt();
                }
            }
            scanner.close();
        }
    }

    /**
     * Processes a category with its own browser instance.
     *
     * @param category         Category name
     * @param applications     List of applications for this category
     * @param baseOutputFolder Base output folder
     * @return List of comparison results
     */
    private List<ComparisonResult> processCategoryWithBrowser(
            String category, List<ApplicationData> applications, String baseOutputFolder) {

        List<ComparisonResult> results = new ArrayList<>();
        WebDriver categoryDriver = null;

        try {
            System.out.println("\n[" + category + "] Starting processing with " + applications.size() + " applications");

            // Create thread-specific WebDriver
            DriverManager driverManager = DriverManager.getInstance();
            driverManager.createDriver();
            categoryDriver = driverManager.getDriver();

            // Login and select group
            categoryDriver.get(config.getBaseUrl());
            Thread.sleep(3000);

            LoginPage loginPage = new LoginPage(categoryDriver);
            GroupSelectionPage groupSelectionPage = loginPage.login(
                    config.getUsername(), config.getPassword());
            SearchPage searchPage = groupSelectionPage.selectGroup(config.getAdminGroup());

            // Navigate to category
            Category categoryEnum = Category.fromString(category);
            searchPage = searchPage.navigateToCategory(categoryEnum);
            Thread.sleep(3000);

            // Create category output folder
            String categoryOutputFolder = baseOutputFolder + File.separator + category + File.separator;
            fileService.createDirectory(categoryOutputFolder);

            // Process each application
            for (int i = 0; i < applications.size(); i++) {
                ApplicationData app = applications.get(i);
                System.out.println("\n[" + category + "] Processing (" + (i + 1) + "/" + applications.size() + "): " + app.getFileName());

                boolean success = bureauDataExtractionService.extractBureauDataForApplication(
                        categoryDriver, app, categoryOutputFolder, searchPage);

                if (success) {
                    // Compare files
                    String preFilePath = categoryOutputFolder + app.getFileName() + "_PRE_" + app.getPreAppId() + ".txt";
                    String postFilePath = categoryOutputFolder + app.getFileName() + "_POST_" + app.getPostAppId() + ".txt";

                    ComparisonResult result = comparisonService.compareFiles(preFilePath, postFilePath, app);
                    results.add(result);

                    // Print result
                    if (result.getStatus() == ComparisonResult.ComparisonStatus.MATCHED) {
                        System.out.println("   ✅ MATCHED - No differences found");
                    } else if (result.getStatus() == ComparisonResult.ComparisonStatus.DIFFERENCES_FOUND) {
                        System.out.println("   ⚠️  DIFFERENCES FOUND - " + result.getDifferenceCount() + " differences");
                    } else {
                        System.out.println("   ❌ ERROR - Comparison failed");
                    }
                } else {
                    System.out.println("   ❌ Extraction failed");
                }

                // Get fresh search page for next application
                if (i < applications.size() - 1) {
                    searchPage = new SearchPage(categoryDriver);
                }
            }

            // Generate category report
            String categoryReportPath = categoryOutputFolder + "comparison_report.txt";
            reportGenerationService.generateComparisonReport(results, categoryReportPath, category);

            System.out.println("\n[" + category + "] ✅ Category processing complete");

        } catch (Exception e) {
            logger.error("[{}] Error: {}", category, e.getMessage(), e);
            System.err.println("\n[" + category + "] ❌ Error: " + e.getMessage());
        } finally {
            if (categoryDriver != null) {
                try {
                    DriverManager.getInstance().quitDriver();
                    logger.info("[{}] Driver cleaned up", category);
                } catch (Exception e) {
                    logger.error("[{}] Error cleaning up driver: {}", category, e.getMessage());
                }
            }
        }

        return results;
    }

    /**
     * Prints summary of comparison results.
     *
     * @param results List of all comparison results
     */
    private void printSummary(List<ComparisonResult> results) {
        long matched = results.stream()
                .filter(r -> r.getStatus() == ComparisonResult.ComparisonStatus.MATCHED)
                .count();

        long differencesFound = results.stream()
                .filter(r -> r.getStatus() == ComparisonResult.ComparisonStatus.DIFFERENCES_FOUND)
                .count();

        long errors = results.stream()
                .filter(r -> r.getStatus() == ComparisonResult.ComparisonStatus.ERROR)
                .count();

        System.out.println("\n========== SUMMARY ==========");
        System.out.println("Total Files: " + results.size());
        System.out.println("Matched: " + matched);
        System.out.println("Differences Found: " + differencesFound);
        System.out.println("Errors: " + errors);
        System.out.println("=============================");
    }
}
