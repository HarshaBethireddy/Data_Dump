package com.harsha.automation.pages;

import com.harsha.automation.core.base.BasePage;
import com.harsha.automation.enums.Category;
import com.harsha.automation.exceptions.PageNavigationException;
import com.harsha.automation.models.CategoryConfig;
import com.harsha.automation.utils.JavaScriptUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import java.time.Duration;
import java.util.List;

/**
 * Page Object for Search Page.
 * Handles application search and navigation to category screens.
 */
public class SearchPage extends BasePage {

    @FindBy(id = "txt-appid")
    private WebElement appIdField;

    @FindBy(id = "btn-search")
    private WebElement searchButton;

    @FindBy(css = "ul#menu")
    private WebElement menuElement;

    /**
     * Constructor initializes the page.
     *
     * @param driver WebDriver instance
     */
    public SearchPage(WebDriver driver) {
        super(driver);
    }

    @Override
    public boolean isLoaded() {
        try {
            return isDisplayed(appIdField) && isDisplayed(searchButton);
        } catch (Exception e) {
            logger.debug("Search page not loaded: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Navigates to category search screen using menu path.
     *
     * @param category Category to navigate to
     * @return SearchPage (fluent interface)
     * @throws PageNavigationException if navigation fails
     */
    public SearchPage navigateToCategory(Category category) {
        logger.info("Navigating to category: {}", category.getCategoryName());

        CategoryConfig config = CategoryConfig.fromCategory(category);
        return navigateToCategoryByMenuPath(config.getMenuPath());
    }

    /**
     * Navigates to category using menu path.
     *
     * @param menuPath Menu path array
     * @return SearchPage (fluent interface)
     * @throws PageNavigationException if navigation fails
     */
    public SearchPage navigateToCategoryByMenuPath(String[] menuPath) {
        logger.info("Navigating using menu path: {}", String.join(" > ", menuPath));

        try {
            openMenuAndClick(menuPath);
            hardWait(3);
            logger.info("Navigation successful");
            return this;
        } catch (Exception e) {
            logger.error("Navigation failed: {}", e.getMessage());
            throw new PageNavigationException("Failed to navigate using menu path", e);
        }
    }

    /**
     * Searches for application by ID.
     *
     * @param applicationId Application ID to search
     * @return ApplicationDetailsPage
     * @throws PageNavigationException if search fails
     */
    public ApplicationDetailsPage searchApplication(String applicationId) {
        logger.info("Searching for application ID: {}", applicationId);

        try {
            // Wait for app ID field
            hardWait(2);

            // Clear and enter application ID
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].scrollIntoView(true);", appIdField);
            appIdField.click();

            // Clear field
            appIdField.sendKeys(Keys.CONTROL + "a");
            appIdField.sendKeys(Keys.DELETE);
            hardWait(1);

            // Type application ID slowly
            for (char c : applicationId.toCharArray()) {
                appIdField.sendKeys(String.valueOf(c));
                Thread.sleep(50);
            }

            // Wait for value to be set
            hardWait(2);

            // Click search button
            searchButton.click();
            logger.debug("Search button clicked");

            // Wait for results
            hardWait(3);

            logger.info("Search completed successfully");
            return new ApplicationDetailsPage(driver);

        } catch (Exception e) {
            logger.error("Search failed for application ID {}: {}", applicationId, e.getMessage());
            throw new PageNavigationException("Failed to search for application: " + applicationId, e);
        }
    }

    /**
     * Opens menu and clicks through menu path.
     *
     * @param labels Menu labels to navigate through
     * @throws PageNavigationException if navigation fails
     */
    private void openMenuAndClick(String... labels) {
        if (labels == null || labels.length == 0) {
            throw new IllegalArgumentException("At least one label is required");
        }

        Actions actions = new Actions(driver);
        JavascriptExecutor js = (JavascriptExecutor) driver;

        WebElement scope = menuElement;

        for (int i = 0; i < labels.length; i++) {
            String label = labels[i].trim().replaceAll("\\s+", " ");

            // Find anchor elements
            String anchorsXpath = scope.getTagName().equalsIgnoreCase("ul") ? "./li/a" : "./ul/li/a";
            List<WebElement> anchors = scope.findElements(By.xpath(anchorsXpath));

            // Find matching link
            WebElement link = anchors.stream().filter(a -> {
                String direct = (String) js.executeScript(
                        "const a=arguments[0]; return [...a.childNodes].filter(n=>n.nodeType===3)" +
                        ".map(n=>n.textContent).join('').replace(/\\s+/g,' ').trim();", a);
                return label.equals(direct);
            }).findFirst().orElseThrow(() ->
                    new NoSuchElementException("Menu item not found: " + label));

            js.executeScript("arguments[0].scrollIntoView({block:'center'});", link);
            hardWait(1);

            boolean isLeaf = (i == labels.length - 1);
            if (isLeaf) {
                // Click the final menu item
                try {
                    link.click();
                } catch (Exception e) {
                    js.executeScript("arguments[0].click();", link);
                }
                return;
            } else {
                // Hover and wait for submenu
                WebElement li = link.findElement(By.xpath("./ancestor::li[1]"));
                boolean opened = false;

                try {
                    actions.moveToElement(link).pause(Duration.ofMillis(150)).perform();
                    opened = waitChildVisibleByJs(li, Duration.ofSeconds(2));
                } catch (Exception ignored) {
                }

                if (!opened) {
                    try {
                        link.click();
                    } catch (Exception e) {
                        js.executeScript("arguments[0].click();", link);
                    }
                    opened = waitChildVisibleByJs(li, Duration.ofSeconds(4));
                }

                if (!opened) {
                    throw new TimeoutException("Submenu did not open for: " + label);
                }
                scope = li;
            }
        }
    }

    /**
     * Waits for child submenu to become visible.
     *
     * @param li      Parent list item element
     * @param timeout Timeout duration
     * @return true if visible, false otherwise
     */
    private boolean waitChildVisibleByJs(WebElement li, Duration timeout) {
        long endTime = System.currentTimeMillis() + timeout.toMillis();

        while (System.currentTimeMillis() < endTime) {
            try {
                WebElement ul = li.findElement(By.xpath("./ul"));
                Boolean visible = (Boolean) JavaScriptUtils.executeScript(driver,
                        "const u=arguments[0]; if(!u) return false;" +
                        "const s=getComputedStyle(u);" +
                        "if(s.display==='none' || s.visibility==='hidden' || +s.opacity===0) return false;" +
                        "const r=u.getBoundingClientRect(); return r.width>0 && r.height>0;", ul);

                if (Boolean.TRUE.equals(visible)) {
                    return true;
                }
            } catch (NoSuchElementException | StaleElementReferenceException ignored) {
            }

            hardWait(1);
        }
        return false;
    }

    /**
     * Clears the search field.
     *
     * @return SearchPage (fluent interface)
     */
    public SearchPage clearSearchField() {
        logger.debug("Clearing search field");
        appIdField.clear();
        return this;
    }

    /**
     * Checks if search button is enabled.
     *
     * @return true if enabled, false otherwise
     */
    public boolean isSearchButtonEnabled() {
        return isEnabled(searchButton);
    }
}
