package com.harsha.automation.services;

import com.harsha.automation.enums.Category;
import com.harsha.automation.enums.ExtractionType;
import com.harsha.automation.exceptions.DataExtractionException;
import com.harsha.automation.models.ApplicationData;
import com.harsha.automation.pages.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

/**
 * Service class for extracting bureau data from the web application.
 */
public class BureauDataExtractionService {
    private static final Logger logger = LogManager.getLogger(BureauDataExtractionService.class);
    private final FileService fileService;

    public BureauDataExtractionService() {
        this.fileService = new FileService();
    }

    /**
     * Extracts bureau data for a single application (both PRE and POST).
     *
     * @param driver         WebDriver instance
     * @param appData        Application data
     * @param outputFolder   Output folder path
     * @param searchPage     Search page instance
     * @return true if successful, false otherwise
     */
    public boolean extractBureauDataForApplication(WebDriver driver, ApplicationData appData,
                                                   String outputFolder, SearchPage searchPage) {
        logger.info("Extracting bureau data for: {}", appData.getFileName());

        boolean preSuccess = extractData(driver, appData.getPreAppId(), outputFolder,
                                        appData.getFileName(), ExtractionType.PRE, searchPage);

        if (preSuccess) {
            searchPage = navigateBackToSearch(driver);
        }

        boolean postSuccess = extractData(driver, appData.getPostAppId(), outputFolder,
                                         appData.getFileName(), ExtractionType.POST, searchPage);

        return preSuccess && postSuccess;
    }

    /**
     * Extracts bureau data for a single APP ID.
     *
     * @param driver       WebDriver instance
     * @param appId        Application ID
     * @param outputFolder Output folder
     * @param fileName     File name
     * @param type         Extraction type
     * @param searchPage   Search page instance
     * @return true if successful, false otherwise
     */
    private boolean extractData(WebDriver driver, String appId, String outputFolder,
                               String fileName, ExtractionType type, SearchPage searchPage) {
        try {
            logger.info("Extracting {} data for APP ID: {}", type, appId);

            // Search for application
            ApplicationDetailsPage detailsPage = searchPage.searchApplication(appId);

            // Open application
            detailsPage.openApplication();

            // View bureau data
            DataViewerPage dataViewerPage = detailsPage.viewBureauData();

            // Extract and save data
            String outputPath = String.format("%s/%s_%s_%s.txt",
                                            outputFolder, fileName, type.getTypeName(), appId);
            boolean success = dataViewerPage.extractBureauData(appId, outputPath, type);

            logger.info("{} extraction {} for APP ID: {}",
                       type, success ? "successful" : "failed", appId);
            return success;

        } catch (Exception e) {
            logger.error("{} extraction failed for APP ID {}: {}",
                        type, appId, e.getMessage());
            return false;
        }
    }

    /**
     * Navigates back to search page after extraction.
     *
     * @param driver WebDriver instance
     * @return SearchPage instance
     */
    private SearchPage navigateBackToSearch(WebDriver driver) {
        try {
            ApplicationDetailsPage detailsPage = new ApplicationDetailsPage(driver);
            return detailsPage.close();
        } catch (Exception e) {
            logger.warn("Failed to navigate back to search: {}", e.getMessage());
            return new SearchPage(driver);
        }
    }
}
