package com.harsha.automation.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.harsha.automation.exceptions.DataExtractionException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Utility class for JSON operations.
 */
public class JsonUtils {
    private static final Logger logger = LogManager.getLogger(JsonUtils.class);
    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * List of possible APP ID key names.
     */
    private static final List<String> APPID_KEYS = Arrays.asList(
            "APPID", "AppID", "AppId", "appId", "appid", "APP_ID", "app_id", "APP-ID", "app-id"
    );

    /**
     * List of possible ID key names.
     */
    private static final List<String> ID_KEYS = Arrays.asList(
            "id", "ID", "Id", "value", "appId", "APPID"
    );

    /**
     * Private constructor to prevent instantiation.
     */
    private JsonUtils() {
    }

    /**
     * Parses JSON string to JsonNode.
     *
     * @param jsonString JSON string
     * @return JsonNode
     * @throws DataExtractionException if parsing fails
     */
    public static JsonNode parseJson(String jsonString) {
        logger.debug("Parsing JSON string");
        try {
            return objectMapper.readTree(jsonString);
        } catch (IOException e) {
            logger.error("Failed to parse JSON: {}", e.getMessage());
            throw new DataExtractionException("Failed to parse JSON", e);
        }
    }

    /**
     * Reads JSON file and returns JsonNode.
     *
     * @param file JSON file
     * @return JsonNode
     * @throws DataExtractionException if file cannot be read
     */
    public static JsonNode readJsonFile(File file) {
        logger.debug("Reading JSON file: {}", file.getAbsolutePath());
        try {
            return objectMapper.readTree(file);
        } catch (IOException e) {
            logger.error("Failed to read JSON file {}: {}", file.getAbsolutePath(), e.getMessage());
            throw new DataExtractionException("Failed to read JSON file: " + file.getName(), e);
        }
    }

    /**
     * Finds APP ID from JsonNode recursively.
     *
     * @param node JsonNode to search
     * @return APP ID string or empty string if not found
     */
    public static String findAppId(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) {
            return "";
        }

        // Check if node is an object
        if (node.isObject()) {
            // Try known APP ID keys first
            for (String key : APPID_KEYS) {
                JsonNode candidate = node.get(key);
                String value = nodeToIdString(candidate);
                if (!value.isEmpty()) {
                    logger.debug("Found APP ID using key '{}': {}", key, value);
                    return value;
                }
            }

            // Search for keys containing "appid" (case insensitive)
            Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> entry = fields.next();
                String fieldName = entry.getKey();
                JsonNode fieldValue = entry.getValue();

                if (fieldName != null && fieldName.toLowerCase().contains("appid")) {
                    String value = nodeToIdString(fieldValue);
                    if (!value.isEmpty()) {
                        logger.debug("Found APP ID using field '{}': {}", fieldName, value);
                        return value;
                    }
                }

                // Recursive search
                String deeperValue = findAppId(fieldValue);
                if (!deeperValue.isEmpty()) {
                    return deeperValue;
                }
            }
        }

        // Check if node is an array
        if (node.isArray()) {
            for (JsonNode item : node) {
                String value = findAppId(item);
                if (!value.isEmpty()) {
                    return value;
                }
            }
        }

        return "";
    }

    /**
     * Converts JsonNode to ID string.
     *
     * @param node JsonNode to convert
     * @return ID string or empty string
     */
    private static String nodeToIdString(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) {
            return "";
        }

        // Direct value (text, number, boolean)
        if (node.isTextual() || node.isNumber() || node.isBoolean()) {
            return node.asText();
        }

        // Object with ID keys
        if (node.isObject()) {
            for (String idKey : ID_KEYS) {
                JsonNode inner = node.get(idKey);
                if (inner != null && !inner.isNull()) {
                    String value = nodeToIdString(inner);
                    if (!value.isEmpty()) {
                        return value;
                    }
                }
            }

            // Try all fields
            Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> entry = fields.next();
                String value = nodeToIdString(entry.getValue());
                if (!value.isEmpty()) {
                    return value;
                }
            }
        }

        // Array - try first element
        if (node.isArray() && node.size() > 0) {
            for (JsonNode item : node) {
                String value = nodeToIdString(item);
                if (!value.isEmpty()) {
                    return value;
                }
            }
        }

        return "";
    }

    /**
     * Converts object to JSON string.
     *
     * @param object Object to convert
     * @return JSON string
     * @throws DataExtractionException if conversion fails
     */
    public static String toJsonString(Object object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (IOException e) {
            logger.error("Failed to convert object to JSON: {}", e.getMessage());
            throw new DataExtractionException("Failed to convert object to JSON", e);
        }
    }

    /**
     * Converts object to pretty printed JSON string.
     *
     * @param object Object to convert
     * @return Pretty printed JSON string
     * @throws DataExtractionException if conversion fails
     */
    public static String toPrettyJsonString(Object object) {
        try {
            return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
        } catch (IOException e) {
            logger.error("Failed to convert object to pretty JSON: {}", e.getMessage());
            throw new DataExtractionException("Failed to convert object to pretty JSON", e);
        }
    }

    /**
     * Gets ObjectMapper instance.
     *
     * @return ObjectMapper instance
     */
    public static ObjectMapper getObjectMapper() {
        return objectMapper;
    }
}
