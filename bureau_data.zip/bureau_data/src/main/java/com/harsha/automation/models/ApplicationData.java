package com.harsha.automation.models;

import com.harsha.automation.enums.Category;
import lombok.*;

/**
 * Model class representing application data for bureau comparison.
 * Uses Builder pattern for flexible object construction.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class ApplicationData {

    /**
     * Name of the file containing application data
     */
    private String fileName;

    /**
     * Pre-deployment application ID
     */
    private String preAppId;

    /**
     * Post-deployment application ID
     */
    private String postAppId;

    /**
     * Category of the application (ACQ, CLI, PRQ)
     */
    private Category category;

    /**
     * Status of data extraction (SUCCESS, FAILED, PENDING)
     */
    private String extractionStatus;

    /**
     * Path to PRE extraction output file
     */
    private String preOutputPath;

    /**
     * Path to POST extraction output file
     */
    private String postOutputPath;

    /**
     * Validation method to check if application data is valid.
     *
     * @return true if all required fields are present, false otherwise
     */
    public boolean isValid() {
        return fileName != null && !fileName.trim().isEmpty() &&
               preAppId != null && !preAppId.trim().isEmpty() &&
               postAppId != null && !postAppId.trim().isEmpty() &&
               category != null && category != Category.UNKNOWN;
    }

    /**
     * Determines category from filename if category is not set.
     */
    public void determineCategory() {
        if (this.category == null || this.category == Category.UNKNOWN) {
            this.category = Category.fromFileName(this.fileName);
        }
    }

    /**
     * Custom builder class for fluent API.
     */
    public static class ApplicationDataBuilder {
        /**
         * Builds ApplicationData with automatic category determination.
         *
         * @return ApplicationData instance
         */
        public ApplicationData buildWithCategoryDetection() {
            if (this.category == null || this.category == Category.UNKNOWN) {
                this.category = Category.fromFileName(this.fileName);
            }
            return new ApplicationData(fileName, preAppId, postAppId, category,
                                     extractionStatus, preOutputPath, postOutputPath);
        }
    }
}
