package com.harsha.automation.enums;

/**
 * Enum representing supported browser types for test execution.
 */
public enum BrowserType {
    /**
     * Google Chrome browser
     */
    CHROME("chrome"),

    /**
     * Mozilla Firefox browser
     */
    FIREFOX("firefox"),

    /**
     * Microsoft Edge browser
     */
    EDGE("edge");

    private final String browserName;

    /**
     * Constructor for BrowserType enum.
     *
     * @param browserName Browser name identifier
     */
    BrowserType(String browserName) {
        this.browserName = browserName;
    }

    /**
     * Gets the browser name identifier.
     *
     * @return Browser name as string
     */
    public String getBrowserName() {
        return browserName;
    }

    /**
     * Gets BrowserType from string value.
     *
     * @param value String value to convert
     * @return Corresponding BrowserType
     * @throws IllegalArgumentException if browser type not found
     */
    public static BrowserType fromString(String value) {
        for (BrowserType type : BrowserType.values()) {
            if (type.name().equalsIgnoreCase(value) || type.browserName.equalsIgnoreCase(value)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown browser type: " + value);
    }
}
