package com.harsha.automation.core.driver;

import com.harsha.automation.config.TestConfiguration;
import com.harsha.automation.enums.BrowserType;
import com.harsha.automation.exceptions.DriverException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

/**
 * Singleton Driver Manager that provides WebDriver instances using ThreadLocal.
 * Manages driver lifecycle and ensures thread-safety for parallel execution.
 */
public class DriverManager {
    private static final Logger logger = LogManager.getLogger(DriverManager.class);
    private static volatile DriverManager instance;
    private final TestConfiguration config;

    /**
     * Private constructor to prevent direct instantiation.
     */
    private DriverManager() {
        this.config = new TestConfiguration();
        logger.info("DriverManager initialized with configuration");
    }

    /**
     * Gets the singleton instance of DriverManager.
     * Implements double-checked locking for thread safety.
     *
     * @return DriverManager instance
     */
    public static DriverManager getInstance() {
        if (instance == null) {
            synchronized (DriverManager.class) {
                if (instance == null) {
                    instance = new DriverManager();
                }
            }
        }
        return instance;
    }

    /**
     * Initializes and returns a WebDriver for the current thread.
     * Uses the browser type from configuration.
     *
     * @return WebDriver instance
     */
    public WebDriver getDriver() {
        if (!ThreadLocalDriver.hasDriver()) {
            logger.info("No driver found for current thread. Creating new driver.");
            createDriver();
        }
        return ThreadLocalDriver.getDriver();
    }

    /**
     * Initializes and returns a WebDriver for the current thread with specified browser.
     *
     * @param browserType Browser type to create
     * @return WebDriver instance
     */
    public WebDriver getDriver(BrowserType browserType) {
        if (!ThreadLocalDriver.hasDriver()) {
            logger.info("No driver found for current thread. Creating new {} driver.", browserType);
            createDriver(browserType);
        }
        return ThreadLocalDriver.getDriver();
    }

    /**
     * Creates a new WebDriver using the browser type from configuration.
     */
    public void createDriver() {
        createDriver(config.getBrowserType());
    }

    /**
     * Creates a new WebDriver for the specified browser type.
     *
     * @param browserType Browser type to create
     * @throws DriverException if driver creation fails
     */
    public void createDriver(BrowserType browserType) {
        try {
            logger.info("Creating new {} driver for thread: {}",
                    browserType, Thread.currentThread().getName());

            WebDriver driver = DriverFactory.createDriver(browserType, config);
            ThreadLocalDriver.setDriver(driver);

            logger.info("Driver created and set for thread: {}", Thread.currentThread().getName());

        } catch (Exception e) {
            logger.error("Failed to create driver: {}", e.getMessage(), e);
            throw new DriverException("Failed to create WebDriver", e);
        }
    }

    /**
     * Quits the WebDriver for the current thread and removes it from ThreadLocal.
     */
    public void quitDriver() {
        if (ThreadLocalDriver.hasDriver()) {
            logger.info("Quitting driver for thread: {}", Thread.currentThread().getName());
            ThreadLocalDriver.quitDriver();
        } else {
            logger.warn("No driver to quit for thread: {}", Thread.currentThread().getName());
        }
    }

    /**
     * Checks if a driver exists for the current thread.
     *
     * @return true if driver exists, false otherwise
     */
    public boolean hasDriver() {
        return ThreadLocalDriver.hasDriver();
    }

    /**
     * Gets the test configuration.
     *
     * @return TestConfiguration instance
     */
    public TestConfiguration getConfig() {
        return config;
    }

    /**
     * Navigates to the specified URL using the current thread's driver.
     *
     * @param url URL to navigate to
     */
    public void navigateTo(String url) {
        logger.info("Navigating to: {}", url);
        getDriver().get(url);
    }

    /**
     * Navigates to the base URL from configuration.
     */
    public void navigateToBaseUrl() {
        String baseUrl = config.getBaseUrl();
        logger.info("Navigating to base URL: {}", baseUrl);
        navigateTo(baseUrl);
    }

    /**
     * Refreshes the current page.
     */
    public void refreshPage() {
        logger.debug("Refreshing current page");
        getDriver().navigate().refresh();
    }

    /**
     * Navigates back to the previous page.
     */
    public void navigateBack() {
        logger.debug("Navigating back");
        getDriver().navigate().back();
    }

    /**
     * Navigates forward to the next page.
     */
    public void navigateForward() {
        logger.debug("Navigating forward");
        getDriver().navigate().forward();
    }

    /**
     * Gets the current page URL.
     *
     * @return Current URL
     */
    public String getCurrentUrl() {
        return getDriver().getCurrentUrl();
    }

    /**
     * Gets the current page title.
     *
     * @return Page title
     */
    public String getPageTitle() {
        return getDriver().getTitle();
    }
}
