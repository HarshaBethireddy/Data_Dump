package com.harsha.automation.config;

import com.harsha.automation.enums.BrowserType;
import lombok.Getter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.Duration;

/**
 * Test configuration class that provides easy access to all test-related configurations.
 * Acts as a facade over ConfigurationManager for test-specific settings.
 */
@Getter
public class TestConfiguration {
    private static final Logger logger = LogManager.getLogger(TestConfiguration.class);
    private static final ConfigurationManager config = ConfigurationManager.getInstance();

    // Application URLs
    private final String baseUrl;

    // Credentials
    private final String username;
    private final String password;

    // Browser Configuration
    private final BrowserType browserType;
    private final boolean headless;
    private final boolean maximized;

    // WebDriver Configuration
    private final Duration implicitWait;
    private final Duration explicitWait;
    private final Duration pageLoadTimeout;
    private final Duration scriptTimeout;

    // Parallel Execution
    private final int browserInstances;
    private final int threadPoolSize;
    private final String threadCount;

    // Folder Paths
    private final String basePrefolder;
    private final String basePostFolder;
    private final String baseOutputDirectory;

    // Group Selection
    private final String adminGroup;

    // Retry Configuration
    private final int maxRetryCount;
    private final boolean retryFailedTests;

    // Screenshot Configuration
    private final boolean captureScreenshotOnFailure;
    private final boolean captureScreenshotOnSuccess;

    // Reporting
    private final String extentReportPath;
    private final String extentReportName;

    /**
     * Constructor initializes all configuration values from ConfigurationManager.
     */
    public TestConfiguration() {
        // Application URLs
        this.baseUrl = config.getProperty("app.base.url");

        // Credentials
        this.username = config.getProperty("app.username");
        this.password = config.getProperty("app.password");

        // Browser Configuration
        this.browserType = BrowserType.valueOf(
                config.getProperty("browser.type", "CHROME").toUpperCase()
        );
        this.headless = config.getBooleanProperty("browser.headless", false);
        this.maximized = config.getBooleanProperty("browser.maximized", true);

        // WebDriver Configuration
        this.implicitWait = Duration.ofSeconds(
                config.getLongProperty("wait.implicit.seconds", 10L)
        );
        this.explicitWait = Duration.ofSeconds(
                config.getLongProperty("wait.explicit.seconds", 60L)
        );
        this.pageLoadTimeout = Duration.ofSeconds(
                config.getLongProperty("wait.page.load.seconds", 60L)
        );
        this.scriptTimeout = Duration.ofSeconds(
                config.getLongProperty("wait.script.seconds", 30L)
        );

        // Parallel Execution
        this.browserInstances = config.getIntProperty("parallel.browser.instances", 3);
        this.threadPoolSize = config.getIntProperty("parallel.thread.pool.size", 4);
        this.threadCount = config.getProperty("parallel.thread.count", "3");

        // Folder Paths
        this.basePrefolder = config.getProperty("folder.pre.base");
        this.basePostFolder = config.getProperty("folder.post.base");
        this.baseOutputDirectory = config.getProperty("folder.output.base");

        // Group Selection
        this.adminGroup = config.getProperty("app.admin.group", "Administrators");

        // Retry Configuration
        this.maxRetryCount = config.getIntProperty("retry.max.count", 1);
        this.retryFailedTests = config.getBooleanProperty("retry.failed.tests", true);

        // Screenshot Configuration
        this.captureScreenshotOnFailure = config.getBooleanProperty("screenshot.on.failure", true);
        this.captureScreenshotOnSuccess = config.getBooleanProperty("screenshot.on.success", false);

        // Reporting
        this.extentReportPath = config.getProperty("report.extent.path", "reports/extent-report.html");
        this.extentReportName = config.getProperty("report.extent.name", "Bureau Comparison Test Report");

        logger.info("Test configuration initialized successfully");
        logConfiguration();
    }

    /**
     * Logs the current configuration for debugging purposes.
     */
    private void logConfiguration() {
        logger.debug("=== Test Configuration ===");
        logger.debug("Base URL: {}", baseUrl);
        logger.debug("Browser: {}", browserType);
        logger.debug("Headless: {}", headless);
        logger.debug("Browser Instances: {}", browserInstances);
        logger.debug("Thread Pool Size: {}", threadPoolSize);
        logger.debug("Explicit Wait: {} seconds", explicitWait.getSeconds());
        logger.debug("Max Retry Count: {}", maxRetryCount);
        logger.debug("=========================");
    }

    /**
     * Gets the implicit wait duration.
     *
     * @return Duration for implicit wait
     */
    public Duration getImplicitWait() {
        return implicitWait;
    }

    /**
     * Gets the explicit wait duration.
     *
     * @return Duration for explicit wait
     */
    public Duration getExplicitWait() {
        return explicitWait;
    }

    /**
     * Gets the page load timeout duration.
     *
     * @return Duration for page load timeout
     */
    public Duration getPageLoadTimeout() {
        return pageLoadTimeout;
    }

    /**
     * Gets the script timeout duration.
     *
     * @return Duration for script timeout
     */
    public Duration getScriptTimeout() {
        return scriptTimeout;
    }
}
