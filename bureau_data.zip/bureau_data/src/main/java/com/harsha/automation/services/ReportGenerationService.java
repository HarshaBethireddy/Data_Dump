package com.harsha.automation.services;

import com.harsha.automation.models.ComparisonResult;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Service class for generating comparison reports.
 */
public class ReportGenerationService {
    private static final Logger logger = LogManager.getLogger(ReportGenerationService.class);
    private final FileService fileService;

    public ReportGenerationService() {
        this.fileService = new FileService();
    }

    /**
     * Generates a detailed comparison report.
     *
     * @param results     List of comparison results
     * @param outputPath  Output file path
     * @param category    Category name
     */
    public void generateComparisonReport(List<ComparisonResult> results, String outputPath, String category) {
        logger.info("Generating comparison report for category: {}", category);

        StringBuilder report = new StringBuilder();

        // Header
        report.append("===== CATEGORY: ").append(category).append(" =====\n");
        report.append("Applications: ").append(results.size()).append("\n");
        report.append("Generated: ").append(LocalDateTime.now()).append("\n");
        report.append("==========================================\n\n");

        // Individual results
        for (ComparisonResult result : results) {
            report.append(generateResultSection(result));
            report.append("\n\n");
        }

        // Summary
        report.append(generateSummary(results));

        // Save report
        fileService.writeFile(outputPath, report.toString());
        logger.info("Comparison report saved: {}", outputPath);
    }

    /**
     * Generates a master report combining all categories.
     *
     * @param allResults  All comparison results
     * @param outputPath  Output file path
     */
    public void generateMasterReport(List<ComparisonResult> allResults, String outputPath) {
        logger.info("Generating master comparison report");

        StringBuilder report = new StringBuilder();

        report.append("===== MASTER BUREAU DATA COMPARISON REPORT =====\n");
        report.append("Generated: ").append(LocalDateTime.now()).append("\n");
        report.append("Total Applications: ").append(allResults.size()).append("\n");
        report.append("==============================================\n\n");

        for (ComparisonResult result : allResults) {
            report.append(generateResultSection(result));
            report.append("\n\n");
        }

        report.append(generateSummary(allResults));

        fileService.writeFile(outputPath, report.toString());
        logger.info("Master report saved: {}", outputPath);
    }

    /**
     * Generates a report section for a single result.
     *
     * @param result Comparison result
     * @return Report section string
     */
    private String generateResultSection(ComparisonResult result) {
        StringBuilder section = new StringBuilder();

        section.append("File: ").append(result.getFileName()).append("\n");
        section.append("Status: ").append(result.getStatus().getDescription()).append("\n");

        if (result.getStatus() == ComparisonResult.ComparisonStatus.ERROR) {
            section.append("Error: ").append(result.getErrorMessage()).append("\n");
        } else {
            section.append("Pre Lines: ").append(result.getPreTotalLines()).append("\n");
            section.append("Post Lines: ").append(result.getPostTotalLines()).append("\n");

            if (result.getStatus() == ComparisonResult.ComparisonStatus.DIFFERENCES_FOUND) {
                section.append("Differences Found: ").append(result.getDifferenceCount()).append("\n");
                section.append("\nDifference Details:\n");

                int displayLimit = Math.min(10, result.getDifferences().size());
                for (int i = 0; i < displayLimit; i++) {
                    ComparisonResult.Difference diff = result.getDifferences().get(i);
                    section.append(diff.toDisplayString()).append("\n\n");
                }

                if (result.getDifferenceCount() > displayLimit) {
                    section.append("... and ").append(result.getDifferenceCount() - displayLimit)
                           .append(" more differences\n");
                }
            }
        }

        return section.toString();
    }

    /**
     * Generates summary statistics.
     *
     * @param results List of results
     * @return Summary string
     */
    private String generateSummary(List<ComparisonResult> results) {
        long matched = results.stream()
                .filter(r -> r.getStatus() == ComparisonResult.ComparisonStatus.MATCHED)
                .count();

        long differencesFound = results.stream()
                .filter(r -> r.getStatus() == ComparisonResult.ComparisonStatus.DIFFERENCES_FOUND)
                .count();

        long errors = results.stream()
                .filter(r -> r.getStatus() == ComparisonResult.ComparisonStatus.ERROR)
                .count();

        StringBuilder summary = new StringBuilder();
        summary.append("\n========== SUMMARY ==========\n");
        summary.append("Total Files: ").append(results.size()).append("\n");
        summary.append("Matched: ").append(matched).append("\n");
        summary.append("Differences Found: ").append(differencesFound).append("\n");
        summary.append("Errors: ").append(errors).append("\n");
        summary.append("=============================\n");

        return summary.toString();
    }
}
