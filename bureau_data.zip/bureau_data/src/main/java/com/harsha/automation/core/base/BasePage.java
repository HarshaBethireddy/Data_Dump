package com.harsha.automation.core.base;

import com.harsha.automation.core.driver.DriverManager;
import com.harsha.automation.utils.JavaScriptUtils;
import com.harsha.automation.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * Base Page class that provides common functionality for all Page Objects.
 * Implements Page Object Model pattern with fluent interface.
 */
public abstract class BasePage {
    protected final Logger logger = LogManager.getLogger(this.getClass());
    protected WebDriver driver;
    protected WebDriverWait wait;
    protected DriverManager driverManager;

    /**
     * Constructor initializes the WebDriver and PageFactory.
     *
     * @param driver WebDriver instance
     */
    protected BasePage(WebDriver driver) {
        this.driver = driver;
        this.driverManager = DriverManager.getInstance();
        this.wait = new WebDriverWait(driver, driverManager.getConfig().getExplicitWait());
        PageFactory.initElements(driver, this);
        logger.debug("{} initialized", this.getClass().getSimpleName());
    }

    /**
     * Abstract method to verify if the page is loaded.
     * Must be implemented by all page classes.
     *
     * @return true if page is loaded, false otherwise
     */
    public abstract boolean isLoaded();

    /**
     * Waits for the page to be loaded.
     *
     * @param timeout Timeout duration
     * @return true if page loaded successfully
     */
    public boolean waitForPageLoad(Duration timeout) {
        logger.debug("Waiting for {} to load", this.getClass().getSimpleName());
        return WaitUtils.waitForCondition(driver, d -> isLoaded(), timeout) != null;
    }

    /**
     * Clicks on an element.
     *
     * @param element Element to click
     */
    protected void click(WebElement element) {
        logger.debug("Clicking element");
        WaitUtils.waitForClickability(driver, getBy(element));
        element.click();
    }

    /**
     * Clicks on an element using JavaScript.
     *
     * @param element Element to click
     */
    protected void clickUsingJS(WebElement element) {
        logger.debug("Clicking element using JavaScript");
        JavaScriptUtils.clickElement(driver, element);
    }

    /**
     * Types text into an element.
     *
     * @param element Element to type into
     * @param text    Text to type
     */
    protected void type(WebElement element, String text) {
        logger.debug("Typing text: {}", text);
        WaitUtils.waitForVisibility(driver, getBy(element));
        element.clear();
        element.sendKeys(text);
    }

    /**
     * Gets text from an element.
     *
     * @param element Element to get text from
     * @return Element text
     */
    protected String getText(WebElement element) {
        logger.debug("Getting text from element");
        WaitUtils.waitForVisibility(driver, getBy(element));
        return element.getText();
    }

    /**
     * Checks if element is displayed.
     *
     * @param element Element to check
     * @return true if displayed, false otherwise
     */
    protected boolean isDisplayed(WebElement element) {
        try {
            return element.isDisplayed();
        } catch (Exception e) {
            logger.debug("Element not displayed: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Checks if element is enabled.
     *
     * @param element Element to check
     * @return true if enabled, false otherwise
     */
    protected boolean isEnabled(WebElement element) {
        try {
            return element.isEnabled();
        } catch (Exception e) {
            logger.debug("Element not enabled: {}", e.getMessage());
            return false;
        }
    }

    /**
     * Waits for element visibility.
     *
     * @param locator Element locator
     * @return Visible WebElement
     */
    protected WebElement waitForVisibility(By locator) {
        logger.debug("Waiting for element visibility: {}", locator);
        return WaitUtils.waitForVisibility(driver, locator);
    }

    /**
     * Waits for element to be clickable.
     *
     * @param locator Element locator
     * @return Clickable WebElement
     */
    protected WebElement waitForClickability(By locator) {
        logger.debug("Waiting for element to be clickable: {}", locator);
        return WaitUtils.waitForClickability(driver, locator);
    }

    /**
     * Waits for element presence.
     *
     * @param locator Element locator
     * @return WebElement
     */
    protected WebElement waitForPresence(By locator) {
        logger.debug("Waiting for element presence: {}", locator);
        return WaitUtils.waitForPresence(driver, locator);
    }

    /**
     * Finds elements by locator.
     *
     * @param locator Element locator
     * @return List of WebElements
     */
    protected List<WebElement> findElements(By locator) {
        logger.debug("Finding elements: {}", locator);
        return driver.findElements(locator);
    }

    /**
     * Finds element by locator.
     *
     * @param locator Element locator
     * @return WebElement
     */
    protected WebElement findElement(By locator) {
        logger.debug("Finding element: {}", locator);
        return driver.findElement(locator);
    }

    /**
     * Scrolls to element.
     *
     * @param element Element to scroll to
     */
    protected void scrollToElement(WebElement element) {
        logger.debug("Scrolling to element");
        JavaScriptUtils.scrollToElement(driver, element);
    }

    /**
     * Highlights element for debugging.
     *
     * @param element Element to highlight
     */
    protected void highlightElement(WebElement element) {
        JavaScriptUtils.highlightElement(driver, element);
    }

    /**
     * Gets current page URL.
     *
     * @return Current URL
     */
    protected String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    /**
     * Gets page title.
     *
     * @return Page title
     */
    protected String getPageTitle() {
        return driver.getTitle();
    }

    /**
     * Refreshes the page.
     */
    protected void refreshPage() {
        logger.debug("Refreshing page");
        driver.navigate().refresh();
    }

    /**
     * Navigates back.
     */
    protected void navigateBack() {
        logger.debug("Navigating back");
        driver.navigate().back();
    }

    /**
     * Hard wait (use sparingly).
     *
     * @param seconds Seconds to wait
     */
    protected void hardWait(int seconds) {
        WaitUtils.hardWait(seconds);
    }

    /**
     * Gets By locator from WebElement (workaround method).
     * Note: This is a simplified implementation.
     *
     * @param element WebElement
     * @return By locator
     */
    private By getBy(WebElement element) {
        // This is a workaround - in real implementation, you'd track locators
        // For now, we'll use a generic approach
        return By.xpath("//body"); // Placeholder
    }

    /**
     * Switches to window by title.
     *
     * @param windowTitle Window title to switch to
     */
    protected void switchToWindowByTitle(String windowTitle) {
        logger.debug("Switching to window: {}", windowTitle);
        String mainWindow = driver.getWindowHandle();
        for (String windowHandle : driver.getWindowHandles()) {
            driver.switchTo().window(windowHandle);
            if (driver.getTitle().equals(windowTitle)) {
                logger.debug("Switched to window: {}", windowTitle);
                return;
            }
        }
        driver.switchTo().window(mainWindow);
        logger.warn("Window not found: {}", windowTitle);
    }

    /**
     * Closes current window and switches back to main window.
     *
     * @param mainWindowHandle Main window handle
     */
    protected void closeAndSwitchToMainWindow(String mainWindowHandle) {
        logger.debug("Closing current window and switching to main");
        driver.close();
        driver.switchTo().window(mainWindowHandle);
    }

    /**
     * Gets all window handles.
     *
     * @return Set of window handles
     */
    protected java.util.Set<String> getAllWindowHandles() {
        return driver.getWindowHandles();
    }

    /**
     * Gets current window handle.
     *
     * @return Current window handle
     */
    protected String getCurrentWindowHandle() {
        return driver.getWindowHandle();
    }
}
