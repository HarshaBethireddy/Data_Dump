package com.harsha.automation.models;

import com.harsha.automation.enums.Category;
import lombok.*;

/**
 * Model class representing configuration for a specific category.
 * Contains navigation menu path and other category-specific settings.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class CategoryConfig {

    /**
     * Category type (ACQ, CLI, PRQ)
     */
    private Category category;

    /**
     * Navigation menu path to reach the category's search screen
     */
    private String[] menuPath;

    /**
     * Display name for the category
     */
    private String displayName;

    /**
     * Description of the category
     */
    private String description;

    /**
     * Whether this category is enabled for processing
     */
    @Builder.Default
    private boolean enabled = true;

    /**
     * Constructor for backward compatibility with existing code.
     *
     * @param menuPath Navigation menu path
     */
    public CategoryConfig(String... menuPath) {
        this.menuPath = menuPath;
    }

    /**
     * Creates a CategoryConfig from Category enum.
     *
     * @param category Category enum value
     * @return CategoryConfig instance
     */
    public static CategoryConfig fromCategory(Category category) {
        return CategoryConfig.builder()
                .category(category)
                .menuPath(category.getMenuPath())
                .displayName(category.getCategoryName())
                .enabled(category.isValid())
                .build();
    }

    /**
     * Validates if the configuration is valid.
     *
     * @return true if configuration is valid, false otherwise
     */
    public boolean isValid() {
        return category != null &&
               category != Category.UNKNOWN &&
               menuPath != null &&
               menuPath.length > 0 &&
               enabled;
    }

    /**
     * Gets the menu path as a formatted string.
     *
     * @return Formatted menu path
     */
    public String getFormattedMenuPath() {
        if (menuPath == null || menuPath.length == 0) {
            return "";
        }
        return String.join(" > ", menuPath);
    }
}
