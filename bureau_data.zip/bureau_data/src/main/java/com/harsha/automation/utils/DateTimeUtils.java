package com.harsha.automation.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Utility class for date and time operations.
 */
public class DateTimeUtils {

    /**
     * Formatter for run directory names (yyyyMMdd_HHmmss_SSS).
     */
    public static final DateTimeFormatter RUN_DIR_FORMATTER =
            DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");

    /**
     * Formatter for display timestamps (yyyy-MM-dd HH:mm:ss).
     */
    public static final DateTimeFormatter DISPLAY_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * Formatter for file names (yyyyMMdd_HHmmss).
     */
    public static final DateTimeFormatter FILE_NAME_FORMATTER =
            DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");

    /**
     * Private constructor to prevent instantiation.
     */
    private DateTimeUtils() {
    }

    /**
     * Gets current timestamp formatted for run directories.
     *
     * @return Formatted timestamp string
     */
    public static String getCurrentTimestampForRunDir() {
        return LocalDateTime.now().format(RUN_DIR_FORMATTER);
    }

    /**
     * Gets current timestamp formatted for display.
     *
     * @return Formatted timestamp string
     */
    public static String getCurrentTimestampForDisplay() {
        return LocalDateTime.now().format(DISPLAY_FORMATTER);
    }

    /**
     * Gets current timestamp formatted for file names.
     *
     * @return Formatted timestamp string
     */
    public static String getCurrentTimestampForFileName() {
        return LocalDateTime.now().format(FILE_NAME_FORMATTER);
    }

    /**
     * Formats a LocalDateTime using the specified pattern.
     *
     * @param dateTime LocalDateTime to format
     * @param pattern  Format pattern
     * @return Formatted string
     */
    public static String format(LocalDateTime dateTime, String pattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return dateTime.format(formatter);
    }

    /**
     * Gets current LocalDateTime.
     *
     * @return Current LocalDateTime
     */
    public static LocalDateTime now() {
        return LocalDateTime.now();
    }
}
