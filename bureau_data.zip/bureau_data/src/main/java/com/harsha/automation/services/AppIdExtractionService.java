package com.harsha.automation.services;

import com.fasterxml.jackson.databind.JsonNode;
import com.harsha.automation.enums.Category;
import com.harsha.automation.exceptions.DataExtractionException;
import com.harsha.automation.models.ApplicationData;
import com.harsha.automation.utils.ExcelUtils;
import com.harsha.automation.utils.FileUtils;
import com.harsha.automation.utils.JsonUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Service class for extracting APP IDs from JSON and TXT files.
 */
public class AppIdExtractionService {
    private static final Logger logger = LogManager.getLogger(AppIdExtractionService.class);
    private final FileService fileService;

    public AppIdExtractionService() {
        this.fileService = new FileService();
    }

    /**
     * Extracts APP IDs from both PRE and POST folders and generates comparison Excel.
     *
     * @param preFolderPath  PRE folder path
     * @param postFolderPath POST folder path
     * @param outputFolder   Output folder for Excel file
     * @return Path to generated Excel file
     */
    public String compareAndExtractAppIds(String preFolderPath, String postFolderPath, String outputFolder) {
        logger.info("Comparing APP IDs between PRE and POST folders");

        // Extract APP IDs from both folders
        Map<String, String> preAppIds = extractAppIdsFromFolder(preFolderPath);
        Map<String, String> postAppIds = extractAppIdsFromFolder(postFolderPath);

        // Get all unique file names
        Set<String> allFileNames = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        allFileNames.addAll(preAppIds.keySet());
        allFileNames.addAll(postAppIds.keySet());

        // Create output directory
        fileService.createDirectory(outputFolder);

        // Build ApplicationData list
        List<ApplicationData> applications = new ArrayList<>();

        for (String fileName : allFileNames) {
            String preAppId = preAppIds.getOrDefault(fileName, "");
            String postAppId = postAppIds.getOrDefault(fileName, "");

            ApplicationData appData = ApplicationData.builder()
                    .fileName(fileName)
                    .preAppId(preAppId)
                    .postAppId(postAppId)
                    .buildWithCategoryDetection();

            applications.add(appData);
        }

        // Write to Excel
        String excelPath = outputFolder + File.separator + "APPIDComparison_ALL.xlsx";
        ExcelUtils.writeComparisonData(applications, excelPath);

        logger.info("APP ID comparison Excel created: {}", excelPath);
        logger.info("Total files compared: {}", applications.size());

        return excelPath;
    }

    /**
     * Extracts APP IDs from all JSON and TXT files in a folder.
     *
     * @param folderPath Folder path
     * @return Map of fileName -> appId
     */
    public Map<String, String> extractAppIdsFromFolder(String folderPath) {
        logger.info("Extracting APP IDs from folder: {}", folderPath);

        Map<String, String> appIds = new HashMap<>();

        if (!fileService.directoryExists(folderPath)) {
            logger.warn("Folder not found: {}", folderPath);
            return appIds;
        }

        File folder = new File(folderPath);
        File[] files = folder.listFiles();

        if (files == null || files.length == 0) {
            logger.warn("No files found in folder: {}", folderPath);
            return appIds;
        }

        for (File file : files) {
            if (file == null || !file.isFile()) {
                continue;
            }

            String fileName = file.getName();
            String extension = FileUtils.getFileExtension(fileName);

            if ("json".equalsIgnoreCase(extension)) {
                String appId = extractAppIdFromJson(file);
                appIds.put(fileName, appId);
            } else if ("txt".equalsIgnoreCase(extension)) {
                String appId = extractAppIdFromTxt(file);
                appIds.put(fileName, appId);
            }
        }

        logger.info("Extracted {} APP IDs from folder", appIds.size());
        return appIds;
    }

    /**
     * Extracts APP ID from JSON file.
     *
     * @param file JSON file
     * @return APP ID or empty string
     */
    private String extractAppIdFromJson(File file) {
        try {
            JsonNode root = JsonUtils.readJsonFile(file);
            String appId = JsonUtils.findAppId(root);
            logger.debug("Extracted APP ID from {}: {}", file.getName(), appId);
            return appId;
        } catch (Exception e) {
            logger.warn("Failed to extract APP ID from JSON {}: {}", file.getName(), e.getMessage());
            return "";
        }
    }

    /**
     * Extracts APP ID from TXT file.
     *
     * @param file TXT file
     * @return APP ID or empty string
     */
    private String extractAppIdFromTxt(File file) {
        try {
            String fileName = file.getName();

            // Try extracting from file name first
            String appId = extractAppIdFromFileName(fileName);
            if (!appId.isEmpty()) {
                logger.debug("Extracted APP ID from filename {}: {}", fileName, appId);
                return appId;
            }

            // Try extracting from file content
            String content = fileService.readFile(file.getAbsolutePath());
            appId = extractAppIdFromContent(content);
            logger.debug("Extracted APP ID from content of {}: {}", fileName, appId);
            return appId;

        } catch (Exception e) {
            logger.warn("Failed to extract APP ID from TXT {}: {}", file.getName(), e.getMessage());
            return "";
        }
    }

    /**
     * Extracts APP ID from file name pattern.
     *
     * @param fileName File name
     * @return APP ID or empty string
     */
    private String extractAppIdFromFileName(String fileName) {
        Pattern pattern = Pattern.compile("_(PRE|POST)_(\\d+)\\.txt$");
        Matcher matcher = pattern.matcher(fileName);
        if (matcher.find()) {
            return matcher.group(2);
        }
        return "";
    }

    /**
     * Extracts APP ID from file content.
     *
     * @param content File content
     * @return APP ID or empty string
     */
    private String extractAppIdFromContent(String content) {
        Pattern pattern = Pattern.compile("Application ID:\\s*(\\d+)");
        Matcher matcher = pattern.matcher(content);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return "";
    }
}
