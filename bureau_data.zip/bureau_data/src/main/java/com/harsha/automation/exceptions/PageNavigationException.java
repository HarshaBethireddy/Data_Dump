package com.harsha.automation.exceptions;

/**
 * Custom exception for page navigation-related errors.
 * Thrown when there are issues navigating between pages or interacting with page elements.
 */
public class PageNavigationException extends RuntimeException {

    /**
     * Constructs a new PageNavigationException with the specified detail message.
     *
     * @param message The detail message
     */
    public PageNavigationException(String message) {
        super(message);
    }

    /**
     * Constructs a new PageNavigationException with the specified detail message and cause.
     *
     * @param message The detail message
     * @param cause   The cause of the exception
     */
    public PageNavigationException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new PageNavigationException with the specified cause.
     *
     * @param cause The cause of the exception
     */
    public PageNavigationException(Throwable cause) {
        super(cause);
    }
}
