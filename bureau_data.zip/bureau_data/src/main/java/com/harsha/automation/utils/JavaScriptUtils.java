package com.harsha.automation.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Utility class for JavaScript operations in Selenium.
 */
public class JavaScriptUtils {
    private static final Logger logger = LogManager.getLogger(JavaScriptUtils.class);

    /**
     * Private constructor to prevent instantiation.
     */
    private JavaScriptUtils() {
    }

    /**
     * Executes JavaScript code.
     *
     * @param driver WebDriver instance
     * @param script JavaScript code to execute
     * @param args   Arguments for the script
     * @return Result of script execution
     */
    public static Object executeScript(WebDriver driver, String script, Object... args) {
        logger.debug("Executing JavaScript: {}", script);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        return js.executeScript(script, args);
    }

    /**
     * Clicks an element using JavaScript.
     *
     * @param driver  WebDriver instance
     * @param element Element to click
     */
    public static void clickElement(WebDriver driver, WebElement element) {
        logger.debug("Clicking element using JavaScript");
        executeScript(driver, "arguments[0].click();", element);
    }

    /**
     * Scrolls to element using JavaScript.
     *
     * @param driver  WebDriver instance
     * @param element Element to scroll to
     */
    public static void scrollToElement(WebDriver driver, WebElement element) {
        logger.debug("Scrolling to element using JavaScript");
        executeScript(driver, "arguments[0].scrollIntoView({block:'center'});", element);
    }

    /**
     * Scrolls to element with smooth behavior.
     *
     * @param driver  WebDriver instance
     * @param element Element to scroll to
     */
    public static void scrollToElementSmooth(WebDriver driver, WebElement element) {
        logger.debug("Scrolling to element smoothly using JavaScript");
        executeScript(driver, "arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", element);
    }

    /**
     * Scrolls page to bottom.
     *
     * @param driver WebDriver instance
     */
    public static void scrollToBottom(WebDriver driver) {
        logger.debug("Scrolling to bottom of page");
        executeScript(driver, "window.scrollTo(0, document.body.scrollHeight);");
    }

    /**
     * Scrolls page to top.
     *
     * @param driver WebDriver instance
     */
    public static void scrollToTop(WebDriver driver) {
        logger.debug("Scrolling to top of page");
        executeScript(driver, "window.scrollTo(0, 0);");
    }

    /**
     * Scrolls by specified pixels.
     *
     * @param driver WebDriver instance
     * @param x      Horizontal scroll amount
     * @param y      Vertical scroll amount
     */
    public static void scrollBy(WebDriver driver, int x, int y) {
        logger.debug("Scrolling by x: {}, y: {}", x, y);
        executeScript(driver, "window.scrollBy(arguments[0], arguments[1]);", x, y);
    }

    /**
     * Highlights an element for debugging.
     *
     * @param driver  WebDriver instance
     * @param element Element to highlight
     */
    public static void highlightElement(WebDriver driver, WebElement element) {
        logger.debug("Highlighting element");
        String originalStyle = element.getAttribute("style");
        executeScript(driver, "arguments[0].setAttribute('style', arguments[1]);", element,
                "border: 3px solid red; background: yellow;");
        WaitUtils.hardWaitMillis(500);
        executeScript(driver, "arguments[0].setAttribute('style', arguments[1]);", element, originalStyle);
    }

    /**
     * Sets value of input field using JavaScript.
     *
     * @param driver  WebDriver instance
     * @param element Input element
     * @param value   Value to set
     */
    public static void setValue(WebDriver driver, WebElement element, String value) {
        logger.debug("Setting value using JavaScript: {}", value);
        executeScript(driver, "arguments[0].value=arguments[1];", element, value);
    }

    /**
     * Gets inner text of element using JavaScript.
     *
     * @param driver  WebDriver instance
     * @param element Element to get text from
     * @return Inner text
     */
    public static String getInnerText(WebDriver driver, WebElement element) {
        logger.debug("Getting inner text using JavaScript");
        return (String) executeScript(driver, "return arguments[0].innerText;", element);
    }

    /**
     * Checks if element is visible using JavaScript.
     *
     * @param driver  WebDriver instance
     * @param element Element to check
     * @return true if visible, false otherwise
     */
    public static boolean isElementVisible(WebDriver driver, WebElement element) {
        logger.debug("Checking element visibility using JavaScript");
        String script = "const elem = arguments[0];" +
                "if (!elem) return false;" +
                "const style = getComputedStyle(elem);" +
                "if (style.display === 'none' || style.visibility === 'hidden' || +style.opacity === 0) return false;" +
                "const rect = elem.getBoundingClientRect();" +
                "return rect.width > 0 && rect.height > 0;";
        return (Boolean) executeScript(driver, script, element);
    }

    /**
     * Removes attribute from element.
     *
     * @param driver    WebDriver instance
     * @param element   Element to modify
     * @param attribute Attribute to remove
     */
    public static void removeAttribute(WebDriver driver, WebElement element, String attribute) {
        logger.debug("Removing attribute '{}' using JavaScript", attribute);
        executeScript(driver, "arguments[0].removeAttribute(arguments[1]);", element, attribute);
    }

    /**
     * Sets attribute value for element.
     *
     * @param driver    WebDriver instance
     * @param element   Element to modify
     * @param attribute Attribute name
     * @param value     Attribute value
     */
    public static void setAttribute(WebDriver driver, WebElement element, String attribute, String value) {
        logger.debug("Setting attribute '{}' to '{}' using JavaScript", attribute, value);
        executeScript(driver, "arguments[0].setAttribute(arguments[1], arguments[2]);", element, attribute, value);
    }

    /**
     * Gets page title using JavaScript.
     *
     * @param driver WebDriver instance
     * @return Page title
     */
    public static String getPageTitle(WebDriver driver) {
        logger.debug("Getting page title using JavaScript");
        return (String) executeScript(driver, "return document.title;");
    }

    /**
     * Refreshes page using JavaScript.
     *
     * @param driver WebDriver instance
     */
    public static void refreshPage(WebDriver driver) {
        logger.debug("Refreshing page using JavaScript");
        executeScript(driver, "location.reload();");
    }

    /**
     * Opens new tab using JavaScript.
     *
     * @param driver WebDriver instance
     * @param url    URL to open in new tab
     */
    public static void openNewTab(WebDriver driver, String url) {
        logger.debug("Opening new tab with URL: {}", url);
        executeScript(driver, "window.open(arguments[0], '_blank');", url);
    }

    /**
     * Checks if page is fully loaded.
     *
     * @param driver WebDriver instance
     * @return true if page is fully loaded, false otherwise
     */
    public static boolean isPageLoaded(WebDriver driver) {
        logger.debug("Checking if page is loaded");
        String state = (String) executeScript(driver, "return document.readyState;");
        return "complete".equals(state);
    }

    /**
     * Waits for page to be fully loaded.
     *
     * @param driver WebDriver instance
     */
    public static void waitForPageLoad(WebDriver driver) {
        logger.debug("Waiting for page to load");
        WaitUtils.waitForCondition(driver,
                d -> executeScript(d, "return document.readyState;").equals("complete"),
                java.time.Duration.ofSeconds(30));
    }

    /**
     * Expands all jsTree nodes using JavaScript.
     *
     * @param driver WebDriver instance
     * @return true if successful, false otherwise
     */
    public static boolean expandAllJsTreeNodes(WebDriver driver) {
        logger.debug("Expanding all jsTree nodes using JavaScript");
        String script =
                "try {" +
                "  if (window.$ && $('.jstree').length && $('.jstree').jstree) {" +
                "    var inst = $('.jstree').jstree(true) || $('.jstree').jstree(); " +
                "    if (inst && inst.open_all) { inst.open_all(); return true; }" +
                "  }" +
                "} catch(e) {}" +
                "return false;";
        Object result = executeScript(driver, script);
        return Boolean.TRUE.equals(result);
    }
}
