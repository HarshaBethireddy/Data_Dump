package com.harsha.automation.core.listeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.harsha.automation.config.TestConfiguration;
import com.harsha.automation.core.driver.DriverManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * ExtentReports Listener for generating HTML test reports.
 * Implements TestNG ITestListener for report generation.
 */
public class ExtentReportListener implements ITestListener {
    private static final Logger logger = LogManager.getLogger(ExtentReportListener.class);
    private static ExtentReports extentReports;
    private static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();
    private TestConfiguration config;

    /**
     * Initializes ExtentReports.
     */
    private synchronized void initializeExtentReports() {
        if (extentReports == null) {
            config = new TestConfiguration();

            String reportPath = config.getExtentReportPath();
            logger.info("Initializing ExtentReports at: {}", reportPath);

            ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);

            // Configure Spark Reporter
            sparkReporter.config().setTheme(Theme.DARK);
            sparkReporter.config().setDocumentTitle(config.getExtentReportName());
            sparkReporter.config().setReportName("Bureau Comparison Test Execution Report");
            sparkReporter.config().setTimeStampFormat("MMM dd, yyyy HH:mm:ss");

            // Initialize ExtentReports
            extentReports = new ExtentReports();
            extentReports.attachReporter(sparkReporter);

            // Set system information
            extentReports.setSystemInfo("Application", "Bureau Comparison Automation");
            extentReports.setSystemInfo("Environment", "QA");
            extentReports.setSystemInfo("Browser", config.getBrowserType().name());
            extentReports.setSystemInfo("OS", System.getProperty("os.name"));
            extentReports.setSystemInfo("Java Version", System.getProperty("java.version"));
            extentReports.setSystemInfo("User", System.getProperty("user.name"));

            logger.info("ExtentReports initialized successfully");
        }
    }

    @Override
    public void onStart(ITestContext context) {
        logger.info("Test Suite Started: {}", context.getName());
        initializeExtentReports();
    }

    @Override
    public void onFinish(ITestContext context) {
        logger.info("Test Suite Finished: {}", context.getName());
        if (extentReports != null) {
            extentReports.flush();
            logger.info("ExtentReports flushed successfully");
        }
    }

    @Override
    public void onTestStart(ITestResult result) {
        logger.info("Test Started: {}", result.getMethod().getMethodName());

        ExtentTest test = extentReports.createTest(
                result.getMethod().getMethodName(),
                result.getMethod().getDescription()
        );

        // Add categories/tags
        if (result.getMethod().getGroups() != null && result.getMethod().getGroups().length > 0) {
            for (String group : result.getMethod().getGroups()) {
                test.assignCategory(group);
            }
        }

        extentTest.set(test);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        logger.info("Test Passed: {}", result.getMethod().getMethodName());

        ExtentTest test = extentTest.get();
        test.log(Status.PASS, MarkupHelper.createLabel(
                "Test Passed: " + result.getMethod().getMethodName(),
                ExtentColor.GREEN
        ));

        long executionTime = result.getEndMillis() - result.getStartMillis();
        test.info("Execution Time: " + executionTime + " ms");

        // Capture screenshot on success if configured
        if (config != null && config.isCaptureScreenshotOnSuccess()) {
            captureScreenshot(test);
        }
    }

    @Override
    public void onTestFailure(ITestResult result) {
        logger.error("Test Failed: {}", result.getMethod().getMethodName());

        ExtentTest test = extentTest.get();
        test.log(Status.FAIL, MarkupHelper.createLabel(
                "Test Failed: " + result.getMethod().getMethodName(),
                ExtentColor.RED
        ));

        // Log failure reason
        if (result.getThrowable() != null) {
            test.fail(result.getThrowable());
        }

        long executionTime = result.getEndMillis() - result.getStartMillis();
        test.info("Execution Time: " + executionTime + " ms");

        // Capture screenshot on failure
        captureScreenshot(test);
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        logger.warn("Test Skipped: {}", result.getMethod().getMethodName());

        ExtentTest test = extentTest.get();
        test.log(Status.SKIP, MarkupHelper.createLabel(
                "Test Skipped: " + result.getMethod().getMethodName(),
                ExtentColor.ORANGE
        ));

        if (result.getThrowable() != null) {
            test.skip(result.getThrowable());
        }
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        logger.warn("Test Failed but within success percentage: {}",
                result.getMethod().getMethodName());
    }

    /**
     * Captures screenshot and attaches to ExtentReport.
     *
     * @param test ExtentTest instance
     */
    private void captureScreenshot(ExtentTest test) {
        try {
            DriverManager driverManager = DriverManager.getInstance();
            if (!driverManager.hasDriver()) {
                logger.warn("No WebDriver available for screenshot");
                return;
            }

            WebDriver driver = driverManager.getDriver();
            TakesScreenshot screenshot = (TakesScreenshot) driver;
            String base64Screenshot = screenshot.getScreenshotAs(OutputType.BASE64);

            test.addScreenCaptureFromBase64String(base64Screenshot,
                    "Screenshot at " + LocalDateTime.now().format(
                            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
                    ));

            logger.debug("Screenshot attached to ExtentReport");

        } catch (Exception e) {
            logger.error("Failed to capture screenshot for ExtentReport: {}", e.getMessage());
        }
    }

    /**
     * Gets the current ExtentTest instance.
     *
     * @return ExtentTest instance
     */
    public static ExtentTest getTest() {
        return extentTest.get();
    }

    /**
     * Logs info message to ExtentReport.
     *
     * @param message Message to log
     */
    public static void logInfo(String message) {
        if (extentTest.get() != null) {
            extentTest.get().info(message);
        }
    }

    /**
     * Logs pass message to ExtentReport.
     *
     * @param message Message to log
     */
    public static void logPass(String message) {
        if (extentTest.get() != null) {
            extentTest.get().pass(message);
        }
    }

    /**
     * Logs fail message to ExtentReport.
     *
     * @param message Message to log
     */
    public static void logFail(String message) {
        if (extentTest.get() != null) {
            extentTest.get().fail(message);
        }
    }

    /**
     * Logs warning message to ExtentReport.
     *
     * @param message Message to log
     */
    public static void logWarning(String message) {
        if (extentTest.get() != null) {
            extentTest.get().warning(message);
        }
    }
}
