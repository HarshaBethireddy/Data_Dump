package com.harsha.automation.runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;

/**
 * Cucumber Test Runner for TestNG integration.
 * Configures Cucumber options and integrates with TestNG for parallel execution.
 */
@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"com.harsha.automation.stepdefinitions"},
        plugin = {
                "pretty",
                "html:reports/cucumber-reports/cucumber-html-report.html",
                "json:reports/cucumber-reports/cucumber.json",
                "junit:reports/cucumber-reports/cucumber.xml"
        },
        monochrome = true,
        tags = "@smoke or @regression",
        dryRun = false,
        snippets = CucumberOptions.SnippetType.CAMELCASE
)
public class TestRunner extends AbstractTestNGCucumberTests {

    /**
     * Enables parallel execution of scenarios.
     * Override scenarios method to enable parallel execution.
     *
     * @return Test data for parallel execution
     */
    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }
}
