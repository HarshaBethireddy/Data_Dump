package com.harsha.automation.stepdefinitions;

import com.harsha.automation.core.driver.DriverManager;
import com.harsha.automation.enums.ExtractionType;
import com.harsha.automation.models.ApplicationData;
import com.harsha.automation.pages.DataViewerPage;
import com.harsha.automation.services.AppIdExtractionService;
import com.harsha.automation.services.BureauDataExtractionService;
import com.harsha.automation.services.FileService;
import com.harsha.automation.utils.DateTimeUtils;
import com.harsha.automation.utils.ExcelUtils;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.io.File;
import java.util.List;

/**
 * Step definitions for data extraction scenarios.
 */
public class DataExtractionSteps {
    private DriverManager driverManager;
    private WebDriver driver;
    private FileService fileService;
    private AppIdExtractionService appIdExtractionService;
    private BureauDataExtractionService bureauDataExtractionService;
    private String outputFolder;

    public DataExtractionSteps() {
        this.driverManager = DriverManager.getInstance();
        this.driver = driverManager.getDriver();
        this.fileService = new FileService();
        this.appIdExtractionService = new AppIdExtractionService();
        this.bureauDataExtractionService = new BureauDataExtractionService();
    }

    @Given("PRE folder is {string}")
    public void preFolderIs(String preFolderName) {
        String preFolderPath = driverManager.getConfig().getBasePrefolder() + preFolderName;
        TestContext.getInstance().setPreFolderPath(preFolderPath);
    }

    @Given("POST folder is {string}")
    public void postFolderIs(String postFolderName) {
        String postFolderPath = driverManager.getConfig().getBasePostFolder() + postFolderName;
        TestContext.getInstance().setPostFolderPath(postFolderPath);
    }

    @Given("the user has application ID {string}")
    public void theUserHasApplicationID(String appId) {
        TestContext.getInstance().setApplicationId(appId);
    }

    @Given("the user has an Excel file with application data")
    public void theUserHasAnExcelFileWithApplicationData() {
        String excelPath = TestContext.getInstance().getExcelFilePath();
        Assert.assertNotNull(excelPath, "Excel file path not set");
        Assert.assertTrue(fileService.fileExists(excelPath), "Excel file does not exist");
    }

    @Given("PRE data file exists for application {string}")
    public void preDataFileExistsForApplication(String appId) {
        String preFilePath = generateFilePath("PRE", appId);
        TestContext.getInstance().setPreDataFilePath(preFilePath);
        // Note: In real scenario, file should exist. For testing, we assume it's set correctly
    }

    @Given("POST data file exists for application {string}")
    public void postDataFileExistsForApplication(String appId) {
        String postFilePath = generateFilePath("POST", appId);
        TestContext.getInstance().setPostDataFilePath(postFilePath);
        // Note: In real scenario, file should exist. For testing, we assume it's set correctly
    }

    @When("the user extracts APP IDs from both folders")
    public void theUserExtractsAppIDsFromBothFolders() {
        String preFolderPath = TestContext.getInstance().getPreFolderPath();
        String postFolderPath = TestContext.getInstance().getPostFolderPath();

        // Create output folder with timestamp
        outputFolder = driverManager.getConfig().getBaseOutputDirectory() +
                      File.separator + "comparison_" + DateTimeUtils.getCurrentTimestampForRunDir();

        String excelPath = appIdExtractionService.compareAndExtractAppIds(
                preFolderPath, postFolderPath, outputFolder);

        TestContext.getInstance().setExcelFilePath(excelPath);
        TestContext.getInstance().setOutputFolder(outputFolder);
    }

    @When("the user processes applications using {int} parallel threads")
    public void theUserProcessesApplicationsUsingParallelThreads(int threadCount) {
        String excelPath = TestContext.getInstance().getExcelFilePath();
        List<ApplicationData> applications = ExcelUtils.readApplicationData(excelPath);

        TestContext.getInstance().setApplicationList(applications);
        TestContext.getInstance().setThreadCount(threadCount);

        // Note: Actual parallel processing would be done in the test class
        // This step just validates the setup
        Assert.assertTrue(applications.size() > 0, "No applications found to process");
    }

    @When("the user executes the complete comparison workflow")
    public void theUserExecutesTheCompleteComparisonWorkflow() {
        // This is a high-level step that combines multiple operations
        theUserExtractsAppIDsFromBothFolders();

        String excelPath = TestContext.getInstance().getExcelFilePath();
        List<ApplicationData> applications = ExcelUtils.readApplicationData(excelPath);
        TestContext.getInstance().setApplicationList(applications);

        // Set flag that workflow was executed
        TestContext.getInstance().setWorkflowExecuted(true);
    }

    @Then("bureau data should be extracted successfully")
    public void bureauDataShouldBeExtractedSuccessfully() {
        String appId = TestContext.getInstance().getApplicationId();
        String outputPath = generateOutputPath(appId, ExtractionType.PRE);

        DataViewerPage dataViewerPage = new DataViewerPage(driver);
        boolean success = dataViewerPage.extractBureauData(appId, outputPath, ExtractionType.PRE);

        Assert.assertTrue(success, "Bureau data extraction failed");
        TestContext.getInstance().setExtractionSuccessful(true);
    }

    @Then("the extracted data should be saved to file")
    public void theExtractedDataShouldBeSavedToFile() {
        String appId = TestContext.getInstance().getApplicationId();
        String outputPath = generateOutputPath(appId, ExtractionType.PRE);

        // Verify file was created (in real test, file would exist after extraction)
        // For step validation, we check the path is set
        Assert.assertNotNull(outputPath, "Output path not set");
        Assert.assertTrue(outputPath.endsWith(".txt"), "Output path should be a .txt file");
    }

    @Then("an Excel comparison file should be generated")
    public void anExcelComparisonFileShouldBeGenerated() {
        String excelPath = TestContext.getInstance().getExcelFilePath();
        Assert.assertNotNull(excelPath, "Excel file path not set");
        Assert.assertTrue(excelPath.endsWith(".xlsx"), "Excel file should have .xlsx extension");
    }

    @Then("the Excel file should contain all application data")
    public void theExcelFileShouldContainAllApplicationData() {
        String excelPath = TestContext.getInstance().getExcelFilePath();

        // Verify Excel file is valid
        boolean isValid = ExcelUtils.isExcelFileValid(excelPath);
        Assert.assertTrue(isValid, "Excel file is not valid");

        // Verify it has data
        int rowCount = ExcelUtils.getRowCount(excelPath);
        Assert.assertTrue(rowCount > 0, "Excel file has no data rows");
    }

    @Then("bureau data should be extracted for all applications")
    public void bureauDataShouldBeExtractedForAllApplications() {
        List<ApplicationData> applications = TestContext.getInstance().getApplicationList();
        Assert.assertNotNull(applications, "Application list not set");
        Assert.assertTrue(applications.size() > 0, "No applications to process");

        // In real scenario, this would verify all files were created
        // For step validation, we check the list is populated
        for (ApplicationData app : applications) {
            Assert.assertTrue(app.isValid(), "Invalid application data: " + app.getFileName());
        }
    }

    @Then("the test should continue with next application")
    public void theTestShouldContinueWithNextApplication() {
        // Verify error was handled and test can continue
        Exception lastException = TestContext.getInstance().getLastException();
        Assert.assertNotNull(lastException, "No exception was captured");

        // Clear exception to continue
        TestContext.getInstance().setLastException(null);
    }

    /**
     * Helper method to generate file path.
     *
     * @param type  PRE or POST
     * @param appId Application ID
     * @return File path
     */
    private String generateFilePath(String type, String appId) {
        String outputFolder = TestContext.getInstance().getOutputFolder();
        if (outputFolder == null) {
            outputFolder = driverManager.getConfig().getBaseOutputDirectory();
        }
        return outputFolder + File.separator + "test_" + type + "_" + appId + ".txt";
    }

    /**
     * Helper method to generate output path.
     *
     * @param appId Application ID
     * @param type  Extraction type
     * @return Output path
     */
    private String generateOutputPath(String appId, ExtractionType type) {
        String outputFolder = TestContext.getInstance().getOutputFolder();
        if (outputFolder == null) {
            outputFolder = driverManager.getConfig().getBaseOutputDirectory();
        }
        return outputFolder + File.separator + "extracted_" + type.getTypeName() + "_" + appId + ".txt";
    }
}
