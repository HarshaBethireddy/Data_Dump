package com.harsha.automation.stepdefinitions;

import com.harsha.automation.core.driver.DriverManager;
import com.harsha.automation.enums.Category;
import com.harsha.automation.pages.ApplicationDetailsPage;
import com.harsha.automation.pages.DataViewerPage;
import com.harsha.automation.pages.SearchPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

/**
 * Step definitions for navigation-related scenarios.
 */
public class NavigationSteps {
    private DriverManager driverManager;
    private WebDriver driver;
    private SearchPage searchPage;
    private ApplicationDetailsPage applicationDetailsPage;
    private DataViewerPage dataViewerPage;

    public NavigationSteps() {
        this.driverManager = DriverManager.getInstance();
        this.driver = driverManager.getDriver();
    }

    @Given("the user navigates to {string} category")
    public void theUserNavigatesToCategory(String categoryName) {
        if (searchPage == null) {
            searchPage = new SearchPage(driver);
        }

        Category category = Category.fromString(categoryName);
        searchPage = searchPage.navigateToCategory(category);
        Assert.assertTrue(searchPage.isLoaded(), "Failed to navigate to " + categoryName + " category");
    }

    @Then("the search screen should be displayed")
    public void theSearchScreenShouldBeDisplayed() {
        Assert.assertTrue(searchPage.isLoaded(), "Search screen is not displayed");
        Assert.assertTrue(searchPage.isSearchButtonEnabled(), "Search button is not enabled");
    }

    @When("the user searches for the application")
    public void theUserSearchesForTheApplication() {
        String appId = TestContext.getInstance().getApplicationId();
        applicationDetailsPage = searchPage.searchApplication(appId);
    }

    @When("the user searches for non-existent application {string}")
    public void theUserSearchesForNonExistentApplication(String appId) {
        try {
            searchPage.searchApplication(appId);
        } catch (Exception e) {
            TestContext.getInstance().setLastException(e);
        }
    }

    @When("the user opens the application details")
    public void theUserOpensTheApplicationDetails() {
        applicationDetailsPage = applicationDetailsPage.openApplication();
        Assert.assertTrue(applicationDetailsPage.isViewBureauButtonDisplayed(),
                         "View Bureau button not displayed");
    }

    @When("the user views the bureau data")
    public void theUserViewsTheBureauData() {
        dataViewerPage = applicationDetailsPage.viewBureauData();
        Assert.assertTrue(dataViewerPage.isLoaded(), "Bureau data viewer not loaded");
    }

    @Then("an appropriate error should be handled")
    public void anAppropriateErrorShouldBeHandled() {
        Exception lastException = TestContext.getInstance().getLastException();
        Assert.assertNotNull(lastException, "Expected an exception but none was thrown");
    }
}
