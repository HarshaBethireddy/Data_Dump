package com.harsha.automation.stepdefinitions;

import com.harsha.automation.models.ApplicationData;
import com.harsha.automation.models.ComparisonResult;
import lombok.Data;

import java.util.List;

/**
 * Singleton context class to share state between Cucumber step definitions.
 * Thread-safe implementation for parallel test execution.
 */
@Data
public class TestContext {
    private static final ThreadLocal<TestContext> instance = ThreadLocal.withInitial(TestContext::new);

    // Folder paths
    private String preFolderPath;
    private String postFolderPath;
    private String outputFolder;

    // File paths
    private String excelFilePath;
    private String preDataFilePath;
    private String postDataFilePath;
    private String masterReportPath;

    // Application data
    private String applicationId;
    private List<ApplicationData> applicationList;

    // Comparison results
    private ComparisonResult comparisonResult;
    private List<ComparisonResult> comparisonResults;

    // Execution flags
    private boolean extractionSuccessful;
    private boolean workflowExecuted;
    private int threadCount;

    // Exception handling
    private Exception lastException;

    /**
     * Private constructor for singleton pattern.
     */
    private TestContext() {
        // Initialize with default values
        this.extractionSuccessful = false;
        this.workflowExecuted = false;
        this.threadCount = 1;
    }

    /**
     * Gets the singleton instance for current thread.
     *
     * @return TestContext instance
     */
    public static TestContext getInstance() {
        return instance.get();
    }

    /**
     * Clears the context for current thread.
     * Should be called after each scenario.
     */
    public static void clear() {
        instance.remove();
    }

    /**
     * Resets all values to defaults.
     */
    public void reset() {
        this.preFolderPath = null;
        this.postFolderPath = null;
        this.outputFolder = null;
        this.excelFilePath = null;
        this.preDataFilePath = null;
        this.postDataFilePath = null;
        this.masterReportPath = null;
        this.applicationId = null;
        this.applicationList = null;
        this.comparisonResult = null;
        this.comparisonResults = null;
        this.extractionSuccessful = false;
        this.workflowExecuted = false;
        this.threadCount = 1;
        this.lastException = null;
    }
}
