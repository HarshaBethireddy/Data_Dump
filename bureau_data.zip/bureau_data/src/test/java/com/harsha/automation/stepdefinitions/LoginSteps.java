package com.harsha.automation.stepdefinitions;

import com.harsha.automation.config.TestConfiguration;
import com.harsha.automation.core.driver.DriverManager;
import com.harsha.automation.pages.GroupSelectionPage;
import com.harsha.automation.pages.LoginPage;
import com.harsha.automation.pages.SearchPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

/**
 * Step definitions for login-related scenarios.
 */
public class LoginSteps {
    private DriverManager driverManager;
    private TestConfiguration config;
    private WebDriver driver;
    private LoginPage loginPage;
    private GroupSelectionPage groupSelectionPage;
    private SearchPage searchPage;

    public LoginSteps() {
        this.driverManager = DriverManager.getInstance();
        this.config = driverManager.getConfig();
        this.driver = driverManager.getDriver();
    }

    @Given("the user is on the login page")
    public void theUserIsOnTheLoginPage() {
        driverManager.navigateToBaseUrl();
        loginPage = new LoginPage(driver);
        Assert.assertTrue(loginPage.isLoaded(), "Login page not loaded");
    }

    @When("the user logs in with valid credentials")
    public void theUserLogsInWithValidCredentials() {
        groupSelectionPage = loginPage.login(config.getUsername(), config.getPassword());
    }

    @When("the user selects {string} group")
    public void theUserSelectsGroup(String groupName) {
        searchPage = groupSelectionPage.selectGroup(groupName);
    }

    @Then("the user should see the main menu")
    public void theUserShouldSeeTheMainMenu() {
        Assert.assertTrue(searchPage.isLoaded(), "Search page not loaded after group selection");
    }
}
