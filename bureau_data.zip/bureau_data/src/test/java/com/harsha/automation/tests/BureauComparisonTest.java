package com.harsha.automation.tests;

import com.harsha.automation.config.TestConfiguration;
import com.harsha.automation.core.base.BaseTest;
import com.harsha.automation.enums.Category;
import com.harsha.automation.models.ApplicationData;
import com.harsha.automation.models.ComparisonResult;
import com.harsha.automation.pages.*;
import com.harsha.automation.services.*;
import com.harsha.automation.utils.DateTimeUtils;
import com.harsha.automation.utils.ExcelUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Main test class for Bureau Data Comparison automation.
 * Extends BaseTest for WebDriver management and configuration.
 */
public class BureauComparisonTest extends BaseTest {

    private AppIdExtractionService appIdExtractionService;
    private BureauDataExtractionService bureauDataExtractionService;
    private ComparisonService comparisonService;
    private ReportGenerationService reportGenerationService;
    private FileService fileService;

    /**
     * Setup method initializes services.
     */
    @Override
    public void setUp() {
        super.setUp();
        this.appIdExtractionService = new AppIdExtractionService();
        this.bureauDataExtractionService = new BureauDataExtractionService();
        this.comparisonService = new ComparisonService();
        this.reportGenerationService = new ReportGenerationService();
        this.fileService = new FileService();
    }

    /**
     * Test: Complete end-to-end bureau comparison workflow.
     * This is the main test that replicates the original functionality.
     */
    @Test(priority = 1, groups = {"smoke", "regression"}, description = "End-to-end bureau comparison")
    public void testCompleteWorkflow() {
        logInfo("Starting complete bureau comparison workflow");

        // Step 1: Get folder names from user (simulated via config for automated testing)
        String preFolderName = "PRE_TEST_DATA"; // In real scenario, this would be user input
        String postFolderName = "POST_TEST_DATA";

        String preFolderPath = config.getBasePrefolder() + preFolderName;
        String postFolderPath = config.getBasePostFolder() + postFolderName;

        // Step 2: Compare APP IDs and generate Excel
        String outputFolder = config.getBaseOutputDirectory() + File.separator +
                            "comparison_" + DateTimeUtils.getCurrentTimestampForRunDir();

        String excelFilePath = appIdExtractionService.compareAndExtractAppIds(
                preFolderPath, postFolderPath, outputFolder);

        Assert.assertNotNull(excelFilePath, "Excel file not generated");
        logInfo("Excel comparison file created: " + excelFilePath);

        // Step 3: Read Excel and extract bureau data for all applications
        List<ApplicationData> applications = ExcelUtils.readApplicationData(excelFilePath);
        Assert.assertTrue(applications.size() > 0, "No applications found in Excel");

        logInfo("Total applications to process: " + applications.size());

        // Step 4: Process applications by category in parallel
        Map<String, List<ApplicationData>> categoryGroups = applications.stream()
                .collect(Collectors.groupingBy(app -> app.getCategory().getCategoryName()));

        logInfo("Categories found: " + categoryGroups.keySet());

        List<ComparisonResult> allResults = processAllCategories(categoryGroups, outputFolder);

        // Step 5: Generate master report
        String masterReportPath = outputFolder + File.separator + "MASTER_comparison_report.txt";
        reportGenerationService.generateMasterReport(allResults, masterReportPath);

        logInfo("Master report generated: " + masterReportPath);
        logInfo("Workflow completed successfully");
    }

    /**
     * Test: Login functionality.
     */
    @Test(priority = 0, groups = {"smoke"}, description = "Verify login functionality")
    public void testLogin() {
        logInfo("Testing login functionality");

        LoginPage loginPage = new LoginPage(driver);
        Assert.assertTrue(loginPage.isLoaded(), "Login page not loaded");

        GroupSelectionPage groupSelectionPage = loginPage.login(
                config.getUsername(), config.getPassword());

        SearchPage searchPage = groupSelectionPage.selectGroup(config.getAdminGroup());
        Assert.assertTrue(searchPage.isLoaded(), "Search page not loaded after login");

        logInfo("Login test passed");
    }

    /**
     * Test: Navigation to all categories.
     */
    @Test(priority = 2, groups = {"smoke"}, description = "Verify navigation to all categories")
    public void testCategoryNavigation() {
        logInfo("Testing category navigation");

        // Login first
        performLogin();

        SearchPage searchPage = new SearchPage(driver);

        // Test navigation to each category
        for (Category category : new Category[]{Category.ACQ, Category.CLI, Category.PRQ}) {
            logInfo("Navigating to category: " + category.getCategoryName());
            searchPage = searchPage.navigateToCategory(category);
            Assert.assertTrue(searchPage.isLoaded(),
                           "Search page not loaded for category: " + category.getCategoryName());
        }

        logInfo("Category navigation test passed");
    }

    /**
     * Processes all categories and returns combined results.
     *
     * @param categoryGroups Map of category to applications
     * @param baseOutputFolder Base output folder
     * @return List of all comparison results
     */
    private List<ComparisonResult> processAllCategories(
            Map<String, List<ApplicationData>> categoryGroups, String baseOutputFolder) {

        List<ComparisonResult> allResults = new ArrayList<>();
        ExecutorService executorService = Executors.newFixedThreadPool(config.getBrowserInstances());
        List<Future<List<ComparisonResult>>> futures = new ArrayList<>();

        try {
            for (Map.Entry<String, List<ApplicationData>> entry : categoryGroups.entrySet()) {
                String categoryName = entry.getKey();
                List<ApplicationData> categoryApps = entry.getValue();

                Future<List<ComparisonResult>> future = executorService.submit(() ->
                        processCategoryApplications(categoryName, categoryApps, baseOutputFolder));

                futures.add(future);
            }

            // Collect results from all futures
            for (Future<List<ComparisonResult>> future : futures) {
                try {
                    List<ComparisonResult> categoryResults = future.get(30, TimeUnit.MINUTES);
                    allResults.addAll(categoryResults);
                } catch (Exception e) {
                    logError("Error processing category: " + e.getMessage());
                }
            }

        } finally {
            executorService.shutdown();
            try {
                if (!executorService.awaitTermination(60, TimeUnit.SECONDS)) {
                    executorService.shutdownNow();
                }
            } catch (InterruptedException e) {
                executorService.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }

        return allResults;
    }

    /**
     * Processes applications for a specific category.
     *
     * @param categoryName Category name
     * @param applications List of applications
     * @param baseOutputFolder Base output folder
     * @return List of comparison results
     */
    private List<ComparisonResult> processCategoryApplications(
            String categoryName, List<ApplicationData> applications, String baseOutputFolder) {

        List<ComparisonResult> results = new ArrayList<>();
        WebDriver categoryDriver = null;

        try {
            logInfo("Processing category: " + categoryName + " with " + applications.size() + " applications");

            // FIXED: Create new WebDriver for this thread to ensure thread safety in parallel execution
            DriverManager categoryDriverManager = DriverManager.getInstance();
            categoryDriverManager.createDriver();
            categoryDriver = categoryDriverManager.getDriver();

            // Create category output folder
            String categoryOutputFolder = baseOutputFolder + File.separator + categoryName;
            fileService.createDirectory(categoryOutputFolder);

            // Login and navigate using the thread-specific driver
            performLoginWithDriver(categoryDriver);
            SearchPage searchPage = new SearchPage(categoryDriver);
            Category category = Category.fromString(categoryName);
            searchPage = searchPage.navigateToCategory(category);

            // Process each application
            for (ApplicationData app : applications) {
                logInfo("Processing application: " + app.getFileName());

                boolean success = bureauDataExtractionService.extractBureauDataForApplication(
                        categoryDriver, app, categoryOutputFolder, searchPage);

                if (success) {
                    // Compare files
                    String preFilePath = categoryOutputFolder + File.separator +
                                       app.getFileName() + "_PRE_" + app.getPreAppId() + ".txt";
                    String postFilePath = categoryOutputFolder + File.separator +
                                        app.getFileName() + "_POST_" + app.getPostAppId() + ".txt";

                    ComparisonResult result = comparisonService.compareFiles(
                            preFilePath, postFilePath, app);
                    results.add(result);
                }

                // Get fresh search page instance for next application
                searchPage = new SearchPage(categoryDriver);
            }

            // Generate category report
            String categoryReportPath = categoryOutputFolder + File.separator + "comparison_report.txt";
            reportGenerationService.generateComparisonReport(results, categoryReportPath, categoryName);

            logInfo("Completed category: " + categoryName);

        } catch (Exception e) {
            logError("Error processing category " + categoryName + ": " + e.getMessage());
        } finally {
            // FIXED: Clean up thread-specific driver after processing
            if (categoryDriver != null) {
                try {
                    DriverManager.getInstance().quitDriver();
                    logInfo("Driver cleaned up for category: " + categoryName);
                } catch (Exception e) {
                    logError("Error cleaning up driver for category " + categoryName + ": " + e.getMessage());
                }
            }
        }

        return results;
    }

    /**
     * Performs login and group selection.
     */
    private void performLogin() {
        navigateToBaseUrl();

        LoginPage loginPage = new LoginPage(driver);
        GroupSelectionPage groupSelectionPage = loginPage.login(
                config.getUsername(), config.getPassword());
        groupSelectionPage.selectGroup(config.getAdminGroup());
    }

    /**
     * Performs login and group selection with a specific WebDriver instance.
     * ADDED: This method supports parallel execution by accepting a thread-specific driver.
     *
     * @param webDriver Thread-specific WebDriver instance
     */
    private void performLoginWithDriver(WebDriver webDriver) {
        webDriver.get(config.getBaseUrl());

        LoginPage loginPage = new LoginPage(webDriver);
        GroupSelectionPage groupSelectionPage = loginPage.login(
                config.getUsername(), config.getPassword());
        groupSelectionPage.selectGroup(config.getAdminGroup());
    }
}
